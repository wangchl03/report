"""Whether historical order/offer ratios >103% coincide with recorded amount-increase coupon use."""

from core import *


def run():
    l = pd.read_parquet(PRIVATE / "loans_clean.parquet")
    c = pd.read_parquet(PRIVATE / "all_issue_histories.parquet")
    for k in ["serial_id", "user_id", "type", "real_use_amount"]:
        c[k] = pd.to_numeric(c[k], errors="coerce")
    used = c[c.type.eq(4) & c.real_use_amount.gt(0) & c.serial_id.notna()]
    keys = set(map(tuple, used[["user_id", "serial_id"]].drop_duplicates().to_numpy()))
    z = l[l.funded & l.utilization.notna()].copy()
    z["recorded_amount_coupon_use"] = [
        (u, s) in keys
        for u, s in z[["user_id", "serial_id"]].itertuples(index=False, name=None)
    ]
    z["ratio_band"] = pd.cut(
        z.utilization,
        [0, 0.97, 1.0300001, 1.2, 1.5, 2, np.inf],
        labels=["<97%", "≈100%", ">103—120%", ">120—150%", ">150—200%", ">200%"],
        right=False,
    ).astype(str)
    out = []
    for (period, band), g in z.assign(
        period=np.where(
            z.apply_time.ge(pd.Timestamp("2026-05-01")), "券历史覆盖期内", "券历史覆盖期前"
        )
    ).groupby(["period", "ratio_band"]):
        out.append(
            {
                "period": period,
                "ratio_band": band,
                "funded_orders": len(g),
                "recorded_amount_coupon_used_orders": int(g.recorded_amount_coupon_use.sum()),
                "mean_ratio": float(g.utilization.mean()),
                "ratio_median": float(g.utilization.median()),
                "apply_remit_median": float((g.apply_amt / g.remit_amt).median()),
            }
        )
    dump(W / "overquota_context_results.json", out)
    mark("overquota_context_complete", funded_orders=len(z))


if __name__ == "__main__":
    run()
