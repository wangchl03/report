"""Fill semantic 20%-coupon coverage and left-censored activity history; no false zeros."""

from core import *
import importlib.util

spec = importlib.util.spec_from_file_location("_behavior_extract", W / "06_behavior_sources.py")
# Read only the definitions without executing extraction-side effects.
import ast

module = ast.parse((W / "06_behavior_sources.py").read_text())
nodes = []
for node in module.body:
    if isinstance(node, ast.Assign) and any(
        isinstance(t, ast.Name) and t.id in ["new_flags", "legacy_flags"] for t in node.targets
    ):
        nodes.append(node)
    if isinstance(node, ast.FunctionDef) and node.name == "make_sql":
        nodes.append(node)
ns = {}
exec(compile(ast.Module(body=nodes, type_ignores=[]), "behavior_definitions", "exec"), ns)
target = pd.read_parquet(PRIVATE / "target_coupon_issues.parquet")
rec = pd.read_parquet(PRIVATE / "recall_batch_features.parquet")
oldusers = set(json.loads((PRIVATE / "behavior_user_ids.json").read_text()))
users = sorted(
    set(map(int, target[target.coupon_id.isin([119, 124, 153, 157, 160, 163, 164])].user_id))
    | set(map(int, rec.churn_user_id))
)
extra = sorted(set(users) - oldusers)
mark("behavior_supplement_start", existing_users=len(oldusers), extra_users=len(extra))
c = connect()
try:
    with c.cursor() as q:
        q.execute("SET application_name='coupon_response_behavior_supplement'")
        q.execute("SET statement_timeout=1800000")
    for source in ["new", "legacy"]:
        if extra:
            f = query_large(
                c,
                ns["make_sql"](source),
                {"start": "2026-05-18", "end": "2026-11-04", "users": extra},
                "behavior_" + source + "_additional_20pct_id153",
            )
            base = PRIVATE / f"behavior_{source}_daily.parquet"
            while not base.exists():
                time.sleep(5)
            old = pd.read_parquet(base)
            old = old[~old.user_id.isin(extra)]
            z = pd.concat([old, f], ignore_index=True)
            assert not z.duplicated(["user_id", "d"]).any()
            tmp = base.with_suffix(".partial")
            z.to_parquet(tmp, index=False, compression="zstd")
            tmp.replace(base)
        clock = "event_time" if source == "new" else "create_time"
        day = "event_date" if source == "new" else "create_date"
        table = "user_behavior_track_record" if source == "new" else "event_track_record"
        sql = f"""SELECT user_id,MIN({clock}) AS first_active_time,MAX({clock}) AS last_active_time,
   COUNT(DISTINCT {day}) AS active_days,COUNT(*) AS logs
   FROM wangchuanliang.{table}
   WHERE {day}>=DATE '2025-11-01' AND {day}<DATE '2026-05-18'
     AND {clock}>=TIMESTAMP '2025-11-01' AND {clock}<TIMESTAMP '2026-05-18'
     AND user_id IN(SELECT unnest(%(users)s::bigint[])) GROUP BY user_id"""
        query_large(c, sql, {"users": users}, "behavior_" + source + "_prestart_history")
finally:
    c.rollback()
    c.close()
dump(PRIVATE / "behavior_user_ids.json", users)
dump(
    W / "behavior_supplement_complete.json",
    {
        "users": len(users),
        "extra_users": len(extra),
        "history_start": "2025-11-01",
        "main_daily_start": "2026-05-18",
    },
)
mark("behavior_supplement_complete", users=len(users), extra_users=len(extra))
