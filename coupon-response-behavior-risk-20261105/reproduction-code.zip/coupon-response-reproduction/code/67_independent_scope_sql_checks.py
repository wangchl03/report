"""Independently check labels and financial totals with SQL over immutable source snapshots.
No live database state is substituted for the original financial snapshot.
"""

from core import *
import sqlite3


def sqlite_frame(c, name, f):
    f = f.copy()
    for col in f:
        if pd.api.types.is_datetime64_any_dtype(f[col]):
            f[col] = f[col].map(lambda x: None if pd.isna(x) else str(x))
    f.to_sql(name, c, index=False, if_exists="replace", chunksize=10000)


def run():
    c = sqlite3.connect(":memory:")
    out = {
        "passed": False,
        "source": "Independent SQL executed over frozen source Parquets; no live financial refresh.",
        "ab_labels": [],
        "financial_groups": [],
        "mismatches": [],
    }
    H = W / "historical_validation/private"
    a = pd.read_parquet(PRIVATE / "expanded_ab_analysis.parquet")
    raw = pd.read_parquet(H / "loan_histories.parquet")
    for col in [
        "user_id",
        "serial_id",
        "is_remit",
        "remit_amt",
        "repaid_amt",
        "loan_status_code",
    ]:
        raw[col] = pd.to_numeric(raw[col], errors="coerce")
    for col in ["apply_time", "remit_time", "due_date"]:
        raw[col] = pd.to_datetime(raw[col], errors="coerce", format="mixed")
    raw = raw.drop_duplicates()
    assert not raw.duplicated(["user_id", "serial_id"]).any()
    sqlite_frame(c, "anchors", a[["episode_id", "study", "ab_group", "user_id", "anchor"]])
    sqlite_frame(
        c,
        "loans",
        raw[
            [
                "user_id",
                "serial_id",
                "apply_time",
                "remit_time",
                "is_remit",
                "remit_amt",
                "repaid_amt",
                "due_date",
                "loan_status_code",
            ]
        ],
    )
    c.execute("CREATE INDEX loans_user_time ON loans(user_id,apply_time,serial_id)")
    sql = """WITH candidates AS (
 SELECT a.*,o.serial_id,o.apply_time,o.is_remit,o.remit_time,o.remit_amt,o.repaid_amt,o.due_date,o.loan_status_code,
 ROW_NUMBER() OVER (PARTITION BY a.episode_id ORDER BY o.apply_time,o.serial_id) AS rn
 FROM anchors a JOIN loans o ON o.user_id=a.user_id AND o.apply_time>=a.anchor AND o.apply_time<'2026-11-04'
 ), first_order AS (SELECT * FROM candidates WHERE rn=1)
 SELECT a.study,a.ab_group,COUNT(*) AS events,
 SUM(CASE WHEN julianday(o.apply_time)-julianday(a.anchor)<3 THEN 1 ELSE 0 END) AS y_3,
 SUM(CASE WHEN julianday(o.apply_time)-julianday(a.anchor)<7 THEN 1 ELSE 0 END) AS y_7,
 SUM(CASE WHEN julianday(o.apply_time)-julianday(a.anchor)<15 THEN 1 ELSE 0 END) AS y_15,
 SUM(CASE WHEN julianday(o.apply_time)-julianday(a.anchor)<30 THEN 1 ELSE 0 END) AS y_30
 FROM anchors a LEFT JOIN first_order o ON a.episode_id=o.episode_id GROUP BY a.study,a.ab_group ORDER BY a.study,a.ab_group"""
    q = pd.read_sql_query(sql, c)
    e = json.loads((W / "expanded_policy_results.json").read_text())
    for r in q.to_dict("records"):
        ref = next(
            v for v in e["ab_rates"] if v["study"] == r["study"] and v["arm"] == r["ab_group"]
        )
        for k in ["events", "y_3", "y_7", "y_15", "y_30"]:
            if int(r[k]) != int(ref[k]):
                out["mismatches"].append(
                    {"part": "ab_labels", "study": r["study"], "arm": r["ab_group"], "field": k}
                )
        out["ab_labels"].append(
            {
                "study": r["study"],
                "arm": r["ab_group"],
                "events": r["events"],
                "labels_match": all(
                    int(r[k]) == int(ref[k]) for k in ["events", "y_3", "y_7", "y_15", "y_30"]
                ),
            }
        )
    u = pd.read_parquet(PRIVATE / "used_target_orders.parquet")
    l = pd.read_parquet(PRIVATE / "loan_histories.parquet")
    for fr in [u, l]:
        for col in [
            "user_id",
            "serial_id",
            "coupon_id",
            "valid_days",
            "is_remit",
            "remit_amt",
            "repaid_amt",
            "real_use_amount",
            "loan_status_code",
        ]:
            if col in fr:
                fr[col] = pd.to_numeric(fr[col], errors="coerce")
        for col in ["create_date", "due_date"]:
            if col in fr:
                fr[col] = pd.to_datetime(fr[col], errors="coerce", format="mixed")
    assert not u.duplicated(["user_id", "serial_id"]).any()
    l = l.drop_duplicates()
    assert not l.duplicated(["user_id", "serial_id"]).any()
    sqlite_frame(
        c,
        "coupon_uses",
        u[
            [
                "user_id",
                "serial_id",
                "coupon_id",
                "valid_days",
                "create_date",
                "real_use_amount",
            ]
        ],
    )
    sqlite_frame(
        c,
        "whole_loans",
        l[
            [
                "user_id",
                "serial_id",
                "is_remit",
                "remit_amt",
                "repaid_amt",
                "due_date",
                "loan_status_code",
            ]
        ],
    )
    c.execute("CREATE INDEX whole_key ON whole_loans(user_id,serial_id)")
    sql = """SELECT CASE WHEN c.coupon_id IN(119,141,153,163,166) THEN .2 WHEN c.coupon_id IN(157,160) THEN .3 ELSE .4 END AS dose,
 c.valid_days,COUNT(*) AS orders,SUM(o.remit_amt) AS funded_amt,SUM(o.repaid_amt) AS repaid_amt,
 SUM(CASE WHEN o.loan_status_code=8 THEN 1 ELSE 0 END) AS overdue_orders,SUM(c.real_use_amount) AS coupon_used_amt
 FROM coupon_uses c JOIN whole_loans o ON o.user_id=c.user_id AND o.serial_id=c.serial_id
 WHERE c.create_date>='2026-06-15' AND c.create_date<'2026-10-31'
 AND o.is_remit=1 AND o.remit_amt>0 AND o.due_date<'2026-11-04' AND o.repaid_amt IS NOT NULL
 GROUP BY 1,c.valid_days ORDER BY 1,c.valid_days"""
    q = pd.read_sql_query(sql, c)
    fin = json.loads((W / "financial_results.json").read_text())["broad_mature"]
    for r in q.to_dict("records"):
        ref = next(
            v for v in fin if v["dose"] == r["dose"] and v["valid_days"] == r["valid_days"]
        )
        dif = {}
        for k in ["orders", "funded_amt", "repaid_amt", "overdue_orders", "coupon_used_amt"]:
            dif[k] = abs(float(r[k]) - float(ref[k]))
            if dif[k] > 1e-6:
                out["mismatches"].append(
                    {
                        "part": "finance",
                        "dose": r["dose"],
                        "valid_days": r["valid_days"],
                        "field": k,
                        "difference": dif[k],
                    }
                )
        out["financial_groups"].append(
            {
                "dose": r["dose"],
                "valid_days": r["valid_days"],
                "orders": r["orders"],
                "max_absolute_difference": max(dif.values()),
            }
        )
    c.close()
    out["passed"] = not out["mismatches"]
    dump(W / "expanded_independent_sql_checks.json", out)
    assert out["passed"], out
    mark(
        "expanded_independent_sql_verified",
        ab_groups=len(out["ab_labels"]),
        financial_groups=len(out["financial_groups"]),
        mismatches=0,
    )


if __name__ == "__main__":
    run()
