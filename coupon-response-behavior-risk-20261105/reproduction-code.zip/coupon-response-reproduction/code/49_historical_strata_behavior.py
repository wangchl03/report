"""Historical assigned-arm replication, pre-issue balance, and first-response timing."""

from core import *
from stats_utils import *
import importlib.util

spec = importlib.util.spec_from_file_location("_ha", W / "48_historical_ab_validation.py")
ha = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ha)
HP = W / "historical_validation" / "private"


def run():
    f = pd.read_parquet(HP / "historical_validated.parquet")
    f["anchor"] = pd.to_datetime(f.anchor)
    f = (
        f[f.qualified]
        .sort_values(["anchor", "episode_id"])
        .drop_duplicates(["study", "user_id", "latest_credit_serial"])
        .copy()
    )
    f["dose"] = f.treat
    features = [
        "score410",
        "score363",
        "score405",
        "prior_fund_n",
        "churn_days",
        "mean_funded_utilization",
        "hist_offer_d7_rate90",
        "latest_credit_amt",
        "pre7_new_active_days",
        "pre7_new_loan_entry_days",
    ]
    out = {
        "balance": [],
        "strata": [],
        "strata_comparisons": [],
        "first_response_windows": [],
        "daily_behavior": [],
        "followup_coupon": [],
    }
    for name, g in f.groupby("study"):
        for col in features:
            a = g[g.treat.eq(0)][col]
            b = g[g.treat.eq(1)][col]
            out["balance"].append(
                {
                    "study": name,
                    "feature": col,
                    "control_known": int(a.notna().sum()),
                    "treatment_known": int(b.notna().sum()),
                    "control_mean": float(a.mean()),
                    "treatment_mean": float(b.mean()),
                    "smd": smd(b, a),
                    "control_missing_share": float(a.isna().mean()),
                    "treatment_missing_share": float(b.isna().mean()),
                }
            )
        for label, lo, hi in [
            ("D0—D2", 0, 3),
            ("D3—D6", 3, 7),
            ("D7—D14", 7, 15),
            ("D15—D29", 15, 30),
        ]:
            z = g.copy()
            z["y"] = z[f"applied_{hi}"] - (z[f"applied_{lo}"] if lo else 0)
            r = cluster_comparison(z, "y", groups=(0, 1), B=2000)
            if r:
                out["first_response_windows"].append({"study": name, "period": label, **r})
        for h in [3, 7, 15, 30]:
            for arm, gg in g.groupby("ab_group"):
                out["followup_coupon"].append(
                    {
                        "study": name,
                        "arm": arm,
                        "window": h,
                        "events": len(gg),
                        "next_coupon_events": int(gg.next_coupon_day.lt(h).sum()),
                        "repeat_share": float(gg.next_coupon_day.lt(h).mean()),
                    }
                )
        if name == "T7_July08_high_discount":
            dims = {"原名单额度使用层": g.interest_type.fillna("unknown")}
        elif name == "T7_July08_utilization_policy":
            dims = {"原名单额度使用层": g.utilization_type.fillna("unknown")}
        else:
            dims = {
                "发券前7天提单页": g.pre7_new_loan_entry_days.gt(0).map(
                    {True: "有", False: "无"}
                )
            }
        dims["重建额度使用率"] = (
            g.mean_funded_utilization.lt(0.8)
            .map({True: "<80%", False: "≥80%"})
            .where(g.mean_funded_utilization.notna(), "缺失")
        )
        dims["流失天数"] = g.churn_days.ge(91).map({True: "≥91天", False: "<91天"})
        dims["近期提单页"] = g.pre7_new_loan_entry_days.gt(0).map({True: "有", False: "无"})
        for dim, levels in dims.items():
            zz = g.assign(level=levels)
            for (lev, arm), gg in zz.groupby(["level", "ab_group"]):
                row = {
                    "study": name,
                    "dimension": dim,
                    "level": lev,
                    "arm": arm,
                    "events": len(gg),
                }
                for h in [3, 7, 15, 30]:
                    row.update(
                        {
                            f"y_{h}": int(gg[f"applied_{h}"].sum()),
                            f"rate_{h}": float(gg[f"applied_{h}"].mean()),
                        }
                    )
                out["strata"].append(row)
            for lev, gg in zz.groupby("level"):
                for h in [3, 7, 30]:
                    r = cluster_comparison(gg, f"applied_{h}", groups=(0, 1), B=1500)
                    if r:
                        out["strata_comparisons"].append(
                            {"study": name, "dimension": dim, "level": lev, "window": h, **r}
                        )
    daily = {}
    for source in ["new", "legacy"]:
        z = pd.read_parquet(HP / f"behavior_{source}_daily.parquet")
        z["d"] = pd.to_datetime(z.d)
        daily[source] = z.set_index(["user_id", "d"])
    for name, g in f.groupby("study"):
        for rd in range(-7, 30):
            key = pd.MultiIndex.from_arrays(
                [g.user_id, (g.anchor + pd.Timedelta(days=rd))], names=["user_id", "d"]
            )
            for source in ["new", "legacy"]:
                for metric, field in [("active", "logs"), ("loan_entry", "loan_entry_n")]:
                    v = (
                        pd.to_numeric(daily[source][field].reindex(key), errors="coerce")
                        .fillna(0)
                        .gt(0)
                        .to_numpy(float)
                    )
                    for t in [0, 1]:
                        ix = g.treat.eq(t).to_numpy()
                        out["daily_behavior"].append(
                            {
                                "study": name,
                                "day": rd,
                                "arm": "treatment" if t else "control",
                                "metric": source + "_" + metric,
                                "events": int(ix.sum()),
                                "rate": float(v[ix].mean()),
                            }
                        )
    dump(W / "historical_strata_behavior_results.json", out)
    review(
        "9-historical-replication",
        [
            "Historical A/B-marked tables are available, but T5 tests target clean-settlement day5, not the current T7 population.",
            "July8 T7 policies are bundles: some comparisons change both discount and amount-increase coupons; they do not isolate a single coupon dose.",
            "The two 30%-3day versus no-coupon T5 rounds differ in early response; actual issuance and pre-issue eligibility are explicitly rechecked.",
        ],
        [
            "Keep historical replications separate from current T7 first-offer comparisons and label assignment provenance limits.",
            "Use first applications and whole-mature cash profit consistently rather than copying old mixed-window or installment-quality numbers.",
        ],
        [
            "Historical randomization mechanism has no retained allocation log; policy bundles and later issuance constrain causal interpretation."
        ],
    )
    mark("historical_strata_behavior_complete", studies=f.study.nunique(), events=len(f))


if __name__ == "__main__":
    run()
