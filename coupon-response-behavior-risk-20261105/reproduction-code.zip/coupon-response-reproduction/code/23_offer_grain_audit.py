"""The user's approved non-recycle1 credit-order denominator, with first contact per order."""

from analysis_contract import *
from stats_utils import *


def run():
    f = pd.read_parquet(PRIVATE / "episode_analysis.parquet")
    f["anchor"] = pd.to_datetime(f.anchor)
    f, co = cohorts_with_offer_grain(f)
    out = {
        "contract": {
            "history_rate_denominator": "Unique user+serial_id passed credit orders, recycle_type known and !=1; own-order application after the credit timestamp.",
            "response_order_denominator": "One qualified latest credit order per user; its earliest eligible T7 recall/coupon contact in the frozen study anchors, selected before future outcomes.",
            "response_numerator": "At least one user application in D0 through D(n-1) after the selected contact; approval/funding not required.",
            "all_contact_sensitivity": "Repeated contacts on different days retained only in a separately labelled contact-event analysis.",
            "same_day_clock_limitation": "Coupon issue dates have no send timestamp; as-of baseline is before 00:00, and D0 may include behavior preceding actual delivery.",
        },
        "rates": [],
        "by_batch": [],
        "grain_difference": [],
        "subgroups": [],
        "availability": [],
        "contrasts": [],
    }
    for name in [
        "main_offer_all",
        "main_offer_simple",
        "extension_offer_all",
        "extension_offer_simple",
    ]:
        z = f[co[name]]
        assert not z.duplicated(["user_id", "latest_credit_serial"]).any()
        for dose, g in z.groupby("dose"):
            out["rates"].append(rm.summarize(g, {"cohort": name, "dose": dose}))
        for (batch, dose), g in z.groupby(["recall_batches", "dose"]):
            if name.startswith("main"):
                out["by_batch"].append(
                    rm.summarize(g, {"cohort": name, "batch": batch, "dose": dose})
                )
        for dim, series in {
            "churn": pd.cut(
                z.churn_days,
                [7, 14, 30, 60, 90, 180, np.inf],
                labels=["8—14天", "15—30天", "31—60天", "61—90天", "91—180天", "181天及以上"],
            ),
            "loanpage": z.pre7_loan_entry_days.gt(0).map(
                {True: "近7天已见提单页", False: "近7天未见提单页"}
            ),
            "active14": z.pre14_active_days.gt(0).map(
                {True: "近14天有活跃", False: "近14天未见活跃"}
            ),
            "risk410": pd.cut(
                z.score410,
                [-np.inf, 450, 500, 528, np.inf],
                labels=["<450", "450—499", "500—527", "≥528"],
                right=False,
            )
            .astype(str)
            .where(z.score410.notna(), "缺失"),
            "demand": pd.Series(
                np.select(
                    [
                        z.hist_offer_d7_n90.lt(3)
                        | z.hist_offer_d7_rate90.isna()
                        | z.mean_funded_utilization.isna(),
                        z.hist_offer_d7_rate90.le(0.2) & z.mean_funded_utilization.lt(0.8),
                        z.hist_offer_d7_rate90.le(0.2) & z.mean_funded_utilization.ge(0.8),
                        z.hist_offer_d7_rate90.gt(0.2) & z.mean_funded_utilization.lt(0.8),
                    ],
                    ["历史不足", "低提单＋低使用", "低提单＋高使用", "高提单＋低使用"],
                    default="高提单＋高使用",
                ),
                index=z.index,
            ),
        }.items():
            zz = z.assign(level=series)
            for (lev, dose), g in zz.groupby(["level", "dose"], observed=True):
                out["subgroups"].append(
                    rm.summarize(
                        g, {"cohort": name, "dimension": dim, "level": str(lev), "dose": dose}
                    )
                )
        for d in [3, 7, 15, 30]:
            for pair in [(0.0, 0.2), (0.2, 0.3), (0.2, 0.4), (0.3, 0.4)]:
                r = cluster_comparison(z, f"applied_{d}", groups=pair, B=2000)
                if r:
                    out["contrasts"].append({"cohort": name, "window": d, **r})
        out["availability"].append(
            {
                "cohort": name,
                "events": len(z),
                "behavior_user_unqueried": int(z.behavior_user_extracted.ne(1).sum()),
                "no_behavior_in_available_history": int(
                    z.no_record_in_available_history.eq(1).sum()
                ),
                "score410_missing": int(z.score410.isna().sum()),
                "score363_missing": int(z.score363.isna().sum()),
                "score405_missing": int(z.score405.isna().sum()),
            }
        )
    for base, new in [
        ("main_all_strategy", "main_offer_all"),
        ("main_simple", "main_offer_simple"),
        ("extension_simple", "extension_offer_simple"),
    ]:
        a = f[co[base]]
        b = f[co[new]]
        out["grain_difference"].append(
            {
                "contacts": base,
                "orders": new,
                "contact_n": len(a),
                "unique_credit_orders_within_contacts": a[["user_id", "latest_credit_serial"]]
                .drop_duplicates()
                .shape[0],
                "first_eligible_all_strategy_then_simple_n": len(b),
            }
        )
    dump(W / "offer_grain_results.json", out)
    f[["episode_id", "user_id", "latest_credit_serial"]].assign(
        **{
            k: v.astype("int8")
            for k, v in co.items()
            if k.endswith("_simple") or k.endswith("_all")
        }
    ).to_parquet(PRIVATE / "analysis_grain_flags.parquet", index=False, compression="zstd")
    review(
        "5-denominator",
        [
            "Repeated coupon contacts can reuse the same latest passed credit order; contact events and credit orders are different denominators.",
            "14.41% of the D15 mature main contact cohort has churn 8–14 days; its two-week behavior baseline can include pre-settlement behavior.",
        ],
        [
            "Add a primary credit-order analysis: first eligible T7 contact per qualified latest user+serial, before looking at future applications.",
            "Retain multi-contact rates separately, use one-week weekday baseline for all T7, and two-week baseline only with stable post-settlement churn>=15.",
        ],
        [
            "Observational coupon allocation, unknown exact send time, and later coupons still limit causal attribution."
        ],
    )
    mark("offer_grain_complete", rates=len(out["rates"]))


if __name__ == "__main__":
    run()
