from pathlib import Path
from datetime import datetime, date, timezone
import os, sys, json, time, hashlib, warnings
import numpy as np
import pandas as pd

W = Path(__file__).resolve().parent
ROOT = W.parent
PRIVATE = Path(os.environ.get("RECALL_PRIVATE_DIR", W / "private"))
PRIVATE.mkdir(parents=True, exist_ok=True)
SQLDIR = W / "sql"
SQLDIR.mkdir(exist_ok=True)


def _exclusions():
    p = os.environ.get("RECALL_EXCLUSION_FILE")
    if not p:
        raise RuntimeError(
            "取数前请设置 RECALL_EXCLUSION_FILE，指向同一份内部用户排除名单。公开包不含用户标识。"
        )
    values = json.loads(Path(p).read_text())
    if isinstance(values, dict):
        values = values.get(
            "user_ids", values.get("excluded_user_ids", values.get("blacklisted_user_ids", []))
        )
    ids = [int(v) for v in values]
    if not ids:
        raise RuntimeError("内部排除名单为空；请核对后再取数。")
    return ids


def excluded_user_ids():
    return _exclusions()


def connect():
    import psycopg2

    c = psycopg2.connect(os.environ["DATABASE_URL"], connect_timeout=20)
    c.set_session(readonly=True, isolation_level="REPEATABLE READ", autocommit=False)
    with c.cursor() as q:
        q.execute("SET TIME ZONE 'America/Belize'")
        q.execute("SET work_mem='64MB'")
        q.execute("SET statement_timeout=1800000")
    return c


def _bound(params):
    return {**params, "__excluded_user_ids": _exclusions()}


def bound_params(params):
    return _bound(params)


def fetch(c, sql, params, name):
    # A JSON value per cursor row preserves embedded newlines. No local helper,
    # secret store, PGP transport or workstation-specific vendor path is required.
    text_sql = "SELECT row_to_json(q)::text FROM (" + sql.rstrip(";\n ") + ") q"
    data = []
    with c.cursor(name="repro_" + str(time.time_ns())) as q:
        q.execute(text_sql, _bound(params))
        while True:
            rows = q.fetchmany(10000)
            if not rows:
                break
            data.extend(repair_json(row[0]) for row in rows)
    return pd.DataFrame(data, dtype=object)


def query(c, sql, params, name, refresh=False):
    target = PRIVATE / (name + ".parquet")
    (SQLDIR / (name + ".sql")).write_text(sql.rstrip(";\n ") + ";\n")
    if target.exists() and not refresh:
        return pd.read_parquet(target)
    f = parquet_safe(fetch(c, sql, params, name))
    f.to_parquet(target, index=False, compression="zstd")
    mark(name, rows=len(f), sha256=hashlib.sha256(target.read_bytes()).hexdigest())
    return f


def query_large(c, sql, params, name, buckets=96):
    # The buckets parameter is retained for API compatibility. A bounded server
    # cursor replaces only the original transport layer, not SQL or calculations.
    return query(c, sql, params, name)


import re


def repair_json(s):
    pat = r'("(?:[^"\\]|\\.)*")|(?P<lead>[:\[,]\s*)(?P<sign>-?)\.(?P<digit>\d)'
    return json.loads(
        re.sub(
            pat,
            lambda m: (
                m.group(0)
                if m.group(1)
                else m.group("lead") + m.group("sign") + "0." + m.group("digit")
            ),
            s,
        ),
        strict=False,
    )


def clean(x):
    if isinstance(x, dict):
        return {str(k): clean(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [clean(v) for v in x]
    if isinstance(x, np.ndarray):
        return clean(x.tolist())
    if isinstance(x, np.generic):
        return clean(x.item())
    if isinstance(x, (date, datetime)):
        return x.isoformat()
    if isinstance(x, float) and not np.isfinite(x):
        return None
    return x


def dump(path, x):
    Path(path).write_text(
        json.dumps(clean(x), ensure_ascii=False, indent=2, default=str, allow_nan=False)
    )


def mark(stage, **x):
    d = {"stage": stage, "at_utc": datetime.now(timezone.utc).isoformat(), **x}
    with (W / "progress.jsonl").open("a") as f:
        f.write(json.dumps(clean(d), ensure_ascii=False, default=str) + "\n")
    print(json.dumps(clean(d), ensure_ascii=False, default=str), flush=True)


def parquet_safe(f):
    f = f.copy()
    for col in f.columns:
        if f[col].dtype == object:
            vals = f[col].dropna()
            kinds = {type(v).__name__ for v in vals}
            if len(kinds) > 1 and any(k in kinds for k in ("str", "date", "datetime")):
                f[col] = f[col].map(lambda v: None if pd.isna(v) else str(v))
    return f


def review(round_id, findings, decisions, unresolved):
    path = W / "iteration_reviews.json"
    prior = json.loads(path.read_text()) if path.exists() else []
    prior.append(
        {
            "round": round_id,
            "at_utc": datetime.now(timezone.utc).isoformat(),
            "findings": findings,
            "decisions": decisions,
            "unresolved": unresolved,
        }
    )
    dump(path, prior)
    mark(
        "review_" + str(round_id), findings=findings, decisions=decisions, unresolved=unresolved
    )


def apply_eligibility_contract(f):
    """Credit eligibility follows the user's pass/non-recycle1 condition; prior use is a feature, not an exclusion."""
    f = f.copy()
    f["eligible_offer"] = f.latest_credit_qualified.eq(1).astype("int8")
    known = f.unknown_settle_n.eq(0) & f.history_conflict_user.eq(0)
    f["history_state_known"] = known.astype("int8")
    f["t7_no_open"] = (f.t7_no_open.eq(1) & known).astype("int8")
    f["strict_t7"] = (f.strict_t7.eq(1) & known).astype("int8")
    f["first_contact_for_offer"] = 0
    q = f[
        f.eligible_offer.eq(1)
        & pd.to_datetime(f.anchor).ge(pd.Timestamp("2026-06-15"))
        & pd.to_datetime(f.anchor).lt(pd.Timestamp("2026-10-31"))
    ].sort_values(["anchor", "episode_id"])
    f.loc[
        q.drop_duplicates(["user_id", "latest_credit_serial"]).index, "first_contact_for_offer"
    ] = 1
    f["primary_offer_denom"] = f.eligible_offer.eq(1)
    credit_day = (
        pd.to_datetime(f.latest_credit_s, unit="s", errors="coerce", utc=True)
        .dt.tz_convert("America/Belize")
        .dt.tz_localize(None)
        .dt.normalize()
    )
    f["latest_credit_age_days"] = (pd.to_datetime(f.anchor) - credit_day).dt.days
    f["positive_credit_amount"] = f.latest_credit_amt.gt(0).astype("int8")
    for n in [30, 90, 180]:
        complete = pd.to_datetime(f.anchor) - pd.Timedelta(days=n + 6) >= pd.Timestamp(
            "2025-01-01"
        )
        f[f"hist_offer_d7_complete{n}"] = complete.astype("int8")
        for col in [f"hist_offer_d7_rate{n}", f"hist_offer_d7_n{n}", f"hist_offer_d7_y{n}"]:
            if col in f:
                f.loc[~complete, col] = np.nan
    if "first_apply_s" in f and "next_coupon_day" in f:
        app_day = (
            pd.to_datetime(f.first_apply_s, unit="s", errors="coerce", utc=True)
            .dt.tz_convert("America/Belize")
            .dt.tz_localize(None)
            .dt.normalize()
        )
        app_delta = (app_day - pd.to_datetime(f.anchor)).dt.days
        f["next_preapplication_coupon_day"] = f.next_coupon_day.where(
            app_delta.isna() | f.next_coupon_day.lt(app_delta)
        )
        f["next_coupon_same_application_day"] = (
            f.next_coupon_day.eq(app_delta) & app_delta.notna()
        ).astype("int8")
    return f


BATCHES = [
    "t7recalllist_active0918",
    "t7recalllist_active1010",
    "t7recalllist_active1016",
    "t7recalllist_active1023",
    "t7recalllist_active1030",
    "t7recalllist_0930",
    "t7recalllist_1010",
    "t7recalllist_1016",
    "t7recalllist_1023",
    "t7recalllist_1030",
]
