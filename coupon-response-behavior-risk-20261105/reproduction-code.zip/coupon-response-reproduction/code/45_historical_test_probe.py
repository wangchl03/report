"""Locate previously documented A/B-marked cohorts as independent reference evidence."""

from core import *

c = connect()
try:
    sql = """SELECT table_name FROM information_schema.tables
        WHERE table_schema='wangchuanliang'
          AND (table_name LIKE 'no_apply_%%' OR table_name LIKE '%%0708%%' OR table_name LIKE '%%0707%%' OR table_name LIKE '%%test%%')
        ORDER BY table_name"""
    f = query(c, sql, {}, "historical_test_tables")
    names = f.table_name.tolist()
    sql = """SELECT table_name,column_name,data_type,ordinal_position FROM information_schema.columns
        WHERE table_schema='wangchuanliang' AND table_name=ANY(%(tables)s)
        ORDER BY table_name,ordinal_position"""
    q = query(c, sql, {"tables": names}, "historical_test_schema")
    dump(W / "historical_test_probe.json", {"tables": names, "columns": q.to_dict("records")})
    mark("historical_test_probe_complete", tables=names)
finally:
    c.rollback()
    c.close()
