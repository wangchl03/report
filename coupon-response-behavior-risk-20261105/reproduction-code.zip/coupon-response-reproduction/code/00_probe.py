from core import *

tables = [
    "coupon_user_copy",
    "coupon_use_record",
    "coupon_cat",
    "tracking_points",
    "user_behavior_track_record",
    "event_track_record",
    "user_behavior_track",
    "event_track",
    "order_loan_f_v2_copy",
    "user",
    "churn_user",
    "churned_user",
]
c = connect()
out = {"report_date_client": "2026-11-05", "readonly": True, "tables": {}}
try:
    with c.cursor() as q:
        q.execute("SET application_name='coupon_response_round0_schema_audit'")
        q.execute(
            "SELECT CURRENT_TIMESTAMP AT TIME ZONE 'America/Belize',current_setting('transaction_read_only')"
        )
        snap, ro = q.fetchone()
        assert ro == "on"
        out["snapshot_business"] = str(snap)
        q.execute(
            """SELECT table_schema,table_name,column_name,data_type FROM information_schema.columns
            WHERE table_schema NOT IN ('pg_catalog','information_schema') AND table_name=ANY(%s)
            ORDER BY table_schema,table_name,ordinal_position""",
            (tables,),
        )
        for sch, t, n, d in q.fetchall():
            out["tables"].setdefault(sch + "." + t, []).append({"name": n, "type": d})
    (W / "source_schema.json").write_text(json.dumps(out, ensure_ascii=False, indent=2))
    sql = """SELECT coupon_id::text AS coupon_id,discount_pct::text AS discount_pct,
        COUNT(*) AS used_orders,MIN(discount_pct_raw)::text AS raw_min,
        MAX(discount_pct_raw)::text AS raw_max,MIN(create_date)::text AS first_send_date,
        MAX(create_date)::text AS last_send_date,
        MIN(apply_date)::text AS first_apply_date,MAX(apply_date)::text AS last_apply_date
        FROM wangchuanliang.coupon_use_record
        WHERE coupon_type=3 AND calc_status='normal'
          AND coupon_id NOT IN (126,149) AND NOT (user_id = ANY(%(__excluded_user_ids)s::bigint[]))
        GROUP BY coupon_id,discount_pct ORDER BY coupon_id,discount_pct"""
    frame = fetch(c, sql, {}, "coupon_id_actual_discount_map")
    out["coupon_mapping"] = frame.to_dict("records")
    (W / "coupon_id_actual_discount_map.sql").write_text(sql + ";\n")
    (W / "source_probe.json").write_text(
        json.dumps(out, ensure_ascii=False, indent=2, default=str)
    )
    if "wangchuanliang.tracking_points" in out["tables"]:
        with c.cursor() as q:
            q.execute("SELECT * FROM wangchuanliang.tracking_points")
            frame = pd.DataFrame(q.fetchall(), columns=[d.name for d in q.description])
        frame.to_parquet(W / "tracking_points.parquet", index=False)
        out["tracking_points_rows"] = len(frame)
    sql = """SELECT coupon_id::text AS coupon_id,COUNT(*) AS sent_records,
        COUNT(DISTINCT user_id) AS users,COUNT(DISTINCT coupon_no) AS coupon_numbers,
        MIN(create_date)::text AS first_send,MAX(create_date)::text AS last_send,
        MIN(expire_date-create_date+1) AS min_valid_days,
        MAX(expire_date-create_date+1) AS max_valid_days,
        SUM(CASE WHEN real_use_amount>0 THEN 1 ELSE 0 END) AS positive_use_rows
        FROM wangchuanliang.coupon_user_copy
        WHERE type=3 AND create_date>=DATE '2026-06-01'
          AND create_date<DATE '2026-11-04' AND NOT (user_id = ANY(%(__excluded_user_ids)s::bigint[]))
          AND coupon_id NOT IN (126,149)
        GROUP BY coupon_id ORDER BY coupon_id"""
    frame = fetch(c, sql, {}, "coupon_send_coverage_since_june")
    out["coupon_send_coverage"] = frame.to_dict("records")
    (W / "coupon_send_coverage.sql").write_text(sql + ";\n")
finally:
    c.rollback()
    c.close()
(W / "source_probe.json").write_text(json.dumps(out, ensure_ascii=False, indent=2, default=str))
print(
    json.dumps(
        {
            "complete": True,
            "snapshot_business": out["snapshot_business"],
            "tables": {t: [x["name"] for x in cols] for t, cols in out["tables"].items()},
            "coupon_map_rows": len(out.get("coupon_mapping", [])),
            "send_coverage": out.get("coupon_send_coverage"),
            "dictionary_rows": out.get("tracking_points_rows"),
        },
        ensure_ascii=False,
        default=str,
    )
)
