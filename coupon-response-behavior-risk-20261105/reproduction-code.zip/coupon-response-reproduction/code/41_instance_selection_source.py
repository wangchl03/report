"""Link documented loan-page coupon selection to the specific coupon INSTANCE.

The suffix is coupon_no (32-hex instance ID), not the coupon_cat configuration ID.
Only hashed/aggregate analysis results are published; instance IDs remain private.
"""

from core import *

c = connect()
try:
    with c.cursor() as q:
        q.execute("SET application_name='coupon_response_instance_selection_readonly'")
        q.execute("SET statement_timeout=1800000")
    users = json.loads((PRIVATE / "behavior_user_ids.json").read_text())
    sql = """WITH events AS (
        SELECT user_id,event_time,event_date,split_part(element_id,'_',1) AS event_base,
            SUBSTRING(element_id FROM POSITION('_' IN element_id)+1) AS coupon_no
        FROM wangchuanliang.user_behavior_track_record
        WHERE event_date>=DATE '2026-06-01' AND event_date<DATE '2026-11-04'
          AND event_time>=TIMESTAMP '2026-06-01' AND event_time<TIMESTAMP '2026-11-04'
          AND event_type='element_click'
          AND user_id IN(SELECT unnest(%(users)s::bigint[]))
          AND split_part(element_id,'_',1) IN ('boxyvbuxjvvehiiq','osuxshhfbtlprnip','vrnfgqufsxosxwgp','vcicilykcblxxksh')
    ), coupons AS (
        SELECT user_id,TRIM(coupon_no) AS coupon_no,coupon_id,create_date,expire_date
        FROM wangchuanliang.coupon_user_copy
        WHERE user_id IN(SELECT unnest(%(users)s::bigint[])) AND NOT (user_id = ANY(%(__excluded_user_ids)s::bigint[]))
          AND type=3 AND coupon_id IN(119,124,153,157)
          AND create_date>=DATE '2026-06-01' AND create_date<DATE '2026-11-01'
    )
    SELECT e.user_id,c.coupon_no,c.coupon_id,c.create_date,c.expire_date,
        e.event_date,e.event_base,COUNT(*) AS logs,
        MIN(EXTRACT(EPOCH FROM e.event_time AT TIME ZONE 'America/Belize')) AS first_epoch,
        MAX(EXTRACT(EPOCH FROM e.event_time AT TIME ZONE 'America/Belize')) AS last_epoch
    FROM events e JOIN coupons c ON e.user_id=c.user_id AND e.coupon_no=c.coupon_no
    WHERE e.event_time>=c.create_date::timestamp AND e.event_date<c.create_date+15
    GROUP BY e.user_id,c.coupon_no,c.coupon_id,c.create_date,c.expire_date,e.event_date,e.event_base"""
    r = query_large(c, sql, {"users": users}, "coupon_instance_selection_daily", buckets=32)
    mark("coupon_instance_selection_source_complete", rows=len(r))
finally:
    c.rollback()
    c.close()
