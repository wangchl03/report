"""Build pre-issue/recall-day cohorts from frozen sources, without future outcomes in features."""

from core import *
from bisect import bisect_left, bisect_right

END = pd.Timestamp("2026-11-04")
DAY = 86400.0
MAP = {
    119: 0.20,
    124: 0.40,
    141: 0.20,
    153: 0.20,
    157: 0.30,
    160: 0.30,
    163: 0.20,
    164: 0.40,
    166: 0.20,
}
NUM = ["serial_id", "user_id", "coupon_id", "type", "amount", "real_use_amount"]


def floats(f, cols):
    for k in cols:
        if k in f:
            f[k] = pd.to_numeric(f[k], errors="coerce")
    return f


def dates(f, cols):
    for k in cols:
        if k in f:
            f[k] = pd.to_datetime(f[k], errors="coerce")
    return f


def seconds(v):
    return np.datetime64(v, "ns").astype("int64") / 1e9


def run():
    audit = {}
    issue = pd.read_parquet(PRIVATE / "all_issue_histories.parquet")
    issue = floats(dates(issue, ["create_date", "expire_date", "used_date"]), NUM)
    audit["issued_rows"] = len(issue)
    audit["exact_issue_duplicates"] = int(issue.duplicated().sum())
    issue = issue.drop_duplicates()
    # Coupon number is unique where populated. Conflicting rows are quarantined, never arbitrarily selected.
    issue["coupon_key"] = issue.coupon_no.fillna("").astype(str).str.strip()
    missing = issue.coupon_key.eq("")
    issue.loc[missing, "coupon_key"] = "MISSING:" + issue.loc[
        missing, ["user_id", "coupon_id", "create_date", "expire_date", "amount"]
    ].astype(str).agg("|".join, axis=1)
    conflicts = issue.groupby("coupon_key").size()
    badkeys = conflicts[conflicts > 1].index
    audit["conflicting_coupon_numbers"] = len(badkeys)
    issue = issue[~issue.coupon_key.isin(badkeys)].copy()
    issue["valid_days"] = (issue.expire_date - issue.create_date).dt.days + 1
    issue["nominal_discount"] = issue.coupon_id.map(MAP)
    # Dates carry no send clock: all pre-treatment features strictly precede 00:00 of the issue date.
    issues = []
    for (uid, dt), g in issue.groupby(["user_id", "create_date"], sort=False):
        ds = g[(g.type == 3) & g.nominal_discount.notna() & (~g.coupon_id.isin([126, 149]))]
        target = ds.nominal_discount.nunique()
        valid = ds.valid_days.nunique()
        issues.append(
            {
                "user_id": int(uid),
                "anchor": dt,
                "coupon_rows": len(g),
                "target_coupon_rows": len(ds),
                "nominal_discount": (
                    float(ds.nominal_discount.iloc[0]) if target == 1 else np.nan
                ),
                "target_dose_versions": target,
                "valid_days": int(ds.valid_days.iloc[0]) if target and valid == 1 else np.nan,
                "target_validity_versions": valid,
                "target_coupon_ids": ",".join(map(str, sorted(set(ds.coupon_id.astype(int))))),
                "has_amount_coupon": int((g.type == 4).any()),
                "has_repayment_coupon": int((g.type == 2).any()),
                "other_application_discount": int(
                    ((g.type == 3) & g.nominal_discount.isna()).any()
                ),
                "fixed_coupon": int(g.coupon_id.isin([126, 149]).any()),
                "last_expiry": g.expire_date.max(),
                "target_used_coupon_rows": int((ds.real_use_amount > 0).sum()),
            }
        )
    sent = pd.DataFrame(issues)
    recall = pd.read_parquet(PRIVATE / "recall_batch_features.parquet")
    recall["user_id"] = pd.to_numeric(recall.churn_user_id).astype("int64")
    recall["anchor"] = pd.to_datetime(recall.batch_date)
    recall["valid_score"] = pd.to_numeric(recall.score, errors="coerce").where(
        lambda s: s.between(0, 3000)
    )
    recall["intent_rank"] = recall.groupby("batch").valid_score.rank(pct=True, method="average")
    rr = []
    for (uid, dt), g in recall.groupby(["user_id", "anchor"], sort=False):
        rr.append(
            {
                "user_id": int(uid),
                "anchor": dt,
                "recall_batches": "|".join(sorted(g.batch.unique())),
                "recall_kind": (
                    "mixed"
                    if g.batch.str.contains("active").any()
                    and (~g.batch.str.contains("active")).any()
                    else ("active" if g.batch.str.contains("active").any() else "regular")
                ),
                "intent_rank": g.intent_rank.mean(),
                "intent_rank_min": g.intent_rank.min(),
                "intent_rank_max": g.intent_rank.max(),
                "source_churn_days": pd.to_numeric(g.churn_days, errors="coerce").mean(),
                "source_strategy": "|".join(sorted(set(g.strat.fillna("unknown").astype(str)))),
                "source_risk_level": "|".join(
                    sorted(set(g.prod_risk_level.fillna("unknown").astype(str)))
                ),
            }
        )
    rec = pd.DataFrame(rr)
    anchors = sent.merge(rec, on=["user_id", "anchor"], how="outer")
    anchors["in_recall"] = anchors.recall_batches.notna().astype("int8")
    anchors["is_target_send"] = (
        (anchors.target_dose_versions == 1) & anchors.nominal_discount.isin([0.2, 0.3, 0.4])
    ).astype("int8")
    # Broad exposure analysis starts June 1. Later issues still retained separately for contamination windows.
    anchors = anchors[
        (
            (anchors.anchor >= pd.Timestamp("2026-06-01"))
            & (anchors.anchor < pd.Timestamp("2026-11-01"))
        )
        & ((anchors.is_target_send == 1) | (anchors.in_recall == 1))
    ].copy()
    anchors = anchors.sort_values(["user_id", "anchor"]).reset_index(drop=True)
    anchors["episode_id"] = np.arange(1, len(anchors) + 1)
    anchors.to_parquet(PRIVATE / "anchors_unfeatured.parquet", index=False, compression="zstd")
    audit.update(
        {
            "user_day_anchors": len(anchors),
            "recall_user_days": int(anchors.in_recall.sum()),
            "target_sends": int(anchors.is_target_send.sum()),
            "users": int(anchors.user_id.nunique()),
            "target_send_dose_validity": anchors[anchors.is_target_send == 1]
            .groupby(["nominal_discount", "valid_days"])
            .size()
            .reset_index(name="episodes")
            .to_dict("records"),
        }
    )
    dump(W / "cohort_construction_audit.json", audit)
    mark("cohort_constructed", **audit)


if __name__ == "__main__":
    run()
