"""Paired user-cluster uncertainty; no feature/model selection after held-out test."""

from core import *
from sklearn.metrics import roc_auc_score, average_precision_score


def metric(y, p, wt):
    order = np.argsort(-p, kind="stable")
    k = int(np.ceil(len(y) * 0.2))
    # Lists are frozen from the original top-20% ranking; cluster resampling assesses their observed outcome uncertainty.
    top = order[:k]
    den = wt[top].sum()
    return [
        roc_auc_score(y, p, sample_weight=wt),
        average_precision_score(y, p, sample_weight=wt),
        (wt[top] * y[top]).sum() / den if den else np.nan,
    ]


def run():
    p = pd.read_parquet(PRIVATE / "diagnostic_response_predictions.parquet")
    p["anchor"] = pd.to_datetime(p.anchor)
    p = p[p.anchor.ge(pd.Timestamp("2026-10-17"))].copy()
    uid, ix = np.unique(p.user_id.to_numpy(), return_inverse=True)
    y = p.applied_3.to_numpy(int)
    a = p.recent_activity_p.to_numpy(float)
    b = p.full_baseline_p.to_numpy(float)
    rng = np.random.default_rng(20261105)
    rows = []
    for _ in range(2000):
        w = rng.poisson(1, len(uid))[ix]
        if (w * y).sum() == 0 or (w * (1 - y)).sum() == 0:
            continue
        rows.append(np.asarray(metric(y, b, w)) - np.asarray(metric(y, a, w)))
    r = np.asarray(rows)
    point = np.asarray(metric(y, b, np.ones(len(y)))) - np.asarray(
        metric(y, a, np.ones(len(y)))
    )
    out = {
        "comparison": "58-feature diagnostic versus 4-feature activity diagnostic, frozen temporal test",
        "events": len(p),
        "users": len(uid),
        "bootstrap_draws": len(r),
        "differences": {
            k: {"point": point[j], "ci95": np.quantile(r[:, j], [0.025, 0.975]).tolist()}
            for j, k in enumerate(["auc", "pr_auc", "fixed_top20_rate"])
        },
        "scope": "Observed application propensity after issued coupons, not individualized causal uplift; fixed top lists and fitted models held constant.",
    }
    dump(W / "model_paired_uncertainty_results.json", out)
    mark("model_paired_uncertainty_complete", **out)


if __name__ == "__main__":
    run()
