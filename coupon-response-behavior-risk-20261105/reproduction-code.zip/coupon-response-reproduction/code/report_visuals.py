from viz_helpers import *


def legend():
    return (
        '<div class="legend">'
        + "".join(
            f'<span><i style="background:{COLORS[d]}"></i>{dose_name(d)}</span>'
            for d in [0.2, 0.3, 0.4]
        )
        + "</div>"
    )


def lead(text):
    return '<div class="lead">' + text + "</div>"


def rate_tiles(rows, title="3日用户提单响应率"):
    body = "<h3>" + esc(title) + '</h3><div class="grid-cards">'
    for r in rows:
        d = r["dose"]
        body += card(
            dose_name(d),
            pct(r["rate_3"]),
            f"{nfmt(r['y_3'])} / {nfmt(r['n_3'])} 笔合格获额<br>"
            + ("样本少，单列展示" if r["n_3"] < 100 else "每笔获额仅保留首次合格召回"),
            COLORS[d],
        )
    return body + "</div>"


def matrix(headers, rows):
    return (
        '<div class="decision-matrix">'
        + "".join('<div class="matrix-head">' + esc(v) + "</div>" for v in headers)
        + "".join("<div>" + str(c) + "</div>" for r in rows for c in r)
        + "</div>"
    )


def daily_heat(records, title):
    days = list(range(-7, 14))
    pairs = [
        (0.2, "new_active", "20% · 活跃"),
        (0.3, "new_active", "30% · 活跃"),
        (0.2, "new_loan_entry", "20% · 提单页"),
        (0.3, "new_loan_entry", "30% · 提单页"),
    ]
    key = {(r["dose"], r["metric"], r["day"]): r for r in records}
    w = 1130
    left = 160
    cw = 44
    top = 72
    rh = 60
    h = top + len(pairs) * rh + 56
    vals = [
        r["rate"]
        for r in records
        if r["day"] in days
        and r["metric"] in ["new_active", "new_loan_entry"]
        and r["dose"] in [0.2, 0.3]
    ]
    mx = max(vals) if vals else 1
    body = f'<text x="14" y="27" class="chart-title">{esc(title)}</text>'
    for j, d in enumerate(days):
        label = ("前" + str(-d)) if d < 0 else "D" + str(d)
        body += f'<text x="{left+(j+.5)*cw}" y="54" class="axis" text-anchor="middle" style="font-size:10px">{label}</text>'
    for i, (dose, metric, label) in enumerate(pairs):
        n = next(
            (key[(dose, metric, d)]["events"] for d in days if (dose, metric, d) in key), 0
        )
        y = top + i * rh
        body += f'<text x="{left-12}" y="{y+23}" text-anchor="end" class="axis">{label}</text><text x="{left-12}" y="{y+42}" text-anchor="end" class="axis" style="font-size:10px">分母 {nfmt(n)} 笔</text>'
        for j, d in enumerate(days):
            r = key.get((dose, metric, d))
            v = r["rate"] if r else None
            q = (v / mx) if v is not None and mx else 0
            color = f"rgb({int(16+q*8)},{int(36+q*102)},{int(59+q*123)})"
            x = left + j * cw
            body += f'<rect x="{x+1}" y="{y+2}" width="{cw-2}" height="{rh-4}" fill="{color}" rx="4"><title>{label} {d}: {pct(v)}</title></rect><text x="{x+cw/2}" y="{y+32}" class="cell-value" style="font-size:10px" text-anchor="middle">{pct(v,2)}</text>'
    xx = left + 7 * cw
    body += f'<path d="M{xx},{top-6} V{top+4*rh}" stroke="#72d9ff" stroke-width="2"/>'
    body += f'<text x="{xx+6}" y="{h-18}" class="axis">D0为发券日；纵向边线分隔发券前与发券后。颜色深浅使用同一比例刻度。</text>'
    return '<div class="chart">' + svg_base(w, h, body, title) + "</div>"


def mechanism_cards(rows):
    body = '<div class="mechanism-grid">'
    for r in rows:
        dose = r["dose"]
        n = r["eligible_credit_orders"]
        a = r["any_user_application_3"]
        u = r["first_order_used_issued_coupon_events"]
        body += f'<article class="mechanism"><b style="color:{COLORS[dose]}">{dose_name(dose)}</b><div class="mechanism-step">合格获额首次召回<strong>{nfmt(n)}</strong></div><div class="connector">↓ 按用户追踪首次提单</div><div class="mechanism-step">3日内有提单<strong>{nfmt(a)} <small>({pct(a/n)})</small></strong></div><div class="connector">↓ 核对本次发出的券实例</div><div class="mechanism-step">首单使用本次券<strong>{nfmt(u)}</strong></div><p class="note">另观测到主动选券 {nfmt(r["loan_coupon_item_selected_events"])} 次获额记录；其中 {nfmt(r["selected_before_first_application_events"])} 次位于首次提单之前。</p></article>'
    return body + "</div>"


def bubble_finance(rows):
    w = 1100
    h = 430
    l = 100
    r = 210
    t = 55
    b = 70
    xmin = 0.15
    xmax = 0.32
    ymin = 0.07
    ymax = 0.23
    x = lambda v: l + (v - xmin) / (xmax - xmin) * (w - l - r)
    y = lambda v: h - b - (v - ymin) / (ymax - ymin) * (h - t - b)
    body = (
        '<text x="18" y="25" class="chart-title">风险与收益坐标：面积代表到期用券订单数</text>'
    )
    for v in [0.15, 0.2, 0.25, 0.3]:
        body += f'<path d="M{x(v)},{t} V{h-b}" class="grid"/><text x="{x(v)}" y="{h-b+26}" class="axis" text-anchor="middle">{pct(v,0)}</text>'
    for v in [0.08, 0.12, 0.16, 0.2]:
        body += f'<path d="M{l},{y(v)} H{w-r}" class="grid"/><text x="{l-16}" y="{y(v)+4}" class="axis" text-anchor="end">{pct(v,0)}</text>'
    for rr in rows:
        d = rr["dose"]
        xx = x(rr["order_overdue_rate"])
        yy = y(rr["profit_rate"])
        radius = 9 + math.sqrt(rr["orders"]) * 0.7
        body += f'<circle cx="{xx}" cy="{yy}" r="{radius}" fill="{COLORS[d]}" fill-opacity=".65" stroke="{COLORS[d]}" stroke-width="2"><title>{dose_name(d)} {nfmt(rr["orders"])}笔；盈利{pct(rr["profit_rate"])}；逾期{pct(rr["order_overdue_rate"])}</title></circle>'
        body += f'<text x="{xx+radius+12}" y="{yy-9}" class="value" fill="{COLORS[d]}">{dose_name(d)}</text><text x="{xx+radius+12}" y="{yy+13}" class="axis">{nfmt(rr["orders"])}笔 · 盈利 {pct(rr["profit_rate"])}</text><text x="{xx+radius+12}" y="{yy+32}" class="axis">逾期 {pct(rr["order_overdue_rate"])}</text>'
    body += f'<text x="{(l+w-r)/2}" y="{h-15}" class="axis" text-anchor="middle">整笔到期订单中，当前状态为8的订单比例 →</text>'
    body += f'<text x="18" y="{t+5}" class="axis">当前盈利率 ↑</text>'
    return '<div class="chart">' + svg_base(w, h, body, "当前盈利率与订单逾期率") + "</div>"


def profit_waterfall(rows):
    w = 1100
    h = 390
    top = 60
    bottom = 65
    left = 130
    right = 70
    ymin = -0.25
    ymax = 0.4
    scale = lambda v: top + (ymax - v) / (ymax - ymin) * (h - top - bottom)
    body = '<text x="18" y="27" class="chart-title">现金盈利拆解：当前逾期仍可能已有部分回款</text>'
    for v in [-0.2, 0, 0.2, 0.4]:
        body += f'<path d="M{left},{scale(v)} H{w-right}" class="grid"/><text x="{left-14}" y="{scale(v)+4}" class="axis" text-anchor="end">{pct(v,0)}</text>'
    for i, row in enumerate(rows):
        start = left + i * 295
        good = next(p for p in row["parts"] if not p["current_status8"])
        bad = next(p for p in row["parts"] if p["current_status8"])
        for j, (val, lab, col) in enumerate(
            [
                (good["profit_contribution"], "其他订单贡献", "#34d399"),
                (bad["profit_contribution"], "状态8订单贡献", "#fb7185"),
                (row["profit_rate"], "合计", COLORS[row["dose"]]),
            ]
        ):
            xx = start + j * 79
            yy = scale(max(0, val))
            hh = abs(scale(val) - scale(0))
            body += f'<rect x="{xx}" y="{yy}" width="55" height="{hh}" rx="4" fill="{col}" fill-opacity=".8"/><text x="{xx+27}" y="{yy-9 if val>=0 else yy+hh+18}" fill="{col}" text-anchor="middle" class="axis">{val*100:+.2f}pp</text><text x="{xx+27}" y="{h-bottom+25}" text-anchor="middle" class="axis" style="font-size:10px">{lab}</text>'
        body += f'<text x="{start+105}" y="{h-12}" text-anchor="middle" fill="{COLORS[row["dose"]]}" class="value">{dose_name(row["dose"])}</text>'
    return (
        '<div class="chart">'
        + svg_base(w, h, body, "不同还款状态对当前盈利率的金额加权贡献")
        + "</div>"
    )


def policy_flow():
    items = [
        ("风险资格", "风控拒绝、风险禁发、逾期或黑名单：停止优惠"),
        ("在途状态", "无在途走流失召回；有在途进入独立循环贷策略"),
        ("需求信号", "近期提单页 → 历史提单率与使用率 → 正常借款节奏"),
        ("优惠试验", "相同资格层内保留无券、20%、30%、40%分组"),
        ("收益复盘", "3/7/15/30日响应 + 同笔放款到期盈利与逾期"),
    ]
    body = '<div class="policy-flow">'
    for i, (title, detail) in enumerate(items):
        body += f"<article><b>{i+1}</b><div><strong>{title}</strong><span>{detail}</span></div></article>"
    return body + "</div>"


EXTRA_CSS = """
.legend{display:flex;gap:20px;flex-wrap:wrap;margin:12px 0;color:#adc5dc;font-size:13px}.legend i{display:inline-block;width:10px;height:10px;border-radius:50%;margin-right:7px}.decision-matrix{display:grid;grid-template-columns:1.1fr 1.7fr 2fr;gap:1px;background:#2b4058;border:1px solid #2b4058;border-radius:9px;overflow:hidden;margin:16px 0}.decision-matrix>div{background:#111e31;padding:14px 16px;font-size:14px}.decision-matrix>.matrix-head{color:#7fd5ed;background:#18314a;font-weight:700}.mechanism-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:16px;margin:18px 0}.mechanism{padding:20px;background:#101e31;border:1px solid #2b435e;border-radius:11px}.mechanism>b{font-size:23px}.mechanism-step{margin-top:14px;color:#a7bdd2;font-size:13px}.mechanism-step strong{display:block;color:#d5ecfb;font-size:25px}.mechanism-step small{font-size:16px}.connector{color:#6488a3;font-size:12px;padding-top:8px}.policy-flow{display:grid;gap:12px;margin:20px 0}.policy-flow article{display:flex;gap:16px;background:#11253a;border:1px solid #29455f;border-radius:10px;padding:15px 18px}.policy-flow article>b{display:flex;align-items:center;justify-content:center;border:1px solid #378ba9;background:#123b50;color:#70daff;font-size:22px;width:40px;height:40px;border-radius:8px;flex:0 0 auto}.policy-flow strong,.policy-flow span{display:block}.policy-flow strong{color:#79d4ed;font-size:17px}.policy-flow span{color:#a2bdd3;font-size:14px}.audit-badge{border:1px solid #31536e;border-radius:7px;padding:10px 15px;margin:8px 0;background:#10283a}.chart{overflow-x:auto}button{cursor:pointer}select{max-width:90%}.intro-links{margin:15px 0}.section-description{color:#b7cce0;margin-top:-6px}.small{font-size:12px;color:#93abc1}@media(max-width:800px){.chart svg{min-width:700px}.mechanism-grid{grid-template-columns:1fr}.decision-matrix{grid-template-columns:1fr}.matrix-head{display:none}.decision-matrix>div:nth-child(3n+1){font-weight:bold;color:#6ad9ff;background:#173148}}
"""


def interactive_script():
    return """<script>document.querySelectorAll('select[data-panels]').forEach(s=>{const update=()=>document.querySelectorAll('[data-panel="'+s.dataset.panels+'"]').forEach(p=>p.hidden=p.dataset.value!==s.value);s.addEventListener('change',update);update();});</script>"""
