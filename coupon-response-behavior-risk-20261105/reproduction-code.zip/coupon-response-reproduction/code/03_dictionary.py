from core import *

f = pd.read_parquet(W / "tracking_points.parquet")
audit = {
    "rows": len(f),
    "columns": list(f.columns),
    "versions": f.version.value_counts(dropna=False).to_dict(),
}
f["base_id"] = f.event_point_id.astype(str).str.extract(r"^([a-z]{16})", expand=False)
audit["pages"] = f[["page_id", "page_name", "page_remark"]].drop_duplicates().to_dict("records")
audit["dictionary_duplicate_keys"] = int(f.duplicated(["page_id", "event_point_id"]).sum())
audit["conflicting_keys"] = []
for (p, e), g in f.groupby(["page_id", "base_id"], dropna=False):
    if g.event_point_meaning.nunique() > 1:
        audit["conflicting_keys"].append(
            {"page_id": p, "base_id": e, "meanings": g.event_point_meaning.unique().tolist()}
        )
terms = ["loan", "amount", "term", "coupon", "contract", "purpose", "plan", "main"]
sel = f[f.page_name.fillna("").str.lower().apply(lambda v: any(t in v for t in terms))]
sel.to_parquet(W / "tracking_dictionary_selected.parquet", index=False)
dump(W / "dictionary_audit.json", audit)
review(
    "0-source",
    [
        "红包发送/到期仅为日期，无法证明日内先后；行为和提单有具体时间。",
        "119/157/124配置分别为20%/30%/40%，3天有效；实际使用部分订单落入15%/35%档。",
        "存在2天与7天红包、重复发放与多策略并发，不能把所有发放作为同质3天单次干预。",
        "十批名单共64366行、24327名不同用户，历史字段含日期哨兵，重建事前特征而不直接使用当前结果。",
    ],
    [
        "以收到红包构造暴露，不以未来用券筛选；固定金额126/149排除。",
        "事前主要截止发券日前一日，日内缺失时间作敏感性核对；完整观察上界2026-11-04。",
        "主分析20/30/40三天券；2/7天券另作持续时间与外推检验。",
        "提单率保留获额通过且recycle_type非1的获额事件分母，发券人数另列；未提单额度使用率记缺失。",
    ],
    [
        "发放是否因用户风险/意愿分而分配？是否存在可用的随机对照？",
        "两套埋点覆盖、主键重复、具体提单页语义覆盖率需要核对。",
        "40%样本规模及长周期成熟盈利样本能否支持分层。",
    ],
)
print(
    json.dumps(
        {
            "pages": len(audit["pages"]),
            "selected_dictionary_rows": len(sel),
            "conflicts": len(audit["conflicting_keys"]),
        }
    )
)
