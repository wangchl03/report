"""Stricter recall-only dose comparison within the SAME calendar date and recorded business risk tier.

The no-coupon rows are mostly high-risk exclusions, not experimental controls.
This script preserves failed balance checks instead of treating matched means as causal proof.
"""

from analysis_contract import *
from sklearn.metrics import roc_auc_score
import importlib.util

spec = importlib.util.spec_from_file_location("_ow", W / "19_balanced_comparisons.py")
ow = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ow)


def binary_smd(x, t, w):
    out = []
    for weighted in [False, True]:
        a = []
        for v in [0, 1]:
            ix = t == v
            ww = w[ix] if weighted else np.ones(ix.sum())
            a.append(float(ww @ x[ix] / ww.sum()))
        sd = np.sqrt((a[0] * (1 - a[0]) + a[1] * (1 - a[1])) / 2)
        out.append(
            (a[1] - a[0]) / sd if sd else (0.0 if abs(a[1] - a[0]) < 1e-12 else float("inf"))
        )
    return out


def complete_balance(z, cols, w):
    out = ow.balance(z, cols, w)
    t = z.treat.to_numpy(int)
    for c in cols:
        missing = pd.to_numeric(z[c], errors="coerce").isna().to_numpy(float)
        if missing.min() != missing.max():
            a, b = binary_smd(missing, t, w)
            out.append({"feature": c + "__missing", "smd_before": a, "smd_after": b})
    for c in ["source_risk_level", "calendar", "recall_kind"]:
        for level in z[c].fillna("unknown").unique():
            a, b = binary_smd(z[c].fillna("unknown").eq(level).to_numpy(float), t, w)
            out.append({"feature": c + "=" + str(level), "smd_before": a, "smd_after": b})
    for c in [
        "score410",
        "churn_days",
        "prior_fund_n",
        "mean_funded_utilization",
        "pre7_active_days",
    ]:
        x = pd.to_numeric(z[c], errors="coerce")
        for q in [0.25, 0.5, 0.75]:
            cut = x.quantile(q)
            a, b = binary_smd(x.le(cut).to_numpy(float), t, w)
            out.append({"feature": c + "__q" + str(q), "smd_before": a, "smd_after": b})
    return out


def run():
    f = pd.read_parquet(PRIVATE / "episode_analysis.parquet")
    f["anchor"] = pd.to_datetime(f.anchor)
    f, co = cohorts_with_offer_grain(f)
    f["calendar"] = f.anchor.dt.strftime("%Y-%m-%d")
    f["source_risk_level"] = f.source_risk_level.fillna("unknown")
    f["kind"] = f.recall_kind.fillna("extension") + "|" + f.source_risk_level
    output = {"assignment": [], "results": []}
    z = f[co["main_offer_simple"]]
    for (risk, dose), g in z.groupby(["source_risk_level", "dose"]):
        output["assignment"].append(
            {
                "risk_tier": risk,
                "dose": dose,
                "events": len(g),
                "applications_3": int(g.applied_3.sum()),
            }
        )
    for name in ["main_offer_simple", "main_offer_simple_stable15"]:
        for pair in [(0.0, 0.2), (0.2, 0.3), (0.2, 0.4), (0.3, 0.4)]:
            initial = f[co[name] & f.dose.isin(pair) & f.observed_3.eq(1)].copy()
            initial["treat"] = initial.dose.eq(pair[1]).astype("int8")
            r = {"cohort": name, "pair": pair, "windows": []}
            for d in [3, 7, 15, 30]:
                z = initial[initial[f"observed_{d}"].eq(1)].copy()
                count = (
                    z.groupby(["calendar", "source_risk_level", "recall_kind", "treat"])
                    .size()
                    .unstack("treat")
                    .fillna(0)
                )
                good = (
                    count.index[count.min(axis=1).ge(20)]
                    if count.shape[1] == 2
                    else count.index[:0]
                )
                z = z[
                    pd.MultiIndex.from_frame(
                        z[["calendar", "source_risk_level", "recall_kind"]]
                    ).isin(good)
                ]
                before_missing = len(z)
                # A missing-value pattern seen in only one arm has no empirical
                # comparison. Restrict this observational comparison, never the
                # unadjusted approved-offer denominator, to shared states.
                for _ in range(10):
                    n0 = len(z)
                    if z.treat.nunique() < 2:
                        break
                    for c in ow.FEATURES:
                        if c not in z:
                            continue
                        state = pd.to_numeric(z[c], errors="coerce").notna()
                        count0 = pd.crosstab(state, z.treat).reindex(
                            index=[False, True], columns=[0, 1], fill_value=0
                        )
                        unsupported = count0.index[
                            (count0.min(axis=1) == 0) & (count0.sum(axis=1) > 0)
                        ]
                        if len(unsupported):
                            z = z[~state.isin(unsupported)]
                    if len(z) == n0:
                        break
                v = {
                    "window": d,
                    "events": len(z),
                    "exact_date_risk_strata": len(good),
                    "before_shared_missingness_support": before_missing,
                    "excluded_unsupported_missing_states": before_missing - len(z),
                }
                if (
                    len(z) < 200
                    or z.treat.nunique() < 2
                    or z.groupby("treat").size().min() < 50
                ):
                    v["status"] = "insufficient_date_risk_support"
                    r["windows"].append(v)
                    continue
                cols = [
                    c
                    for c in ow.FEATURES
                    if c in z and pd.to_numeric(z[c], errors="coerce").notna().any()
                ]
                pred, w = ow.fit_weights(z, cols)
                bal = complete_balance(z, cols, w)
                v.update(ow.weighted_rates(z, w, f"applied_{d}", B=2000))
                v.update(
                    {
                        "status": "observational_estimate",
                        "full_balance": bal,
                        "max_abs_smd_after": max(abs(b["smd_after"]) for b in bal),
                        "groups": [],
                        "allocation_auc": float(roc_auc_score(z.treat, pred)),
                    }
                )
                for treat, g in z.groupby("treat"):
                    ww = w[z.treat.eq(treat).to_numpy()]
                    v["groups"].append(
                        {
                            "dose": pair[treat],
                            "events": len(g),
                            "effective_n": float(ww.sum() ** 2 / (ww @ ww)),
                        }
                    )
                v["balance_sufficient"] = (
                    v["max_abs_smd_after"] <= 0.1
                    and min(g["effective_n"] for g in v["groups"]) >= 50
                )
                z[["episode_id", "user_id", "dose"]].assign(
                    overlap_weight=w, propensity=pred
                ).to_parquet(
                    PRIVATE / f"overlap_strict_{name}_{pair[0]}_{pair[1]}_{d}d.parquet",
                    index=False,
                    compression="zstd",
                )
                r["windows"].append(v)
            output["results"].append(r)
            dump(W / "strict_assignment_results.json", output)
            mark("strict_assignment_pair_complete", cohort=name, pair=pair)
    review(
        "6-assignment",
        [
            "Among main first-contact orders, no-coupon rows are overwhelmingly recorded high/high2 risk tiers; they are not randomized controls.",
            "Most early 40% first-contact orders receive another 10% coupon the next day; long-window response is a sequence of policies.",
        ],
        [
            "Compare doses only with same calendar day and recorded business risk tier; include missingness and quantile balance diagnostics.",
            "Separate received-coupon response from incremental effect. Report insufficient overlap instead of extrapolating.",
        ],
        [
            "Even exact date/risk comparisons retain nonrandom allocation and unknown actual delivery time."
        ],
    )


if __name__ == "__main__":
    run()
