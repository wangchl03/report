"""Outstanding-loan users are an auxiliary population, with their own denominator and risk-state checks."""

from analysis_contract import *
from stats_utils import *


def run():
    f = pd.read_parquet(PRIVATE / "episode_analysis.parquet")
    f["anchor"] = pd.to_datetime(f.anchor)
    f, co = cohorts_with_offer_grain(f)
    z = (
        f[co["extension_outstanding"]]
        .sort_values(["anchor", "episode_id"])
        .drop_duplicates(["user_id", "latest_credit_serial"])
        .copy()
    )
    z["late_state"] = np.where(
        z.open_late_periods.gt(0) | z.open_overdue_n.gt(0), "当时已有逾期", "当时未见逾期"
    )
    z["strategy"] = np.where(z.simple_discount, "仅降息", "同时有其他优惠")
    z["open_band"] = np.where(z.open_n.eq(1), "1笔在途", "2笔及以上在途")
    out = {
        "rates": [],
        "risk_state": [],
        "open_count": [],
        "financial": [],
        "definition": "Qualified passed non-recycle1 latest offer, known histories, open funded loans before issue day. One first observed contact per offer; kept separate from T7.",
        "data_limit": "Loan and installment due/repayment clocks identify outstanding/late state; a full historical payment ledger is not available to reconstruct exact remaining credit balance.",
    }
    for (dose, strategy), g in z.groupby(["dose", "strategy"]):
        out["rates"].append(rm.summarize(g, {"dose": dose, "strategy": strategy}))
    for (dose, strategy, late), g in z.groupby(["dose", "strategy", "late_state"]):
        out["risk_state"].append(
            rm.summarize(g, {"dose": dose, "strategy": strategy, "late_state": late})
        )
    for (dose, state), g in z.groupby(["dose", "open_band"]):
        out["open_count"].append(rm.summarize(g, {"dose": dose, "state": state}))
    finance = pd.read_parquet(PRIVATE / "used_orders_finance.parquet")
    finance = finance.merge(
        f[["episode_id", "open_late_periods", "open_overdue_n"]],
        on="episode_id",
        how="left",
        validate="many_to_one",
    )
    q = finance[
        finance.whole_mature
        & finance.repaid_amt.notna()
        & finance.valid_days.eq(3)
        & finance.eligible_offer.eq(1)
        & finance.open_n.gt(0)
    ]
    combined = (
        q.has_amount_coupon.eq(1)
        | q.has_repayment_coupon.eq(1)
        | q.other_application_discount.eq(1)
        | q.fixed_coupon.eq(1)
    )
    late = q.open_late_periods.gt(0) | q.open_overdue_n.gt(0)
    for (dose, combined, late), g in q.assign(combined=combined, late=late).groupby(
        ["dose", "combined", "late"]
    ):
        n = len(g)
        a = g.remit_amt.sum()
        out["financial"].append(
            {
                "dose": dose,
                "combined": bool(combined),
                "late_before_issue": bool(late),
                "mature_used_orders": n,
                "profit_rate": float((g.repaid_amt.sum() - a) / a),
                "order_overdue_rate": float(g.loan_status_code.eq(8).mean()),
                "mean_fund_amt": float(g.remit_amt.mean()),
            }
        )
    dump(W / "inflight_validation_results.json", out)
    mark("inflight_validation_complete", first_offer_events=len(z))


if __name__ == "__main__":
    run()
