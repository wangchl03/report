"""Describe lifecycle transitions and order-linked scores; never use them as pre-issue covariates."""

from core import *


def run():
    states = pd.read_parquet(PRIVATE / "inflight_application_state_finance.parquet")
    q = pd.read_parquet(PRIVATE / "used_orders_finance.parquet").merge(
        states[["user_id", "serial_id", "state"]],
        on=["user_id", "serial_id"],
        validate="one_to_one",
    )
    m = pd.read_parquet(PRIVATE / "risk_score_histories.parquet")
    for c in m:
        m[c] = pd.to_numeric(m[c], errors="coerce")
    cols = ["score363", "score405", "score410"]
    for c in cols:
        m[c] = m[c].where(m[c].between(0, 3000))
    agg = m.groupby(["user_id", "serial_id"])[cols].agg(["min", "nunique"])
    scores = pd.DataFrame(
        {c: agg[(c, "min")].where(agg[(c, "nunique")].eq(1)) for c in cols}
    ).reset_index()
    q = q.merge(
        scores.rename(columns={c: "order_" + c for c in cols}),
        on=["user_id", "serial_id"],
        validate="one_to_one",
        how="left",
    )
    l = pd.read_parquet(PRIVATE / "loans_clean.parquet")
    lg = {u: g for u, g in l[l.funded].groupby("user_id")}
    details = []
    for a in q.itertuples():
        app = a.apply_time.tz_localize("America/Belize").timestamp()
        g = lg.get(a.user_id)
        prior = g[
            g.serial_id.ne(a.serial_id)
            & g.fund_s.lt(app)
            & g.valid_settle.notna()
            & g.settle_s.le(app)
        ].sort_values("settle_s")
        last = prior.iloc[-1] if len(prior) else None
        details.append(
            {
                "user_id": a.user_id,
                "serial_id": a.serial_id,
                "latest_settle_to_app_hours": (
                    (app - last.settle_s) / 3600 if last is not None else np.nan
                ),
                "latest_settle_to_app_days": (
                    (a.apply_time.normalize() - last.valid_settle.normalize()).days
                    if last is not None
                    else np.nan
                ),
                "last_settled_late_asof_app": (
                    int(last.valid_settle.normalize() > last.due_day)
                    if last is not None
                    else np.nan
                ),
            }
        )
    q = q.merge(pd.DataFrame(details), on=["user_id", "serial_id"], validate="one_to_one")
    out = {
        "profiles": [],
        "definition": "These fields describe the later application state and scores linked to that application order. They cannot be used to select who originally received a coupon.",
    }
    for state, g in q.groupby("state"):
        r = {
            "state": state,
            "orders": len(g),
            "mean_amount": float(g.remit_amt.mean()),
            "prior_fund_count_median": float(g.prior_fund_n.median()),
            "same_day_reborrow_after_settlement": int(g.latest_settle_to_app_days.eq(0).sum()),
            "last_settled_late_known_at_app": int(g.last_settled_late_asof_app.eq(1).sum()),
            "median_hours_since_settlement": float(g.latest_settle_to_app_hours.median()),
        }
        for col in cols:
            for scope, c in [("issue_", col), ("order_", "order_" + col)]:
                r[scope + col + "_known"] = int(g[c].notna().sum())
                r[scope + col + "_mean"] = float(g[c].mean())
                r[scope + col + "_median"] = float(g[c].median())
        out["profiles"].append(r)
    dump(W / "transition_customer_profile_results.json", out)
    mark("transition_profiles_complete", orders=len(q))


if __name__ == "__main__":
    run()
