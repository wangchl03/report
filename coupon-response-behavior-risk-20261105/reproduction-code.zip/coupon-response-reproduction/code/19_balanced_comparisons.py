"""Overlap-weighted observational checks, with same-day support and user-disjoint cross fitting."""

from core import *
from sklearn.compose import ColumnTransformer
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.linear_model import LogisticRegression
from sklearn.pipeline import Pipeline
from sklearn.model_selection import GroupKFold
from sklearn.metrics import roc_auc_score
from stats_utils import *
import importlib.util

spec = importlib.util.spec_from_file_location("_rates", W / "11_rates.py")
rm = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rm)
FEATURES = [
    "score410",
    "score363",
    "score405",
    "prior_fund_n",
    "churn_days",
    "mean_borrow_gap_days",
    "prior_apps30",
    "mean_funded_utilization",
    "last_funded_utilization",
    "mean_utilization90",
    "hist_offer_d0_rate90",
    "hist_offer_d0_n90",
    "hist_offer_d7_rate90",
    "hist_offer_d7_n90",
    "latest_credit_amt",
    "latest_credit_age_days",
    "mean_prior_fund_amt",
    "prior_settled_ever_overdue_n",
    "last_settled_overdue_days",
    "prior_late_periods_known",
    "prior_period_late_fraction",
    "days_since_last_active",
    "pre7_active_days",
    "pre7_loan_entry_days",
    "pre7_amount_days",
    "pre7_term_days",
    "pre7_plan_days",
    "pre14_active_days",
    "pre14_loan_entry_days",
    "pre7_coupon_open_days",
    "pre7_coupon_confirm_days",
    "pre7_submit_days",
    "coupon_sends_prior30",
    "prior_coupon_still_valid",
    "prior_target_coupon_use_rate30",
    "prior_expired_target_coupons30",
    "excess_idle_days",
    "historical_clean_gap_median",
    "last_funded_loan_day",
    "last_funded_fee_rate",
]


def balance(z, cols, w):
    out = []
    t = z.treat.to_numpy(bool)
    for c in cols:
        x = pd.to_numeric(z[c], errors="coerce").to_numpy(float)
        ok = np.isfinite(x)
        if (ok & t).sum() < 2 or (ok & ~t).sum() < 2:
            continue

        def moments(ix, weighted):
            ww = w[ix] if weighted else np.ones(ix.sum())
            if ww.sum() <= 0:
                return np.nan, np.nan
            avg = np.sum(ww * x[ix]) / ww.sum()
            var = np.sum(ww * (x[ix] - avg) ** 2) / ww.sum()
            return avg, var

        vals = []
        for weighted in [False, True]:
            m0, v0 = moments(ok & ~t, weighted)
            m1, v1 = moments(ok & t, weighted)
            sd = np.sqrt((v0 + v1) / 2)
            vals.append(
                (m1 - m0) / sd if sd > 0 else (0.0 if abs(m1 - m0) < 1e-12 else float("inf"))
            )
        out.append({"feature": c, "smd_before": vals[0], "smd_after": vals[1]})
    return out


def weighted_rates(z, w, col, B=2000):
    zz = z[z[col].notna()].copy()
    zz["weight"] = w[z[col].notna().to_numpy()]
    zz["wy"] = zz.weight * zz[col]
    p = zz.groupby(["user_id", "treat"])[["weight", "wy"]].sum().unstack("treat").fillna(0)
    if 0 not in p.weight or 1 not in p.weight:
        return None
    a = p.wy[0].to_numpy()
    b = p.weight[0].to_numpy()
    c = p.wy[1].to_numpy()
    d = p.weight[1].to_numpy()
    if min(b.sum(), d.sum()) <= 0:
        return None
    rng = np.random.default_rng(20261105)
    out = []
    for off in range(0, B, 100):
        ww = rng.poisson(1, (min(100, B - off), len(p)))
        den0 = ww @ b
        den1 = ww @ d
        x0 = np.divide(ww @ a, den0, out=np.full(len(den0), np.nan), where=den0 > 0)
        x1 = np.divide(ww @ c, den1, out=np.full(len(den1), np.nan), where=den1 > 0)
        out.extend((x1 - x0).tolist())
    return {
        "rate0": float(a.sum() / b.sum()),
        "rate1": float(c.sum() / d.sum()),
        "difference": float(c.sum() / d.sum() - a.sum() / b.sum()),
        "ci95": np.nanquantile(out, [0.025, 0.975]).tolist(),
        "bootstrap_users": len(p),
        "bootstrap_draws": B,
    }


def fit_weights(z, cols):
    x = z[cols + ["calendar", "kind"]].copy()
    for c in cols:
        x[c] = pd.to_numeric(x[c], errors="coerce")
    y = z.treat.to_numpy(int)
    pred = np.full(len(z), np.nan)
    cv = GroupKFold(n_splits=5)
    for tr, va in cv.split(x, y, z.user_id):
        preprocess = ColumnTransformer(
            [
                (
                    "numeric",
                    Pipeline(
                        [
                            ("missing", SimpleImputer(strategy="median", add_indicator=True)),
                            ("scale", StandardScaler()),
                        ]
                    ),
                    cols,
                ),
                ("categorical", OneHotEncoder(handle_unknown="ignore"), ["calendar", "kind"]),
            ]
        )
        model = Pipeline(
            [
                ("pre", preprocess),
                ("model", LogisticRegression(C=0.5, max_iter=1500, solver="lbfgs")),
            ]
        )
        model.fit(x.iloc[tr], y[tr])
        pred[va] = model.predict_proba(x.iloc[va])[:, 1]
    assert np.isfinite(pred).all()
    return pred, np.where(y == 1, 1 - pred, pred)


def run(cnames=None, output_name="balanced_comparison_results.json", prefix="overlap_v2"):
    from analysis_contract import cohorts_with_offer_grain

    f = pd.read_parquet(PRIVATE / "episode_analysis.parquet")
    f["anchor"] = pd.to_datetime(f.anchor)
    f, co = cohorts_with_offer_grain(f)
    f["calendar"] = f.anchor.dt.strftime("%Y-%m-%d")
    f["kind"] = f.recall_kind.fillna("extension")
    results = []
    for cname in cnames or ["main_simple", "extension_simple"]:
        for pair in [(0.0, 0.2), (0.2, 0.3), (0.2, 0.4), (0.3, 0.4)]:
            initial = f[co[cname] & f.dose.isin(pair) & f.observed_3.eq(1)].copy()
            initial["treat"] = initial.dose.eq(pair[1]).astype("int8")
            item = {
                "cohort": cname,
                "pair": pair,
                "raw_eligible_events": len(initial),
                "windows": [],
                "interpretation": "Window-specific same-day, profile-balanced observed association; not a randomized incremental effect.",
            }
            cached = {}
            for d in [3, 7, 15, 30]:
                z = initial[initial[f"observed_{d}"].eq(1)].copy()
                counts = z.groupby(["calendar", "treat"]).size().unstack().fillna(0)
                common = counts.index[(counts.min(axis=1) >= 20) & (counts.shape[1] == 2)]
                z = z[z.calendar.isin(common)].copy()
                v = {
                    "window": d,
                    "same_day_supported_events": len(z),
                    "common_dates": list(common),
                }
                if (
                    len(z) < 200
                    or z.treat.nunique() < 2
                    or z.groupby("treat").size().min() < 50
                    or z.groupby("treat").user_id.nunique().min() < 20
                ):
                    v["status"] = "insufficient_common_support"
                    item["windows"].append(v)
                    continue
                cols = [
                    c
                    for c in FEATURES
                    if c in z and pd.to_numeric(z[c], errors="coerce").notna().any()
                ]
                signature = hashlib.sha256(z.episode_id.to_numpy("int64").tobytes()).hexdigest()
                if signature in cached:
                    pred, w = cached[signature]
                else:
                    pred, w = fit_weights(z, cols)
                    cached[signature] = (pred, w)
                bs = balance(z, cols, w)
                v.update(
                    {
                        "status": "estimated_observational",
                        "treatment_separability_auc": float(roc_auc_score(z.treat, pred)),
                        "support_p05_p95": float(((pred >= 0.05) & (pred <= 0.95)).mean()),
                        "balance": bs,
                        "max_abs_smd_after": float(max(abs(b["smd_after"]) for b in bs)),
                        "groups": [],
                    }
                )
                for t, g in z.groupby("treat"):
                    ix = z.treat.eq(t).to_numpy()
                    ww = w[ix]
                    v["groups"].append(
                        {
                            "dose": pair[t],
                            "events": len(g),
                            "users": g.user_id.nunique(),
                            "effective_n": float(ww.sum() ** 2 / (ww @ ww)),
                            "propensity_q05": float(np.quantile(pred[ix], 0.05)),
                            "propensity_q50": float(np.quantile(pred[ix], 0.5)),
                            "propensity_q95": float(np.quantile(pred[ix], 0.95)),
                        }
                    )
                v.update(weighted_rates(z, w, f"applied_{d}", B=2000))
                v["balance_sufficient"] = (
                    v["max_abs_smd_after"] <= 0.1
                    and min(g["effective_n"] for g in v["groups"]) >= 50
                )
                item["windows"].append(v)
                z[["episode_id", "user_id", "dose"]].assign(
                    propensity=pred, overlap_weight=w
                ).to_parquet(
                    PRIVATE / f"{prefix}_{cname}_{pair[0]}_{pair[1]}_{d}d.parquet",
                    index=False,
                    compression="zstd",
                )
            results.append(item)
            dump(W / output_name, results)
            mark(
                "balanced_pair_v2_complete",
                cohort=cname,
                pair=pair,
                windows=len(item["windows"]),
            )
    dump(W / output_name, results)


if __name__ == "__main__":
    run()
