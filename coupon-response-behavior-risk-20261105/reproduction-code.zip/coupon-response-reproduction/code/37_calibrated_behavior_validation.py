"""Behavior change checks using accepted, outcome-blind, fully calibrated comparisons only."""

from analysis_contract import *
import importlib.util

spec = importlib.util.spec_from_file_location("_ow", W / "19_balanced_comparisons.py")
ow = importlib.util.module_from_spec(spec)
spec.loader.exec_module(ow)


def run():
    checks = json.loads((W / "covariate_calibration_results.json").read_text())
    out = []
    for r in checks:
        if not r["balance_sufficient"]:
            continue
        name = r["cohort"]
        pair = r["pair"]
        h = r["window"]
        base = "two_week" if name.endswith("stable15") else "one_week"
        w = pd.read_parquet(PRIVATE / f"calibrated_{name}_{pair[0]}_{pair[1]}_{h}d.parquet")
        d = pd.read_parquet(PRIVATE / f"behavior_delta_{name}_{h}d.parquet")
        z = d.merge(
            w[["episode_id", "calibrated_weight"]], on="episode_id", validate="one_to_one"
        )
        z["treat"] = z.dose.eq(pair[1]).astype("int8")
        # All accepted dose20/30 main orders are behavior-extracted; require exact coverage,
        # otherwise a fresh balance calculation would be needed for the subset.
        assert len(z) == len(w)
        cols = [
            c
            for c in z
            if (
                c.endswith("_" + base + "_delta")
                or c.endswith("_" + base + "_before_app_delta")
                or c.endswith("_" + base + "_before_new_coupon_delta")
            )
            and ("new_active" in c or "new_loan_entry" in c)
        ]
        cols += ["placebo_new_active", "placebo_new_loan_entry"]
        for day in [3, 7, 15, 30]:
            if day <= h:
                z[f"repeat_by_{day}"] = z.next_coupon_day.lt(day).astype(float)
                cols.append(f"repeat_by_{day}")
        for col in cols:
            v = ow.weighted_rates(z, z.calibrated_weight.to_numpy(float), col, B=2000)
            out.append(
                {
                    "cohort": name,
                    "pair": pair,
                    "window": h,
                    "metric": col,
                    "events": len(z),
                    "baseline": base,
                    **v,
                }
            )
    dump(W / "calibrated_behavior_results.json", out)
    mark("calibrated_behavior_validation_complete", comparisons=len(out))


if __name__ == "__main__":
    run()
