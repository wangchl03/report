"""Observed, instance-linked selection chain; treatment still defined by sending, never by selection/use."""

from analysis_contract import *


def run():
    f = pd.read_parquet(PRIVATE / "episode_analysis.parquet")
    f["anchor"] = pd.to_datetime(f.anchor)
    f, co = cohorts_with_offer_grain(f)
    e = pd.read_parquet(PRIVATE / "coupon_instance_selection_daily.parquet")
    for k in ["create_date", "expire_date", "event_date"]:
        e[k] = pd.to_datetime(e[k], errors="coerce")
    for k in ["user_id", "coupon_id", "first_epoch", "last_epoch"]:
        e[k] = pd.to_numeric(e[k], errors="coerce")
    e["kind"] = e.event_base.map(
        {
            "boxyvbuxjvvehiiq": "loan_coupon_item",
            "osuxshhfbtlprnip": "loan_coupon_item",
            "vrnfgqufsxosxwgp": "coupon_list_use",
            "vcicilykcblxxksh": "coupon_rule",
        }
    )
    e["relative_day"] = (e.event_date - e.create_date).dt.days
    # Sending is observed independent of all later selection or redemption outcomes.
    c = pd.read_parquet(PRIVATE / "all_issue_histories.parquet")
    for k in ["create_date", "expire_date", "used_date"]:
        c[k] = pd.to_datetime(c[k], errors="coerce")
    for k in ["user_id", "serial_id", "coupon_id", "type", "real_use_amount"]:
        c[k] = pd.to_numeric(c[k], errors="coerce")
    target = c[
        c.type.eq(3)
        & c.coupon_id.isin([119, 124, 153, 157])
        & ((c.expire_date - c.create_date).dt.days + 1).eq(3)
    ].copy()
    target["coupon_no"] = target.coupon_no.astype(str).str.strip()
    assert not target.duplicated("coupon_no").any()
    e = e[e.coupon_no.isin(target.coupon_no)]
    out = {
        "chains": [],
        "by_day": [],
        "selection_timing": [],
        "audit": {
            "instance_user_day_rows": len(e),
            "instance_ids_published": False,
            "instance_key_meaning": "element_id suffix joins coupon_user_copy.coupon_no, not coupon_id",
            "unobserved_selection_does_not_mean_unseen": "Coupons can be preselected/used without a recorded item click; absent clicks are not no-exposure labels.",
        },
    }
    for name in ["main_offer_simple", "extension_offer_simple"]:
        z = f[co[name] & f.dose.gt(0) & f.observed_3.eq(1)].copy()
        ee = e.merge(
            z[
                [
                    "episode_id",
                    "user_id",
                    "anchor",
                    "dose",
                    "first_apply_s",
                    "first_apply_serial",
                ]
            ],
            left_on=["user_id", "create_date"],
            right_on=["user_id", "anchor"],
            validate="many_to_one",
        )
        use = target.merge(
            z[["episode_id", "user_id", "anchor", "dose", "first_apply_serial"]],
            left_on=["user_id", "create_date"],
            right_on=["user_id", "anchor"],
            validate="many_to_one",
        )
        used = use[use.real_use_amount.gt(0)]
        for dose, g in z.groupby("dose"):
            a = ee[ee.dose.eq(dose) & ee.relative_day.lt(3)]
            u = used[used.dose.eq(dose)]
            selected = a[a.kind.eq("loan_coupon_item")]
            pre = selected[selected.first_epoch.lt(selected.first_apply_s)]
            firstused = u[u.serial_id.eq(u.first_apply_serial)]
            out["chains"].append(
                {
                    "cohort": name,
                    "dose": dose,
                    "eligible_credit_orders": len(g),
                    "any_user_application_3": int(g.applied_3.sum()),
                    "loan_coupon_item_selected_events": selected.episode_id.nunique(),
                    "selected_before_first_application_events": pre.episode_id.nunique(),
                    "any_coupon_list_use_events": a[
                        a.kind.eq("coupon_list_use")
                    ].episode_id.nunique(),
                    "rule_read_events": a[a.kind.eq("coupon_rule")].episode_id.nunique(),
                    "issued_coupon_actually_used_events": u.episode_id.nunique(),
                    "first_order_used_issued_coupon_events": firstused.episode_id.nunique(),
                    "actual_used_orders": u[["user_id", "serial_id"]]
                    .drop_duplicates()
                    .shape[0],
                }
            )
        for (dose, day, kind), g in ee.groupby(["dose", "relative_day", "kind"]):
            out["by_day"].append(
                {
                    "cohort": name,
                    "dose": dose,
                    "day": day,
                    "kind": kind,
                    "events": g.episode_id.nunique(),
                    "coupon_instances": g.coupon_no.nunique(),
                }
            )
        aa = (
            ee[ee.kind.eq("loan_coupon_item") & ee.first_epoch.lt(ee.first_apply_s)]
            .sort_values("first_epoch")
            .drop_duplicates("episode_id")
        )
        aa["hours_to_first_application"] = (aa.first_apply_s - aa.first_epoch) / 3600
        for dose, g in aa.groupby("dose"):
            out["selection_timing"].append(
                {
                    "cohort": name,
                    "dose": dose,
                    "selected_before_first_app_events": len(g),
                    "median_hours_to_application": float(g.hours_to_first_application.median()),
                    "within_1h": int(g.hours_to_first_application.le(1).sum()),
                }
            )
    dump(W / "coupon_instance_mechanism_results.json", out)
    mark("coupon_instance_mechanism_complete", chains=len(out["chains"]))


if __name__ == "__main__":
    run()
