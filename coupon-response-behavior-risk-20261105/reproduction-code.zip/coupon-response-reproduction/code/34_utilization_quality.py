"""Check amount-utilization coverage, extreme values, and sensitivity without zero-filling missing credit limits."""

from analysis_contract import *


def run():
    f = pd.read_parquet(PRIVATE / "episode_analysis.parquet")
    f["anchor"] = pd.to_datetime(f.anchor)
    f, co = cohorts_with_offer_grain(f)
    l = pd.read_parquet(PRIVATE / "loans_clean.parquet")
    rows = []
    lg = {u: g[g.funded].sort_values("remit_time") for u, g in l.groupby("user_id", sort=False)}
    for uid, g in f.groupby("user_id", sort=False):
        a = lg.get(uid)
        times = (
            a.remit_time.to_numpy("datetime64[ns]")
            if a is not None
            else np.array([], dtype="datetime64[ns]")
        )
        ratio = a.utilization.to_numpy(float) if a is not None else np.array([], float)
        known = np.isfinite(ratio)
        plausible = known & (ratio >= 0) & (ratio <= 1.03)
        nk = np.r_[0, np.cumsum(known)]
        np_ = np.r_[0, np.cumsum(plausible)]
        sr = np.r_[0, np.cumsum(np.where(plausible, ratio, 0))]
        bad = np.r_[0, np.cumsum(known & ~plausible)]
        inds = np.searchsorted(times, g.anchor.to_numpy("datetime64[ns]"), side="left")
        for e, n in zip(g.episode_id, inds):
            rows.append(
                {
                    "episode_id": e,
                    "fund_util_known_n": nk[n],
                    "fund_util_plausible_n": np_[n],
                    "fund_util_anomalous_n": bad[n],
                    "fund_util_plausible_mean": sr[n] / np_[n] if np_[n] else np.nan,
                    "fund_util_coverage": nk[n] / n if n else np.nan,
                    "prior_fund_n_independent": n,
                }
            )
    x = pd.DataFrame(rows)
    f = f.merge(x, on="episode_id", validate="one_to_one")
    assert f.prior_fund_n.eq(f.prior_fund_n_independent).all()
    out = {"coverage": [], "double_low_sensitivity": []}
    for name in ["main_offer_simple", "extension_offer_simple"]:
        z = f[co[name].to_numpy() & f.dose.gt(0)]
        for dose, g in z.groupby("dose"):
            out["coverage"].append(
                {
                    "cohort": name,
                    "dose": dose,
                    "events": len(g),
                    "mean_known_coverage": float(g.fund_util_coverage.mean()),
                    "all_fund_util_missing": int(g.fund_util_known_n.eq(0).sum()),
                    "any_anomalous_util": int(g.fund_util_anomalous_n.gt(0).sum()),
                    "anomalous_user_mean_gt103": int(g.mean_funded_utilization.gt(1.03).sum()),
                }
            )
        for label, mask in {
            "原始历史均值": z.mean_funded_utilization.lt(0.8),
            "剔除单笔>103%后均值": z.fund_util_plausible_mean.lt(0.8),
            "额度覆盖≥80%且无异常": z.fund_util_coverage.ge(0.8)
            & z.fund_util_anomalous_n.eq(0)
            & z.mean_funded_utilization.lt(0.8),
        }.items():
            zz = z[mask & z.hist_offer_d7_n90.ge(3) & z.hist_offer_d7_rate90.le(0.2)]
            for dose, g in zz.groupby("dose"):
                out["double_low_sensitivity"].append(
                    rm.summarize(g, {"cohort": name, "definition": label, "dose": dose})
                )
    dump(W / "utilization_quality_results.json", out)
    mark("utilization_quality_complete", events=len(f))


if __name__ == "__main__":
    run()
