"""Decompose mature used-order cash profit into current-overdue and other orders."""

from core import *


def run():
    f = pd.read_parquet(PRIVATE / "used_orders_finance.parquet")
    z = f[
        f.whole_mature
        & f.repaid_amt.notna()
        & f.valid_days.eq(3)
        & f.strict_t7.eq(1)
        & f.eligible_offer.eq(1)
        & f.has_amount_coupon.eq(0)
        & f.has_repayment_coupon.eq(0)
        & f.other_application_discount.eq(0)
        & f.fixed_coupon.eq(0)
    ]
    out = []
    for dose, g in z.groupby("dose"):
        total = g.remit_amt.sum()
        r = {"dose": dose, "orders": len(g), "funded_amt": float(total), "parts": []}
        for state, gg in g.assign(current_overdue=g.loan_status_code.eq(8)).groupby(
            "current_overdue"
        ):
            a = gg.remit_amt.sum()
            p = gg.repaid_amt.sum()
            r["parts"].append(
                {
                    "current_status8": bool(state),
                    "orders": len(gg),
                    "funded_amt": float(a),
                    "repaid_amt": float(p),
                    "funded_amount_share": float(a / total),
                    "receipt_remit_ratio": float(p / a),
                    "profit_contribution": float((p - a) / total),
                }
            )
        r["profit_rate"] = float((g.repaid_amt.sum() - total) / total)
        assert abs(sum(v["profit_contribution"] for v in r["parts"]) - r["profit_rate"]) < 1e-12
        out.append(r)
    dump(W / "cash_profit_bridge_results.json", out)
    mark("cash_profit_bridge_complete", groups=len(out))


if __name__ == "__main__":
    run()
