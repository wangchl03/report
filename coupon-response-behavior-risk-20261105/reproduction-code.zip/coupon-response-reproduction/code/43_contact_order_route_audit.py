"""Separate repeated-contact response, unique qualified offer response, and same-order conversion."""

from analysis_contract import *


def run():
    f = pd.read_parquet(PRIVATE / "episode_analysis.parquet")
    f["anchor"] = pd.to_datetime(f.anchor)
    f, co = cohorts_with_offer_grain(f)
    l = pd.read_parquet(PRIVATE / "loans_clean.parquet")[
        ["user_id", "serial_id", "apply_s"]
    ].rename(columns={"serial_id": "latest_credit_serial", "apply_s": "own_order_apply_s"})
    f = f.merge(l, on=["user_id", "latest_credit_serial"], how="left", validate="many_to_one")
    t = (
        f.anchor.dt.tz_localize("America/Belize")
        .astype("datetime64[ns, America/Belize]")
        .astype("int64")
        .to_numpy()
        / 1e9
    )
    for d in [3, 7, 15, 30]:
        f[f"own_order_applied_{d}"] = (
            (f.own_order_apply_s.ge(t) & f.own_order_apply_s.lt(t + d * 86400))
            .astype(float)
            .where(f[f"observed_{d}"].eq(1))
        )
    out = {"routes": [], "contact_ordinal": [], "same_application_reuse": []}
    for name in ["main_offer_simple", "extension_offer_simple"]:
        z = f[co[name].to_numpy()]
        for dose, g in z.groupby("dose"):
            for d in [3, 7, 15, 30]:
                gg = g[g[f"observed_{d}"].eq(1)]
                respond = gg[gg[f"applied_{d}"].eq(1)]
                out["routes"].append(
                    {
                        "cohort": name,
                        "dose": dose,
                        "window": d,
                        "approved_credit_orders": len(gg),
                        "any_user_application_events": int(gg[f"applied_{d}"].sum()),
                        "same_credit_order_applications": int(
                            gg[f"own_order_applied_{d}"].sum()
                        ),
                        "any_user_application_rate": (
                            float(gg[f"applied_{d}"].mean()) if len(gg) else None
                        ),
                        "same_order_application_rate": (
                            float(gg[f"own_order_applied_{d}"].mean()) if len(gg) else None
                        ),
                        "different_first_order_route": int(
                            respond.first_apply_serial.ne(respond.latest_credit_serial).sum()
                        ),
                    }
                )
        for d in [3, 7, 15, 30]:
            g = z[z[f"applied_{d}"].eq(1)]
            out["same_application_reuse"].append(
                {
                    "cohort": name,
                    "window": d,
                    "responding_credit_events": len(g),
                    "unique_application_orders": g[["user_id", "first_apply_serial"]]
                    .drop_duplicates()
                    .shape[0],
                    "reused_application_attributions": int(
                        g.duplicated(["user_id", "first_apply_serial"]).sum()
                    ),
                }
            )
    for allname, simplename in [
        ("main_all_strategy", "main_simple"),
        ("extension_all_strategy", "extension_simple"),
    ]:
        z = f[co[allname].to_numpy()].sort_values(["anchor", "episode_id"]).copy()
        z["contact_ordinal"] = z.groupby(["user_id", "latest_credit_serial"]).cumcount() + 1
        z["contact_band"] = pd.cut(
            z.contact_ordinal,
            [0, 1, 2, 3, np.inf],
            labels=["首次", "第2次", "第3次", "第4次及以上"],
        )
        z = z[z.simple_discount | z.no_coupon_at_anchor]
        for (band, dose), g in z.groupby(["contact_band", "dose"], observed=True):
            out["contact_ordinal"].append(
                rm.summarize(
                    g, {"cohort": simplename, "contact_ordinal": str(band), "dose": dose}
                )
            )
    f[
        ["episode_id", "user_id", "latest_credit_serial"]
        + [f"own_order_applied_{d}" for d in [3, 7, 15, 30]]
    ].to_parquet(
        PRIVATE / "same_order_response_labels.parquet", index=False, compression="zstd"
    )
    dump(W / "contact_order_route_results.json", out)
    mark("contact_order_route_complete", route_cells=len(out["routes"]))


if __name__ == "__main__":
    run()
