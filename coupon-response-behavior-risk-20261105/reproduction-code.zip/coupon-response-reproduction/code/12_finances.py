"""Whole-order finances: each used coupon order counted once, no installment duplication."""

from core import *
from stats_utils import *

MAP = {
    119: 0.20,
    124: 0.40,
    141: 0.20,
    153: 0.20,
    157: 0.30,
    160: 0.30,
    163: 0.20,
    164: 0.40,
    166: 0.20,
}
END = pd.Timestamp("2026-11-04")


def agg(g, keys=None, ci=False):
    r = {
        "orders": len(g),
        "users": g.user_id.nunique(),
        "funded_amt": float(g.remit_amt.sum()),
        "repaid_amt": float(g.repaid_amt.sum()),
        "net_received": float((g.repaid_amt - g.remit_amt).sum()),
        "coupon_used_amt": float(g.real_use_amount.sum()),
        "mean_funded_amt": float(g.remit_amt.mean()) if len(g) else None,
        "median_funded_amt": float(g.remit_amt.median()) if len(g) else None,
        "profit_rate": (
            float((g.repaid_amt.sum() - g.remit_amt.sum()) / g.remit_amt.sum())
            if g.remit_amt.sum() > 0
            else None
        ),
        "overdue_orders": int(g.overdue.sum()),
        "order_overdue_rate": float(g.overdue.mean()) if len(g) else None,
        "ever_late_orders": int(g.ever_late.sum()),
        "ever_late_rate": float(g.ever_late.mean()) if len(g) else None,
        "mean_days_past_due": float(g.days_past_due.mean()) if len(g) else None,
        "mean_loan_day": float(g.loan_day.mean()) if len(g) else None,
    }
    if keys:
        r.update(keys)
    if ci and len(g) >= 20:
        r.update(financial_bootstrap(g, B=2000))
    return r


def run():
    used = pd.read_parquet(PRIVATE / "used_target_orders.parquet")
    loan = pd.read_parquet(PRIVATE / "loan_histories.parquet")
    for f in [used, loan]:
        for c in [
            "user_id",
            "serial_id",
            "coupon_id",
            "valid_days",
            "real_use_amount",
            "discount_pct",
            "discount_pct_raw",
            "remit_amt",
            "repaid_amt",
            "is_remit",
            "loan_status_code",
            "loan_day",
            "total_term",
            "overdue_days",
        ]:
            if c in f:
                f[c] = pd.to_numeric(f[c], errors="coerce")
        for c in [
            "apply_time",
            "apply_date",
            "remit_time",
            "due_date",
            "repaid_time",
            "create_date",
            "expire_date",
        ]:
            if c in f:
                f[c] = pd.to_datetime(f[c], errors="coerce", format="mixed")
    used = used[
        used.create_date.ge(pd.Timestamp("2026-06-15"))
        & used.create_date.lt(pd.Timestamp("2026-10-31"))
    ].copy()
    audit = {
        "used_rows": len(used),
        "used_unique_serials": used.serial_id.nunique(),
        "duplicate_used_keys": int(used.duplicated(["user_id", "serial_id"]).sum()),
    }
    assert not used.duplicated(["user_id", "serial_id"]).any()
    loan = loan.drop_duplicates()
    bad = loan.groupby(["user_id", "serial_id"]).size()
    bad = bad[bad > 1].index
    loan = loan[~pd.MultiIndex.from_frame(loan[["user_id", "serial_id"]]).isin(bad)].copy()
    # Apply time comes from the order source, not coupon use date.
    keep = [
        "user_id",
        "serial_id",
        "loan_type",
        "loan_day",
        "total_term",
        "apply_time",
        "apply_amt",
        "remit_time",
        "remit_amt",
        "repaid_amt",
        "is_remit",
        "due_date",
        "loan_status_code",
        "overdue_days",
        "pre_amt",
        "post_amt",
    ]
    used = used.rename(
        columns={"apply_time": "coupon_apply_time", "apply_amt": "coupon_apply_amt"}
    )
    f = used.merge(
        loan[keep],
        on=["user_id", "serial_id"],
        how="left",
        validate="one_to_one",
        indicator=True,
    )
    audit["unmatched_orders"] = int(f._merge.ne("both").sum())
    audit["missing_receipt_funded_orders"] = int((f.is_remit.eq(1) & f.repaid_amt.isna()).sum())
    f["nominal_discount"] = f.coupon_id.map(MAP)
    f["dose"] = f.nominal_discount
    f["funded"] = f.is_remit.eq(1) & f.remit_amt.gt(0)
    f["whole_mature"] = f.funded & f.due_date.notna() & f.due_date.lt(END)
    f["overdue"] = f.loan_status_code.eq(8).astype("int8")
    f["ever_late"] = f.overdue_days.gt(0).astype("int8")
    f["days_past_due"] = (END - f.due_date).dt.days
    f["apply_month"] = f.apply_time.dt.strftime("%Y-%m")
    f["issue_month"] = f.create_date.dt.strftime("%Y-%m")
    f["use_after_expiry"] = f.apply_time.dt.normalize().gt(f.expire_date)
    audit["after_expiry_orders"] = int(f.use_after_expiry.sum())
    audit["same_coupon_order_apply_clock_mismatch"] = int(
        ((f.apply_time - f.coupon_apply_time).dt.total_seconds().abs() > 1).sum()
    )
    # Use the as-of issue baseline where available; never use current score to describe pre-issue risk.
    p = PRIVATE / "episode_features.parquet"
    if p.exists():
        a = pd.read_parquet(p)
        a["anchor"] = pd.to_datetime(a.anchor)
        a = apply_eligibility_contract(a)
        a.to_parquet(p, index=False, compression="zstd")
        cols = [
            "user_id",
            "anchor",
            "t7_no_open",
            "strict_t7",
            "eligible_offer",
            "open_n",
            "score410",
            "score363",
            "score405",
            "prior_fund_n",
            "churn_days",
            "mean_funded_utilization",
            "hist_offer_d7_rate90",
            "has_amount_coupon",
            "has_repayment_coupon",
            "other_application_discount",
            "fixed_coupon",
            "in_recall",
            "episode_id",
        ]
        f = f.merge(
            a[cols],
            left_on=["user_id", "create_date"],
            right_on=["user_id", "anchor"],
            how="left",
            validate="many_to_one",
        )
    results = {
        "audit": audit,
        "broad_mature": [],
        "monthly": [],
        "products": [],
        "loan_types": [],
        "exact_actual_discount": [],
    }
    mature = f[f.whole_mature & f.repaid_amt.notna()]
    for (dose, valid), g in mature.groupby(["dose", "valid_days"]):
        results["broad_mature"].append(agg(g, {"dose": dose, "valid_days": valid}, ci=True))
    for (dose, mon), g in mature[mature.valid_days.eq(3)].groupby(["dose", "apply_month"]):
        results["monthly"].append(agg(g, {"dose": dose, "apply_month": mon}))
    for (dose, ld), g in mature[mature.valid_days.eq(3)].groupby(["dose", "loan_day"]):
        results["products"].append(agg(g, {"dose": dose, "loan_day": ld}))
    for (dose, lt), g in mature[mature.valid_days.eq(3)].groupby(["dose", "loan_type"]):
        results["loan_types"].append(agg(g, {"dose": dose, "loan_type": lt}))
    for dose, g in mature[mature.discount_pct.isin([0.2, 0.3, 0.4])].groupby("discount_pct"):
        results["exact_actual_discount"].append(agg(g, {"actual_discount": dose}))
    if "t7_no_open" in f:
        results["t7_qualified_mature"] = []
        results["t7_risk_bands"] = []
        results["t7_maturity_sensitivity"] = []
        results["t7_simple_mature"] = []
        results["main_simple_mature"] = []
        t = f[
            f.whole_mature
            & f.repaid_amt.notna()
            & f.valid_days.eq(3)
            & f.strict_t7.eq(1)
            & f.eligible_offer.eq(1)
        ]
        t["risk_band"] = (
            pd.cut(
                t.score410,
                [-np.inf, 450, 500, 528, np.inf],
                labels=["<450", "450-499", "500-527", ">=528"],
                right=False,
            )
            .astype(str)
            .where(t.score410.notna(), "missing")
        )
        for dose, g in t.groupby("dose"):
            results["t7_qualified_mature"].append(agg(g, {"dose": dose}, ci=True))
        pure = t[
            t.has_amount_coupon.fillna(0).eq(0)
            & t.has_repayment_coupon.fillna(0).eq(0)
            & t.other_application_discount.fillna(0).eq(0)
            & t.fixed_coupon.fillna(0).eq(0)
        ]
        for dose, g in pure.groupby("dose"):
            results["t7_simple_mature"].append(agg(g, {"dose": dose}, ci=True))
        for dose, g in pure.groupby("dose"):
            results["main_simple_mature"].append(agg(g, {"dose": dose}, ci=True))
        for (dose, band), g in t.groupby(["dose", "risk_band"]):
            results["t7_risk_bands"].append(agg(g, {"dose": dose, "risk_band": band}))
        # Entire issue cohort can support 30-day return plus at most 60-day contracts by this cutoff.
        z = t[(t.create_date + pd.Timedelta(days=90) <= END) & t.loan_day.le(60)]
        for dose, g in z.groupby("dose"):
            results["t7_maturity_sensitivity"].append(
                agg(
                    g, {"dose": dose, "definition": "issue+90d observed; loan_day<=60"}, ci=True
                )
            )
    f.to_parquet(PRIVATE / "used_orders_finance.parquet", index=False, compression="zstd")
    dump(W / "financial_results.json", results)
    mark("finances_complete", **audit, mature_orders=len(mature))
    print(json.dumps(results["broad_mature"], ensure_ascii=False, default=str), flush=True)


if __name__ == "__main__":
    run()
