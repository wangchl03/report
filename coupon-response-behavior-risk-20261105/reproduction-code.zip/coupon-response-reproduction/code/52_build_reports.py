"""Expanded recall-period reports. Every displayed result is read from computed aggregates.
A/B assignment, observational dose differences, behavior mechanisms and selected loan quality are distinct.
"""

from core import *
from report_visuals import *
from verify_reference import validate

validate()
import re

OUT = ROOT / "reports"
OUT.mkdir(parents=True, exist_ok=True)
FILES = ["01-conversion-behavior.html", "02-customer-strategy.html", "03-profit-risk-test.html"]
TITLES = [
    "转化与行为：30%券A/B与20%／40%召回",
    "用户画像：哪些人响应，哪些人值得测试",
    "盈利与逾期：同笔订单验证与决策规则",
]
STUDIES = [
    "T5_30pct_7day_vs_none",
    "T5_30pct_7day_vs_3day",
    "T5_30pct_3day_vs_none_round1",
    "T5_30pct_3day_vs_none_round2",
]
SHORT = {
    STUDIES[0]: "7月21—24日",
    STUDIES[1]: "8月4—7日",
    STUDIES[2]: "8月18—21日",
    STUDIES[3]: "8月26—28日",
}
LABEL = {
    STUDIES[0]: "30%券策略 vs 原对照",
    STUDIES[1]: "30%七天券 vs 三天券",
    STUDIES[2]: "30%三天券 vs 原对照①",
    STUDIES[3]: "30%三天券 vs 原对照②",
}


def loadjson(name):
    return json.loads((W / name).read_text())


def records(name, key=None):
    x = loadjson(name)
    return x[key] if key else x


def filtered(rows, **kw):
    return [r for r in rows if all(r.get(k) == v for k, v in kw.items())]


def one(rows, **kw):
    return next(r for r in rows if all(r.get(k) == v for k, v in kw.items()))


def baseline_name(k):
    return {
        "score410": "410模型分",
        "score363": "363模型分",
        "score405": "405模型分",
        "prior_fund_n": "历史成功借款次数",
        "churn_days": "流失天数",
        "mean_funded_utilization": "历史额度使用率",
        "hist_offer_d7_rate90": "历史7日提单率（90日）",
        "latest_credit_amt": "最新获额金额",
    }.get(k, k)


def baseline_value(k, v):
    if v is None:
        return "—"
    return (
        pct(v)
        if k in ["mean_funded_utilization", "hist_offer_d7_rate90"]
        else nfmt(v) if k == "latest_credit_amt" else f"{v:.2f}"
    )


def nav():
    return (
        '<a href="index.html">总览</a>'
        + "".join(
            '<a href="' + f + '">' + esc(t.split("：")[0]) + "</a>"
            for f, t in zip(FILES, TITLES)
        )
        + '<a href="#methods">统计口径</a><a href="#appendix">完整代码</a>'
    )


def write(name, title, subtitle, body):
    html = page(title, subtitle, body, nav(), interactive_script()).replace(
        "</style>", EXTRA_CSS + "\n[hidden]{display:none!important}</style>"
    )
    version = hashlib.sha256(
        (W / "expanded_policy_results.json").read_bytes()
        + (W / "pooled_ab_replication_results.json").read_bytes()
    ).hexdigest()[:10]
    html = re.sub(
        r'href="((?!https?://|#)[^"?]+\.(?:html|zip|json))"',
        lambda m: 'href="' + m.group(1) + "?v=" + version + '"',
        html,
    )
    (OUT / name).write_text(html)


def methods(extra=""):
    rows = [
        [
            "研究范围",
            "召回/发券日2026年6月15日—10月30日（含）；不是按用券日期选样本。提单、行为截至11月3日完整业务日；回款、当前状态采用11月4日原冻结查询快照。",
        ],
        [
            "获额分母",
            "召回日前最新一次获额通过（is_pass1=1），recycle_type已知且不等于1。先找最新，再判通过；不回退到更早通过记录。不要求未来用券、提单或放款。",
        ],
        [
            "去重单位",
            "主T7分析：每位用户、每笔最新合格获额，取研究范围内第一次合格三天券召回/名单记录，再区分纯降息与组合策略。同用户不同获额可分别计数。各有效期扩展先在目标券中取首次记录，单独展示。",
        ],
        [
            "T7与T5",
            "主T7要求已全部结清、无在途、距最近干净结清超过7个自然日且结清后未再提单。no_apply_*测试以结清第5天为主，按原测试名单另行分析，不能标成T7或直接外推长流失。",
        ],
        [
            "A/B分析",
            "用户确认no_apply_*为A/B测试，实验组分配30%减息券。按原ab_group保留实验、对照，不按未来是否收到/使用券重分组；每轮测试内，同用户同获额保留最早记录。另核对实际发券、重复干预与基线。",
        ],
        [
            "提单分子",
            "召回日00:00起首次提单；3日=D0—D2、7日=D0—D6、15日=D0—D14、30日=D0—D29。不要求审批通过或放款。按用户追踪，可能重新获额后提单；另列同serial_id直接提单。",
        ],
        [
            "观察期",
            "每个窗口仅使用已完整观察的合格获额分母；主表不同窗口的分母可能不同。A/B四轮均已满30天，可在同一名单比较累计变化。",
        ],
        [
            "收到券与用券",
            "coupon_user_copy为发放记录；coupon_use_record为实际使用记录。用券不作为提单率分母条件。只研究20%、30%、40%比例券；低档券作为后续干预审计，固定126/149不混入。",
        ],
        [
            "券档与金额",
            "119、124、157配置为20%、40%、30%；153等配置缺失券以历史实际使用幅度核验并做敏感性分析。整笔实际幅度=real_use_amount/(apply_amt×产品total_fee)，小数比例；按最近5个百分点归档，不与分期表重复累计。",
        ],
        [
            "行为时点",
            "user_behavior_track_record以已转换的event_time事件时刻为准，并用event_unix毫秒值校验，含义参照tracking_points；event_track_record用create_time交叉核对。统计用户每日有无行为，不能把两张表日志条数直接相加。无日志不等于确定无需求。",
        ],
        [
            "行为基线",
            "T7用前一周同星期基线；流失≥15天可用前两周。T5 A/B改用发券前4个完整日，避免前7日混入结清前行为。行为日差以America/Belize划分。",
        ],
        [
            "历史提单率",
            "发券前第96至第7天的90个成熟获额日：通过且recycle_type非1的不同获额订单数为分母；同订单获额后D0—D6提单为分子。少于3笔单列；缺失不补0。",
        ],
        [
            "历史额度使用率",
            "历史成功放款订单逐笔apply_amt/同serial_id提单前获额金额，再算术平均；97%—103%归100%。历史提额券可造成>103%，单独解释与敏感性检验。",
        ],
        [
            "可用历史",
            "获额源查询自2025-01-01起，借款史按可用全历史；行为最早自2025-11-01起。无法确认历史最新获额、结清状态或行为覆盖时按未知处理，不补造通过或活跃。",
        ],
        [
            "生命周期与评分",
            "借款次数、相邻成功放款间隔、历史结清至再提单间隔、当前非在途天数、近期活跃与提单页均取召回前数据。363/405/410匹配历史获额流水，缺分单列；源分数表缺生成时刻。",
        ],
        [
            "财务与逾期",
            "同一提单订单成功放款且整笔到期才入财务；不要求当天放款。盈利率=(Σrepaid_amt−Σremit_amt)/Σremit_amt；订单逾期率=当前状态8的订单数/到期订单数。实际用券财务与A/B原分组首单财务分开展示。",
        ],
        [
            "金额风险",
            "同一批整笔到期订单：状态8分期合同金额/全部分期合同金额；逾期分期回收率=状态8分期repaid_amt_period/remit_amt_period。先聚合到订单，防止整笔红包和回款被分期关联放大。",
        ],
        [
            "不确定性",
            "差值区间按用户聚类重抽样；分组与指标较多，区间为探索性名义95%。同日、风险层、画像校准仅为观察性复核，不等同随机实验。删截后续提单/发券属于机制敏感性分析，也会引入选择。",
        ],
        [
            "归因限制",
            "发券只有日期，缺精确发送/送达/阅读时间，D0可能早于实际发送。重复发券与自动券影响长期结果；不能用原始响应率排名券的因果效果，也不能把已到期用券订单盈利直接当新增利润。",
        ],
    ]
    return section(
        "口径",
        "统计口径与数据边界",
        table(["项目", "定义"], rows, "展开完整统计口径") + extra,
        "methods",
    )


def appendix():
    p = ROOT / "完整取数PGSQL.sql"
    code = esc(p.read_text()) if p.exists() else ""
    return section(
        "附录",
        "完整取数与分析代码",
        '<p class="note">公开包包含按模块排版的PGSQL、时点特征、A/B检验、行为分析、财务与模型诊断程序及环境依赖。精确复现需同版本内部快照；公开文件不含用户明细、红包实例ID或连接凭据。</p><p><a class="pill" href="../完整取数PGSQL.sql" download>下载完整取数PGSQL</a> <a class="pill" href="../本次独立复现核对.json">查看数据核对结果</a></p><details><summary>展开完整PGSQL代码</summary><pre><code>'
        + code
        + "</code></pre></details>",
        "appendix",
    )


def ab_forest(e, horizons=(3, 7)):
    rows = []
    for st in STUDIES:
        for h in horizons:
            r = one(e["ab_comparisons"], study=st, window=h)
            rows.append(
                {
                    "label": SHORT[st] + " · " + str(h) + "日",
                    "profit_rate": r["difference"],
                    "profit_ci95": r["difference_ci95"],
                    "color": "#38bdf8" if h == 3 else "#a78bfa" if h == 7 else "#34d399",
                }
            )
    return interval_plot(
        rows, title="按原A/B分组：实验组减对照组的提单率差及95%区间", unit="pp"
    )


def ab_full_table(e):
    rows = []
    for st in STUDIES:
        for arm in ["control", "treatment"]:
            r = one(e["ab_rates"], study=st, arm=arm)
            rows.append(
                [
                    SHORT[st],
                    LABEL[st],
                    "实验组" if arm == "treatment" else "对照组",
                    nfmt(r["events"]),
                ]
                + [
                    pct(r["rate_" + str(h)]) + " · " + nfmt(r["y_" + str(h)]) + "人"
                    for h in [3, 7, 15, 30]
                ]
            )
    return table(
        ["批次", "分配政策", "分组", "合格获额数", "3日", "7日", "15日", "30日"],
        rows,
        "展开四轮A/B完整结果",
    )


def horizon_heat(rows, caption):
    vals = []
    counts = []
    for d in [0.2, 0.3, 0.4]:
        r = one(rows, dose=d)
        vals.append(
            [r["rate_" + str(h)] if r["n_" + str(h)] >= 30 else None for h in [3, 7, 15, 30]]
        )
        counts.append(
            [nfmt(r["y_" + str(h)]) + "/" + nfmt(r["n_" + str(h)]) for h in [3, 7, 15, 30]]
        )
    return heatmap(
        [dose_name(d) for d in [0.2, 0.3, 0.4]],
        ["3日", "7日", "15日", "30日"],
        vals,
        counts,
        caption,
    )


def ab_behavior_chart(e, st, source="new", metric="loan_entry"):
    rows = filtered(e["ab_daily"], study=st, source=source, metric=metric)
    days = list(range(-4, 15))
    w = 1100
    h = 330
    l = 90
    r = 70
    t = 55
    b = 62
    mx = max([v["rate"] for v in rows if v["day"] in days] + [0.05]) * 1.2
    xx = lambda d: l + (d + 4) / (18) * (w - l - r)
    yy = lambda v: h - b - v / mx * (h - t - b)
    body = (
        '<text x="18" y="26" class="chart-title">'
        + esc(SHORT[st] + "：每日提单页用户比例（新埋点）")
        + "</text>"
    )
    for j in range(5):
        v = mx * j / 4
        y = yy(v)
        body += f'<path d="M{l},{y} H{w-r}" class="grid"/><text x="{l-12}" y="{y+4}" class="axis" text-anchor="end">{pct(v,0)}</text>'
    for d in days:
        if d in [-4, -1, 0, 2, 4, 6, 8, 10, 12, 14]:
            body += (
                f'<text x="{xx(d)}" y="{h-b+25}" class="axis" text-anchor="middle">D{d}</text>'
            )
    body += f'<path d="M{xx(0)},{t} V{h-b}" stroke="#426c85" stroke-dasharray="5 4"/>'
    for arm, color in [("control", "#94a3b8"), ("treatment", "#a78bfa")]:
        rr = sorted(
            [v for v in rows if v["arm"] == arm and v["day"] in days], key=lambda v: v["day"]
        )
        pts = " ".join(f'{xx(v["day"])},{yy(v["rate"])}' for v in rr)
        body += f'<polyline points="{pts}" fill="none" stroke="{color}" stroke-width="2.5"/>'
        for v in rr:
            body += f'<circle cx="{xx(v["day"])}" cy="{yy(v["rate"])}" r="3" fill="{color}"><title>D{v["day"]} {arm}: {pct(v["rate"])}</title></circle>'
    body += '<text x="90" y="318" class="axis">灰：原对照；紫：30%实验组。固定分母；D0为发券日，包含提单后行为。</text>'
    return '<div class="chart">' + svg_base(w, h, body, "A/B发券前后每日提单页覆盖") + "</div>"


def ab_flow(e):
    body = (
        '<div class="controls"><label>选择测试<select data-panels="flow">'
        + "".join('<option value="' + st + '">' + SHORT[st] + "</option>" for st in STUDIES)
        + "</select></label></div>"
    )
    for st in STUDIES:
        inside = '<text x="18" y="25" class="chart-title">3日流程：合格获额 → 提单前进入页面 → 有页面且完成提单</text>'
        for i, arm in enumerate(["control", "treatment"]):
            r = one(e["ab_funnel"], study=st, arm=arm, source="union", window=3)
            y = 64 + i * 144
            col = "#94a3b8" if arm == "control" else "#a78bfa"
            inside += f'<text x="18" y="{y+49}" class="axis">{"实验组" if arm=="treatment" else "对照组"}</text>'
            nodes = [
                ("合格获额", r["events"], "作为原始分母"),
                (
                    "提单前进入页面",
                    r["before_first_app_page_events"],
                    pct(r["before_first_app_page_events"] / r["events"]) + " / 合格获额",
                ),
                (
                    "有页面且提单",
                    r["applicants_with_prior_page"],
                    pct(r["page_to_application_share"]) + " / 前一节点",
                ),
            ]
            for j, (title, n, desc) in enumerate(nodes):
                x = 120 + j * 310
                inside += f'<rect x="{x}" y="{y}" width="250" height="105" rx="10" fill="#14273d" stroke="{col}"/><text x="{x+18}" y="{y+25}" class="axis">{title}</text><text x="{x+18}" y="{y+56}" class="value" fill="{col}">{nfmt(n)}</text><text x="{x+18}" y="{y+83}" class="axis">{desc}</text>'
                if j < 2:
                    inside += f'<path d="M{x+262},{y+49} H{x+294} l-7,-5 M{x+294},{y+49} l-7,5" stroke="{col}" fill="none" stroke-width="2"/>'
            inside += f'<text x="120" y="{y+125}" class="axis">后台实际3日提单 {nfmt(r["applicants"])} 人；其中提单前有页面记录 {nfmt(r["applicants_with_prior_page"])} 人。两套埋点按用户日取并集。</text>'
        body += (
            '<div data-panel="flow" data-value="'
            + st
            + '"><div class="chart">'
            + svg_base(1100, 370, inside, "A/B从合格获额到提单页和后台提单的流程")
            + "</div></div>"
        )
    return body


def report1():
    e = records("expanded_policy_results.json")
    rr = filtered(records("offer_grain_results.json", "rates"), cohort="main_offer_simple")
    main = [r for r in rr if r["dose"] > 0]
    j = one(e["ab_comparisons"], study=STUDIES[0], window=7)
    j30 = one(e["ab_comparisons"], study=STUDIES[0], window=30)
    body = section(
        "一",
        "7、8月30%券A/B：分批核验，合并同政策测试",
        lead(
            "7月30%策略与8月三天券合并均出现短期转化提升；长期效果仍要按政策、成熟窗口和后续干预分别判断。这些T5结果不能直接外推为长流失T7增量。"
        )
        + ab_forest(e)
        + conclusion(
            [
                f'7月21—24日：7日提单率{pct(j["rates"][0])}→{pct(j["rates"][1])}，差{pp(j["difference"])}，95%区间{pp(j["difference_ci95"][0])}至{pp(j["difference_ci95"][1])}。',
                f'同一批用户30日差为{pp(j30["difference"])}；这是整套分配政策的结果，含执行偏差及后续干预，不能解释为单张券的纯效果。',
                "7月实验组393笔收到七天30%券、147笔收到三天30%券；对照组也有自动低档券，结果属于整套30%策略，不能归为七天券的单独效果。",
                "8月七天券与三天券直接对照未确认优势。两轮三天券点估计不同，效果差异本身仍需检验；下方保留逐轮与合并结果。",
            ]
        )
        + ab_full_table(e)
        + table(
            [
                "批次源表",
                "原分组",
                "合格获额",
                "3日提单率",
                "7日提单率",
                "15日提单率",
                "30日提单率",
            ],
            [
                [
                    r["batch"],
                    "实验组" if r["arm"] == "treatment" else "对照组",
                    nfmt(r["events"]),
                ]
                + [
                    pct(r["rate_" + str(h)]) + " (" + nfmt(r["y_" + str(h)]) + ")"
                    for h in [3, 7, 15, 30]
                ]
                for r in e["ab_batch_rates"]
            ],
            "展开各日批次结果，检查聚合是否掩盖差异",
        )
        + table(
            ["研究", "源表", "用户阶段", "合格获额", "日期"],
            [
                [
                    LABEL[r["study"]],
                    "<br>".join(r["source_tables"]),
                    "结清第" + nfmt(r["churn_min"]) + "天",
                    nfmt(r["events"]),
                    r["first_date"] + "—" + r["last_date"],
                ]
                for r in e["ab_scope"]
            ],
            "展开名单来源与生命周期",
        )
        + table(
            ["研究", "基线特征", "对照均值", "实验均值", "SMD", "对照有效值", "实验有效值"],
            [
                [
                    SHORT[r["study"]],
                    baseline_name(r["feature"]),
                    baseline_value(r["feature"], r["control_mean"]),
                    baseline_value(r["feature"], r["treatment_mean"]),
                    ("—" if r["smd"] is None else f'{r["smd"]:.3f}'),
                    nfmt(r["control_known"]),
                    nfmt(r["treatment_known"]),
                ]
                for r in e["ab_balance"]
            ],
            "展开A/B事前画像平衡",
        )
        + table(
            ["研究", "原分组", "当日实际发券组合", "数量", "占比"],
            [
                [
                    SHORT[r["study"]],
                    "实验组" if r["arm"] == "treatment" else "对照组",
                    r["signature"],
                    nfmt(r["events"]),
                    pct(r["share"]),
                ]
                for r in e["ab_issuance"]
            ],
            "展开实际发券执行核对",
        )
        + '<p class="note">按原ab_group分析，不把未领券者或未用券者从实验组删除。用户已确认A/B设计；现有数据未保留分配日志，多指标区间按探索性结果解读。</p>',
        "ab",
    )
    allrows = [
        r
        for r in filtered(records("offer_grain_results.json", "rates"), cohort="main_offer_all")
        if r["dose"] > 0
    ]
    pooled = records("pooled_ab_replication_results.json")
    plots = []
    for r in pooled["raw"]:
        plots.append(
            {
                "label": str(r["window"]) + "日 · 同政策合并",
                "profit_rate": r["difference"],
                "profit_ci95": r["difference_ci95"],
                "color": COLORS[0.3],
            }
        )
    p3 = one(pooled["raw"], window=3)
    p30 = one(pooled["raw"], window=30)
    ps = one(pooled["calendar_standardized"], window=3)
    rd = one(pooled["round_difference"], window=3)
    body += section(
        "合并",
        "8月同为30%三天券：合并后支持短期提单提升",
        interval_plot(plots, title="8月两轮同政策合并：实验组减原对照组提单率", unit="pp")
        + conclusion(
            [
                f'两轮合计1,546名用户：3日提单率{pct(p3["rates"][0])}→{pct(p3["rates"][1])}，差{pp(p3["difference"])}，95%区间{pp(p3["difference_ci95"][0])}至{pp(p3["difference_ci95"][1])}。',
                f'按各发券批次统一权重后，3日差为{pp(ps["difference"])}；30日合并差为{pp(p30["difference"])}，区间跨0，长期增量尚不明确。',
                f'两轮3日效果之差为{pp(rd["difference_of_effects"])}，95%区间{pp(rd["difference_ci95"][0])}至{pp(rd["difference_ci95"][1])}；不能仅凭一轮显著、一轮不显著，就认定效果真有差别。',
            ]
        )
        + table(
            ["窗口", "对照提单率", "实验提单率", "合并差值", "95%区间", "批次标准化差值"],
            [
                [
                    str(r["window"]) + "日",
                    pct(r["rates"][0]),
                    pct(r["rates"][1]),
                    pp(r["difference"]),
                    pp(r["difference_ci95"][0]) + "至" + pp(r["difference_ci95"][1]),
                    pp(one(pooled["calendar_standardized"], window=r["window"])["difference"]),
                ]
                for r in pooled["raw"]
            ],
            "展开合并与批次标准化结果",
        )
        + '<p class="note">只合并两轮同为30%三天券对原对照的测试；不将七天券混入三天券结果。仍保留每轮结果，避免只选择效果较好的批次。</p>',
        "pooled",
    )
    body += section(
        "二",
        "扩展T7主样本：20%、30%、40%的实际响应",
        rate_tiles(allrows, title="三天券全部策略：3日用户提单响应率")
        + horizon_heat(allrows, "先保留当日所有策略；不把提额组合当纯降息")
        + "<h3>仅降息子样本：剔除当日其他优惠组合</h3>"
        + rate_tiles(main)
        + horizon_heat(main, "6月15日—10月30日；仅降息三天券，首次合格召回")
        + conclusion(
            [
                "主表分母是召回日前最新获额通过、recycle_type非1的合格获额记录，包含后续未提单者；不是只看实际用券者。",
                "6月已有合格发券记录，但三天券均叠加其他优惠，计入全部策略，未进入仅降息子样本；各有效期扩展另列。",
                f'发券范围内，同日收到不同目标券档的用户日有{nfmt(e["issue_policy_audit"]["different_target_doses_same_day"])}个，不强行归入单一券档；同档但多有效期另列。',
                "各档人群、发放月份、历史意愿和风险不同；原始响应率高低不能直接作为优惠优劣排名。不同窗口各取成熟分母。",
            ]
        )
        + table(
            ["券档", "合格获额", "3日", "7日", "15日", "30日", "15日内再次发券比例"],
            [
                [dose_name(r["dose"]), nfmt(r["events"])]
                + [
                    pct(r["rate_" + str(h)])
                    + " ("
                    + nfmt(r["y_" + str(h)])
                    + "/"
                    + nfmt(r["n_" + str(h)])
                    + ")"
                    for h in [3, 7, 15, 30]
                ]
                + [pct(r["censor_repeat_coupon_15"])]
                for r in main
            ],
            "展开完整分子、分母及重复发券",
        )
        + table(
            ["月", "有效天数", "实际发券用户日", "最新获额通过非1", "其中合格T7用户日"],
            [
                [
                    r["month"],
                    (nfmt(r["valid_days"]) if r["valid_days"] is not None else "同日多有效期"),
                    nfmt(r["raw_contacts"]),
                    nfmt(r["passed_non1"]),
                    nfmt(r["qualified_t7"]),
                ]
                for r in e["period_coverage"]
            ],
            "展开6—10月发券覆盖与资格筛选",
        )
        + table(
            [
                "券档",
                "有效天数",
                "当日策略",
                "合格获额",
                "3日提单率",
                "7日提单率",
                "30日提单率",
            ],
            [
                [
                    dose_name(r["dose"]),
                    nfmt(r["valid_days"]),
                    "仅降息" if r["pure"] else "叠加其他政策",
                    nfmt(r["records"]),
                ]
                + [
                    pct(r["rate_" + str(h)])
                    + " ("
                    + nfmt(r["y_" + str(h)])
                    + "/"
                    + nfmt(r["n_" + str(h)])
                    + ")"
                    for h in [3, 7, 30]
                ]
                for r in e["duration_rates"]
            ],
            "展开2天、3天、7天有效期独立统计",
        ),
        "t7",
    )
    calibration = filtered(
        records("covariate_calibration_results.json"), cohort="main_offer_simple"
    )
    rplot = []
    tab = []
    for r in calibration:
        if r["pair"] != [0.2, 0.3]:
            continue
        tab.append(
            [
                str(r["window"]) + "日",
                nfmt(r["events"]),
                "通过" if r["balance_sufficient"] else "未通过",
                pct(r.get("difference")),
                pp(r["ci95"][0]) + "至" + pp(r["ci95"][1]) if r.get("ci95") else "不输出",
            ]
        )
        if r["balance_sufficient"]:
            rplot.append(
                {
                    "label": str(r["window"]) + "日 · 30%减20%",
                    "profit_rate": r["difference"],
                    "profit_ci95": r["ci95"],
                    "color": COLORS[0.3],
                }
            )
    body += section(
        "三",
        "同日与同画像复核：通过平衡后才输出差值",
        interval_plot(rplot, title="30%相对20%：观察性画像校准结果", unit="pp")
        + conclusion(
            [
                "先限制共同日期、原风险层与名单类型，再平衡事前评分、流失、使用率、历史提单率与行为；未通过平衡的比较不输出效果。",
                "画像校准不能消除未记录的分配原因。40%已有同日同风险层的初步候选，但完整事前画像未通过预设平衡；不能输出可信的可比差值。",
            ]
        )
        + table(["窗口", "共同样本", "平衡", "差值", "95%区间"], tab, "展开校准核对")
        + table(
            ["比较", "组别", "共同候选记录", "预设平衡矩", "能否匹配共同目标"],
            [
                [
                    dose_name(r["pair"][0]) + " vs " + dose_name(r["pair"][1]),
                    dose_name(r["dose"]),
                    nfmt(r["events"]),
                    nfmt(r["moments"]),
                    "可行" if r["feasible_exact_common_moments"] else "不可行",
                ]
                for r in records("balance_feasibility_results.json")
            ],
            "展开40%比较的事前平衡可行性核验",
        )
        + '<p class="note">该核验只使用事前特征，不使用提单结果。每组候选虽存在，但在本次预设的共同目标下无法同时满足全部画像矩；不为得到优惠差值而放松条件。</p>',
        "balanced",
    )
    july = e["july40_contacts"]
    cards = (
        '<div class="grid-cards">'
        + "".join(
            card(
                r["day"],
                nfmt(r["users"]) + "人",
                ("三天40%券" if r["coupon_id"] == 124 else "七天40%券")
                + "；其中"
                + nfmt(r["in_july16_users"])
                + "人属于7月16日名单",
                COLORS[0.4],
            )
            for r in july
        )
        + "</div>"
    )
    body += section(
        "四",
        "7月40%券：同一批人的连续触达",
        cards
        + conclusion(
            [
                "7月20日和23日的40%发券均来自7月16日那批用户，不能算作三个独立实验。",
                "自动低档券和再次40%券均会影响后续提单；低于20%的券不列为目标档，但保留在干预时间审计中。",
            ]
        )
        + '<p class="note">此处为实际发券人数；主T7表还需通过获额、结清、流失和去重筛选，因此人数不同。</p>',
        "july40",
    )
    for st in STUDIES:
        body += section(
            "行为",
            SHORT[st] + "：红包是否改变了提单页行为",
            ab_behavior_chart(e, st) + _ab_behavior_effect(e, st),
            "behavior-" + str(STUDIES.index(st)),
        )
    body += section(
        "核验",
        "提单页埋点覆盖：没有日志不代表没有完成流程",
        table(
            [
                "研究",
                "窗口",
                "埋点来源",
                "原分组",
                "有提单页行为",
                "后台提单人数",
                "提单前有页面记录",
                "占后台提单人数",
            ],
            [
                [
                    SHORT[r["study"]],
                    str(r["window"]) + "日",
                    {"new": "新埋点", "legacy": "旧埋点", "union": "两套并集"}[r["source"]],
                    "实验组" if r["arm"] == "treatment" else "对照组",
                    nfmt(r["seen_loanpage_events"]),
                    nfmt(r["applicants"]),
                    nfmt(r["applicants_with_prior_page"]),
                    pct(r["recorded_prior_page_share_of_applicants"]),
                ]
                for r in e["ab_funnel"]
            ],
            "展开提单页与后台订单的交叉覆盖",
        )
        + conclusion(
            [
                "后台提单来自订单表；两套埋点并集对四轮A/B的3日实际提单者，提单前页面覆盖均超过98%。",
                "提单率改善与日均提单页比例变化不显著可以同时出现；现有数据不能据此断定红包不起作用，也不能证明其行为影响持续一周。",
            ]
        ),
        "trackingcoverage",
    )
    profiles = filtered(
        records("behavior_state_corrected_results.json", "profiles"),
        cohort="main_offer_simple",
        window=15,
    )
    timing = table(
        ["研究", "首次提单阶段", "对照占比", "实验占比", "实验减对照", "95%区间"],
        [
            [
                SHORT[r["study"]],
                r["period"],
                pct(r["rates"][0]),
                pct(r["rates"][1]),
                pp(r["difference"]),
                pp(r["difference_ci95"][0]) + "至" + pp(r["difference_ci95"][1]),
            ]
            for r in e["ab_timing"]
        ],
        "展开首次提单分阶段差异（共同30日成熟分母）",
    )
    flow = table(
        ["研究", "原分组", "提单前进入页面人数", "其中3日提单人数", "页面后提单比例"],
        [
            [
                SHORT[r["study"]],
                "实验组" if r["arm"] == "treatment" else "对照组",
                nfmt(r["before_first_app_page_events"]),
                nfmt(r["applicants_with_prior_page"]),
                pct(r["page_to_application_share"]),
            ]
            for r in e["ab_funnel"]
            if r["source"] == "union" and r["window"] == 3
        ],
        "展开页面到提单的描述性流程",
    )
    body += section(
        "阶段",
        "提单是提前发生，还是长期新增",
        ab_flow(e)
        + timing
        + flow
        + conclusion(
            [
                "同一成熟名单拆成D0、D1—D2、D3—D6、D7—D14、D15—D29，阶段占比可加总为30日提单率。",
                "页面后提单比例以已经出现页面行为者为分母，属于后续行为条件统计；只能辅助解释流程，不能单独当红包的因果效果。",
                "8月第一轮早期提升伴随后段回落；30日差值区间仍宽，不能仅凭短期显著、长期不显著就断言全部是提前提单。",
            ]
        ),
        "timing",
    )
    body += section(
        "五",
        "T7行为：长期活跃不等于三天券持续作用",
        daily_heat(profiles, "同一D15成熟分母：发券前7日至发券后13日")
        + conclusion(
            [
                "活跃、进入提单页、实际首次提单依次核对；提单后浏览和还款也会增加日志，不能全部算成需求提升。",
                "两周后观察到行为差异，并不能证明单张三天券影响持续一周；需排查重复发券、提单后行为、发券日前趋势及原人群差异。",
            ]
        )
        + _behavior_sensitivity(),
        "t7behavior",
    )
    mech = filtered(
        records("coupon_instance_mechanism_results.json", "chains"), cohort="main_offer_simple"
    )
    body += section(
        "六",
        "发放—提单—用券：核对具体红包实例",
        mechanism_cards([r for r in mech if r["dose"] > 0])
        + conclusion(
            [
                "使用coupon_no及选券事件核对具体实例，不能仅凭coupon_id配置判断用户使用了本次券。",
                "没有主动选券点击不等于未见券：部分订单自动使用优惠；发放记录也不能替代送达、阅读日志。",
            ]
        ),
        "instance",
    )
    routes = [
        r
        for r in filtered(
            records("contact_order_route_results.json", "routes"),
            cohort="main_offer_simple",
            window=3,
        )
        if r["dose"] > 0
    ]
    body += section(
        "关联",
        "合格获额用户响应与原获额订单直接转化",
        table(
            [
                "券档",
                "合格获额分母",
                "用户3日首次提单",
                "其中同serial_id提单",
                "同订单直接提单率",
                "另一个serial_id首次提单",
            ],
            [
                [
                    dose_name(r["dose"]),
                    nfmt(r["approved_credit_orders"]),
                    nfmt(r["any_user_application_events"]),
                    nfmt(r["same_credit_order_applications"]),
                    pct(r["same_order_application_rate"]),
                    nfmt(r["different_first_order_route"]),
                ]
                for r in routes
            ],
            "展开响应提单与原获额serial_id的关联",
        )
        + conclusion(
            [
                "主指标衡量合格获额对应的用户是否在召回后提单；允许用户重新获额并使用新订单提单，因此不是原获额serial_id的直接订单转化率。",
                "盈利和逾期始终匹配这笔实际首次提单订单本身；不替换为用户其他后续放款订单。",
            ]
        ),
        "order-route",
    )
    body += methods() + appendix()
    write(
        FILES[0],
        TITLES[0],
        "召回批次：2026年6月15日—10月30日 · 原分组A/B、T7与重复触达分别核验",
        body,
    )


def _ab_behavior_effect(e, st):
    rows = []
    tab = []
    for period in ["D0—D2", "D3—D6", "D7—D13", "D14—D29"]:
        r = one(
            e["ab_behavior_effects"],
            study=st,
            source="new",
            metric="loan_entry",
            period=period,
            version="change_vs_pre4",
        )
        rows.append(
            {
                "label": period,
                "profit_rate": r["difference"],
                "profit_ci95": r["difference_ci95"],
                "color": COLORS[0.3],
            }
        )
        for source in ["new", "legacy"]:
            s = one(
                e["ab_behavior_effects"],
                study=st,
                source=source,
                metric="loan_entry",
                period=period,
                version="change_vs_pre4",
            )
            tab.append(
                [
                    period,
                    "新埋点" if source == "new" else "旧埋点",
                    pp(s["difference"]),
                    pp(s["difference_ci95"][0]) + "至" + pp(s["difference_ci95"][1]),
                ]
            )
    r0 = rows[0]
    r7 = rows[2]
    return (
        interval_plot(
            rows, title="每日提单页覆盖变化差：相对发券前4日的实验组减对照组", unit="pp"
        )
        + conclusion(
            [
                f'D0—D2变化差{pp(r0["profit_rate"])}；D7—D13变化差{pp(r7["profit_rate"])}。区间跨0表示尚未确认该阶段仍有差异。',
                "此处是每日行为比例，不能与“至少一次提单”的累计转化率混用；T5基线只用前4个完整日。",
            ]
        )
        + table(["阶段", "埋点来源", "日均覆盖变化差", "95%区间"], tab, "展开新旧埋点交叉核对")
    )


def _behavior_sensitivity():
    rows = []
    for suf, label in [
        ("delta", "包含全部后续行为"),
        ("before_app_delta", "仅首次提单前"),
        ("before_new_coupon_delta", "再排除后续发券后"),
    ]:
        a = filtered(
            records("calibrated_behavior_results.json"),
            cohort="main_offer_simple_stable15",
            window=15,
            metric="D7—D13_new_loan_entry_two_week_" + suf,
        )
        for r in a:
            if r.get("ci95"):
                rows.append(
                    {
                        "label": label,
                        "profit_rate": r["difference"],
                        "profit_ci95": r["ci95"],
                        "color": COLORS[0.3],
                    }
                )
    return interval_plot(rows, title="流失≥15天：D7—D13提单页变化差的机制敏感性检验", unit="pp")


def report2():
    data = records("demand_response_profile_results.json")
    rows = filtered(data["univariate"], cohort="main_offer_simple")
    recent = one(rows, dimension="recent_state", level="近7天已见提单页", dose=0.2)
    silent = one(rows, dimension="recent_state", level="近14天未见活跃", dose=0.2)
    dual = one(rows, dimension="rate_util_cell", level="低提单＋低使用", dose=0.2)
    kpis = (
        '<div class="grid-cards">'
        + card(
            "20%券 · 近7天已见提单页",
            pct(recent["rate_3"]),
            nfmt(recent["y_3"]) + "/" + nfmt(recent["n_3"]) + "；3日提单",
        )
        + card(
            "20%券 · 近14天未见活跃",
            pct(silent["rate_3"]),
            nfmt(silent["y_3"]) + "/" + nfmt(silent["n_3"]) + "；3日提单",
        )
        + card(
            "20%券 · 双低用户",
            pct(dual["rate_3"]),
            nfmt(dual["y_3"]) + "/" + nfmt(dual["n_3"]) + "；双低仍可能有需求",
        )
        + "</div>"
    )
    body = section(
        "一",
        "先识别需求，再测试折扣",
        kpis
        + lead(
            "近期进入提单页、历史借款节奏和非在途时长可以帮助筛选响应用户。它们预测“谁会提单”，尚不能直接确定“给谁更高红包才有增量”。"
        )
        + _feature_explorer(rows)
        + conclusion(
            [
                "高响应画像适合提高触达优先级；要确认红包对某类用户更有效，必须比较同类用户的实验与对照差值。",
                f'20%券组：近期提单页用户3日响应为{pct(recent["rate_3"])}，14天未见活跃为{pct(silent["rate_3"])}；这是响应画像差异，不是优惠增量差异。',
            ]
        ),
        "profiles",
    )
    cells = ["低提单＋低使用", "低提单＋高使用", "高提单＋低使用", "高提单＋高使用"]
    vv = []
    nn = []
    for cell in cells:
        v = []
        n = []
        for d in [0.2, 0.3, 0.4]:
            r = next(
                (
                    r
                    for r in rows
                    if r["dimension"] == "rate_util_cell"
                    and r["level"] == cell
                    and r["dose"] == d
                ),
                None,
            )
            v.append(r["rate_3"] if r and r["n_3"] >= 30 else None)
            n.append(nfmt(r["y_3"]) + "/" + nfmt(r["n_3"]) if r else "无样本")
        vv.append(v)
        nn.append(n)
    body += section(
        "二",
        "历史提单率×额度使用率：双低不能直接排除",
        heatmap(
            cells,
            ["20%券", "30%券", "40%券"],
            vv,
            nn,
            "首次合格T7召回：3日提单率；少于30笔不着色",
        )
        + conclusion(
            [
                "低提单：成熟历史获额至少3笔、7日提单率≤20%；低使用：历史成功放款额度使用率算术平均<80%。",
                "同一格仍可能混合“近期看过提单页”与“长期沉默”用户。先做需求交叉分层，不能仅凭一格平均值决定是否发券。",
            ]
        )
        + _double_low_joint(data),
        "demand",
    )
    f = pd.read_parquet(PRIVATE / "demand_profiles.parquet")
    from analysis_contract import cohorts_with_offer_grain

    f, co = cohorts_with_offer_grain(f)
    z = f[co["main_offer_simple"] & f.churn_days.ge(91) & f.score410.ge(528) & f.dose.gt(0)]
    states = [
        "近7天已见提单页",
        "近7天活跃、未见提单页",
        "上周有活跃、本周沉默",
        "近14天未见活跃",
    ]
    values = []
    counts = []
    for d in [0.2, 0.3, 0.4]:
        v = []
        n = []
        for st in states:
            g = z[z.dose.eq(d) & z.recent_state.eq(st) & z.observed_3.eq(1)]
            v.append(float(g.applied_3.mean()) if len(g) >= 30 else None)
            n.append(nfmt(g.applied_3.sum()) + "/" + nfmt(len(g)))
        values.append(v)
        counts.append(n)
    body += section(
        "三",
        "长流失、低意向：关注需求恢复，不能只加折扣",
        heatmap(
            [dose_name(d) for d in [0.2, 0.3, 0.4]],
            ["近期提单页", "活跃未见提单页", "上周活跃后沉默", "14天未见活跃"],
            values,
            counts,
            "流失≥91天、410≥528；3日提单率",
        )
        + conclusion(
            [
                "528是本次沿用的画像分层值，不能替代风控准入。持续沉默也可能是未送达或没有看到券，当前缺少送达、阅读数据。",
                "下一步将“唤醒内容/渠道”与“券强度”分开测试；以首次进入提单页、提单率及同笔订单成熟盈利共同验收。",
                "当前数据尚不能确认40%券能解决长期低意向；不能用少量高响应或零响应样本推出普遍结论。",
            ]
        )
        + table(
            ["券档", "行为状态", "名单意愿层", "合格获额", "3日提单率"],
            [
                [
                    dose_name(r["dose"]),
                    r["recent_state"],
                    r["rank"],
                    nfmt(r["n_3"]),
                    pct(r["rate_3"]),
                ]
                for r in filtered(
                    data["long_silent"], cohort="main_offer_simple", risk="410≥528"
                )
            ],
            "展开长流失与原名单意愿层交叉结果",
        ),
        "silent",
    )
    e = records("expanded_policy_results.json")
    tab = []
    for r in e["ab_subgroup_comparisons"]:
        if r["dimension"] == "发券前4天提单页" and r["window"] == 3:
            tab.append(
                [
                    SHORT[r["study"]],
                    r["level"],
                    nfmt(r["events"]),
                    pp(r["difference"]),
                    pp(r["difference_ci95"][0]) + "至" + pp(r["difference_ci95"][1]),
                ]
            )
    body += section(
        "四",
        "哪类用户受券影响更大：用A/B检验画像差值",
        table(
            ["研究", "前4天提单页", "合格获额", "3日实验减对照", "95%区间"],
            tab,
            "展开近期提单页分层A/B结果",
        )
        + conclusion(
            [
                "近期提单页用户自身响应率高，不代表其红包增量更高；需要检验“有行为”和“无行为”两层的处理效应差异。",
                "借款次数、410分、额度使用率、历史提单率的分层结果用于下一轮假设；本轮多重探索不能直接固化成精准发券规则。",
            ]
        )
        + table(
            ["研究", "维度", "层级", "窗口", "样本", "实验减对照", "95%区间"],
            [
                [
                    SHORT[r["study"]],
                    r["dimension"],
                    r["level"],
                    str(r["window"]) + "日",
                    nfmt(r["events"]),
                    pp(r["difference"]),
                    pp(r["difference_ci95"][0]) + "至" + pp(r["difference_ci95"][1]),
                ]
                for r in e["ab_subgroup_comparisons"]
            ],
            "展开完整生命周期与行为分层A/B结果",
        ),
        "uplift",
    )
    hist = records("historical_ab_validation_results.json")
    hplots = []
    htab = []
    for st, lab in [
        ("T7_July08_high_discount", "7月8日较高优惠组合"),
        ("T7_July08_utilization_policy", "7月8日使用率分配策略"),
    ]:
        for h in [7, 30]:
            r = one(
                hist["comparisons"], study=st, scope="qualified_unique_credit_orders", window=h
            )
            hplots.append(
                {
                    "label": lab + " · " + str(h) + "日",
                    "profit_rate": r["difference"],
                    "profit_ci95": r["difference_ci95"],
                    "color": COLORS[0.3] if h == 7 else COLORS[0.2],
                }
            )
        for r in filtered(hist["rates"], study=st, scope="qualified_unique_credit_orders"):
            htab.append(
                [lab, "实验组" if r["arm"] == "treatment" else "对照组", nfmt(r["events"])]
                + [pct(r["rate_" + str(h)]) for h in [3, 7, 15, 30]]
            )
    body += section(
        "历史",
        "长流失T7政策测试：不能把组合效应算给单一券档",
        interval_plot(hplots, title="7月8日原政策分组：实验组减对照组提单率", unit="pp")
        + table(
            ["测试", "分组", "合格获额", "3日", "7日", "15日", "30日"],
            htab,
            "展开7月8日历史测试",
        )
        + conclusion(
            [
                "较高优惠组合测试没有确认稳定的长期增量；按使用率分配的另一政策组合表现较好，但同时改变了提额与降息。",
                "这些名单比T5更接近长流失召回场景，但它们无法分离出单独30%券或40%券的净效应，不能据此直接为所有沉默用户加大优惠。",
            ]
        ),
        "historical-t7",
    )
    model = records("response_ranking_results.json")
    rowsm = model["models"]
    act = one(rowsm, name="recent_activity")
    full = one(rowsm, name="full_baseline")
    pair = records("model_paired_uncertainty_results.json")
    body += section(
        "五",
        "模型诊断：意愿排序与优惠决策分开",
        heatmap(
            ["活跃4特征·逻辑回归", "需求15特征·逻辑回归", "画像58特征·LightGBM"],
            ["测试AUC", "测试PR-AUC", "前20%提单率"],
            [[r["test"]["auc"], r["test"]["pr_auc"], r["test"]["top20_rate"]] for r in rowsm],
            None,
            "时间外测试：仅历史已发券T7用户；三列均为0—1数值，第三列为提单比例",
            False,
        )
        + table(
            ["模型", "特征数", "测试记录", "AUC", "PR-AUC", "前20%提单/人数", "前20%提单率"],
            [
                [
                    {
                        "recent_activity": "活跃特征·逻辑回归",
                        "core_demand": "核心需求·逻辑回归",
                        "full_baseline": "完整画像·LightGBM",
                    }[r["name"]],
                    nfmt(r["feature_count"]),
                    nfmt(r["test"]["n"]),
                    f'{r["test"]["auc"]:.4f}',
                    f'{r["test"]["pr_auc"]:.4f}',
                    nfmt(r["test"]["top20_applicants"]) + "/" + nfmt(r["test"]["top20_n"]),
                    pct(r["test"]["top20_rate"]),
                ]
                for r in rowsm
            ],
            "展开模型时间外测试",
        )
        + conclusion(
            [
                f'完整画像测试AUC为{full["test"]["auc"]:.4f}，近期活跃为{act["test"]["auc"]:.4f}。这衡量收到既有政策后谁会提单，不是红包的个体增量模型。',
                f'同样选前20%，完整画像比4项活跃特征基线多筛中{nfmt(full["test"]["top20_applicants"]-act["test"]["top20_applicants"])}名实际提单者；提单率差{pp(pair["differences"]["fixed_top20_rate"]["point"])}，95%区间{pp(pair["differences"]["fixed_top20_rate"]["ci95"][0])}至{pp(pair["differences"]["fixed_top20_rate"]["ci95"][1])}，尚未确认稳定运营优势。',
                "这项比较同时改变了特征与算法，不能把全部增益归于新增特征。训练、验证、测试按日期隔离；当前仅作为离线排序诊断，不能直接输出每人最优20%／30%／40%政策。",
            ]
        ),
        "model",
    )
    body += methods() + appendix()
    write(
        FILES[1],
        TITLES[1],
        "生命周期、模型分、历史提单率、额度使用率、近期行为与借款节奏",
        body,
    )


def _feature_explorer(rows):
    labels = {
        "recent_state": "近期行为",
        "churn_band": "流失天数",
        "loan_count_band": "借款次数",
        "util_band": "额度使用率",
        "historical_rate_band": "历史提单率",
        "gap_band": "相邻借款间隔",
        "idle_excess_band": "超出个人历史间隔",
        "expired_coupon_band": "历史过期券",
        "last_util_trend": "使用率变化",
        "rank_band": "原名单意愿层",
    }
    body = (
        '<div class="controls"><label>查看维度<select data-panels="profile">'
        + "".join('<option value="' + d + '">' + v + "</option>" for d, v in labels.items())
        + "</select></label></div>"
    )
    for dim, title in labels.items():
        rr = [r for r in rows if r["dimension"] == dim]
        levels = list(dict.fromkeys(r["level"] for r in rr))
        orders = {
            "recent_state": [
                "近7天已见提单页",
                "近7天活跃、未见提单页",
                "上周有活跃、本周沉默",
                "近14天未见活跃",
                "可用历史未见行为",
            ],
            "churn_band": [
                "8—14天",
                "15—30天",
                "31—60天",
                "61—90天",
                "91—180天",
                "181天及以上",
            ],
            "loan_count_band": ["1次", "2—3次", "4—6次", "7次及以上"],
            "util_band": ["<40%", "40—<60%", "60—<80%", "80—<97%", "≈100%", ">103%"],
            "historical_rate_band": [
                "0%",
                ">0—20%",
                ">20—50%",
                ">50—80%",
                ">80%",
                "历史获额少于3次",
            ],
            "gap_band": ["<15天", "15—30天", "31—60天", "61天及以上"],
            "idle_excess_band": ["未超过历史间隔", "超出0—30天", "超出31—90天", "超出90天以上"],
            "rank_band": ["本批前30%", "本批中间40%", "本批后30%", "名单无有效评分"],
        }
        if dim in orders:
            levels = sorted(
                levels, key=lambda x: orders[dim].index(x) if x in orders[dim] else 99
            )
        v = []
        n = []
        for lev in levels:
            row = []
            nr = []
            for d in [0.2, 0.3, 0.4]:
                r = next((r for r in rr if r["level"] == lev and r["dose"] == d), None)
                row.append(r["rate_3"] if r and r["n_3"] >= 30 else None)
                nr.append(nfmt(r["y_3"]) + "/" + nfmt(r["n_3"]) if r else "无样本")
            v.append(row)
            n.append(nr)
        body += (
            '<div data-panel="profile" data-value="'
            + dim
            + '">'
            + heatmap(levels, ["20%券", "30%券", "40%券"], v, n, title + "：3日提单率")
            + "</div>"
        )
    return body


def _double_low_joint(data):
    states = [
        "近7天已见提单页",
        "近7天活跃、未见提单页",
        "上周有活跃、本周沉默",
        "近14天未见活跃",
    ]
    rr = filtered(data["joint"], cohort="main_offer_simple", cell="低提单＋低使用")
    v = []
    nn = []
    for st in states:
        row = []
        n = []
        for d in [0.2, 0.3, 0.4]:
            r = next((r for r in rr if r["recent_state"] == st and r["dose"] == d), None)
            row.append(r["rate_3"] if r and r["n_3"] >= 30 else None)
            n.append(nfmt(r["y_3"]) + "/" + nfmt(r["n_3"]) if r else "无样本")
        v.append(row)
        nn.append(n)
    return heatmap(
        states, ["20%券", "30%券", "40%券"], v, nn, "双低用户再按近期行为拆分：3日提单率"
    )


def report3():
    fin = records("financial_results.json")
    rr = fin["t7_simple_mature"]
    e = records("expanded_policy_results.json")
    body = section(
        "一",
        "已使用红包订单：能盈利，不等于优惠带来新增利润",
        lead(
            "扩展期内三档纯降息T7的已到期用券订单均有正的当前现金盈利；不同档的件均、账期、风险和成熟程度不同，不能按原始盈利率决定最优折扣。"
        )
        + interval_plot(
            [dict(r, label=dose_name(r["dose"])) for r in rr],
            title="当前现金盈利率及用户聚类95%区间",
        )
        + table(
            [
                "券档",
                "到期用券订单",
                "放款金额",
                "件均",
                "回款金额",
                "当前盈利率",
                "当前订单逾期率",
            ],
            [
                [
                    dose_name(r["dose"]),
                    nfmt(r["orders"]),
                    nfmt(r["funded_amt"]),
                    nfmt(r["mean_funded_amt"]),
                    nfmt(r["repaid_amt"]),
                    pct(r["profit_rate"]),
                    pct(r["order_overdue_rate"]),
                ]
                for r in rr
            ],
            "展开到期订单现金盈利与风险",
        )
        + conclusion(
            [
                "这里包含研究期内符合资格的实际用券订单，可能来自重复召回；与主表“每笔获额首次召回”的人数不是同一个分母。",
                "回款减放款已体现实际支付结果，不再重复扣一次红包减免额；仍未扣资金、触达和运营成本，也不是最终利润。",
            ]
        ),
        "used",
    )
    mix = records("financial_mix_results.json")
    ages = ["到期0—14天", "到期15—30天", "到期31—60天", "到期61—120天", "到期121天以上"]
    mv = []
    mn = []
    for age in ages:
        row = []
        ns = []
        for d in [0.2, 0.3, 0.4]:
            r = next((r for r in mix["by_age"] if r["level"] == age and r["dose"] == d), None)
            row.append(r["profit_rate"] if r and r["orders"] >= 30 else None)
            ns.append(nfmt(r["orders"]) + "笔" if r else "无样本")
        mv.append(row)
        mn.append(ns)
    body += section(
        "对齐",
        "到期时长、件均与产品结构：先拆开再比较",
        heatmap(
            ages,
            ["20%券", "30%券", "40%券"],
            mv,
            mn,
            "同批T7纯降息到期用券订单：按距到期日时长拆分盈利率",
        )
        + table(
            ["券档", "订单数", "件均", "金额中位数", "平均账期", "平均距到期天数"],
            [
                [
                    dose_name(r["dose"]),
                    nfmt(r["orders"]),
                    nfmt(r["mean_funded_amt"]),
                    nfmt(r["median_funded_amt"]),
                    f'{r["mean_loan_day"]:.1f}天',
                    f'{r["mean_days_past_due"]:.1f}天',
                ]
                for r in rr
            ],
            "展开财务客群差异",
        )
        + conclusion(
            [
                "三档券的件均、账期和到期经过时长不同，回款成熟程度也不同；灰格表示少于30笔，不据此判断优劣。",
                "即使在相同金额、风险或账期层中比较，样本仍来自实际用券者；这些拆分是质量核对，不能替代原分组的收益评估。",
            ]
        )
        + table(
            ["风险层", "金额层", "券档", "到期订单", "盈利率", "订单逾期率"],
            [
                [
                    r["risk"],
                    r["amount"],
                    dose_name(r["dose"]),
                    nfmt(r["orders"]),
                    pct(r["profit_rate"]),
                    pct(r["order_overdue_rate"]),
                ]
                for r in mix["by_joint"]
            ],
            "展开同风险与同金额的财务交叉分层",
        ),
        "maturity",
    )
    tab = []
    values = []
    counts = []
    for st in STUDIES:
        row = []
        cnt = []
        for arm in ["control", "treatment"]:
            r = one(e["ab_finance"], study=st, arm=arm, window=30)
            row.append(r["profit_rate"] if r["orders"] >= 30 else None)
            cnt.append(nfmt(r["orders"]) + "笔到期首单")
            tab.append(
                [
                    SHORT[st],
                    "实验组" if arm == "treatment" else "对照组",
                    nfmt(r["assigned_events"]),
                    nfmt(r["funded_first_orders"]),
                    nfmt(r["orders"]),
                    pct(r["mature_share_of_funded"]),
                    nfmt(r["mean_funded_amt"]),
                    pct(r["profit_rate"]),
                    pct(r["order_overdue_rate"]),
                ]
            )
        values.append(row)
        counts.append(cnt)
    body += section(
        "二",
        "A/B原分组：追踪相同首次提单订单的质量",
        heatmap(
            [SHORT[s] for s in STUDIES],
            ["原对照", "30%实验组"],
            values,
            counts,
            "30日首次提单后成功放款、整笔已到期：当前盈利率",
        )
        + table(
            [
                "研究",
                "分组",
                "合格获额",
                "首单放款",
                "整笔到期",
                "成熟覆盖",
                "件均",
                "盈利率",
                "订单逾期率",
            ],
            tab,
            "展开A/B同笔订单财务",
        )
        + conclusion(
            [
                "A/B财务保留原分组，不要求实际使用本次红包；仅追踪每位用户召回后第一笔提单本身，避免混入任意后续订单。",
                "到期财务仍是对已放款且已到期订单的条件比较：两组转化和成熟覆盖不同，不能直接用条件盈利率证明每个召回用户的增量利润。",
                "7月30%策略虽然提高7日提单，但已观测的成熟净回款/合格获额并未高于对照；区间较宽，尚不能确认收益增加或下降。",
            ]
        )
        + table(
            [
                "研究",
                "分组",
                "提单窗口",
                "到期首单",
                "盈利率",
                "订单逾期率",
                "已观测成熟净回款/合格获额",
            ],
            [
                [
                    SHORT[r["study"]],
                    "实验组" if r["arm"] == "treatment" else "对照组",
                    str(r["window"]) + "日",
                    nfmt(r["orders"]),
                    pct(r["profit_rate"]),
                    pct(r["order_overdue_rate"]),
                    nfmt(r["observed_mature_net_per_assigned"]),
                ]
                for r in e["ab_finance"]
            ],
            "展开3／7／15／30日同笔首单财务敏感性",
        ),
        "abfinance",
    )
    amount = records("period_amount_risk_results.json")
    body += section(
        "金额",
        "分期金额风险：与同一批到期整笔订单对齐",
        table(
            [
                "券档",
                "到期订单",
                "匹配订单",
                "分期数",
                "当前逾期分期数",
                "金额逾期率",
                "逾期分期回收率",
            ],
            [
                [
                    dose_name(r["dose"]),
                    nfmt(r["whole_mature_used_orders"]),
                    nfmt(r["matched_whole_orders"]),
                    nfmt(r["installments"]),
                    nfmt(r["overdue_installments"]),
                    pct(r["amount_overdue_rate"]),
                    pct(r["overdue_period_recovery_rate"]),
                ]
                for r in amount
            ],
            "展开金额逾期与回收",
        )
        + conclusion(
            [
                "订单逾期率描述有多少笔整单当前逾期；金额逾期率描述合同金额暴露，两者不能互相替代。",
                "逾期分期已有部分回款时，订单状态仍可能为8，因此现金盈利率和当前逾期率可以同时为正。",
            ]
        ),
        "amountrisk",
    )
    risk = [dict(r, risk_band=r["level"]) for r in mix["by_risk"]]
    bands = ["<450", "450—499", "500—527", "≥528", "缺失"]
    vv = []
    nn = []
    for band in bands:
        row = []
        ns = []
        for d in [0.2, 0.3, 0.4]:
            r = next((r for r in risk if r["risk_band"] == band and r["dose"] == d), None)
            row.append(r["order_overdue_rate"] if r and r["orders"] >= 30 else None)
            ns.append(nfmt(r["orders"]) + "笔" if r else "无样本")
        vv.append(row)
        nn.append(ns)
    cashrows = [
        dict(
            label=SHORT[r["study"]],
            profit_rate=r["difference"],
            profit_ci95=r["difference_ci95"],
            color=COLORS[0.3],
        )
        for r in e["ab_cash_comparisons"]
        if r["window"] == 30
    ]
    body += section(
        "收益",
        "每笔合格获额的已观测成熟现金贡献",
        interval_plot(
            cashrows,
            title="实验组减对照：30日首单成熟净回款/合格获额（金额）",
            format_pct=False,
            unit="money",
        )
        + table(
            ["研究", "对照金额", "实验金额", "金额差", "95%区间"],
            [
                [
                    SHORT[r["study"]],
                    nfmt(r["rates"][0]),
                    nfmt(r["rates"][1]),
                    nfmt(r["difference"]),
                    nfmt(r["difference_ci95"][0]) + "至" + nfmt(r["difference_ci95"][1]),
                ]
                for r in e["ab_cash_comparisons"]
                if r["window"] == 30
            ],
            "展开原分组现金贡献及不确定性",
        )
        + '<p class="note">未提单者本笔贡献为0；有放款但尚未整笔到期者暂未计入成熟净回款，成熟覆盖见上表。该指标尚未扣营销与资金成本，也不是终局增量利润。</p>',
        "cash",
    )
    body += section(
        "三",
        "风控优先：高响应不能抵消高风险",
        heatmap(
            [
                "410 " + ("缺分" if b in ["missing", "缺失"] else b.replace(">=", "≥"))
                for b in bands
            ],
            ["20%券", "30%券", "40%券"],
            vv,
            nn,
            "同批T7纯降息三天券到期用券订单：当前订单逾期率",
        )
        + conclusion(
            [
                "实际投放先使用现行风控准入与禁发规则；当前整笔或分期逾期用户不进入优惠池。缺风险分不能直接按低风险处理。",
                "410分是风险画像，不能替代提单意愿；当前分层为描述性分析，未据此新建或调整线上授信门槛。",
            ]
        ),
        "risk",
    )
    inflight = records("inflight_validation_results.json")
    trans = records("inflight_state_transition_results.json")
    body += section(
        "四",
        "有在途另走策略：提单当刻还要满足状态要求",
        table(
            ["券档", "策略", "发券前状态", "合格获额", "3日提单", "提单率"],
            [
                [
                    dose_name(r["dose"]),
                    r["strategy"],
                    r["late_state"],
                    nfmt(r["n_3"]),
                    nfmt(r["y_3"]),
                    pct(r["rate_3"]),
                ]
                for r in inflight["risk_state"]
            ],
            "展开在途用户独立分层",
        )
        + '<p class="note">以下迁移仅限20%纯降息、发券前仍在途且整笔及分期未见逾期的'
        + nfmt(trans["eligible_issue_offer_orders"])
        + "笔合格获额；其中3日首次提单"
        + nfmt(trans["application_orders_3day"])
        + "笔。</p>"
        + table(
            ["首次提单时状态", "提单数"],
            [[k, nfmt(v)] for k, v in trans["states_at_first_application"].items()],
            "展开发券到提单之间的在途变化",
        )
        + conclusion(
            [
                "发券时有在途，不保证提单那一刻仍有在途；必须按具体时间核对整笔及分期逾期，不能用当前状态倒推。",
                "在途与无在途T7不是同一类需求和风险，不合并成一个红包政策。",
            ]
        ),
        "inflight",
    )
    body += section(
        "五",
        "落地规则：先准入，再需求，最后测试强度",
        policy_flow()
        + table(
            ["人群", "行动", "验证目标"],
            [
                [
                    "风控拒绝／整笔或分期逾期／禁发",
                    "不发优惠；按现行规则处理",
                    "不以提单率换取新增风险",
                ],
                [
                    "低风险＋近期提单页＋超出正常借款节奏",
                    "进入受控优惠测试，保留无券对照",
                    "比较20%、30%、40%的新增提单与成熟现金收益",
                ],
                [
                    "低风险＋长流失＋持续沉默",
                    "先测试渠道与内容唤醒，再测试折扣",
                    "先进入提单页，再提单；核对送达与阅读",
                ],
                [
                    "低历史提单率＋低使用率",
                    "结合近期行为和个人周期分层",
                    "避免把尚有需求的双低用户全部剔除",
                ],
                [
                    "同用户短期多次发券",
                    "控制频次并记录完整触达链",
                    "识别边际响应与长期影响，减少互相污染",
                ],
            ],
            "展开可执行政策框架",
        )
        + conclusion(
            [
                "目前可落地的是风险准入、需求排序、频次控制和分层A/B；尚不能宣称已经验证每位用户最优折扣。",
                "完整记录分组、发送时刻、券有效期、送达、曝光、行为、提单serial_id和到期回款，才能把召回收益闭环。",
            ]
        ),
        "decision",
    )
    body += methods() + appendix()
    write(FILES[2], TITLES[2], "风险准入先行 · 提单首单、实际用券和成熟回款分开评估", body)


def landing():
    e = records("expanded_policy_results.json")
    a = one(e["ab_comparisons"], study=STUDIES[0], window=7)
    pooled = records("pooled_ab_replication_results.json")
    p3 = one(pooled["raw"], window=3)
    m = filtered(records("offer_grain_results.json", "rates"), cohort="main_offer_simple")
    m = [r for r in m if r["dose"] > 0]
    body = section(
        "一",
        "本轮结论：30%有有效场景，40%证据需按触达链解读",
        conclusion(
            [
                f'30%发券策略：7月T5 A/B的7日提单率由{pct(a["rates"][0])}升至{pct(a["rates"][1])}；8月两轮三天券合并，3日提单率由{pct(p3["rates"][0])}升至{pct(p3["rates"][1])}。',
                "T7三档主样本已扩展至6月15日—10月30日实际发券记录；40%主要为7月同一批连续触达，不能按原始响应率判断最优券档。",
                "近期提单页、流失时长、借款节奏与使用率能够区分响应；持续沉默用户先验证唤醒。高响应与高优惠增量需分别检验。",
                "实际用券到期订单当前现金盈利为正；仍需风险准入与原分组成熟收益验证，不能直接当作新增利润。",
            ]
        )
        + rate_tiles(m, title="T7仅降息三天券：3日提单率"),
        "overview",
    )
    body += section(
        "二",
        "三份报告：从转化到机制，再到收益",
        '<div class="report-links">'
        + "".join(
            '<a class="report-link" href="'
            + f
            + '"><b>'
            + esc(t)
            + "</b><span>"
            + esc(d)
            + "</span></a>"
            for f, t, d in zip(
                FILES,
                TITLES,
                [
                    "四轮30% A/B、T7三档提单、7月40%触达链、行为能持续几天。",
                    "额度使用率×历史提单率、长流失、近期提单页、借款周期与排序模型。",
                    "同笔首单、用券订单、整笔到期风险、现金盈利与政策门槛。",
                ],
            )
        )
        + "</div>",
        "reports",
    )
    body += section(
        "三",
        "数据边界：窗口完整，群体分开",
        table(
            ["内容", "范围"],
            [
                ["主研究召回日期", "2026-06-15—2026-10-30（含）"],
                ["提单与埋点观察", "截至2026-11-03完整业务日，沿用原冻结上界"],
                ["回款与状态", "原2026-11-04冻结查询快照，未将未到期订单当0收益"],
                [
                    "T7纯降息三天券首次获额记录",
                    nfmt(e["primary_scope"]["qualified_3day_first_offer_records"])
                    + "笔；"
                    + nfmt(e["primary_scope"]["distinct_users"])
                    + "名用户",
                ],
                ["no_apply_*四轮A/B", "结清第5天为主，四轮均已完整观察30日；原分组保留"],
                ["7月40%召回", "7月16日1,000人；20日903人；23日841人，为重叠触达"],
                ["复现与隐私", "附完整取数PGSQL和分析程序；不公开用户明细或凭据"],
            ],
            "展开研究样本与边界",
        )
        + conclusion(
            [
                "主样本并不限于原来的10张9—10月名单；按实际发券时间筛选，未列入旧名单的7月用户也纳入。",
                "T5 A/B、T7观察性对照、在途用户和不同券有效期分别展示，保持可解释性。",
            ]
        ),
        "scope",
    )
    body += methods() + appendix()
    write(
        "index.html",
        "降息红包：转化、行为与风险验证",
        "6月15日—10月30日召回批次 · 纳入7月40%券与7—8月30%券A/B测试",
        body,
    )


def run():
    report1()
    report2()
    report3()
    landing()
    mark("expanded_reports_built", output=str(OUT), pages=4)


if __name__ == "__main__":
    run()
