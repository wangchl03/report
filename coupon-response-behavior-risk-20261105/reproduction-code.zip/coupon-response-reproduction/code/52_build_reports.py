"""Three concise visual reports plus navigation. All numbers come from frozen computed results."""

from core import *
from report_visuals import *
from verify_reference import validate

validate()
from scipy.stats import norm

OUT = ROOT / "reports"
OUT.mkdir(parents=True, exist_ok=True)
FILES = ["01-conversion-behavior.html", "02-customer-strategy.html", "03-profit-risk-test.html"]
TITLES = [
    "转化与行为：红包影响持续多久",
    "需求画像：什么用户更容易响应",
    "盈利与逾期：怎样控制召回风险",
]


def loadjson(name):
    return json.loads((W / name).read_text())


def records(name, key=None):
    x = loadjson(name)
    return x[key] if key else x


def filtered(rows, **kw):
    return [r for r in rows if all(r.get(k) == v for k, v in kw.items())]


def nav():
    return (
        '<a href="index.html">总览</a>'
        + "".join(
            '<a href="' + f + '">' + esc(t.split("：")[0]) + "</a>"
            for f, t in zip(FILES, TITLES)
        )
        + '<a href="#methods">统计口径</a><a href="#appendix">完整代码</a>'
    )


def reproduction_status():
    p = ROOT / "本次独立复现核对.json"
    if not p.exists():
        return "尚未完成独立复现，不发布。"
    r = json.loads(p.read_text())
    if not r["passed"]:
        raise RuntimeError("Independent reproduction failed.")
    return "172,886条研究记录的历史与行为特征一致；22份汇总结果一致；41,241条模型评分的预测值最大差异为0；481笔提单时状态另经独立SQL核对。"


def write(name, title, subtitle, body):
    html = page(title, subtitle, body, nav(), interactive_script())
    html = html.replace("</style>", EXTRA_CSS + "\n[hidden]{display:none!important}</style>")
    (OUT / name).write_text(html)


def methods(extra=""):
    rows = [
        [
            "统计单位",
            "每位用户、每笔最新合格获额，保留本次研究名单/发券记录范围内第一次合格召回；不表示用户一生首次收到券，同一用户不同获额分别计数。",
        ],
        [
            "获额分母",
            "发券日前最新获额 is_pass1=1，recycle_type已知且不等于1；先取最新，再判断通过，不能回退到更早通过记录。",
        ],
        [
            "T7范围",
            "发券日前已全部结清、无在途；距最近干净结清自然日超过7天，且结清后至发券日前没有再次提单。",
        ],
        [
            "提单分子",
            "按用户追踪召回日00:00起首次提单，不要求审批通过或放款；可能重新获额后提单。附表另列同serial_id直接提单。",
        ],
        [
            "窗口",
            "3日=D0—D2；7日=D0—D6；15日=D0—D14；30日=D0—D29。仅纳入观察完整的获额记录，不把未成熟窗口记0。",
        ],
        [
            "券与对照",
            "以系统发放记录为暴露，不以未来用券筛选分母；主分析限三天券，当日仅降息与同时提额/还款分开。无券记录组不是随机对照。",
        ],
        [
            "券档识别",
            "119/157/124由配置核对为20%/30%/40%；153配置缺失，依据历史实际使用幅度识别为20%，另做剔除153的敏感性检验。发放组别在观察提单结果前确定，不根据未来是否使用红包重分组。",
        ],
        [
            "发放与真正触达",
            "没有短信/推送送达、阅读或精确发券时刻；发券到账不等于用户已看到。不能把未响应全部解释为没有需求或价格不敏感。",
        ],
        [
            "行为",
            "新埋点用event_time；旧埋点用其create_time记录时钟作交叉核对。用户/业务日出现记1，不把两套日志条数直接相加。",
        ],
        [
            "时间边界",
            "America/Belize；提单与行为截至2026-11-03完整业务日。回款和状态为2026-11-04本次查询快照。发券只有日期，D0无法逐笔证明行为发生在实际发送之后。",
        ],
        [
            "历史提单率特征",
            "通过且recycle_type非1的不同获额订单为分母；同订单获额后D0—D6提单为分子。采用发券前第96至第7天的90个已成熟获额日，不机械纳入尚未满7天的近端获额。",
        ],
        [
            "额度使用率特征",
            "主画像用历史成功放款订单的apply_amt / 同serial_id提单前匹配的获额金额，先逐笔计算再算术平均；97%—103%归100%，缺额度不补0。额度覆盖率也在成功放款订单内计算。",
        ],
        [
            "借款与闲置周期",
            "成功放款按时间排序，相邻间隔取算术平均，只有一笔则缺失。另取历史已完成的“干净结清到再提单”间隔中位数；当前流失天数减该值为超出历史间隔。",
        ],
        [
            "事前模型分",
            "匹配本次历史获额流水的363、405、410，缺分按缺失；未用现在最新用户评分回填。源表缺少分生成时间，仍需线上时间日志验证。",
        ],
        [
            "区间与归因",
            "主要差异采用用户聚类重抽样；校准只用事前画像，每个成熟窗口单独重做。探索性多维对照不能直接视为券的因果增量。",
        ],
    ]
    return section(
        "口径",
        "统计口径与数据边界",
        table(["项目", "定义"], rows, "展开完整统计口径") + extra,
        "methods",
    )


def appendix():
    p = ROOT / "完整取数PGSQL.sql"
    code = esc(p.read_text()) if p.exists() else "完整代码见下载包。"
    text = '<p class="note">SQL负责只读取数；Python完成时点还原、分组、画像校准、置信区间与模型诊断。需要同版本私有快照与内部排除名单才能精确复现；公开包不含用户明细、红包实例ID或数据库凭据。</p>'
    text += '<p><a class="pill" href="../完整取数PGSQL.sql" download>下载完整取数PGSQL</a></p>'
    text += (
        "<details><summary>展开完整PGSQL取数代码（已按模块排版）</summary><pre><code>"
        + code
        + "</code></pre></details>"
    )
    return section("附录", "完整取数与分析代码", text, "appendix")


def horizon_heat(rows, cohort, groupkey, caption):
    zz = filtered(rows, cohort=cohort)
    doses = [0.2, 0.3, 0.4]
    values = []
    counts = []
    for dose in doses:
        r = next((r for r in zz if r["dose"] == dose), None)
        values.append(
            [
                r.get("rate_" + str(h)) if r and r.get("n_" + str(h), 0) >= 30 else None
                for h in [3, 7, 15, 30]
            ]
        )
        counts.append(
            [
                (
                    f"{nfmt(r['y_'+str(h)])}/{nfmt(r['n_'+str(h)])}"
                    if r and r.get("n_" + str(h), 0) > 0
                    else "尚未成熟"
                )
                for h in [3, 7, 15, 30]
            ]
        )
    return heatmap(
        [dose_name(d) for d in doses], ["3日", "7日", "15日", "30日"], values, counts, caption
    )


def report1():
    rates = records("offer_grain_results.json", "rates")
    main = [r for r in filtered(rates, cohort="main_offer_simple") if r["dose"] > 0]
    body = section(
        "一",
        "先看结果：各档券的实际提单响应",
        lead(
            "可以用于识别响应画像与设计受控测试；目前不能确认20%、30%、40%中哪一档具有最高新增提单收益，也不能确认单张三天券的影响持续一周。"
        )
        + rate_tiles(main)
        + '<p class="note">主样本来自10批T7召回名单；分母是不同的已通过、recycle_type非1获额订单。这里衡量用户后续是否提单；不等于“红包新增了多少提单”。40%首次召回仅74笔。</p>'
        + horizon_heat(rates, "main_offer_simple", "dose", "10批名单：按各窗口成熟范围分别统计")
        + conclusion(
            [
                "20%组260/3,802，30%组207/4,015，40%组8/74；三组人群和发券日期不同，原始比率不能直接排名优惠效果。",
                "每个窗口使用各自成熟分母；不同列不能作为同一批人的累计转化曲线。",
            ]
        )
        + table(
            ["券", "3日", "7日", "15日", "30日"],
            [
                [dose_name(r["dose"])]
                + [
                    (
                        pct(r["rate_" + str(h)])
                        if r["n_" + str(h)] >= 30
                        else "样本少" if r["n_" + str(h)] else "未成熟"
                    )
                    + " ("
                    + nfmt(r["y_" + str(h)])
                    + "/"
                    + nfmt(r["n_" + str(h)])
                    + ")"
                    for h in [3, 7, 15, 30]
                ]
                for r in main
            ],
        ),
        "results",
    )
    calibration = filtered(
        records("covariate_calibration_results.json"), cohort="main_offer_simple"
    )
    rr = []
    for r in calibration:
        if r["balance_sufficient"] and r["pair"] == [0.2, 0.3]:
            rr.append(
                {
                    "label": str(r["window"]) + "日 · 30%相对20%",
                    "profit_rate": r["difference"],
                    "profit_ci95": r["ci95"],
                    "color": COLORS[0.3],
                    "note": f"同日、同风险层、同名单类型；共同画像 {nfmt(r['events'])} 笔",
                }
            )
    supply = records("approved_product_supply_results.json", "comparisons")
    supply_table = table(
        ["成熟窗口", "共同样本", "30%减20%", "95%区间", "结论"],
        [
            (
                [
                    str(r["window"]) + "日",
                    nfmt(r["events"]),
                    pp(r["difference"]),
                    pp(r["ci95"][0]) + "至" + pp(r["ci95"][1]),
                    "观察性敏感性检验",
                ]
                if r.get("balance_sufficient")
                else [
                    str(r["window"]) + "日",
                    nfmt(r["events"]),
                    "不输出",
                    "不输出",
                    "平衡未通过",
                ]
            )
            for r in supply
        ],
        "展开加入获额当时产品组合后的复核",
    )
    body += section(
        "二",
        "共同画像复核：更高折扣没有稳定优势",
        interval_plot(rr, title="30%相对20%的响应率差值及95%区间（pp为百分点）", unit="pp")
        + conclusion(
            [
                "3日差值为+0.11个百分点，95%区间−1.80至+1.97个百分点；既不能确认30%更优，也不能据此认定两档效果相同。",
                "未发券记录组98.19%来自名单high/high2风险层，不能充当普通用户的随机无券对照；40%缺少足够的同层可比样本。",
            ]
        )
        + '<p class="note">已同时平衡分数、流失、使用率、历史提单率、行为、借款周期、缺失模式与分布分位点。再限制相同的事前获额产品组合后，3日差为+0.26个百分点（−2.88至+3.31）；结论未改变。仍为观察性关联，不能消除未记录的分配原因。</p>'
        + supply_table,
        "comparison",
    )
    profiles = filtered(
        records("behavior_state_corrected_results.json", "profiles"),
        cohort="main_offer_simple",
        window=15,
    )
    body += section(
        "三",
        "行为持续多久：先区分活动与首次提单",
        daily_heat(profiles, "同一D15成熟样本：发券前一周至发券后两周")
        + conclusion(
            [
                "图中各日使用固定分母：20%组3,014笔、30%组3,386笔。活跃和提单页是每日有行为的记录比例，不能用日志条数替代。",
                "用户提单后可能继续浏览或还款；判断意愿持续性时，需要同时核对首次提单后及再次发券后的行为。",
            ]
        )
        + "<h3>严格可比的流失≥15天人群：一周后的差异来自哪里</h3>"
        + _behavior_forest()
        + conclusion(
            [
                "第D7—D13日，30%相对20%的提单页变化差为+1.57个百分点；仅保留首次提单及后续发券之前的行为后，差为+0.17个百分点，区间跨0。",
                "这是一项机制核对，删截本身也受后续行为影响；现有数据无法确认原始三天券独立影响了一周。",
            ]
        )
        + '<p class="note">D0为发券日，第D7—D13日即第二周。以上探索性对照未作多重比较确认；流失≥15天时，两周行为基线均处于结清之后。</p>',
        "duration",
    )
    mech = filtered(
        records("coupon_instance_mechanism_results.json", "chains"), cohort="main_offer_simple"
    )
    body += section(
        "四",
        "从券实例核对过程：实际用券不要求主动选券",
        mechanism_cards(mech)
        + conclusion(
            [
                "通过选券事件后缀关联coupon_no，能核对具体发出的红包实例；仅将配置ID关联上，无法完成这项核验。",
                "20%组247笔、30%组191笔首次提单订单使用了本次券；主动选券点击明显更少，未见点击不能解释成“用户没看到券”。",
            ]
        )
        + '<div class="audit-badge">历史扩展40%首次召回930笔中，有672笔在次日又收到自动10%券。低于20%的券不作为目标优惠组，但必须计入后续干预审计。</div>',
        "mechanism",
    )
    hist = records("historical_ab_validation_results.json", "comparisons")
    hrows = []
    for st, label in [
        ("T5_30pct_3day_vs_none_round1", "T5第一轮"),
        ("T5_30pct_3day_vs_none_round2", "T5第二轮"),
    ]:
        for h in [3, 30]:
            r = next(
                r
                for r in hist
                if r["study"] == st
                and r["scope"] == "qualified_unique_credit_orders"
                and r["window"] == h
            )
            hrows.append(
                {
                    "label": label + " · " + str(h) + "日",
                    "profit_rate": r["difference"],
                    "profit_ci95": r["difference_ci95"],
                    "color": "#38bdf8" if h == 3 else "#a78bfa",
                }
            )
    body += section(
        "五",
        "历史复核：早提单与新增提单要分别检验",
        interval_plot(hrows, title="30%三天券相对原名单对照：两轮结果（pp为百分点）", unit="pp")
        + conclusion(
            [
                "T5第一轮3日差+6.61个百分点，30日差为+0.58个百分点，但长期区间较宽；现有结果同时容许部分时点前移和长期增量尚未看清。",
                "第二轮3日差约+1.07个百分点，未稳定复制第一轮；T5为结清第5天人群，不能直接外推T7长流失用户。",
            ]
        )
        + '<p class="note">同一30日成熟样本中，第一轮D3—D29才首次提单的差值为−6.03个百分点，95%区间−12.48至+0.27，仍跨0。不能仅凭“3日显著、30日不显著”就证明时点前移。历史A/B标签已对照实际发券，但缺少随机种子或分配日志，不能仅凭标签认定因果效应。</p>',
        "replication",
    )
    route = filtered(
        records("contact_order_route_results.json", "routes"),
        cohort="main_offer_simple",
        window=3,
    )
    extra = table(
        ["券", "合格获额", "用户有提单的获额记录", "同订单serial_id提单", "同订单提单率"],
        [
            [
                dose_name(r["dose"]),
                nfmt(r["approved_credit_orders"]),
                nfmt(r["any_user_application_events"]),
                nfmt(r["same_credit_order_applications"]),
                pct(r["same_order_application_rate"]),
            ]
            for r in route
            if r["dose"] > 0
        ],
        "展开用户响应与同订单直接提单的区别",
    )
    checks = filtered(
        records("exposure_definition_sensitivity_results.json", "rates"),
        cohort="main_offer_simple",
    )
    extra += table(
        ["敏感性口径", "券", "3日提单/获额", "3日响应率"],
        [
            [
                r["restriction"],
                dose_name(r["dose"]),
                nfmt(r["y_3"]) + "/" + nfmt(r["n_3"]),
                pct(r["rate_3"]),
            ]
            for r in checks
        ],
        "展开券配置、既有有效券与用户去重敏感性",
    )
    body += methods(extra) + appendix()
    write(FILES[0], TITLES[0], "20% / 30% / 40%三天券 · 收到券、行为、首次提单分开核对", body)


def _behavior_forest():
    rows = []
    for suffix, label in [
        ("delta", "包含后续行为"),
        ("before_app_delta", "仅首次提单前"),
        ("before_new_coupon_delta", "再排除后续发券后"),
    ]:
        r = next(
            r
            for r in records("calibrated_behavior_results.json")
            if r["cohort"] == "main_offer_simple_stable15"
            and r["window"] == 15
            and r["metric"] == "D7—D13_new_loan_entry_two_week_" + suffix
        )
        rows.append(
            {
                "label": label,
                "profit_rate": r["difference"],
                "profit_ci95": r["ci95"],
                "color": COLORS[0.3],
            }
        )
    return interval_plot(
        rows, title="D7—D13提单页日覆盖变化差：30%减去20%（pp为百分点）", unit="pp"
    )


def report2():
    data = records("demand_response_profile_results.json")
    f = pd.read_parquet(PRIVATE / "demand_profiles.parquet")
    from analysis_contract import cohorts_with_offer_grain

    f, co = cohorts_with_offer_grain(f)
    body = section(
        "一",
        "双低不是弱需求的充分条件",
        lead(
            "历史提单率与额度使用率必须结合近期行为、流失时长和正常借款节奏。响应高也不等于“提高折扣能带来更多新增提单”。"
        )
        + '<div class="grid-cards">'
        + card(
            "20%组 · 双低用户3日响应",
            "9.77%",
            "51 / 522；历史合格获额≥3笔，历史7日提单率≤20%，额度使用率<80%",
        )
        + card("同一双低组 · 近7天见提单页", "16.80%", "43 / 256")
        + card("同一双低组 · 近14天未见活跃", "1.65%", "2 / 121")
        + "</div>"
        + _demand_joint(data)
        + conclusion(
            [
                "不能直接把双低用户排除：本批20%券双低组响应率高于整体6.84%。这只是画像关联，不能据此认定20%券对双低用户的增量更高。",
                "额度覆盖≥80%且未出现历史单笔>103%的敏感性样本中，双低组仍为39/436＝8.94%。结论并非完全由额度缺失或提额比值拉高造成。",
            ]
        ),
        "demand",
    )
    z = f[
        co["main_offer_simple"]
        & f.churn_days.ge(91)
        & f.score410.ge(528)
        & f.dose.gt(0)
        & f.observed_3.eq(1)
    ]
    labels = [
        "近7天已见提单页",
        "上周有活跃、本周沉默",
        "近7天活跃、未见提单页",
        "近14天未见活跃",
    ]
    vals = []
    counts = []
    for d in [0.2, 0.3, 0.4]:
        v = []
        nn = []
        for state in labels:
            g = z[z.dose.eq(d) & z.recent_state.eq(state)]
            n = len(g)
            y = int(g.applied_3.sum())
            v.append(y / n if n >= 30 else None)
            nn.append(f"{nfmt(y)}/{nfmt(n)}")
        vals.append(v)
        counts.append(nn)
    body += section(
        "二",
        "长流失：先找回需求信号，再验证价格",
        heatmap(
            [dose_name(d) for d in [0.2, 0.3, 0.4]],
            ["近期提单页", "上周活跃后沉默", "活跃未见提单页", "14天未见活跃"],
            vals,
            counts,
            "流失≥91天、410≥528：研究名单范围内首次合格召回",
        )
        + conclusion(
            [
                "长流失且近14天未见活跃的20%组为2/154＝1.30%，30%组为8/864＝0.93%；近期已见提单页者分别为10/60、8/99。",
                "40%同层样本很少，不支持“40%能激活”或“40%无效”的判断。对持续沉默用户，先验证唤醒与需求恢复，再测试折扣强度。",
            ]
        )
        + '<div class="audit-badge">再限名单意愿分位于本批后30%：长流失、410≥528、近14天未见活跃的20%组仅1/78提单，30%组为5/508。当前没有证据表明加大折扣就能解决这一层的低响应。</div>'
        + '<p class="note">528为沿用的分析分层值，不是本次重新切的前20%，也不代替风控准入。灰格表示少于30笔；0次响应不等于真实概率为0。</p>',
        "longchurn",
    )
    body += section(
        "三",
        "完整画像：把借款节奏、使用率与提单率连起来",
        _feature_explorer(data)
        + conclusion(
            [
                "超出自己历史结清至再提单间隔越久，响应通常越低；但该间隔需要至少一次已完成的历史往返，缺失不能解释为“从未有需求”。",
                "历史获额提单率的分母固定为通过且recycle_type非1的获额订单；历史笔数少于3次单列，不能把缺失率补成0。",
            ]
        )
        + '<div class="audit-badge">提额背景核验：25,946笔能匹配到实际提额券使用的历史放款中，原始使用率中位数为110%；把已观测提额金额加入额度后，中位数为100%。原始额度使用率保留，新增视图仅用于解释和敏感性验证。</div>',
        "profile",
    )
    inflight = records("inflight_validation_results.json")
    transition = records("inflight_state_transition_results.json")
    ifin = next(
        r
        for r in inflight["financial"]
        if r["dose"] == 0.2 and not r["combined"] and not r["late_before_issue"]
    )
    body += section(
        "四",
        "有在途另看：响应高，不代表风险低",
        '<div class="grid-cards">'
        + card("20%仅降息 · 当时未见逾期", "18.32%", "950 / 5,187笔在途获额首次研究召回")
        + card(
            "在途成熟用券订单当前逾期",
            pct(ifin["order_overdue_rate"]),
            nfmt(ifin["mature_used_orders"])
            + "笔成熟订单；当前现金盈利"
            + pct(ifin["profit_rate"]),
        )
        + "</div>"
        + table(
            ["券", "当日策略", "发券前逾期状态", "合格获额", "3日有提单", "3日响应率"],
            [
                [
                    dose_name(r["dose"]),
                    r["strategy"],
                    r["late_state"],
                    nfmt(r["n_3"]),
                    nfmt(r["y_3"]),
                    pct(r["rate_3"]),
                ]
                for r in inflight["risk_state"]
            ],
            "展开在途用户的独立统计",
        )
        + "<h3>发券时有在途，还要核对提单那一刻</h3>"
        + table(
            ["首次提单时状态", "3日提单数", "占5,187笔合格获额"],
            [
                [k, nfmt(v), pct(v / transition["eligible_issue_offer_orders"])]
                for k, v in transition["states_at_first_application"].items()
            ],
            "展开发券到提单之间的状态变化",
        )
        + '<p class="note">若同时要求提单那一刻仍有在途、且整笔与分期均未见逾期，有效提单为867/5,187＝'
        + pct(867 / 5187)
        + "；77次已全部结清，6次已见逾期。这是后续状态拆分，不能拿来事后重选优惠组。财务481笔的提单时状态已通过独立SQL逐笔核对。</p>"
        + conclusion(
            [
                "在途组和T7组分开统计，不能用更高响应率证明其风险更低；本组财务也与T7不是同一人群。",
                "历史样本中仍有发券前已发生逾期的记录。下一轮必须在券入口实时核查整笔与分期逾期，不能只看最后一次获额通过。",
            ]
        )
        + '<p class="note">响应与财务均限发券前有在途、未见整笔或分期逾期。“仅降息”剔除当日其他优惠；财务是实际用券后整笔到期的481笔订单，并非上方5,187笔获额的全部后续订单。在途余额历史流水不足，不补造精确剩余可借额度。该层30%、40%缺少可比样本。</p>',
        "inflight",
    )
    models = records("response_ranking_results.json", "models")
    act = next(r for r in models if r["name"] == "recent_activity")
    full = next(r for r in models if r["name"] == "full_baseline")
    rows = []
    for r in [act, full]:
        t = r["test"]
        rows.append(
            [
                ("仅近期活跃" if r["name"] == "recent_activity" else "完整事前画像"),
                nfmt(r["feature_count"]),
                f"{t['auc']:.4f}",
                f"{t['pr_auc']:.4f}",
                f"{t['brier']:.4f}",
                nfmt(t["top20_applicants"]) + "/" + nfmt(t["top20_n"]),
                pct(t["top20_rate"]),
            ]
        )
    imp = records("validation_group_importance_results.json", "groups")
    imp = sorted(imp, key=lambda r: r["auc_drop_mean"], reverse=True)
    body += section(
        "五",
        "模型诊断：排序有提升，等量触达收益仍需确认",
        '<div class="grid-cards">'
        + card(
            "时间留出AUC", f"{full['test']['auc']:.4f}", f"仅活跃模型 {act['test']['auc']:.4f}"
        )
        + card(
            "同选前20%的实际提单",
            "183 vs 177",
            "各选1,501笔；多筛中6次实际提单，不能称作新增提单",
        )
        + card(
            "前20%响应率差",
            "+0.40个百分点",
            "95%区间 −0.35至+1.15个百分点，尚不能确认稳定的触达收益提升",
        )
        + "</div>"
        + table(
            ["诊断模型", "特征数", "AUC", "PR-AUC", "Brier", "前20%提单/入选", "前20%响应率"],
            rows,
            "展开模型评价指标",
        )
        + heatmap(
            [r["group"] for r in imp[:6]],
            ["打乱后AUC平均下降"],
            [[r["auc_drop_mean"]] for r in imp[:6]],
            None,
            "验证集特征组置乱：近期行为最重要",
            percentage=False,
        )
        + conclusion(
            [
                "完整模型在7,502笔历史留出记录、303次提单上AUC约0.7921；相对仅活跃的0.7732存在排序改善。",
                "本次只是发券后响应概率诊断，不是原V4模型升级，也不是“谁会被优惠说服”的增量模型。近期行为最重要，使用率、历史提单率与借款周期提供补充。",
            ]
        )
        + '<p class="note">测试覆盖10月17—31日，模型诊断仅纳入事前有可用行为历史的发券记录；正文转化分母保留未见历史行为者。按时间分训练、验证和测试，边界留出完整3日；只由验证集选型。特征组打乱是预测贡献，不是因果贡献。风险分对提单排序贡献较小，不等于风险分对盈利控制不重要。</p>',
        "model",
    )
    body += section(
        "六",
        "可执行的召回分流方案",
        matrix(
            ["人群", "已有证据", "下一步动作"],
            [
                [
                    "近期提单页、风控可营销",
                    "20%与30%组均有较高实际响应；高自然意愿与优惠增量尚未分开",
                    "保留无券留出；以20%为低让利测试基线，对照30%，不直接给全部用户最高折扣。",
                ],
                [
                    "双低、但近期有提单页",
                    "双低20%组中此层43/256响应，不能判为弱需求",
                    "核对可借金额、期限和提单卡点；同层随机测试优惠。",
                ],
                [
                    "长流失、14天未见活跃",
                    "20%与30%主样本响应约1%；提高折扣缺乏稳定增量证据",
                    "先小流量验证低成本唤醒；重新活跃或进入提单页后，再触发优惠试验。",
                ],
                [
                    "已多次召回、没有需求信号",
                    "20%组首次响应6.84%，第2次2.48%，第3次1.63%",
                    "对持续无响应者降低发券频率，设置观察冷却；出现新需求信号后重新评估。",
                ],
                [
                    "有在途、无逾期",
                    "属于循环贷需求，20%组响应明显更高；无法与T7直接混比",
                    "使用独立额度、偿付能力与分期逾期检查；不套用T7折扣最优结论。",
                ],
                [
                    "高风险或资格不清楚",
                    "高提单意愿并不保证能盈利；缺失风险分不能视为低风险",
                    "按营销风险禁发规则停止优惠；缺资料进入审核，不由意愿分覆盖风控。",
                ],
            ],
        )
        + conclusion(
            [
                "这些是待验证的分流规则，不是已经证实的个人最优优惠。",
                "首期可以用少量可解释信号分流并保留随机留出；不必因58特征模型AUC更高，就把全部复杂度直接搬上线。",
            ]
        )
        + '<p class="note">高响应人群不一定更受红包影响：T5两轮历史名单中，“近期提单页”与券策略的3日交互差分别为+2.05和+3.65个百分点，区间均跨0，尚不能确认存在稳定的更高优惠增量。下一轮需要在相同意愿层内随机分券验证。</p>',
        "strategy",
    )
    body += methods() + appendix()
    write(FILES[1], TITLES[1], "额度使用率 × 合格获额提单率 × 在途状态 × 行为 × 借款周期", body)


def _demand_joint(data):
    out = '<div class="controls"><label>优惠档位<select data-panels="demand-joint"><option value="0.2">20%</option><option value="0.3">30%</option></select></label></div>'
    states = [
        "近7天已见提单页",
        "上周有活跃、本周沉默",
        "近7天活跃、未见提单页",
        "近14天未见活跃",
    ]
    states += ["可用历史未见行为"]
    cells = ["低提单＋低使用", "低提单＋高使用", "高提单＋低使用", "高提单＋高使用", "信息不足"]
    for d in [0.2, 0.3]:
        zz = filtered(data["joint"], cohort="main_offer_simple", dose=d)
        v = []
        cnt = []
        for cell in cells:
            a = []
            b = []
            for state in states:
                r = next(
                    (r for r in zz if r["cell"] == cell and r["recent_state"] == state), None
                )
                a.append(r["rate_3"] if r and r["n_3"] >= 30 else None)
                b.append(f"{nfmt(r['y_3'])}/{nfmt(r['n_3'])}" if r else "0/0")
            v.append(a)
            cnt.append(b)
        out += (
            f'<div data-panel="demand-joint" data-value="{d}">'
            + heatmap(
                cells,
                [
                    "近期提单页",
                    "上周活跃后沉默",
                    "活跃未见提单页",
                    "14天未见活跃",
                    "历史未见行为",
                ],
                v,
                cnt,
                dose_name(d) + "：历史需求标签与近期行为",
            )
            + "</div>"
        )
    return (
        out
        + '<p class="note">历史获额不足3笔、历史提单率或额度无法计算者归“信息不足”，仍保留在总分母；未见行为指可用埋点中没有记录，不代表用户绝对没有访问。</p>'
    )


def _feature_explorer(data):
    dims = [
        ("recent_state", "近期行为"),
        ("churn_band", "流失天数"),
        ("loan_count_band", "历史成功借款次数"),
        ("util_band", "额度使用率"),
        ("historical_rate_band", "历史合格获额7日提单率"),
        ("gap_band", "历史相邻借款间隔"),
        ("idle_excess_band", "超出历史结清至再借间隔"),
        ("expired_coupon_band", "历史发券频次"),
        ("rank_band", "原名单意愿分层"),
    ]
    out = (
        '<div class="controls"><label>查看维度<select data-panels="feature-explorer">'
        + "".join(f'<option value="{k}">{v}</option>' for k, v in dims)
        + "</select></label></div>"
    )
    order = {
        "churn_band": [
            "8—14天",
            "15—30天",
            "31—60天",
            "61—90天",
            "91—180天",
            "181天及以上",
            "信息不足",
        ],
        "loan_count_band": ["1次", "2—3次", "4—6次", "7次及以上"],
        "util_band": ["<40%", "40—<60%", "60—<80%", "80—<97%", "≈100%", ">103%", "信息不足"],
        "historical_rate_band": [
            "0%",
            ">0—20%",
            ">20—50%",
            ">50—80%",
            ">80%",
            "历史获额少于3次",
            "信息不足",
        ],
        "gap_band": ["<15天", "15—30天", "31—60天", "61天及以上", "信息不足"],
        "idle_excess_band": [
            "未超过历史间隔",
            "超出0—30天",
            "超出31—90天",
            "超出90天以上",
            "信息不足",
        ],
        "rank_band": ["本批前30%", "本批中间40%", "本批后30%", "名单无有效评分"],
    }
    for key, label in dims:
        rr = filtered(data["univariate"], cohort="main_offer_simple", dimension=key)
        levels = list(dict.fromkeys(r["level"] for r in rr))
        levels.sort(
            key=lambda v: (
                order.get(key, levels).index(v) if v in order.get(key, levels) else 999
            )
        )
        values = []
        counts = []
        for lev in levels:
            v = []
            n = []
            for d in [0.2, 0.3, 0.4]:
                r = next((r for r in rr if r["level"] == lev and r["dose"] == d), None)
                v.append(r["rate_3"] if r and r["n_3"] >= 30 else None)
                n.append(f"{nfmt(r['y_3'])}/{nfmt(r['n_3'])}" if r else "0/0")
            values.append(v)
            counts.append(n)
        out += (
            f'<div data-panel="feature-explorer" data-value="{key}">'
            + heatmap(
                levels, ["20%券", "30%券", "40%券"], values, counts, label + "：3日用户响应"
            )
            + "</div>"
        )
    return (
        out
        + '<p class="note">每格为提单记录数/合格获额记录数。灰格为少于30笔；维度均为发券前信息，表内差异为描述性关联。原名单分数只在本批内分位排序，生成时点未验证，不能作为实时评分有效性的证明。</p>'
    )


def report3():
    fin = records("financial_results.json")
    rows = fin["t7_simple_mature"]
    amount = records("period_amount_risk_results.json")
    body = section(
        "一",
        "实际用券后的盈利与风险，要同时看",
        lead(
            "历史到期用券订单的当前现金盈利为正，但仍有较高逾期。不能据此给高风险用户发券，也不能把三档的盈利差异全部归因于折扣。"
        )
        + bubble_finance(rows)
        + table(
            [
                "券",
                "到期放款订单",
                "件均放款",
                "当前盈利率",
                "订单逾期率",
                "金额逾期率",
                "实际减息/放款金额",
            ],
            [
                [
                    dose_name(r["dose"]),
                    nfmt(r["orders"]),
                    nfmt(r["mean_funded_amt"]),
                    pct(r["profit_rate"]),
                    pct(r["order_overdue_rate"]),
                    pct(
                        next(a for a in amount if a["dose"] == r["dose"])["amount_overdue_rate"]
                    ),
                    pct(r["coupon_used_amt"] / r["funded_amt"]),
                ]
                for r in rows
            ],
            "展开到期用券订单完整指标",
        )
        + conclusion(
            [
                "20%组715笔、盈利13.72%、订单逾期26.15%；30%组260笔、盈利17.23%、逾期24.62%；40%组114笔、盈利15.41%、逾期21.93%。",
                "三组件均放款分别约3,497、5,197、7,224，且到期时长、产品和风险结构不同。不能用原始盈利率给优惠档位排最优。",
            ]
        )
        + '<p class="note">财务样本为2026年6—10月收到三天券、发券日符合T7及合格获额条件、当日仅降息、实际用券且整笔到期的成功放款订单。一笔订单只计一次，允许同用户不同借款。它与前页“研究范围内首次获额召回”的分母不同。</p>',
        "financial",
    )
    mix = records("financial_mix_results.json")
    ages = ["到期0—14天", "到期15—30天", "到期31—60天", "到期61—120天", "到期121天以上"]
    vals = []
    counts = []
    for d in [0.2, 0.3, 0.4]:
        a = []
        b = []
        for age in ages:
            r = next((r for r in mix["by_age"] if r["dose"] == d and r["level"] == age), None)
            a.append(r["profit_rate"] if r and r["orders"] >= 30 else None)
            b.append(nfmt(r["orders"]) + "笔" if r else "0笔")
        vals.append(a)
        counts.append(b)
    body += section(
        "二",
        "观察时长与风险结构，会改变表面结论",
        heatmap(
            [dose_name(d) for d in [0.2, 0.3, 0.4]],
            ages,
            vals,
            counts,
            "同一财务样本：按距整笔到期天数分层的当前盈利率",
        )
        + conclusion(
            [
                "40%组到期订单主要集中在到期61—120天；30%组更多来自较近到期批次。简单并排比较会混合不同回收时长。",
                "在410≥528的分析层，三档当前盈利分别约16.56%、20.86%、18.54%，也不能证明某档折扣造成更高盈利。",
            ]
        )
        + table(
            ["券", "410分层", "到期用券订单", "当前盈利率", "订单逾期率"],
            [
                [
                    dose_name(r["dose"]),
                    r["level"],
                    nfmt(r["orders"]),
                    pct(r["profit_rate"]) if r["orders"] >= 30 else "样本少",
                    pct(r["order_overdue_rate"]) if r["orders"] >= 30 else "样本少",
                ]
                for r in sorted(
                    mix["by_risk"],
                    key=lambda r: (
                        r["dose"],
                        {"<450": 0, "450—499": 1, "500—527": 2, "≥528": 3, "缺失": 4}.get(
                            r["level"], 5
                        ),
                    ),
                )
            ],
            "展开同一财务样本的风险分层",
        )
        + '<p class="note">仅≥30笔单元展示比例；小样本没有被记为0。410阈值只用于画像核验，是否可营销仍由风控资格与实时偿付约束决定。</p>',
        "mix",
    )
    bridge = records("cash_profit_bridge_results.json")
    body += section(
        "三",
        "为什么逾期较高，当前盈利仍可能为正",
        profit_waterfall(bridge)
        + conclusion(
            [
                "以20%组为例，非状态8订单贡献+34.68个百分点，状态8订单贡献−20.96个百分点，合计为+13.72%。这里按放款金额加权，没有平均订单盈利率。",
                "当前逾期整笔订单已收回约29.58%的放款额，前序已还分期仍产生现金回款；“订单逾期”不等于整笔金额全部未收回。",
            ]
        )
        + table(
            ["券", "当前逾期整笔订单回款/放款", "逾期分期金额回收率", "金额逾期率"],
            [
                [
                    dose_name(r["dose"]),
                    pct(
                        next(p for p in r["parts"] if p["current_status8"])[
                            "receipt_remit_ratio"
                        ]
                    ),
                    pct(
                        next(a for a in amount if a["dose"] == r["dose"])[
                            "overdue_period_recovery_rate"
                        ]
                    ),
                    pct(
                        next(a for a in amount if a["dose"] == r["dose"])["amount_overdue_rate"]
                    ),
                ]
                for r in bridge
            ],
            "展开整笔与分期回收口径",
        )
        + '<p class="note">盈利率=(Σrepaid_amt−Σremit_amt)/Σremit_amt；只用整笔到期且成功放款订单。减息已影响回款，不再次扣减红包金额。该口径未额外扣资金、触达或催收成本，不等于会计净利润。</p>',
        "cash",
    )
    body += section(
        "四",
        "下一轮：用受控测试识别真正的优惠增量",
        policy_flow()
        + matrix(
            ["设计项", "执行方式", "判断标准"],
            [
                [
                    "分组资格",
                    "最新获额通过且recycle_type非1；剔除风险禁发、逾期、黑名单。T7与有在途分别试验。",
                    "资格在分组前确定；缺失风险信息不自动进入低风险组。",
                ],
                [
                    "优惠档位",
                    "同一风险与需求层内，用户随机分无券、20%、30%、40%；券均3天，同一发送时点与触达方式；同一用户在试验内固定分组，避免重复获额跨组。",
                    "按分组保留全部合格获额分母，不能只比较最后用券者。",
                ],
                [
                    "阻断后续干预",
                    "首7日阻断其他自动/手工优惠，记录全部额外干预；确有必要的例外单独标记。",
                    "先保证实验两组在优惠之外可比，再判断行为是否持续一周。",
                ],
                [
                    "低意向长流失",
                    "预先独立一层：长流失＋近期无提单页；加入低成本唤醒对照，而非直接提高券额。",
                    "单独检验进入提单页、首次提单与到期收益，不从高活跃组外推。",
                ],
                [
                    "观察结果",
                    "3/7/15/30日首次提单率；日活与提单页；实际用券；同笔放款到期盈利及订单/金额逾期。",
                    "3日提升但30日不提升，判为时点前移信号，不能直接认定新增召回。",
                ],
                [
                    "扩量条件",
                    "同时通过转化、风险与收益门槛，门槛在试验前约定；对高风险用户持续禁发。",
                    "有证据再扩量；区间跨0、小样本或尚未到期，继续观察而不提前宣布最优。",
                ],
            ],
        )
        + _power_table()
        + conclusion(
            [
                "现有数据支持按需求信号分流；不支持一套固定规则准确给出每人的最优折扣。",
                "目前不宜仅凭“低意向、流失长”直接加到40%。先把自然回归、被价格说服和高风险排除分开。",
            ]
        ),
        "test",
    )
    body += section(
        "五",
        "把引擎输出与验证记录落下来",
        matrix(
            ["输出", "必留记录", "作用"],
            [
                [
                    "准入结果",
                    "资格时点、最新获额流水、风险结论、在途与逾期状态、排除原因",
                    "解释为什么此人能或不能进入优惠候选。",
                ],
                [
                    "需求画像",
                    "行为截止时间、近期提单页、历史获额提单分子/分母、额度使用率覆盖、借款周期",
                    "缺失保持缺失，避免把无记录当无需求。",
                ],
                [
                    "策略记录",
                    "试验ID、随机组、优惠档、券实例、发送/送达时间、到期时间、后续发券",
                    "保证能区分初券与后续干预，核对真正执行。",
                ],
                [
                    "结果归属",
                    "首次提单serial_id、同笔放款、到期日、快照回款/状态、观察成熟标记",
                    "不拿另一笔借款代替本笔财务结果，也不把未成熟观察记成0。",
                ],
            ],
        )
        + '<div class="audit-badge">发布前独立目录复现：<span id="repro-status">'
        + reproduction_status()
        + "</span></div>",
        "engine",
    )
    extra = table(
        ["财务指标", "统计定义"],
        [
            [
                "订单逾期率",
                "同一整笔到期成功放款样本中，当前loan_status_code=8的订单数/全部订单数。",
            ],
            [
                "金额逾期率",
                "同一整笔到期订单的分期中，状态8的Σapply_amt_period/全部分期Σapply_amt_period。",
            ],
            [
                "逾期分期回收率",
                "当前状态8分期的Σrepaid_amt_period/Σremit_amt_period；不把已还正常分期回款计入。",
            ],
            [
                "实际减息/放款金额",
                "同一到期用券订单的Σreal_use_amount/Σremit_amt；仅用于规模说明，不在现金盈利中重复扣除。",
            ],
            [
                "优惠幅度",
                "实际使用按real_use_amount/(apply_amt×产品total_fee)核验，比例保存为小数，按最近5个百分点归一；固定金额券不纳入。",
            ],
            [
                "主名单与历史扩展",
                "10批名单用于当前响应；6—10月发券扩展用于成熟用券财务。40%主名单尚无成熟财务，不能以历史114笔替代本批。",
            ],
        ],
        "展开财务、红包幅度与样本口径",
    )
    body += methods(extra) + appendix()
    write(FILES[2], TITLES[2], "当前现金盈利 × 当前逾期 × 件均 × 观察时长 · 风险资格优先", body)


def _power_table():
    rows = []
    alpha = 0.05 / 3
    za = norm.ppf(1 - alpha / 2)
    zb = norm.ppf(0.8)
    for p0, p1 in [(0.05, 0.06), (0.01, 0.015)]:
        bar = (p0 + p1) / 2
        n = math.ceil(
            (
                za * math.sqrt(2 * bar * (1 - bar))
                + zb * math.sqrt(p0 * (1 - p0) + p1 * (1 - p1))
            )
            ** 2
            / (p1 - p0) ** 2
        )
        rows.append([pct(p0), pct(p1), pp(p1 - p0), nfmt(n), nfmt(n * 4)])
    return (
        table(
            ["假设无券率", "目标优惠率", "目标提升", "约需每组", "四组合计"],
            rows,
            "展开样本量测算（规划假设，不是效果预测）",
        )
        + '<p class="note">样本量按80%把握度、三档分别与无券比较的α=0.05/3估算，未计流失和执行偏差。人群不足时，优先预设一档与无券的正式对照，其他档作后续阶段，不能用每组几百人确认1个百分点的稳定提升。</p>'
    )


def landing():
    body = section(
        "一",
        "本次能确认什么",
        lead(
            "近期提单页行为比简单“双低”标签更能区分响应；三档优惠的最优增量尚未确认。高风险用户不应因意愿高而进入发券名单。"
        )
        + '<div class="grid-cards">'
        + card("20% · 首次研究召回3日响应", "6.84%", "260 / 3,802笔合格获额")
        + card("30% · 首次研究召回3日响应", "5.16%", "207 / 4,015笔合格获额", COLORS[0.3])
        + card("40% · 首次研究召回3日响应", "10.81%", "8 / 74笔；不足以判断最优", COLORS[0.4])
        + "</div>"
        + conclusion(
            [
                "20%与30%在同日、同风险与共同画像下，3日差值约+0.11个百分点，区间跨0；不能直接认定更高折扣更有效。",
                "单张三天券的影响能否持续一周，现有数据无法确认：后续发券和首次提单后的行为必须剥离。",
                "双低不等于弱需求。20%双低组中，近期有提单页者43/256响应；近14天未见活跃者2/121响应。",
                "历史到期用券订单均有正的当前现金盈利，但订单逾期约22%—26%，必须同时看风险、金额与回收时长。",
            ]
        ),
        "overview",
    )
    body += section(
        "二",
        "按问题阅读三份报告",
        '<div class="report-links">'
        + "".join(
            f'<a class="report-link" href="{f}"><b>{i+1:02d} · {esc(t)}</b><span>{d}</span></a>'
            for i, (f, t, d) in enumerate(
                zip(
                    FILES,
                    TITLES,
                    [
                        "各档优惠的实际响应、每日行为、后续发券、券实例链路，以及两轮历史对照复核。",
                        "额度使用率与历史提单率交互、长流失与近期提单页、借款节奏、模型诊断及分流方案。",
                        "当前用券盈利与订单/金额逾期、件均与观察时长、现金盈利拆解，以及可执行的受控测试。",
                    ],
                )
            )
        )
        + "</div>",
        "reports",
    )
    body += section(
        "三",
        "本轮复盘怎样改变了分析",
        matrix(
            ["核查", "发现的问题", "最终处理"],
            [
                [
                    "单位",
                    "同一获额被多次召回，未响应者会重复留在名单",
                    "主结果按不同合格获额取研究范围内首次；重复触达单列。",
                ],
                [
                    "对照",
                    "当前未见发券者主要来自高风险层",
                    "不将其当作随机对照；按同日、同风险、同名单来源核验优惠档。",
                ],
                [
                    "窗口",
                    "3日平衡后直接取长期成熟子集，画像会重新失衡",
                    "各窗口独立重做支持范围、缺失/分布平衡与用户聚类区间。",
                ],
                [
                    "行为",
                    "T7短流失用户的前两周含结清前行为；提单后行为混入意愿",
                    "主基线用前一周；流失≥15天复核两周；补看首次提单与后续发券前。",
                ],
                [
                    "额度",
                    "超过100%的使用率有大量真实提额券背景",
                    "保留原指标，并验证提额后的额度视图；不把全部超额值当坏数据。",
                ],
                [
                    "复核",
                    "历史A/B存在T5、人群分层、组合优惠与执行差异",
                    "分别复算实际发券、事前资格和首次提单；不把A/B标签直接等同随机化。",
                ],
            ],
        )
        + '<p class="note">分析采用实际名单、发券、订单与两套原始埋点；不生成模拟业务效果，不发送红包或改写业务表。统计表与完整附录默认折叠。</p>',
        "iterations",
    )
    body += methods() + appendix()
    write(
        "index.html",
        "降息红包：转化、行为持续性与风险收益",
        "20% / 30% / 40% · 多轮数据复核 · 2026年11月5日",
        body,
    )


def run():
    report1()
    report2()
    report3()
    landing()
    mark("reports_built", directory=str(OUT), html_files=4)


if __name__ == "__main__":
    run()
