from pathlib import Path
import json, math

ROOT=Path(__file__).resolve().parent.parent

def differences(a,b,path=""):
    if isinstance(a,dict) and isinstance(b,dict):
        out=[]
        if set(a)!=set(b):out.append(path+": keys differ")
        for k in sorted(set(a)&set(b)):out.extend(differences(a[k],b[k],path+"/"+str(k)))
        return out
    if isinstance(a,list) and isinstance(b,list):
        if len(a)!=len(b):return [path+": list length differs"]
        return [v for i,(x,y) in enumerate(zip(a,b)) for v in differences(x,y,path+"/"+str(i))]
    if isinstance(a,(int,float)) and isinstance(b,(int,float)):
        good=(a==b) if isinstance(a,int) and isinstance(b,int) else math.isclose(a,b,rel_tol=1e-8,abs_tol=1e-10)
        return [] if good else [path+": numeric value differs"]
    return [] if a==b else [path+": value differs"]

def validate():
    reference=json.loads((ROOT/"reference_aggregates.json").read_text())
    failures=[]
    for filename,expected in reference.items():
        p=ROOT/"code"/filename
        if not p.exists():failures.append(filename+": missing");continue
        failures.extend(differences(expected,json.loads(p.read_text()),filename))
    result={"checked_result_files":len(reference),"matched":not failures,"differences":failures[:100],"numeric_relative_tolerance":1e-8,"numeric_absolute_tolerance":1e-10}
    (ROOT/"reference_verification.json").write_text(json.dumps(result,ensure_ascii=False,indent=2))
    if failures:raise RuntimeError("Reference check failed; original frozen narrative was not rendered. See reference_verification.json.")
    print(json.dumps(result,ensure_ascii=False),flush=True)
    return result

if __name__=="__main__":validate()
