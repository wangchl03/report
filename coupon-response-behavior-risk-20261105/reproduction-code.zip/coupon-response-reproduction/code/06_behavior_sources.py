"""Aggregate raw records by actual source clock and user/day. Never export raw text input."""

from core import *

MODE = sys.argv[1] if len(sys.argv) > 1 else "both"
sel = pd.read_parquet(PRIVATE / "target_coupon_issues.parquet")
rec = pd.read_parquet(PRIVATE / "recall_batch_features.parquet")
# 3-day target and the historical 7-day target offers, plus all recall candidates.
users = sorted(
    set(map(int, sel[sel.coupon_id.isin([119, 124, 157, 160, 163, 164])].user_id))
    | set(map(int, rec.churn_user_id))
)
dump(PRIVATE / "behavior_user_ids.json", users)
new_flags = {
    "app_start": "event_type='app_start'",
    "loan_entry": "event_type='page_view' AND page_type='page_view_in' AND page_base IN ('xyrsaqxpwmedzlsm','vdecaucgiowzpoeh')",
    "submit": "event_type='element_click' AND element_base IN ('hfmgyiwihoavrqzv','udopwuxjursbmvcm')",
    "amount": "(event_type='text_change' AND element_type='editing' AND element_base='gbyukfclsrdmxaon') OR (event_type='slider_change' AND element_base='jrocyutivyeqdxrx') OR (event_type='element_click' AND element_base IN ('xhwhgrqsxqkfwpoj','saynozmunkdceoya','gwexsotywwgsvrgv'))",
    "term": "event_type='element_click' AND element_base IN ('zfmdsmjpuslrcchx','denkhhpvgqgwethb','rdapttngylaiuvth','gfelmnelmexljaiv')",
    "plan": "event_type='element_click' AND element_base IN ('omuwccqjaovwdwyx','gemkzaypdtcrwdkg')",
    "contract": "event_type='element_click' AND element_base IN ('oflwqlzkgvyvhltd','gwhhjdfmvnpjaouh')",
    "coupon_open": "event_type='element_click' AND element_base IN ('ejknnzgmqlepvxuy','gbjnaljcxrmlvpwo')",
    "coupon_confirm": "event_type='element_click' AND element_base IN ('dmadzxixvpamlgpg','mpjlvbjrygzfqxvo')",
    "coupon_page": "event_type='page_view' AND page_type='page_view_in' AND page_base='iqsvfjcxwpqtsrbj'",
}
legacy_flags = {
    "app_start": "event_type='app_start'",
    "loan_entry": "event_type='page_view_in' AND props_id IN ('Loan_newpage','Loan_newpage_select')",
    "submit": "event_type='element_click' AND props_id IN ('Loan_newconfirm','Loan_newconfirm_select')",
    "amount": "props_id IN ('amount_modification','loan_form_loan_amount_selectionn_new','loan_form_loan_amount_selectionn_new_select')",
    "term": "props_id IN ('loan_form_term_selection_new','loan_form_term_selection_new_select')",
    "plan": "props_id IN ('Loan_plan_newdetails','Loan_plan_newdetails_select')",
    "contract": "props_id IN ('Loan_contract_newdetails','Loan_contract_newdetails_select')",
    "coupon_open": "props_id IN ('Order_coupons_page','Order_coupons_page_select')",
    "coupon_confirm": "props_id IN ('Order_coupons_confirm','Order_coupons_confirm_select')",
    "coupon_page": "props_id IN ('Order_coupons_page','Order_coupons_page_select')",
}


def make_sql(source):
    if source == "new":
        raw = """SELECT user_id,event_date AS d,event_time AS t,event_unix,event_type,page_type,element_type,
       split_part(page_id,'_',1) AS page_base,split_part(element_id,'_',1) AS element_base
       FROM wangchuanliang.user_behavior_track_record
       WHERE event_date>=%(start)s::date AND event_date<%(end)s::date
         AND event_time>=%(start)s::timestamp AND event_time<%(end)s::timestamp
         AND user_id IN(SELECT unnest(%(users)s::bigint[]))"""
        flags = new_flags
        extra = "SUM(CASE WHEN t::date<>d THEN 1 ELSE 0 END) AS date_mismatch_n, SUM(CASE WHEN ABS(event_unix/1000.0-EXTRACT(EPOCH FROM t AT TIME ZONE 'America/Belize'))>1 THEN 1 ELSE 0 END) AS epoch_mismatch_n"
    else:
        raw = """SELECT user_id,create_date AS d,create_time AS t,create_unix,event_type,props_id,event_start_time,event_end_time
       FROM wangchuanliang.event_track_record
       WHERE create_date>=%(start)s::date AND create_date<%(end)s::date
         AND create_time>=%(start)s::timestamp AND create_time<%(end)s::timestamp
         AND user_id IN(SELECT unnest(%(users)s::bigint[]))"""
        flags = legacy_flags
        extra = "SUM(CASE WHEN t::date<>d THEN 1 ELSE 0 END) AS date_mismatch_n, SUM(CASE WHEN event_end_time>0 AND ABS(event_end_time/1000.0-EXTRACT(EPOCH FROM t AT TIME ZONE 'America/Belize'))>86400 THEN 1 ELSE 0 END) AS device_clock_far_n"
    fields = [
        "user_id",
        "d",
        "COUNT(*) AS logs",
        "MIN(EXTRACT(EPOCH FROM t AT TIME ZONE 'America/Belize')) AS first_active_epoch",
        "MAX(EXTRACT(EPOCH FROM t AT TIME ZONE 'America/Belize')) AS last_active_epoch",
        extra,
    ]
    for k, cond in flags.items():
        fields += [
            f"SUM(CASE WHEN ({cond}) THEN 1 ELSE 0 END) AS {k}_n",
            f"MIN(CASE WHEN ({cond}) THEN EXTRACT(EPOCH FROM t AT TIME ZONE 'America/Belize') END) AS {k}_epoch",
        ]
    return (
        "WITH raw AS ("
        + raw
        + ") SELECT\n "
        + ",\n ".join(fields)
        + "\n FROM raw GROUP BY user_id,d"
    )


c = connect()
try:
    with c.cursor() as q:
        q.execute("SET application_name='coupon_response_raw_behavior_daily'")
        q.execute("SET statement_timeout=1800000")
    # The pre-Sep21 data share one large partition: scan it once, not once per day.
    spans = [
        ("2026-05-18", "2026-09-21"),
        ("2026-09-21", "2026-10-01"),
        ("2026-10-01", "2026-10-16"),
        ("2026-10-16", "2026-11-04"),
    ]
    for source in ["new", "legacy"] if MODE == "both" else [MODE]:
        frames = []
        for start, end in spans:
            f = query_large(
                c,
                make_sql(source),
                {"start": start, "end": end, "users": users},
                f"behavior_{source}_{start}_{end}",
            )
            frames.append(f)
        full = pd.concat(frames, ignore_index=True)
        full.to_parquet(
            PRIVATE / f"behavior_{source}_daily.parquet", index=False, compression="zstd"
        )
        mark(
            "behavior_" + source + "_complete",
            rows=len(full),
            users=full.user_id.nunique(),
            logs=int(pd.to_numeric(full.logs).sum()),
        )
finally:
    c.rollback()
    c.close()
dump(
    W / "behavior_semantics.json",
    {
        "new_clock": "event_time",
        "legacy_clock": "create_time (legacy server record clock; device clock separately audited)",
        "flags_new": new_flags,
        "flags_legacy": legacy_flags,
        "source_counts_not_summed": True,
        "binary_union_after_user_day_alignment": True,
        "users": len(users),
        "spans": spans,
    },
)
