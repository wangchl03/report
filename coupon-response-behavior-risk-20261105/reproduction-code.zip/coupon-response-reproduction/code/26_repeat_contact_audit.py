"""Audit subsequent coupons and repeated qualified offers without conditioning main eligibility on future exposure."""

from analysis_contract import *


def run():
    f = pd.read_parquet(PRIVATE / "episode_analysis.parquet")
    f["anchor"] = pd.to_datetime(f.anchor)
    f, co = cohorts_with_offer_grain(f)
    c = pd.read_parquet(PRIVATE / "all_issue_histories.parquet")
    for col in ["create_date", "expire_date", "used_date"]:
        c[col] = pd.to_datetime(c[col], errors="coerce", format="mixed")
    for col in ["user_id", "coupon_id", "type"]:
        c[col] = pd.to_numeric(c[col], errors="coerce")
    c = c[c.type.isin([3, 4])].drop_duplicates()
    cg = {
        k: g.sort_values(["create_date", "coupon_id"])
        for k, g in c.groupby("user_id", sort=False)
    }
    out = {
        "repeat_windows": [],
        "next_coupon_identity": [],
        "repeat_offer_sizes": [],
        "intent_prior_validity": [],
    }
    for name in [
        "main_simple",
        "extension_simple",
        "main_offer_simple",
        "extension_offer_simple",
    ]:
        z = f[co[name] & f.dose.gt(0)]
        for h in [3, 7, 15, 30]:
            for dose, g in z[z[f"observed_{h}"].eq(1)].groupby("dose"):
                out["repeat_windows"].append(
                    {
                        "cohort": name,
                        "window": h,
                        "dose": dose,
                        "events": len(g),
                        "next_coupon_in_window": int(g.next_coupon_day.lt(h).sum()),
                        "confirmed_new_coupon_before_application": int(
                            g.next_preapplication_coupon_day.lt(h).sum()
                        ),
                        "same_day_application_order_unknown": int(
                            (
                                g.next_coupon_day.lt(h)
                                & g.next_coupon_same_application_day.eq(1)
                            ).sum()
                        ),
                        "prior_valid_coupon": int(g.prior_coupon_still_valid.eq(1).sum()),
                    }
                )
        # First subsequent issue day can contain several coupons. Count both event-level occurrence and unique coupon IDs.
        rr = []
        for a in z.itertuples():
            if not np.isfinite(a.next_coupon_day) or a.next_coupon_day >= 15:
                continue
            cc = cg.get(a.user_id)
            if cc is None:
                continue
            day = a.anchor + pd.Timedelta(days=int(a.next_coupon_day))
            q = cc[cc.create_date.eq(day)]
            for (cid, ctype), gg in q.groupby(["coupon_id", "type"]):
                rr.append(
                    {
                        "episode_id": a.episode_id,
                        "dose": a.dose,
                        "day": int(a.next_coupon_day),
                        "coupon_id": int(cid),
                        "type": int(ctype),
                        "before_app_confirmed": int(
                            np.isfinite(a.next_preapplication_coupon_day)
                        ),
                        "same_day_unknown": a.next_coupon_same_application_day,
                    }
                )
        if rr:
            for (dose, cid, ctype, day), g in pd.DataFrame(rr).groupby(
                ["dose", "coupon_id", "type", "day"]
            ):
                out["next_coupon_identity"].append(
                    {
                        "cohort": name,
                        "dose": dose,
                        "next_coupon_id": cid,
                        "type": ctype,
                        "relative_day": day,
                        "events": len(g),
                        "before_app_confirmed": int(g.before_app_confirmed.sum()),
                        "same_day_unknown": int(g.same_day_unknown.sum()),
                    }
                )
        size = z.groupby(["user_id", "latest_credit_serial"]).size()
        for k, v in size.value_counts().sort_index().items():
            out["repeat_offer_sizes"].append(
                {"cohort": name, "contact_count": int(k), "credit_orders": int(v)}
            )
        for dose, g in z.groupby("dose"):
            for valid, gg in g.groupby("prior_coupon_still_valid"):
                out["intent_prior_validity"].append(
                    rm.summarize(gg, {"cohort": name, "dose": dose, "prior_valid": int(valid)})
                )
    dump(W / "repeat_contact_results.json", out)
    mark("repeat_contact_audit_complete", identities=len(out["next_coupon_identity"]))


if __name__ == "__main__":
    run()
