"""Expanded primary period, assigned 30% A/B studies, behavior mechanism and same-order finances.
All eligibility and dose classification precede observing a response. No outcome-based arm filtering.
"""

from core import *
from stats_utils import *
from analysis_contract import cohorts_with_offer_grain

STUDIES = [
    "T5_30pct_7day_vs_none",
    "T5_30pct_7day_vs_3day",
    "T5_30pct_3day_vs_none_round1",
    "T5_30pct_3day_vs_none_round2",
]
END = pd.Timestamp("2026-11-04")


def finance(g):
    n = len(g)
    amt = float(g.remit_amt.sum())
    rec = float(g.repaid_amt.sum())
    return {
        "orders": n,
        "users": int(g.user_id.nunique()),
        "funded_amt": amt,
        "repaid_amt": rec,
        "mean_funded_amt": amt / n if n else None,
        "profit_rate": (rec - amt) / amt if amt else None,
        "overdue_orders": int(g.loan_status_code.eq(8).sum()),
        "order_overdue_rate": float(g.loan_status_code.eq(8).mean()) if n else None,
    }


def run():
    f = pd.read_parquet(PRIVATE / "episode_analysis.parquet")
    f["anchor"] = pd.to_datetime(f.anchor)
    f, co = cohorts_with_offer_grain(f)
    period = f.anchor.ge("2026-06-15") & f.anchor.lt("2026-10-31")
    out = {
        "contract": {
            "recall_start": "2026-06-15",
            "recall_end_inclusive": "2026-10-30",
            "outcome_upper_exclusive": "2026-11-04",
            "ab_provenance": "用户确认 no_apply_* 为A/B测试，实验组分配30%减息券；采用原名单分组，实际发券另行核对。",
            "ab_denominator": "最新获额通过且recycle_type非1，按测试目标核验已结清、未再提单；每测试内同用户同获额保留最早记录。",
            "behavior_baseline": "T5基线用发券前4个完整日；原前7日可能包含结清之前的行为，不用于本次AB行为变化基线。",
            "finance": "相同首次提单订单，成功放款且整笔到期；不是任意后续订单。回款/逾期为冻结查询时点。",
        },
        "primary_scope": {},
        "duration_rates": [],
        "monthly_rates": [],
        "july40_contacts": [],
        "ab_rates": [],
        "ab_comparisons": [],
        "ab_issuance": [],
        "ab_scope": [],
        "ab_timing": [],
        "ab_finance": [],
        "ab_cash_comparisons": [],
        "period_coverage": [],
        "ab_daily": [],
        "ab_behavior_effects": [],
        "ab_subgroup_rates": [],
        "ab_subgroup_comparisons": [],
        "ab_balance": [],
        "ab_funnel": [],
        "ab_batch_rates": [],
        "quality_checks": {},
    }
    main = f[co["main_offer_simple"] & f.dose.gt(0)]
    for (month, days), gg in f[period & f.is_target_send.eq(1)].groupby(
        ["anchor_month", "valid_days"], dropna=False
    ):
        out["period_coverage"].append(
            {
                "month": month,
                "valid_days": int(days) if pd.notna(days) else None,
                "raw_contacts": len(gg),
                "passed_non1": int(gg.eligible_offer.eq(1).sum()),
                "qualified_t7": int((gg.eligible_offer.eq(1) & gg.strict_t7.eq(1)).sum()),
            }
        )
    out["primary_scope"] = {
        "qualified_3day_first_offer_records": len(main),
        "distinct_users": int(main.user_id.nunique()),
        "first_anchor": str(main.anchor.min().date()),
        "last_anchor": str(main.anchor.max().date()),
        "raw_target_contacts_in_period": int((period & f.is_target_send.eq(1)).sum()),
    }
    target = f[
        period & f.is_target_send.eq(1) & f.eligible_offer.eq(1) & f.strict_t7.eq(1)
    ].sort_values(["anchor", "episode_id"])
    target = target.drop_duplicates(["user_id", "latest_credit_serial"])
    for (dose, duration, pure), g in target.groupby(["dose", "valid_days", "simple_discount"]):
        r = {
            "dose": float(dose),
            "valid_days": int(duration),
            "pure": bool(pure),
            "records": len(g),
        }
        for h in [3, 7, 15, 30]:
            z = g[g[f"observed_{h}"].eq(1)]
            r.update(
                {
                    f"n_{h}": len(z),
                    f"y_{h}": int(z[f"applied_{h}"].sum()),
                    f"rate_{h}": float(z[f"applied_{h}"].mean()) if len(z) else None,
                }
            )
        out["duration_rates"].append(r)
    for (month, dose), g in main.groupby(["anchor_month", "dose"]):
        r = {
            "month": month,
            "dose": float(dose),
            "records": len(g),
            "repeat_coupon_by7": float(g.next_coupon_day.lt(7).mean()),
        }
        for h in [3, 7, 15, 30]:
            z = g[g[f"observed_{h}"].eq(1)]
            r.update(
                {
                    f"n_{h}": len(z),
                    f"y_{h}": int(z[f"applied_{h}"].sum()),
                    f"rate_{h}": float(z[f"applied_{h}"].mean()) if len(z) else None,
                }
            )
        out["monthly_rates"].append(r)
    c = pd.read_parquet(PRIVATE / "target_coupon_issues.parquet")
    c["create_date"] = pd.to_datetime(c.create_date)
    c["coupon_id"] = pd.to_numeric(c.coupon_id)
    cp = c[c.create_date.ge("2026-06-15") & c.create_date.lt("2026-10-31")].copy()
    cp["dose"] = cp.coupon_id.map(
        {
            119: 0.2,
            124: 0.4,
            141: 0.2,
            153: 0.2,
            157: 0.3,
            160: 0.3,
            163: 0.2,
            164: 0.4,
            166: 0.2,
        }
    )
    cp["valid_days"] = (pd.to_datetime(cp.expire_date) - cp.create_date).dt.days + 1
    groups = cp.groupby(["user_id", "create_date"])
    out["issue_policy_audit"] = {
        "target_issue_rows": len(cp),
        "target_user_days": len(groups),
        "different_target_doses_same_day": int(groups.dose.nunique().gt(1).sum()),
        "different_target_validities_same_day": int(groups.valid_days.nunique().gt(1).sum()),
        "single_dose_and_multiple_validities_separately_reported": True,
        "mixed_dose_days_excluded_from_single_dose_comparison": True,
    }
    july = c[
        c.coupon_id.isin([124, 164])
        & c.create_date.ge("2026-07-01")
        & c.create_date.lt("2026-08-01")
    ]
    first = set(july[july.create_date.eq("2026-07-16")].user_id)
    for (day, cid), g in july.groupby(["create_date", "coupon_id"]):
        out["july40_contacts"].append(
            {
                "day": str(day.date()),
                "coupon_id": int(cid),
                "issue_rows": len(g),
                "users": int(g.user_id.nunique()),
                "in_july16_users": len(set(g.user_id) & first),
            }
        )
    H = W / "historical_validation/private"
    a = pd.read_parquet(H / "historical_validated.parquet")
    a["anchor"] = pd.to_datetime(a.anchor)
    a = (
        a[a.study.isin(STUDIES) & a.qualified]
        .sort_values(["anchor", "episode_id"])
        .drop_duplicates(["study", "user_id", "latest_credit_serial"])
        .copy()
    )
    assert not a.duplicated(["study", "user_id", "latest_credit_serial"]).any()
    assert a.anchor.ge("2026-06-15").all() and a.anchor.lt("2026-10-31").all()
    assert all(a[f"observed_{h}"].eq(1).all() for h in [3, 7, 15, 30])
    loans = pd.read_parquet(H / "loans_clean.parquet")
    daily = {}
    for source in ["new", "legacy"]:
        b = pd.read_parquet(H / f"behavior_{source}_daily.parquet")
        b["d"] = pd.to_datetime(b.d)
        daily[source] = b.set_index(["user_id", "d"])
    for st, g in a.groupby("study"):
        g = g.copy()
        out["ab_scope"].append(
            {
                "study": st,
                "events": len(g),
                "users": int(g.user_id.nunique()),
                "churn_min": float(g.churn_days.min()),
                "churn_max": float(g.churn_days.max()),
                "first_date": str(g.anchor.min().date()),
                "last_date": str(g.anchor.max().date()),
                "source_tables": sorted(set(g.batch)),
            }
        )
        for arm, gg in g.groupby("ab_group"):
            r = {"study": st, "arm": arm, "events": len(gg), "users": int(gg.user_id.nunique())}
            for h in [3, 7, 15, 30]:
                r.update(
                    {
                        f"y_{h}": int(gg[f"applied_{h}"].sum()),
                        f"rate_{h}": float(gg[f"applied_{h}"].mean()),
                    }
                )
            out["ab_rates"].append(r)
            for sig, ss in gg.groupby("actual_issue_signature"):
                out["ab_issuance"].append(
                    {
                        "study": st,
                        "arm": arm,
                        "signature": sig,
                        "events": len(ss),
                        "share": len(ss) / len(gg),
                    }
                )
            for batch, ss in gg.groupby("batch"):
                r = {"study": st, "batch": batch, "arm": arm, "events": len(ss)}
                for h in [3, 7, 15, 30]:
                    r.update(
                        {
                            f"y_{h}": int(ss[f"applied_{h}"].sum()),
                            f"rate_{h}": float(ss[f"applied_{h}"].mean()),
                        }
                    )
                out["ab_batch_rates"].append(r)
        for h in [3, 7, 15, 30]:
            out["ab_comparisons"].append(
                {
                    "study": st,
                    "window": h,
                    **cluster_comparison(g, f"applied_{h}", groups=(0, 1), B=4000),
                }
            )
        app_day = (
            pd.to_datetime(g.first_apply_s, unit="s", errors="coerce", utc=True)
            .dt.tz_convert("America/Belize")
            .dt.tz_localize(None)
            .dt.normalize()
        )
        delta = (app_day - g.anchor).dt.days
        for low, high, label in [
            (0, 1, "D0"),
            (1, 3, "D1—D2"),
            (3, 7, "D3—D6"),
            (7, 15, "D7—D14"),
            (15, 30, "D15—D29"),
        ]:
            zz = g.copy()
            zz["window_response"] = delta.ge(low) & delta.lt(high)
            out["ab_timing"].append(
                {
                    "study": st,
                    "period": label,
                    **cluster_comparison(zz, "window_response", groups=(0, 1), B=4000),
                }
            )
        for col in [
            "score410",
            "score363",
            "score405",
            "prior_fund_n",
            "churn_days",
            "mean_funded_utilization",
            "hist_offer_d7_rate90",
            "latest_credit_amt",
        ]:
            c0 = g[g.treat.eq(0)][col]
            c1 = g[g.treat.eq(1)][col]
            out["ab_balance"].append(
                {
                    "study": st,
                    "feature": col,
                    "control_mean": float(c0.mean()),
                    "treatment_mean": float(c1.mean()),
                    "smd": smd(c1, c0),
                    "control_known": int(c0.notna().sum()),
                    "treatment_known": int(c1.notna().sum()),
                }
            )
        for h in [3, 7, 15, 30]:
            response = g[g[f"applied_{h}"].eq(1)][
                ["user_id", "episode_id", "first_apply_serial", "ab_group"]
            ].merge(
                loans[
                    [
                        "user_id",
                        "serial_id",
                        "funded",
                        "remit_amt",
                        "repaid_amt",
                        "due_date",
                        "loan_status_code",
                    ]
                ],
                left_on=["user_id", "first_apply_serial"],
                right_on=["user_id", "serial_id"],
                validate="many_to_one",
            )
            cash = g[["user_id", "dose", "episode_id"]].copy()
            cash["cash_net"] = 0.0
            cash["funded_amt"] = 0.0
            cash["repaid_amt"] = 0.0
            cash["mature_order"] = 0
            matured = response[
                response.funded
                & pd.to_datetime(response.due_date).lt(END)
                & response.repaid_amt.notna()
            ].drop_duplicates(["user_id", "serial_id"])
            ix = cash.episode_id.isin(matured.episode_id)
            mm = matured.set_index("episode_id")
            cash.loc[ix, "cash_net"] = (
                cash.loc[ix, "episode_id"].map(mm.repaid_amt - mm.remit_amt).to_numpy()
            )
            cash.loc[ix, "funded_amt"] = cash.loc[ix, "episode_id"].map(mm.remit_amt).to_numpy()
            cash.loc[ix, "repaid_amt"] = (
                cash.loc[ix, "episode_id"].map(mm.repaid_amt).to_numpy()
            )
            cash.loc[ix, "mature_order"] = 1
            out["ab_cash_comparisons"].append(
                {
                    "study": st,
                    "window": h,
                    **cluster_comparison(cash, "cash_net", groups=(0, 1), B=4000),
                    "interpretation": "Observed mature same-first-order net receipts per originally assigned eligible credit event. Incomplete maturity and omitted costs prevent final profit interpretation.",
                }
            )
            for arm, gg in response.groupby("ab_group"):
                gg = gg.drop_duplicates(["user_id", "serial_id"])
                m = gg[gg.funded & pd.to_datetime(gg.due_date).lt(END) & gg.repaid_amt.notna()]
                denom = int(g.ab_group.eq(arm).sum())
                r = finance(m)
                r.update(
                    {
                        "study": st,
                        "arm": arm,
                        "window": h,
                        "assigned_events": denom,
                        "first_response_orders": len(gg),
                        "funded_first_orders": int(gg.funded.sum()),
                        "mature_share_of_funded": (
                            len(m) / int(gg.funded.sum()) if gg.funded.sum() else None
                        ),
                        "observed_mature_net_per_assigned": float(
                            (m.repaid_amt - m.remit_amt).sum() / denom
                        ),
                    }
                )
                out["ab_finance"].append(r)
        for h in [3, 7]:
            entries = {}
            before = {}
            for source in ["new", "legacy"]:
                seen = np.zeros(len(g), bool)
                pre = np.zeros(len(g), bool)
                for d in range(h):
                    key = pd.MultiIndex.from_arrays(
                        [g.user_id, (g.anchor + pd.Timedelta(days=d))], names=["user_id", "d"]
                    )
                    vv = (
                        pd.to_numeric(
                            daily[source]["loan_entry_n"].reindex(key), errors="coerce"
                        )
                        .fillna(0)
                        .gt(0)
                        .to_numpy()
                    )
                    tt = pd.to_numeric(
                        daily[source]["loan_entry_epoch"].reindex(key), errors="coerce"
                    ).to_numpy(float)
                    seen |= vv
                    pre |= vv & (tt < g.first_apply_s.fillna(np.inf).to_numpy(float))
                entries[source] = seen
                before[source] = pre
            entries["union"] = entries["new"] | entries["legacy"]
            before["union"] = before["new"] | before["legacy"]
            for source in ["new", "legacy", "union"]:
                for arm in ["control", "treatment"]:
                    ix = g.ab_group.eq(arm).to_numpy()
                    app = g[f"applied_{h}"].eq(1).to_numpy()
                    n = int(ix.sum())
                    y = int((ix & app).sum())
                    covered = int((ix & app & before[source]).sum())
                    out["ab_funnel"].append(
                        {
                            "study": st,
                            "source": source,
                            "window": h,
                            "arm": arm,
                            "events": n,
                            "seen_loanpage_events": int((ix & entries[source]).sum()),
                            "before_first_app_page_events": int((ix & before[source]).sum()),
                            "page_to_application_share": (
                                covered / int((ix & before[source]).sum())
                                if (ix & before[source]).any()
                                else None
                            ),
                            "applicants": y,
                            "applicants_with_prior_page": covered,
                            "applicants_without_prior_page": y - covered,
                            "recorded_prior_page_share_of_applicants": (
                                covered / y if y else None
                            ),
                        }
                    )
        for source in ["new", "legacy"]:
            for metric, field, epoch in [
                ("active", "logs", "first_active_epoch"),
                ("loan_entry", "loan_entry_n", "loan_entry_epoch"),
            ]:
                vals = {}
                preapp = {}
                for day in range(-4, 30):
                    key = pd.MultiIndex.from_arrays(
                        [g.user_id, (g.anchor + pd.Timedelta(days=day))], names=["user_id", "d"]
                    )
                    vv = (
                        pd.to_numeric(daily[source][field].reindex(key), errors="coerce")
                        .fillna(0)
                        .gt(0)
                        .to_numpy(float)
                    )
                    tt = pd.to_numeric(
                        daily[source][epoch].reindex(key), errors="coerce"
                    ).to_numpy(float)
                    vals[day] = vv
                    preapp[day] = (
                        vv * (tt < g.first_apply_s.fillna(np.inf).to_numpy(float))
                        if day >= 0
                        else vv
                    )
                    for arm in ["control", "treatment"]:
                        ix = g.ab_group.eq(arm).to_numpy()
                        out["ab_daily"].append(
                            {
                                "study": st,
                                "source": source,
                                "metric": metric,
                                "day": day,
                                "arm": arm,
                                "events": int(ix.sum()),
                                "rate": float(vv[ix].mean()),
                            }
                        )
                baseline = np.mean([vals[d] for d in [-4, -3, -2, -1]], axis=0)
                if source == "new" and metric == "loan_entry":
                    g["pre4_loanpage_days"] = np.sum(
                        [vals[d] for d in [-4, -3, -2, -1]], axis=0
                    )
                if source == "new" and metric == "active":
                    g["pre4_active_days"] = np.sum([vals[d] for d in [-4, -3, -2, -1]], axis=0)
                for start, stop, label in [
                    (0, 3, "D0—D2"),
                    (3, 7, "D3—D6"),
                    (7, 14, "D7—D13"),
                    (14, 30, "D14—D29"),
                ]:
                    post = np.mean([vals[d] for d in range(start, stop)], axis=0)
                    for version, v in [
                        ("post", post),
                        ("change_vs_pre4", post - baseline),
                        (
                            "before_first_app",
                            np.mean([preapp[d] for d in range(start, stop)], axis=0),
                        ),
                    ]:
                        gg = g[["user_id", "dose"]].copy()
                        gg["value"] = v
                        r = cluster_comparison(gg, "value", groups=(0, 1), B=2000)
                        out["ab_behavior_effects"].append(
                            {
                                "study": st,
                                "source": source,
                                "metric": metric,
                                "period": label,
                                "version": version,
                                **r,
                            }
                        )
        dims = {
            "发券前4天提单页": g.pre4_loanpage_days.gt(0).map({True: "有", False: "无"}),
            "发券前4天活跃": g.pre4_active_days.gt(0).map({True: "有", False: "无"}),
            "历史成功借款次数": pd.cut(
                g.prior_fund_n,
                [0, 1, 3, 6, np.inf],
                labels=["1次", "2—3次", "4—6次", "7次及以上"],
                include_lowest=True,
            ),
            "410模型分": pd.cut(
                g.score410,
                [-np.inf, 500, 528, np.inf],
                labels=["<500", "500—527", "≥528"],
                right=False,
            )
            .astype(str)
            .where(g.score410.notna(), "缺分"),
            "历史额度使用率": pd.cut(
                g.mean_funded_utilization,
                [-np.inf, 0.8, 1.03, np.inf],
                labels=["<80%", "80%—103%", ">103%"],
                right=False,
            )
            .astype(str)
            .where(g.mean_funded_utilization.notna(), "缺失"),
            "历史7日提单率": pd.cut(
                g.hist_offer_d7_rate90,
                [-0.01, 0.2, 0.5, 1.01],
                labels=["≤20%", "20%—50%", ">50%"],
            )
            .astype(str)
            .where(g.hist_offer_d7_n90.ge(3), "不足3笔/缺失"),
        }
        for dim, levels in dims.items():
            zz = g.assign(level=levels)
            for lev, gg in zz.groupby("level", observed=True):
                for arm, aa in gg.groupby("ab_group"):
                    r = {
                        "study": st,
                        "dimension": dim,
                        "level": str(lev),
                        "arm": arm,
                        "events": len(aa),
                    }
                    for h in [3, 7, 15, 30]:
                        r.update(
                            {
                                f"y_{h}": int(aa[f"applied_{h}"].sum()),
                                f"rate_{h}": float(aa[f"applied_{h}"].mean()),
                            }
                        )
                    out["ab_subgroup_rates"].append(r)
                if gg.treat.value_counts().min() >= 20 and gg.treat.nunique() == 2:
                    for h in [3, 7, 30]:
                        out["ab_subgroup_comparisons"].append(
                            {
                                "study": st,
                                "dimension": dim,
                                "level": str(lev),
                                "window": h,
                                **cluster_comparison(gg, f"applied_{h}", groups=(0, 1), B=2000),
                            }
                        )
    out["quality_checks"] = {
        "ab_unique_study_user_credit": not a.duplicated(
            ["study", "user_id", "latest_credit_serial"]
        ).any(),
        "all_ab_windows_mature": all(a[f"observed_{h}"].eq(1).all() for h in [3, 7, 15, 30]),
        "main_in_scope": bool(
            main.anchor.ge("2026-06-15").all() and main.anchor.lt("2026-10-31").all()
        ),
        "main_unique_user_credit": not main.duplicated(
            ["user_id", "latest_credit_serial"]
        ).any(),
        "excluded_user_present": bool(
            main.user_id.isin(excluded_user_ids()).any()
            or a.user_id.isin(excluded_user_ids()).any()
        ),
    }
    a.to_parquet(PRIVATE / "expanded_ab_analysis.parquet", index=False, compression="zstd")
    dump(W / "expanded_policy_results.json", out)
    mark(
        "expanded_policy_validation_complete",
        **out["primary_scope"],
        ab_events=len(a),
        ab_studies=len(out["ab_scope"]),
    )


if __name__ == "__main__":
    run()
