"""Validate historical A/B-marked policy bundles against actual issuance and pre-issue eligibility.

Randomization provenance is not reconstructed from an A/B label. T5 and T7
populations remain separate; assigned-arm analysis never conditions on redemption.
"""

from core import *
from stats_utils import *

H = W / "historical_validation"
HP = H / "private"


def study(t):
    if t == "user_test_verification_0708":
        return "T7_July08_utilization_policy"
    if t == "high_discount_test_0708":
        return "T7_July08_high_discount"
    if any(d in t for d in ["0716_0721", "0717_0722", "0718_0723", "0719_0724"]):
        return "T5_30pct_7day_vs_none"
    if any(d in t for d in ["0730_0804", "0731_0805", "0801_0806", "0802_0807"]):
        return "T5_30pct_7day_vs_3day"
    if any(d in t for d in ["0813_0818", "0815_0820", "0816_0821"]):
        return "T5_30pct_3day_vs_none_round1"
    if any(d in t for d in ["0821_0826", "0822_0827", "0823_0828"]):
        return "T5_30pct_3day_vs_none_round2"
    return "T5_September18_marked_test"


def run():
    f = pd.read_parquet(HP / "historical_analysis.parquet")
    f["anchor"] = pd.to_datetime(f.anchor)
    if "churn_days_y" in f:
        f = f.rename(
            columns={"churn_days_y": "churn_days", "churn_days_x": "source_churn_days"}
        )
    f = apply_eligibility_contract(f)
    f["study"] = f.batch.map(study)
    f["treat"] = f.ab_group.eq("treatment").astype(int)
    f["dose"] = f.treat
    f["clean_no_apply"] = (
        f.open_n.eq(0)
        & f.prior_settled_n.gt(0)
        & f.days_since_last_apply.ge(f.days_since_last_settle)
        & f.history_state_known.eq(1)
    )
    f["domain_ok"] = np.where(
        f.study.str.startswith("T7_"), f.strict_t7.eq(1), f.clean_no_apply & f.churn_days.ge(4)
    )
    f["qualified"] = f.eligible_offer.eq(1) & f.domain_ok
    f["calendar"] = f.anchor.dt.strftime("%Y-%m-%d")
    c = pd.read_parquet(HP / "all_issue_histories.parquet")
    for k in ["create_date", "expire_date", "used_date"]:
        c[k] = pd.to_datetime(c[k], errors="coerce")
    for k in ["type", "coupon_id", "real_use_amount", "user_id"]:
        c[k] = pd.to_numeric(c[k], errors="coerce")
    cat = pd.read_parquet(PRIVATE / "coupon_catalog.parquet")
    for k in ["coupon_id", "type", "rate"]:
        cat[k] = pd.to_numeric(cat[k], errors="coerce")
    cat = cat[cat.type.eq(3)]
    agg = cat.groupby("coupon_id").rate.agg(["min", "nunique"])
    rate_map = agg.loc[agg["nunique"].eq(1), "min"].to_dict()
    rate_map.update(
        {
            119: 0.2,
            124: 0.4,
            141: 0.2,
            153: 0.2,
            157: 0.3,
            160: 0.3,
            163: 0.2,
            164: 0.4,
            166: 0.2,
        }
    )
    c["nominal_rate"] = c.coupon_id.map(rate_map)
    c["valid_days"] = (c.expire_date - c.create_date).dt.days + 1
    by = {uid: g for uid, g in c.groupby("user_id", sort=False)}
    alloc = []
    for a in f.itertuples():
        cc = by.get(a.user_id)
        cc = cc[cc.create_date.eq(a.anchor)] if cc is not None else c.iloc[:0]
        sig = []
        for (tp, r, d), g in cc.groupby(["type", "nominal_rate", "valid_days"], dropna=False):
            sig.append(
                ("减息" + str(round(r * 100)) + "%/" + str(int(d)) + "天")
                if tp == 3 and np.isfinite(r)
                else ("提额" if tp == 4 else ("还款" if tp == 2 else "其他/配置缺失"))
            )
        alloc.append(
            {
                "episode_id": a.episode_id,
                "actual_issue_signature": (
                    "＋".join(sorted(set(sig))) if sig else "当日无券记录"
                ),
                "has_any_issue": int(len(cc) > 0),
                "has_discount20": int((cc.type.eq(3) & cc.nominal_rate.eq(0.2)).any()),
                "has_discount30": int((cc.type.eq(3) & cc.nominal_rate.eq(0.3)).any()),
                "has_discount40": int((cc.type.eq(3) & cc.nominal_rate.eq(0.4)).any()),
                "has_amount": int(cc.type.eq(4).any()),
            }
        )
    f = f.merge(pd.DataFrame(alloc), on="episode_id", validate="one_to_one")
    out = {
        "scope": [],
        "issuance": [],
        "rates": [],
        "batch_rates": [],
        "comparisons": [],
        "baseline": [],
        "subgroups": [],
        "finance": [],
        "provenance": "User confirms no_apply_* were A/B tests with treatment assigned 30% discount. Analyze original assigned arms, audit execution and baseline balance. No retained allocation log is available; non-no_apply July studies change policy bundles.",
    }
    features = [
        "score410",
        "score363",
        "score405",
        "prior_fund_n",
        "churn_days",
        "mean_funded_utilization",
        "hist_offer_d7_rate90",
        "latest_credit_amt",
        "pre7_new_active_days",
        "pre7_new_loan_entry_days",
    ]
    loans = pd.read_parquet(HP / "loans_clean.parquet")
    for name, g in f.groupby("study"):
        out["scope"].append(
            {
                "study": name,
                "raw_events": len(g),
                "raw_users": g.user_id.nunique(),
                "qualified_events": int(g.qualified.sum()),
                "latest_passed_non1_events": int(g.eligible_offer.sum()),
                "strict_t7": int(g.strict_t7.sum()),
                "mean_reconstructed_churn": float(g.churn_days.mean()),
            }
        )
        for scope, z in [("all_list", g), ("qualified_contacts", g[g.qualified])]:
            if scope == "qualified_contacts":
                z = z.sort_values(["anchor", "episode_id"]).drop_duplicates(
                    ["user_id", "latest_credit_serial"]
                )
                scope = "qualified_unique_credit_orders"
            for (arm, signature), gg in z.groupby(["ab_group", "actual_issue_signature"]):
                out["issuance"].append(
                    {
                        "study": name,
                        "scope": scope,
                        "arm": arm,
                        "issue_signature": signature,
                        "events": len(gg),
                    }
                )
            for arm, gg in z.groupby("ab_group"):
                rr = {
                    "study": name,
                    "scope": scope,
                    "arm": arm,
                    "events": len(gg),
                    "users": gg.user_id.nunique(),
                }
                for d in [3, 7, 15, 30]:
                    rr.update(
                        {
                            f"y_{d}": int(gg[f"applied_{d}"].sum()),
                            f"rate_{d}": float(gg[f"applied_{d}"].mean()),
                        }
                    )
                out["rates"].append(rr)
                for col in features:
                    out["baseline"].append(
                        {
                            "study": name,
                            "scope": scope,
                            "arm": arm,
                            "feature": col,
                            "known": int(gg[col].notna().sum()),
                            "mean": float(gg[col].mean()),
                            "median": float(gg[col].median()),
                        }
                    )
            for d in [3, 7, 15, 30]:
                r = cluster_comparison(z, f"applied_{d}", groups=(0, 1), B=2000)
                if r:
                    out["comparisons"].append({"study": name, "scope": scope, "window": d, **r})
            if scope != "qualified_unique_credit_orders":
                continue
            for col, label in [
                ("pre7_new_loan_entry_days", "recent_loanpage"),
                ("pre7_new_active_days", "recent_active"),
                ("mean_funded_utilization", "util_low80"),
                ("churn_days", "churn_ge91"),
            ]:
                zz = z.copy()
                if col == "mean_funded_utilization":
                    zz["level"] = (
                        zz[col]
                        .lt(0.8)
                        .map({True: "<80%", False: "≥80%"})
                        .where(zz[col].notna(), "缺失")
                    )
                elif col == "churn_days":
                    zz["level"] = zz[col].ge(91).map({True: "≥91天", False: "<91天"})
                else:
                    zz["level"] = zz[col].gt(0).map({True: "有", False: "无"})
                for (lev, arm), gg in zz.groupby(["level", "ab_group"]):
                    out["subgroups"].append(
                        {
                            "study": name,
                            "dimension": label,
                            "level": lev,
                            "arm": arm,
                            "events": len(gg),
                            "y_3": int(gg.applied_3.sum()),
                            "rate_3": float(gg.applied_3.mean()),
                            "y_7": int(gg.applied_7.sum()),
                            "rate_7": float(gg.applied_7.mean()),
                        }
                    )
            # Current cash quality of the same first response order within 3d.
            use = z.loc[
                z.applied_3.eq(1), ["episode_id", "user_id", "first_apply_serial", "ab_group"]
            ].merge(
                loans[
                    [
                        "user_id",
                        "serial_id",
                        "funded",
                        "remit_amt",
                        "repaid_amt",
                        "due_date",
                        "loan_status_code",
                    ]
                ],
                left_on=["user_id", "first_apply_serial"],
                right_on=["user_id", "serial_id"],
                validate="many_to_one",
            )
            use = use[
                use.funded
                & use.due_date.lt(pd.Timestamp("2026-11-04"))
                & use.repaid_amt.notna()
            ]
            for arm, gg in use.groupby("ab_group"):
                gg = gg.drop_duplicates(["user_id", "serial_id"])
                out["finance"].append(
                    {
                        "study": name,
                        "arm": arm,
                        "mature_first_orders": len(gg),
                        "funded_amt": float(gg.remit_amt.sum()),
                        "repaid_amt": float(gg.repaid_amt.sum()),
                        "profit_rate": float(
                            (gg.repaid_amt.sum() - gg.remit_amt.sum()) / gg.remit_amt.sum()
                        ),
                        "order_overdue_rate": float(gg.loan_status_code.eq(8).mean()),
                    }
                )
            for (batch, arm), gg in z.groupby(["batch", "ab_group"]):
                out["batch_rates"].append(
                    {
                        "study": name,
                        "batch": batch,
                        "arm": arm,
                        "events": len(gg),
                        "y_3": int(gg.applied_3.sum()),
                        "rate_3": float(gg.applied_3.mean()),
                    }
                )
    f.to_parquet(HP / "historical_validated.parquet", index=False, compression="zstd")
    dump(W / "historical_ab_validation_results.json", out)
    mark("historical_AB_validation_complete", studies=len(out["scope"]))


if __name__ == "__main__":
    run()
