"""Audit the expanded recall period and July coupon cohorts using actual issue records."""

from core import *
import re

START = pd.Timestamp("2026-06-15")
STOP = pd.Timestamp("2026-10-31")


def run():
    c = connect()
    try:
        tables = query(
            c,
            """SELECT table_name FROM information_schema.tables WHERE table_schema='wangchuanliang'
            AND (table_name ILIKE '%%recall%%' OR table_name ILIKE '%%test%%' OR table_name ILIKE 'no_apply_%%') ORDER BY table_name""",
            {},
            "recall_table_inventory",
        )
        names = [
            t
            for t in tables.table_name
            if t.startswith(
                ("t7recall", "no_apply_", "user_test_", "high_discount_test_", "user_recall_")
            )
        ]
        schema = query(
            c,
            """SELECT table_name,column_name,data_type,ordinal_position FROM information_schema.columns
            WHERE table_schema='wangchuanliang' AND table_name=ANY(%(tables)s) ORDER BY table_name,ordinal_position""",
            {"tables": names},
            "expanded_recall_schema",
        )
        frames = []
        audits = []
        preferred = [
            "churn_user_id",
            "user_id",
            "uid",
            "ab_group",
            "coupon_level_2",
            "score",
            "prod_risk_level",
            "strat",
            "churn_days",
            "churned_days",
            "utilization_type",
            "user_type",
            "interest_type",
        ]
        for t in names:
            cols = schema.loc[schema.table_name.eq(t), "column_name"].tolist()
            key = next((k for k in ["churn_user_id", "user_id", "uid"] if k in cols), None)
            if key is None:
                continue
            use = [v for v in preferred if v in cols]
            sql = (
                "SELECT "
                + ",".join('"' + v + '"' for v in use)
                + " FROM wangchuanliang."
                + t
                + ' WHERE "'
                + key
                + '" IS NOT NULL AND "'
                + key
                + '"<> ALL(%(__excluded_user_ids)s::bigint[])'
            )
            f = query(c, sql, {}, "expanded_list_" + t)
            f = f.reindex(columns=use)
            f["user_id"] = pd.to_numeric(f[key], errors="coerce")
            f = f[f.user_id.notna()].copy()
            f["user_id"] = f.user_id.astype("int64")
            f["batch"] = t
            m = re.search(r"(\d{4})$", t)
            md = m.group(1) if m else None
            if md is None:
                n = re.fullmatch(r"no_apply_\d{4}_(\d{4})_30pct", t)
                md = n.group(1) if n else None
            f["list_date"] = pd.Timestamp("2026-" + md[:2] + "-" + md[2:]) if md else pd.NaT
            frames.append(f)
            audits.append(
                {
                    "table": t,
                    "rows": len(f),
                    "users": int(f.user_id.nunique()),
                    "list_date": str(f.list_date.iloc[0]) if len(f) else None,
                    "ab_groups": (
                        f.ab_group.astype(str).value_counts().to_dict()
                        if "ab_group" in f
                        else {}
                    ),
                }
            )
        lists = parquet_safe(pd.concat(frames, ignore_index=True, sort=False))
        lists.to_parquet(
            PRIVATE / "expanded_recall_lists.parquet", index=False, compression="zstd"
        )
    finally:
        c.rollback()
        c.close()
    issues = pd.read_parquet(PRIVATE / "all_issue_histories.parquet")
    for col in ["create_date", "expire_date"]:
        issues[col] = pd.to_datetime(issues[col], errors="coerce")
    for col in ["user_id", "coupon_id", "type"]:
        issues[col] = pd.to_numeric(issues[col], errors="coerce")
    out = {
        "recall_tables": audits,
        "issue_period": ["2026-06-15", "2026-10-30"],
        "july40": [],
        "july40_overlap": [],
        "ab_design_provenance": "User confirms no_apply_* are A/B tests and treatment received 30% interest discount; analyze assigned arms and audit actual delivery separately.",
    }
    q = issues[
        issues.type.eq(3)
        & issues.coupon_id.isin([124, 164])
        & issues.create_date.between("2026-07-01", "2026-07-31")
    ]
    dates = {}
    for (day, coupon), g in q.groupby(["create_date", "coupon_id"]):
        users = set(g.user_id)
        dates[str(day.date())] = users
        rec = {
            "date": str(day.date()),
            "coupon_id": int(coupon),
            "coupon_rows": len(g),
            "users": len(users),
            "valid_days": sorted(set((g.expire_date - g.create_date).dt.days + 1)),
            "list_overlap": [],
        }
        for t, gg in lists.groupby("batch"):
            overlap = users & set(gg.user_id)
            if len(overlap) >= 0.5 * len(users):
                rec["list_overlap"].append(
                    {
                        "table": t,
                        "users": len(overlap),
                        "ab_groups": (
                            gg[gg.user_id.isin(overlap)]
                            .ab_group.astype(str)
                            .value_counts()
                            .to_dict()
                            if "ab_group" in gg
                            else {}
                        ),
                    }
                )
        out["july40"].append(rec)
    ds = sorted(dates)
    for i, day in enumerate(ds):
        for next_day in ds[i + 1 :]:
            out["july40_overlap"].append(
                {
                    "first_date": day,
                    "later_date": next_day,
                    "shared_users": len(dates[day] & dates[next_day]),
                }
            )
    dump(W / "expanded_scope_audit.json", out)
    mark("expanded_scope_audited", tables=len(audits), july40_dates=ds)


if __name__ == "__main__":
    run()
