from core import *

sql = """SELECT CASE WHEN c.coupon_id IN(119,141,153,163,166) THEN 0.20
                  WHEN c.coupon_id IN(157,160) THEN 0.30 ELSE 0.40 END AS dose,
 c.valid_days,COUNT(*) AS orders,SUM(o.remit_amt) AS funded_amt,SUM(o.repaid_amt) AS repaid_amt,
 SUM(CASE WHEN o.loan_status_code=8 THEN 1 ELSE 0 END) AS overdue_orders,
 SUM(c.real_use_amount) AS coupon_used_amt
 FROM wangchuanliang.coupon_use_record c
 JOIN wangchuanliang.order_loan_f_v2_copy o ON o.user_id=c.user_id AND o.serial_id=c.serial_id
 WHERE c.coupon_type=3 AND c.real_use_amount>0
  AND c.coupon_id IN(119,124,141,153,157,160,163,164,166)
  AND c.create_date>=DATE '2026-06-15' AND c.create_date<DATE '2026-10-31'
  AND NOT (c.user_id = ANY(%(__excluded_user_ids)s::bigint[])) AND o.is_remit=1 AND o.remit_amt>0 AND o.due_date<DATE '2026-11-04'
 GROUP BY 1,c.valid_days ORDER BY 1,c.valid_days"""
c = connect()
try:
    f = query(c, sql, {}, "independent_financial_totals_expanded")
finally:
    c.rollback()
    c.close()
expected = json.loads((W / "financial_results.json").read_text())["broad_mature"]
mismatches = []
for row in f.to_dict("records"):
    match = next(
        x
        for x in expected
        if abs(float(x["dose"]) - float(row["dose"])) < 1e-6
        and int(x["valid_days"]) == int(row["valid_days"])
    )
    for k in ["orders", "funded_amt", "repaid_amt", "overdue_orders", "coupon_used_amt"]:
        if abs(float(match[k]) - float(row[k])) > 1e-5:
            mismatches.append(
                {
                    "dose": row["dose"],
                    "valid_days": row["valid_days"],
                    "field": k,
                    "python": match[k],
                    "sql": row[k],
                }
            )
assert not mismatches, mismatches
dump(
    W / "independent_financial_check.json",
    {
        "groups": len(f),
        "checked_fields": [
            "orders",
            "funded_amt",
            "repaid_amt",
            "overdue_orders",
            "coupon_used_amt",
        ],
        "mismatches": mismatches,
    },
)
mark("independent_financial_sql_check_complete", groups=len(f), mismatches=len(mismatches))
