from core import *

c = connect()
out = {}
try:
    with c.cursor() as q:
        q.execute("SET application_name='coupon_response_scope_and_batch_extraction'")
        q.execute("SELECT CURRENT_TIMESTAMP AT TIME ZONE 'America/Belize'")
        out["snapshot_business"] = str(q.fetchone()[0])
        q.execute(
            """SELECT table_name,column_name,data_type FROM information_schema.columns
            WHERE table_schema='wangchuanliang' AND (table_name=ANY(%s) OR table_name IN ('order_vir_f_copy','side_recycle_type_copy','model_result_copy','repayment_plan_v2_copy'))
            ORDER BY table_name,ordinal_position""",
            (BATCHES,),
        )
        cols = {}
        for t, n, d in q.fetchall():
            cols.setdefault(t, []).append({"name": n, "type": d})
        out["columns"] = cols
    dump(W / "cohort_source_schema.json", out)
    frames = []
    for table in BATCHES:
        assert table in cols
        names = [x["name"] for x in cols[table]]
        allowed = [
            n for n in names if n not in ["phone", "name", "email", "identity_number", "tcnt"]
        ]
        sql = (
            "SELECT "
            + ",".join('"' + n + '"' for n in allowed)
            + " FROM wangchuanliang."
            + table
            + " WHERE churn_user_id IS NOT NULL AND NOT (churn_user_id = ANY(%(__excluded_user_ids)s::bigint[]))"
        )
        f = query(c, sql, {}, table)
        f["batch"] = table
        f["batch_date"] = "2026-" + table[-4:-2] + "-" + table[-2:]
        frames.append(f)
    cohort = parquet_safe(pd.concat(frames, ignore_index=True, sort=False))
    cohort.to_parquet(
        PRIVATE / "recall_batch_features.parquet", index=False, compression="zstd"
    )
    out["recall_rows"] = len(cohort)
    out["recall_unique_users"] = cohort.churn_user_id.nunique()
    f = query(c, "SELECT * FROM wangchuanliang.coupon_cat", {}, "coupon_catalog")
    out["coupon_catalog"] = f.to_dict("records")
    # Coupon configuration and observed use map are separate evidence sources.
    # Date-only timestamps and true event clocks are recorded explicitly.
    sql = """SELECT coupon_id::text AS coupon_id,create_date::text AS send_date,
        expire_date-create_date+1 AS valid_days,COUNT(*) AS coupons,
        COUNT(DISTINCT user_id) AS users,SUM(CASE WHEN real_use_amount>0 THEN 1 ELSE 0 END) AS used_coupons
        FROM wangchuanliang.coupon_user_copy
        WHERE type=3 AND coupon_id NOT IN (126,149) AND NOT (user_id = ANY(%(__excluded_user_ids)s::bigint[]))
          AND create_date>=DATE '2026-06-01' AND create_date<DATE '2026-11-04'
        GROUP BY coupon_id,create_date,expire_date-create_date+1
        ORDER BY create_date,coupon_id"""
    f = query(c, sql, {}, "coupon_daily_allocation")
    out["allocation_rows"] = len(f)
    sql = """SELECT 'new'::text AS source,event_date::text AS event_date,
        COUNT(*) AS rows,COUNT(DISTINCT user_id) AS users,
        MIN(event_time)::text AS first_time,MAX(event_time)::text AS last_time
        FROM wangchuanliang.user_behavior_track_record
        WHERE event_date>=DATE '2026-11-04'-2 AND event_date<=DATE '2026-11-04'
        GROUP BY event_date
        UNION ALL
        SELECT 'legacy'::text,create_date::text,COUNT(*),COUNT(DISTINCT user_id),MIN(create_time)::text,MAX(create_time)::text
        FROM wangchuanliang.event_track_record
        WHERE create_date>=DATE '2026-11-04'-2 AND create_date<=DATE '2026-11-04'
        GROUP BY create_date"""
    f = query(c, sql, {}, "recent_tracking_coverage")
    out["tracking_coverage"] = f.to_dict("records")
finally:
    c.rollback()
    c.close()
dump(W / "scope_summary.json", out)
mark(
    "scope_complete",
    recall_rows=out["recall_rows"],
    recall_unique_users=out["recall_unique_users"],
    tracking_coverage=out["tracking_coverage"],
)
