"""Additional baseline mechanisms: normal clean-settlement gaps, prior coupon response, last product and price."""

from core import *

TARGET_IDS = [119, 124, 141, 153, 157, 160, 163, 164, 166]


def extend(f, loans):
    coupons = pd.read_parquet(PRIVATE / "all_issue_histories.parquet")
    for k in ["create_date", "expire_date", "used_date"]:
        coupons[k] = pd.to_datetime(coupons[k], errors="coerce", format="mixed")
    for k in ["user_id", "type", "coupon_id", "real_use_amount"]:
        coupons[k] = pd.to_numeric(coupons[k], errors="coerce")
    cg = {
        uid: g
        for uid, g in coupons[coupons.type.eq(3) & coupons.coupon_id.isin(TARGET_IDS)].groupby(
            "user_id", sort=False
        )
    }
    lg = {
        uid: g.sort_values(["apply_time", "serial_id"])
        for uid, g in loans.groupby("user_id", sort=False)
    }
    records = []
    clock_violations = 0
    for uid, aa in f.groupby("user_id", sort=False):
        ll = lg.get(uid)
        cc = cg.get(uid)
        funds = ll[ll.funded].sort_values("remit_time") if ll is not None else loans.iloc[:0]
        app_times = (
            ll.apply_time.to_numpy(dtype="datetime64[ns]")
            if ll is not None
            else np.array([], dtype="datetime64[ns]")
        )
        fund_times = funds.remit_time.to_numpy(dtype="datetime64[ns]")
        gap_pairs = []
        for ct in sorted(funds.valid_settle.dropna().unique()):
            # Complete clean settlement: no other funded loan is outstanding after all settlements at ct.
            open_at = funds[
                (funds.remit_time <= ct)
                & (funds.valid_settle.isna() | (funds.valid_settle > ct))
            ]
            if len(open_at):
                continue
            j = np.searchsorted(app_times, np.datetime64(ct, "ns"), side="left")
            if j < len(app_times):
                gap_pairs.append(
                    (
                        pd.Timestamp(app_times[j]),
                        (pd.Timestamp(app_times[j]) - pd.Timestamp(ct)).total_seconds()
                        / 86400.0,
                    )
                )
        for a in aa.itertuples():
            r = {"episode_id": a.episode_id}
            t = np.datetime64(a.anchor, "ns")
            n = np.searchsorted(fund_times, t, side="left")
            if n:
                last = funds.iloc[n - 1]
                r.update(
                    {
                        "last_funded_loan_day": last.loan_day,
                        "last_funded_total_term": last.total_term,
                        "last_funded_product": last.product_no,
                        "days_since_last_fund": (a.anchor - last.remit_time).total_seconds()
                        / 86400.0,
                        "last_funded_fee_rate": (
                            (last.pre_amt + last.post_amt) / last.remit_amt
                            if last.remit_amt > 0
                            else np.nan
                        ),
                    }
                )
            else:
                r.update(
                    {
                        "last_funded_loan_day": np.nan,
                        "last_funded_total_term": np.nan,
                        "last_funded_product": None,
                        "days_since_last_fund": np.nan,
                        "last_funded_fee_rate": np.nan,
                    }
                )
            gg = [v for when, v in gap_pairs if when < a.anchor]
            r["completed_clean_gap_n"] = len(gg)
            r["historical_clean_gap_median"] = float(np.median(gg)) if gg else np.nan
            r["historical_clean_gap_mean"] = float(np.mean(gg)) if gg else np.nan
            r["excess_idle_days"] = (
                a.churn_days - r["historical_clean_gap_median"]
                if np.isfinite(a.churn_days) and gg
                else np.nan
            )
            r["borrow_cycle_multiple"] = (
                r["days_since_last_fund"] / a.mean_borrow_gap_days
                if np.isfinite(a.mean_borrow_gap_days) and a.mean_borrow_gap_days > 0
                else np.nan
            )
            r["last_util_minus_mean"] = a.last_funded_utilization - a.mean_funded_utilization
            if cc is not None:
                hist = cc[
                    (cc.create_date >= a.anchor - pd.Timedelta(days=30))
                    & (cc.expire_date < a.anchor)
                ]
                used = (
                    hist.real_use_amount.gt(0)
                    & hist.used_date.ge(hist.create_date)
                    & hist.used_date.lt(a.anchor)
                )
                r["prior_expired_target_coupons30"] = len(hist)
                r["prior_used_target_coupons30"] = int(used.sum())
                r["prior_target_coupon_use_rate30"] = (
                    float(used.mean()) if len(hist) else np.nan
                )
            else:
                r.update(
                    {
                        "prior_expired_target_coupons30": 0,
                        "prior_used_target_coupons30": 0,
                        "prior_target_coupon_use_rate30": np.nan,
                    }
                )
            records.append(r)
        if len(records) % 20000 < len(aa):
            mark("cycle_extension_progress", episodes=len(records))
    cols = [c for c in pd.DataFrame(records).columns if c != "episode_id"]
    out = f.drop(columns=[c for c in cols if c in f]).merge(
        pd.DataFrame(records), on="episode_id", validate="one_to_one"
    )
    dump(
        W / "customer_cycle_extension_audit.json",
        {
            "events": len(out),
            "future_completed_gap_not_used": True,
            "coupon_usage_requires_expired_coupon_and_used_date_before_anchor": True,
            "normal_cycle_available_events": int(out.historical_clean_gap_median.notna().sum()),
            "historical_coupon_use_rate_available_events": int(
                out.prior_target_coupon_use_rate30.notna().sum()
            ),
        },
    )
    return out
