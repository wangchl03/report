from core import *
from stats_utils import *
from importlib import import_module
import importlib.util

spec = importlib.util.spec_from_file_location("_rates", W / "11_rates.py")
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)


def band(s, edges, labels):
    return (
        pd.cut(s, edges, labels=labels, right=False, include_lowest=True)
        .astype(str)
        .where(s.notna(), "缺失")
    )


def run():
    f = pd.read_parquet(PRIVATE / "episode_analysis.parquet")
    f, co = m.define_cohorts(f)
    f["borrow_band"] = band(
        f.prior_fund_n, [-np.inf, 2, 4, 7, np.inf], ["1次", "2—3次", "4—6次", "7次及以上"]
    )
    f["churn_band"] = band(
        f.churn_days,
        [-np.inf, 8, 15, 31, 61, 91, 181, np.inf],
        ["≤7天", "8—14天", "15—30天", "31—60天", "61—90天", "91—180天", "181天及以上"],
    )
    f["risk410_band"] = band(
        f.score410, [-np.inf, 450, 500, 528, np.inf], ["<450", "450—499", "500—527", "≥528"]
    )
    f["util_band"] = band(
        f.mean_funded_utilization,
        [-np.inf, 0.4, 0.6, 0.8, 0.97, 1.030000001, np.inf],
        ["<40%", "40—59%", "60—79%", "80—96%", "≈100%", ">103%"],
    )
    f["last_util_band"] = band(
        f.last_funded_utilization,
        [-np.inf, 0.4, 0.6, 0.8, 0.97, 1.030000001, np.inf],
        ["<40%", "40—59%", "60—79%", "80—96%", "≈100%", ">103%"],
    )
    f["active7_band"] = band(
        f.pre7_active_days, [-np.inf, 1, 3, 5, np.inf], ["0天", "1—2天", "3—4天", "5—7天"]
    )
    f["loan_page7_band"] = band(
        f.pre7_loan_entry_days, [-np.inf, 1, 2, 4, np.inf], ["0天", "1天", "2—3天", "4天及以上"]
    )
    f["gap_band"] = band(
        f.mean_borrow_gap_days,
        [-np.inf, 8, 15, 31, 61, np.inf],
        ["<8天", "8—<15天", "15—<31天", "31—<61天", "≥61天"],
    )
    f["hist_rate_band"] = (
        pd.cut(
            f.hist_offer_d7_rate90,
            [-1e-10, 0, 0.2, 0.5, 0.8, 1.00000001],
            labels=["0%", ">0—20%", ">20—50%", ">50—80%", ">80%"],
            right=True,
        )
        .astype(str)
        .where(f.hist_offer_d7_rate90.notna(), "缺失")
    )
    f.loc[f.hist_offer_d7_n90.lt(3), "hist_rate_band"] = "历史获额少于3次"
    f["rank_band"] = (
        pd.cut(
            f.intent_rank,
            [-np.inf, 0.3, 0.7, np.inf],
            labels=["本批后30%", "本批中间40%", "本批前30%"],
            right=True,
        )
        .astype(str)
        .where(f.intent_rank.notna(), "缺失")
    )
    f["open_band"] = band(
        f.open_n, [-np.inf, 1, 2, np.inf], ["无在途", "1笔在途", "2笔及以上在途"]
    )
    f["past_period_band"] = band(
        f.prior_late_periods_known,
        [-np.inf, 1, 3, np.inf],
        ["历史0期逾期", "历史1—2期逾期", "历史≥3期逾期"],
    )
    f.loc[f.prior_observed_due_periods.eq(0), "past_period_band"] = "未观测到已到期分期"
    f["coupon_history_band"] = band(
        f.coupon_sends_prior30,
        [-np.inf, 1, 3, 5, np.inf],
        ["近30天0次", "近30天1—2次", "近30天3—4次", "近30天≥5次"],
    )
    f["pre_response_state"] = "近14天未见活跃"
    f.loc[f.pre14_active_days.gt(0), "pre_response_state"] = "上周有活跃、本周沉默"
    f.loc[f.pre7_active_days.gt(0), "pre_response_state"] = "近7天活跃、未见提单页"
    f.loc[f.pre7_loan_entry_days.gt(0), "pre_response_state"] = "近7天已见提单页"
    f.loc[f.no_record_in_available_history.eq(1), "pre_response_state"] = "可用历史未见行为记录"
    f["demand_cell"] = "历史信息不足"
    known = f.hist_offer_d7_n90.ge(3) & f.mean_funded_utilization.notna()
    lo = f.hist_offer_d7_rate90.le(0.2)
    lu = f.mean_funded_utilization.lt(0.8)
    for a, b, l in [
        (True, True, "低历史提单＋低使用率"),
        (True, False, "低历史提单＋高使用率"),
        (False, True, "高历史提单＋低使用率"),
        (False, False, "高历史提单＋高使用率"),
    ]:
        f.loc[known & lo.eq(a) & lu.eq(b), "demand_cell"] = l
    features = [
        "borrow_band",
        "churn_band",
        "risk410_band",
        "util_band",
        "last_util_band",
        "active7_band",
        "loan_page7_band",
        "gap_band",
        "hist_rate_band",
        "rank_band",
        "coupon_history_band",
        "demand_cell",
        "past_period_band",
        "pre_response_state",
    ]
    out = {"subgroups": [], "joint": [], "inflight": [], "availability": {}}
    for cname in ["main_all_strategy", "main_simple", "extension_simple"]:
        z = f[co[cname]]
        for col in features:
            for (level, dose), g in z.groupby([col, "dose"]):
                out["subgroups"].append(
                    m.summarize(
                        g, {"cohort": cname, "dimension": col, "level": level, "dose": dose}
                    )
                )
    for cname in ["main_simple", "extension_simple"]:
        z = f[co[cname] & f.score410.ge(528)]
        for (churn, active, dose), g in z.groupby(["churn_band", "loan_page7_band", "dose"]):
            out["joint"].append(
                m.summarize(
                    g,
                    {
                        "cohort": cname,
                        "risk": "410>=528",
                        "churn": churn,
                        "loanpage": active,
                        "dose": dose,
                    },
                )
            )
    inflight = f[f.primary_offer_denom.eq(1) & f.is_target_send.eq(1) & f.valid_days.eq(3)]
    for (state, dose), g in inflight.groupby(["open_band", "dose"]):
        out["inflight"].append(m.summarize(g, {"state": state, "dose": dose}))
    for cname in ["main_all_strategy", "extension_simple"]:
        z = f[co[cname]]
        out["availability"][cname] = {
            c: {"known": int(z[c].notna().sum()), "missing": int(z[c].isna().sum())}
            for c in [
                "score410",
                "score363",
                "score405",
                "mean_funded_utilization",
                "hist_offer_d7_rate90",
                "mean_borrow_gap_days",
                "intent_rank",
            ]
        }
    f.to_parquet(PRIVATE / "analysis_segmented.parquet", index=False, compression="zstd")
    dump(W / "subgroup_results.json", out)
    mark(
        "subgroups_complete",
        cells=len(out["subgroups"]),
        joint=len(out["joint"]),
        inflight=len(out["inflight"]),
    )


if __name__ == "__main__":
    run()
