"""Outcome-blind linear feasibility check for failed 40% entropy-calibration moments."""

from analysis_contract import *
from scipy.optimize import linprog
import importlib.util

spec = importlib.util.spec_from_file_location("_calibration", W / "31_covariate_calibration.py")
cal = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cal)


def run():
    f = pd.read_parquet(PRIVATE / "episode_analysis.parquet")
    f["anchor"] = pd.to_datetime(f.anchor)
    f, co = cohorts_with_offer_grain(f)
    f["calendar"] = f.anchor.dt.strftime("%Y-%m-%d")
    f["source_risk_level"] = f.source_risk_level.fillna("unknown")
    rows = []
    for pair in [(0.2, 0.4), (0.3, 0.4)]:
        p = pd.read_parquet(
            PRIVATE / f"overlap_strict_main_offer_simple_{pair[0]}_{pair[1]}_3d.parquet"
        )
        z = f.merge(p[["episode_id", "overlap_weight"]], on="episode_id", validate="one_to_one")
        z["treat"] = z.dose.eq(pair[1]).astype(int)
        cols = [
            c
            for c in cal.st.ow.FEATURES
            if c in z and pd.to_numeric(z[c], errors="coerce").notna().any()
        ]
        x, names = cal.design(z, cols)
        target = np.average(x, weights=z.overlap_weight, axis=0)
        for t in [0, 1]:
            xx = x[z.treat.eq(t)]
            A = np.vstack([np.ones(len(xx)), xx.T])
            b = np.r_[1.0, target]
            r = linprog(np.zeros(len(xx)), A_eq=A, b_eq=b, bounds=(0, None), method="highs")
            rows.append(
                {
                    "pair": list(pair),
                    "dose": pair[t],
                    "events": len(xx),
                    "moments": len(target),
                    "feasible_exact_common_moments": bool(r.success),
                    "solver_status": int(r.status),
                    "solver_message": r.message,
                    "uses_application_outcomes": False,
                }
            )
    dump(W / "balance_feasibility_results.json", rows)
    mark(
        "balance_feasibility_checked",
        arms=len(rows),
        feasible=sum(r["feasible_exact_common_moments"] for r in rows),
    )


if __name__ == "__main__":
    run()
