"""Outcome-blind entropy calibration after strict date/risk common support.

Target moments are the pooled overlap-weighted baseline distribution. Both arms
are calibrated to the same target, including missingness and quantile indicators.
Failed convergence/low ESS remains a failed comparison, never a reason to change outcomes.
"""

from analysis_contract import *
from scipy.optimize import minimize
from scipy.special import logsumexp
import importlib.util

spec = importlib.util.spec_from_file_location(
    "_strict", W / "30_strict_assignment_comparisons.py"
)
st = importlib.util.module_from_spec(spec)
spec.loader.exec_module(st)
ow = st.ow


def design(z, cols):
    a = []
    names = []
    for c in cols:
        x = pd.to_numeric(z[c], errors="coerce").to_numpy(float)
        missing = ~np.isfinite(x)
        med = np.nanmedian(x)
        xx = np.where(missing, med, x)
        sd = np.std(xx)
        if sd > 1e-10:
            a.append((xx - np.mean(xx)) / sd)
            names.append(c)
        if missing.any() and not missing.all():
            a.append(missing.astype(float))
            names.append(c + "__missing")
    for c in [
        "score410",
        "churn_days",
        "prior_fund_n",
        "mean_funded_utilization",
        "pre7_active_days",
    ]:
        x = pd.to_numeric(z[c], errors="coerce")
        for q in [0.25, 0.5, 0.75]:
            a.append(x.le(x.quantile(q)).to_numpy(float))
            names.append(c + "__q" + str(q))
    for c in ["source_risk_level", "calendar", "recall_kind"]:
        for level in z[c].fillna("unknown").unique():
            a.append(z[c].fillna("unknown").eq(level).to_numpy(float))
            names.append(c + "=" + str(level))
    x = np.column_stack(a)
    good = x.std(axis=0) > 1e-10
    return x[:, good], [n for n, g in zip(names, good) if g]


def calibrate(x, target, base):
    logbase = np.log(np.maximum(base, 1e-12))
    logbase -= logsumexp(logbase)

    def fg(lam):
        lp = logbase + x @ lam
        v = logsumexp(lp)
        w = np.exp(lp - v)
        return v - target @ lam, (w @ x - target)

    result = minimize(
        fg,
        np.zeros(x.shape[1]),
        method="L-BFGS-B",
        jac=True,
        options={"maxiter": 3000, "ftol": 1e-13, "gtol": 1e-8, "maxls": 50},
    )
    ww = np.exp(logbase + x @ result.x - logsumexp(logbase + x @ result.x))
    residual = float(np.max(np.abs(ww @ x - target)))
    return ww, {
        "optimizer_success": bool(result.success),
        "moment_max_error": residual,
        "iterations": result.nit,
        "effective_n": float(1 / (ww @ ww)),
        "max_weight_share": float(ww.max()),
    }


def run():
    contract = {
        "design": "Calibrate each arm baseline moments to the pooled initial overlap-weighted target, after exact date/risk support.",
        "outcomes_used_to_fit_weights": False,
        "numeric_and_missing_balance": True,
        "quantile_balance": True,
        "acceptance": "max SMD <=0.1, each ESS>=50, moment max residual<=1e-4, maximum single weight share<=5%.",
        "failed_comparisons": "Retain failures; do not infer a treatment effect from failed balance.",
    }
    dump(W / "covariate_calibration_contract.json", contract)
    f = pd.read_parquet(PRIVATE / "episode_analysis.parquet")
    f["anchor"] = pd.to_datetime(f.anchor)
    f, co = cohorts_with_offer_grain(f)
    f["calendar"] = f.anchor.dt.strftime("%Y-%m-%d")
    f["source_risk_level"] = f.source_risk_level.fillna("unknown")
    initial = json.loads((W / "strict_assignment_results.json").read_text())
    out = []
    for item in initial["results"]:
        name = item["cohort"]
        pair = item["pair"]
        for v in item["windows"]:
            if v["status"] != "observational_estimate":
                continue
            h = v["window"]
            path = PRIVATE / f"overlap_strict_{name}_{pair[0]}_{pair[1]}_{h}d.parquet"
            if not path.exists():
                continue
            p = pd.read_parquet(path)
            z = f.merge(
                p[["episode_id", "overlap_weight"]], on="episode_id", validate="one_to_one"
            )
            z["treat"] = z.dose.eq(pair[1]).astype("int8")
            cols = [
                c
                for c in ow.FEATURES
                if c in z and pd.to_numeric(z[c], errors="coerce").notna().any()
            ]
            x, xnames = design(z, cols)
            target = np.average(x, weights=z.overlap_weight, axis=0)
            w = np.zeros(len(z))
            fits = []
            for t in [0, 1]:
                ix = z.treat.eq(t).to_numpy()
                ww, fit = calibrate(x[ix], target, z.overlap_weight.to_numpy()[ix])
                w[ix] = ww
                fit["dose"] = pair[t]
                fits.append(fit)
            b = st.complete_balance(z, cols, w)
            maxsmd = max(abs(r["smd_after"]) for r in b)
            good = (
                maxsmd <= 0.1
                and min(r["effective_n"] for r in fits) >= 50
                and max(r["moment_max_error"] for r in fits) <= 1e-4
                and max(r["max_weight_share"] for r in fits) <= 0.05
            )
            # Freeze outcome-blind weights before evaluating any application label.
            z[["episode_id", "user_id", "dose"]].assign(calibrated_weight=w).to_parquet(
                PRIVATE / f"calibrated_{name}_{pair[0]}_{pair[1]}_{h}d.parquet",
                index=False,
                compression="zstd",
            )
            r = {
                "cohort": name,
                "pair": pair,
                "window": h,
                "events": len(z),
                "fits": fits,
                "max_abs_smd_after": maxsmd,
                "balance_sufficient": good,
                "balance": b,
                "design_columns": xnames,
            }
            if good:
                r.update(ow.weighted_rates(z, w, f"applied_{h}", B=2000))
            else:
                r["status"] = "outcome_estimate_suppressed_failed_balance"
            out.append(r)
            dump(W / "covariate_calibration_results.json", out)
            mark(
                "calibration_complete",
                cohort=name,
                pair=pair,
                window=h,
                balanced=good,
                max_smd=maxsmd,
            )
    dump(W / "covariate_calibration_results.json", out)


if __name__ == "__main__":
    run()
