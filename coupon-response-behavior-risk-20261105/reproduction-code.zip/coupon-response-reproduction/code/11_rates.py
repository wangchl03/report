from core import *
from stats_utils import *


def define_cohorts(f):
    f = apply_eligibility_contract(f)
    for c in [
        "has_amount_coupon",
        "has_repayment_coupon",
        "other_application_discount",
        "fixed_coupon",
        "prior_coupon_still_valid",
    ]:
        f[c] = pd.to_numeric(f[c], errors="coerce").fillna(0)
    f["dose"] = f.nominal_discount
    f["no_coupon_at_anchor"] = f.coupon_rows.fillna(0).eq(0)
    f.loc[f.no_coupon_at_anchor, "dose"] = 0.0
    f["simple_discount"] = (
        f.has_amount_coupon.eq(0)
        & f.has_repayment_coupon.eq(0)
        & f.other_application_discount.eq(0)
        & f.fixed_coupon.eq(0)
    )
    period = f.anchor.ge(pd.Timestamp("2026-06-15")) & f.anchor.lt(pd.Timestamp("2026-10-31"))
    eligible = f.primary_offer_denom.eq(1) & period
    target = f.is_target_send.eq(1) & f.valid_days.eq(3)
    t7 = f.strict_t7.eq(1)
    # Actual issue records define all recall dates in the expanded main period.
    # Named-list membership remains a separate provenance field.
    recall = f.in_recall.eq(1) | f.is_target_send.eq(1)
    control = f.no_coupon_at_anchor & recall
    cohorts = {
        "main_all_strategy": eligible & t7 & recall & (target | control),
        "main_simple": eligible & t7 & recall & ((target & f.simple_discount) | control),
        "main_simple_no_active_prior_coupon": eligible
        & t7
        & recall
        & ((target & f.simple_discount) | control)
        & f.prior_coupon_still_valid.eq(0),
        "extension_all_strategy": eligible & t7 & (target | control),
        "extension_simple": eligible & t7 & ((target & f.simple_discount) | control),
        "extension_simple_first_contact": eligible
        & t7
        & ((target & f.simple_discount) | control)
        & f.first_contact_for_offer.eq(1),
        "extension_outstanding": eligible
        & f.history_state_known.eq(1)
        & f.open_n.gt(0)
        & target,
        "extension_prior_unsuccessful_attempts": eligible
        & f.t7_no_open.eq(1)
        & f.strict_t7.eq(0)
        & target,
        "extension_7day_coupon": eligible & t7 & f.is_target_send.eq(1) & f.valid_days.eq(7),
    }
    return f, cohorts


def summarize(g, extra=None):
    r = {
        "events": len(g),
        "users": g.user_id.nunique(),
        "credit_orders": g[["user_id", "latest_credit_serial"]].drop_duplicates().shape[0],
    }
    for d in [3, 7, 15, 30]:
        z = g[g[f"observed_{d}"] == 1]
        n = len(z)
        y = int(z[f"applied_{d}"].sum())
        r.update(
            {
                f"n_{d}": n,
                f"y_{d}": y,
                f"rate_{d}": rate(y, n),
                f"censor_repeat_coupon_{d}": (
                    float(z.next_coupon_day.lt(d).mean()) if n else None
                ),
            }
        )
    for col in [
        "score410",
        "score363",
        "score405",
        "prior_fund_n",
        "mean_funded_utilization",
        "last_utilization",
        "hist_offer_d0_rate90",
        "hist_offer_d7_rate90",
        "churn_days",
        "mean_borrow_gap_days",
        "pre7_active_days",
        "pre7_loan_entry_days",
    ]:
        if col in g:
            r[col + "_mean"] = float(g[col].mean()) if g[col].notna().any() else None
            r[col + "_median"] = float(g[col].median()) if g[col].notna().any() else None
    r["prior_coupon_still_valid_rate"] = (
        float(g.prior_coupon_still_valid.mean()) if len(g) else None
    )
    if extra:
        r.update(extra)
    return r


def run():
    f = pd.read_parquet(PRIVATE / "episode_analysis.parquet")
    if "open_late_periods" not in f:
        import importlib.util

        spec = importlib.util.spec_from_file_location(
            "_period_features", W / "17_period_features.py"
        )
        pm = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(pm)
        pm.run()
        f = pd.read_parquet(PRIVATE / "episode_analysis.parquet")
    f["anchor"] = pd.to_datetime(f.anchor)
    f, cohorts = define_cohorts(f)
    output = {
        "cohorts": {},
        "monthly": [],
        "recall_batches": [],
        "strategies": [],
        "comparisons": [],
        "fixed_observation_cohorts": [],
    }
    for name, mask in cohorts.items():
        z = f[mask]
        rows = []
        for dose, g in z.groupby("dose", dropna=False):
            rows.append(summarize(g, {"dose": dose}))
        output["cohorts"][name] = rows
        if name in ["main_all_strategy", "main_simple", "extension_simple"]:
            for full in [7, 15, 30]:
                zz = z[z[f"observed_{full}"].eq(1)]
                for dose, g in zz.groupby("dose"):
                    rr = {
                        "cohort": name,
                        "fully_observed_days": full,
                        "dose": dose,
                        "events": len(g),
                        "users": g.user_id.nunique(),
                        "windows": {},
                    }
                    for d in [3, 7, 15, 30]:
                        if d <= full:
                            rr["windows"][str(d)] = {
                                "applicants": int(g[f"applied_{d}"].sum()),
                                "denominator": len(g),
                                "rate": float(g[f"applied_{d}"].mean()),
                            }
                    output["fixed_observation_cohorts"].append(rr)
        if name in ["main_all_strategy", "main_simple", "extension_simple"]:
            for (mon, dose), g in z.groupby(["anchor_month", "dose"]):
                output["monthly"].append(
                    summarize(g, {"cohort": name, "month": mon, "dose": dose})
                )
    main = f[cohorts["main_all_strategy"]]
    for (batch, dose), g in main.groupby(["recall_batches", "dose"]):
        output["recall_batches"].append(summarize(g, {"batch": batch, "dose": dose}))
    ext = f[cohorts["extension_all_strategy"]]
    for (dose, amount, repaid), g in ext.groupby(
        ["dose", "has_amount_coupon", "has_repayment_coupon"]
    ):
        output["strategies"].append(
            summarize(g, {"dose": dose, "amount_coupon": amount, "repayment_coupon": repaid})
        )
    for cname in ["main_simple", "extension_simple", "extension_simple_first_contact"]:
        z = f[cohorts[cname]]
        for d in [3, 7, 15, 30]:
            for pair in [(0.0, 0.2), (0.2, 0.3), (0.2, 0.4), (0.3, 0.4)]:
                r = cluster_comparison(
                    z[z[f"observed_{d}"].eq(1)], f"applied_{d}", groups=pair, B=2000
                )
                if r:
                    output["comparisons"].append({"cohort": cname, "window": d, **r})
    dump(W / "rates_results.json", output)
    f.to_parquet(PRIVATE / "analysis_ready.parquet", index=False, compression="zstd")
    mark("rates_complete", cohorts={k: int(v.sum()) for k, v in cohorts.items()})
    print(json.dumps(output["cohorts"], ensure_ascii=False, default=str), flush=True)


if __name__ == "__main__":
    run()
