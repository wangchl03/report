"""Predefined threshold grid, not threshold optimization or model tuning."""

from analysis_contract import *


def run():
    f = pd.read_parquet(PRIVATE / "episode_analysis.parquet")
    f, co = cohorts_with_offer_grain(f)
    out = {"grid": [], "composition": []}
    for name in ["main_offer_simple", "extension_offer_simple"]:
        z = f[co[name] & f.dose.isin([0.2, 0.3]) & f.observed_3.eq(1)]
        for d, g in z.groupby("dose"):
            known = (
                g.hist_offer_d7_n90.ge(3)
                & g.hist_offer_d7_rate90.notna()
                & g.mean_funded_utilization.notna()
            )
            for cutoff in [0.0, 0.1, 0.2, 0.3, 0.5]:
                for util in [0.4, 0.6, 0.8, 1.03]:
                    a = g[
                        known
                        & g.hist_offer_d7_rate90.le(cutoff)
                        & g.mean_funded_utilization.lt(util)
                    ]
                    out["grid"].append(
                        {
                            "cohort": name,
                            "dose": d,
                            "history_rate_le": cutoff,
                            "mean_util_lt": util,
                            "events": len(a),
                            "y_3": int(a.applied_3.sum()),
                            "rate_3": float(a.applied_3.mean()) if len(a) else None,
                            "recent_loanpage_share": (
                                float(a.pre7_loan_entry_days.gt(0).mean()) if len(a) else None
                            ),
                            "median_churn": float(a.churn_days.median()) if len(a) else None,
                        }
                    )
            for label, a in [
                ("全部", g),
                ("有足够历史", g[known]),
                (
                    "双低",
                    g[
                        known
                        & g.hist_offer_d7_rate90.le(0.2)
                        & g.mean_funded_utilization.lt(0.8)
                    ],
                ),
            ]:
                out["composition"].append(
                    {
                        "cohort": name,
                        "dose": d,
                        "group": label,
                        "events": len(a),
                        "y_3": int(a.applied_3.sum()),
                        "rate_3": float(a.applied_3.mean()) if len(a) else None,
                        "recent_loanpage_share": (
                            float(a.pre7_loan_entry_days.gt(0).mean()) if len(a) else None
                        ),
                        "median_churn": float(a.churn_days.median()) if len(a) else None,
                        "median_fund_count": float(a.prior_fund_n.median()) if len(a) else None,
                    }
                )
    dump(W / "demand_threshold_sensitivity_results.json", out)
    mark("demand_threshold_grid_complete", cells=len(out["grid"]))


if __name__ == "__main__":
    run()
