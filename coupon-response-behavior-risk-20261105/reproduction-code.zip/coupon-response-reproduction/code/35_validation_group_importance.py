"""Frozen-model replay plus validation-only group permutation, no test-driven model tuning."""

from analysis_contract import *
import lightgbm, joblib
from sklearn.metrics import roc_auc_score, average_precision_score, brier_score_loss

GROUPS = {
    "近期行为": ["days_since_last_active", "pre7_", "pre14_", "no_record_in_available_history"],
    "流失与借款周期": [
        "churn_days",
        "mean_borrow_gap_days",
        "days_since_first_apply",
        "historical_clean_gap_median",
        "completed_clean_gap_n",
        "excess_idle_days",
        "borrow_cycle_multiple",
    ],
    "额度与使用": [
        "last_funded_utilization",
        "mean_funded_utilization",
        "mean_utilization90",
        "utilization_known_n",
        "latest_credit_amt",
        "mean_prior_fund_amt",
        "median_prior_fund_amt",
        "last_util_minus_mean",
    ],
    "历史获额提单率": ["hist_offer_"],
    "风险与逾期历史": [
        "score410",
        "score363",
        "score405",
        "prior_settled_ever_overdue_n",
        "last_settled_overdue_days",
        "prior_late_periods_known",
        "prior_period_late_fraction",
    ],
    "历史发券与使用": [
        "coupon_sends_prior",
        "prior_coupon_still_valid",
        "prior_target_coupon_use_rate30",
        "prior_expired_target_coupons30",
    ],
    "借款次数及最近产品": [
        "prior_fund_n",
        "prior_apps30",
        "prior_apps90",
        "last_funded_loan_day",
        "last_funded_fee_rate",
    ],
    "获额距今时间": ["latest_credit_age_days"],
    "本次券幅度": ["dose"],
}


def run():
    f = pd.read_parquet(PRIVATE / "episode_analysis.parquet")
    f["anchor"] = pd.to_datetime(f.anchor)
    f, _ = cohorts_with_offer_grain(f)
    pred = pd.read_parquet(PRIVATE / "diagnostic_response_predictions.parquet")
    pred["anchor"] = pd.to_datetime(pred.anchor)
    obj = joblib.load(PRIVATE / "full_baseline_diagnostic_model.joblib")
    model = obj["model"]
    cols = obj["features"]
    z = pred[["episode_id", "anchor", "applied_3", "full_baseline_p"]].merge(
        f[["episode_id"] + cols], on="episode_id", validate="one_to_one"
    )
    x = z[cols].apply(pd.to_numeric, errors="coerce")
    replay = model.predict_proba(x)[:, 1]
    error = float(np.max(np.abs(replay - z.full_baseline_p.to_numpy())))
    assert error < 1e-12
    valid = z.anchor.ge(pd.Timestamp("2026-09-18")) & (
        z.anchor + pd.Timedelta(days=3) <= pd.Timestamp("2026-10-17")
    )
    x = x[valid].reset_index(drop=True)
    dates = z.loc[valid, "anchor"].reset_index(drop=True)
    y = z.loc[valid, "applied_3"].to_numpy(int)
    baseline = model.predict_proba(x)[:, 1]
    auc = roc_auc_score(y, baseline)
    ap = average_precision_score(y, baseline)
    out = {
        "model_replay_max_abs_error": error,
        "validation_events": len(x),
        "baseline_auc": auc,
        "baseline_pr_auc": ap,
        "groups": [],
    }
    assigned = []
    rng = np.random.default_rng(20261105)
    for name, prefixes in GROUPS.items():
        cc = [c for c in cols if any(c == p or c.startswith(p) for p in prefixes)]
        assigned += cc
        repeats = []
        for _ in range(20):
            xx = x.copy()
            for _, ix in dates.groupby(dates).groups.items():
                ix = np.asarray(ix)
                perm = rng.permutation(ix)
                xx.loc[ix, cc] = x.loc[perm, cc].to_numpy()
            p = model.predict_proba(xx)[:, 1]
            repeats.append([auc - roc_auc_score(y, p), ap - average_precision_score(y, p)])
        a = np.asarray(repeats)
        out["groups"].append(
            {
                "group": name,
                "features": cc,
                "auc_drop_mean": a[:, 0].mean(),
                "auc_drop_range": np.quantile(a[:, 0], [0.05, 0.95]).tolist(),
                "pr_auc_drop_mean": a[:, 1].mean(),
                "pr_auc_drop_range": np.quantile(a[:, 1], [0.05, 0.95]).tolist(),
                "permutations": 20,
            }
        )
    assert set(assigned) == set(cols), set(cols) - set(assigned)
    assert len(assigned) == len(set(assigned))
    dump(W / "validation_group_importance_results.json", out)
    mark("validation_group_importance_complete", replay_error=error, groups=len(out["groups"]))


if __name__ == "__main__":
    run()
