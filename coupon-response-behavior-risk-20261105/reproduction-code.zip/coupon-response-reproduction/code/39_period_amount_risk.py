"""Installment amount risk within the SAME whole-mature used-coupon order set.

Coupon waiver is never summed after the one-to-many installment join.
"""

from core import *


def run():
    f = pd.read_parquet(PRIVATE / "used_orders_finance.parquet")
    z = f[
        f.whole_mature
        & f.repaid_amt.notna()
        & f.valid_days.eq(3)
        & f.strict_t7.eq(1)
        & f.eligible_offer.eq(1)
        & f.has_amount_coupon.eq(0)
        & f.has_repayment_coupon.eq(0)
        & f.other_application_discount.eq(0)
        & f.fixed_coupon.eq(0)
    ].copy()
    p = pd.read_parquet(PRIVATE / "periods_all_history.parquet").drop_duplicates()
    for c in [
        "user_id",
        "serial_id",
        "current_term",
        "loan_status_code_period",
        "apply_amt_period",
        "remit_amt_period",
        "repaid_amt_period",
    ]:
        p[c] = pd.to_numeric(p[c], errors="coerce")
    assert not p.duplicated(["user_id", "serial_id", "current_term"]).any()
    p = p.merge(
        z[["user_id", "serial_id", "dose"]], on=["user_id", "serial_id"], validate="many_to_one"
    )
    out = []
    for dose, g in p.groupby("dose"):
        overdue = g[g.loan_status_code_period.eq(8)]
        total = g.apply_amt_period.sum()
        risk = overdue.apply_amt_period.sum()
        remit = overdue.remit_amt_period.sum()
        paid = overdue.repaid_amt_period.sum()
        out.append(
            {
                "dose": dose,
                "whole_mature_used_orders": int(z.dose.eq(dose).sum()),
                "matched_whole_orders": g[["user_id", "serial_id"]].drop_duplicates().shape[0],
                "installments": len(g),
                "overdue_installments": len(overdue),
                "total_installment_contract_amount": float(total),
                "overdue_installment_contract_amount": float(risk),
                "amount_overdue_rate": float(risk / total) if total > 0 else None,
                "overdue_period_remit_amount": float(remit),
                "overdue_period_repaid_amount": float(paid),
                "overdue_period_recovery_rate": float(paid / remit) if remit > 0 else None,
            }
        )
    dump(W / "period_amount_risk_results.json", out)
    mark("period_amount_risk_complete", whole_orders=len(z), periods=len(p))


if __name__ == "__main__":
    run()
