"""Before-outcome product supply check; never match on the product later chosen by the borrower."""

from analysis_contract import *
import re, importlib.util

spec = importlib.util.spec_from_file_location("_st", W / "30_strict_assignment_comparisons.py")
st = importlib.util.module_from_spec(spec)
spec.loader.exec_module(st)
spec = importlib.util.spec_from_file_location("_cal", W / "31_covariate_calibration.py")
cal = importlib.util.module_from_spec(spec)
spec.loader.exec_module(cal)
ow = st.ow


def canon(v):
    if v is None or pd.isna(v):
        return "未知"
    s = str(v).replace(" ", "")
    if not re.fullmatch(r"\d+(,\d+)*", s):
        return "未知"
    return ",".join(str(n) for n in sorted({int(v) for v in s.split(",")}))


def run():
    f = pd.read_parquet(PRIVATE / "episode_analysis.parquet")
    f["anchor"] = pd.to_datetime(f.anchor)
    f, co = cohorts_with_offer_grain(f)
    c = pd.read_parquet(PRIVATE / "credits_clean.parquet")
    f = f.merge(
        c[["user_id", "serial_id", "credit_s", "risk_product", "total_term"]],
        left_on=["user_id", "latest_credit_serial", "latest_credit_s"],
        right_on=["user_id", "serial_id", "credit_s"],
        how="left",
        validate="many_to_one",
    )
    f["approved_product_group"] = f.risk_product.map(canon)
    f["latest_offer_term"] = pd.to_numeric(f.total_term, errors="coerce").where(lambda x: x > 0)
    f["calendar"] = f.anchor.dt.strftime("%Y-%m-%d")
    f["kind"] = f.recall_kind.fillna("unknown") + "|" + f.source_risk_level.fillna("unknown")
    z0 = f[co["main_offer_simple"].to_numpy() & f.dose.isin([0.2, 0.3])].copy()
    out = {
        "baseline_products": [],
        "comparisons": [],
        "definition": "Same-date, recorded-risk, list-kind and approved-product-group common support; product information is from the credit offer before issue, not a subsequent application.",
    }
    for (product, dose), g in z0.groupby(["approved_product_group", "dose"]):
        out["baseline_products"].append(
            {
                "product": product,
                "dose": dose,
                "events": len(g),
                "y_3": int(g.applied_3.sum()),
                "rate_3": float(g.applied_3.mean()),
            }
        )
    for h in [3, 7, 15, 30]:
        z = z0[z0[f"observed_{h}"].eq(1) & z0.approved_product_group.ne("未知")].copy()
        z["treat"] = z.dose.eq(0.3).astype(int)
        block = ["calendar", "source_risk_level", "recall_kind", "approved_product_group"]

        def support(zz):
            n = zz.groupby(block + ["treat"]).size().unstack("treat").fillna(0)
            good = n.index[n.min(axis=1).ge(20)] if n.shape[1] == 2 else n.index[:0]
            return zz[pd.MultiIndex.from_frame(zz[block]).isin(good)]

        z = support(z)
        raw_n = len(z)
        cols = [
            c
            for c in ow.FEATURES + ["latest_offer_term"]
            if c in z and pd.to_numeric(z[c], errors="coerce").notna().any()
        ]
        for _ in range(10):
            old_n = len(z)
            for col in cols:
                s = pd.to_numeric(z[col], errors="coerce").notna()
                n = pd.crosstab(s, z.treat).reindex(
                    index=[False, True], columns=[0, 1], fill_value=0
                )
                bad = n.index[n.min(axis=1).eq(0) & n.sum(axis=1).gt(0)]
                z = z[~s.isin(bad)]
            z = support(z)
            if len(z) == old_n:
                break
        r = {"window": h, "supported_before_missing_filter": raw_n, "events": len(z)}
        if len(z) < 400 or z.treat.nunique() < 2 or z.groupby("treat").size().min() < 50:
            r["status"] = "insufficient_product_support"
            out["comparisons"].append(r)
            continue
        for i, v in enumerate(z.approved_product_group.unique()):
            z["approved_product_" + str(i)] = z.approved_product_group.eq(v).astype(int)
            cols.append("approved_product_" + str(i))
        cols = [v for v in cols if z[v].notna().any()]
        pred, base = ow.fit_weights(z, cols)
        x, names = cal.design(z, cols)
        target = np.average(x, weights=base, axis=0)
        weight = np.zeros(len(z))
        fits = []
        for t in [0, 1]:
            ix = z.treat.eq(t).to_numpy()
            ww, fit = cal.calibrate(x[ix], target, base[ix])
            weight[ix] = ww
            fit["dose"] = 0.3 if t else 0.2
            fits.append(fit)
        balance = st.complete_balance(z, cols, weight)
        mx = max(abs(v["smd_after"]) for v in balance)
        accepted = (
            mx <= 0.1
            and min(v["effective_n"] for v in fits) >= 50
            and max(v["moment_max_error"] for v in fits) <= 1e-4
            and max(v["max_weight_share"] for v in fits) <= 0.05
        )
        r.update(
            {
                "balance_sufficient": accepted,
                "max_abs_smd": mx,
                "fits": fits,
                "product_groups": z.approved_product_group.nunique(),
            }
        )
        if accepted:
            r.update(ow.weighted_rates(z, weight, f"applied_{h}", B=2000))
            r["status"] = "observational_product_supply_sensitivity"
        else:
            r["status"] = "failed_balance_estimate_suppressed"
        out["comparisons"].append(r)
    dump(W / "approved_product_supply_results.json", out)
    mark("approved_product_supply_check_complete", windows=len(out["comparisons"]))


if __name__ == "__main__":
    run()
