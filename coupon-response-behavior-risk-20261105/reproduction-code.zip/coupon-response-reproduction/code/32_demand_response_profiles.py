"""Customer response heterogeneity: descriptive associations, never coupon-induced lift labels."""

from analysis_contract import *
from stats_utils import *


def cut(s, bins, labels):
    return (
        pd.cut(s, bins, labels=labels, include_lowest=True, right=False)
        .astype(str)
        .where(s.notna(), "信息不足")
    )


def run():
    f = pd.read_parquet(PRIVATE / "episode_analysis.parquet")
    f["anchor"] = pd.to_datetime(f.anchor)
    f, co = cohorts_with_offer_grain(f)
    f["recent_state"] = "近14天未见活跃"
    f.loc[f.pre14_active_days.gt(0), "recent_state"] = "上周有活跃、本周沉默"
    f.loc[f.pre7_active_days.gt(0), "recent_state"] = "近7天活跃、未见提单页"
    f.loc[f.pre7_loan_entry_days.gt(0), "recent_state"] = "近7天已见提单页"
    f.loc[f.no_record_in_available_history.eq(1), "recent_state"] = "可用历史未见行为"
    f["churn_band"] = cut(
        f.churn_days,
        [8, 15, 31, 61, 91, 181, np.inf],
        ["8—14天", "15—30天", "31—60天", "61—90天", "91—180天", "181天及以上"],
    )
    f["loan_count_band"] = cut(
        f.prior_fund_n, [1, 2, 4, 7, np.inf], ["1次", "2—3次", "4—6次", "7次及以上"]
    )
    f["util_band"] = cut(
        f.mean_funded_utilization,
        [0, 0.4, 0.6, 0.8, 0.97, 1.03000001, np.inf],
        ["<40%", "40—<60%", "60—<80%", "80—<97%", "≈100%", ">103%"],
    )
    f["historical_rate_band"] = (
        pd.cut(
            f.hist_offer_d7_rate90,
            [-1e-10, 0, 0.2, 0.5, 0.8, 1.0000001],
            labels=["0%", ">0—20%", ">20—50%", ">50—80%", ">80%"],
            right=True,
        )
        .astype(str)
        .where(f.hist_offer_d7_rate90.notna(), "信息不足")
    )
    f.loc[f.hist_offer_d7_n90.lt(3), "historical_rate_band"] = "历史获额少于3次"
    f["gap_band"] = cut(
        f.mean_borrow_gap_days,
        [0, 15, 31, 61, np.inf],
        ["<15天", "15—30天", "31—60天", "61天及以上"],
    )
    f["idle_excess_band"] = cut(
        f.excess_idle_days,
        [-np.inf, 0.000001, 31, 91, np.inf],
        ["未超过历史间隔", "超出0—30天", "超出31—90天", "超出90天以上"],
    )
    f["expired_coupon_band"] = cut(
        f.prior_expired_target_coupons30,
        [0, 1, 3, np.inf],
        ["近30天0张已过期券", "近30天1—2张已过期券", "近30天≥3张已过期券"],
    )
    f["last_util_trend"] = cut(
        f.last_util_minus_mean,
        [-np.inf, -0.2, 0.2000001, np.inf],
        ["最近使用率低于历史≥20个百分点", "最近与历史接近", "最近使用率高于历史>20个百分点"],
    )
    f["rank_band"] = (
        pd.cut(
            f.intent_rank,
            [-np.inf, 0.3, 0.7, np.inf],
            labels=["本批后30%", "本批中间40%", "本批前30%"],
            right=True,
        )
        .astype(str)
        .where(f.intent_rank.notna(), "名单无有效评分")
    )
    f["low_hist_rate"] = f.hist_offer_d7_n90.ge(3) & f.hist_offer_d7_rate90.le(0.2)
    f["low_util"] = f.mean_funded_utilization.lt(0.8)
    f["double_low"] = f.low_hist_rate & f.low_util
    f["rate_util_cell"] = "信息不足"
    enough = (
        f.hist_offer_d7_n90.ge(3)
        & f.hist_offer_d7_rate90.notna()
        & f.mean_funded_utilization.notna()
    )
    for a, b, label in [
        (True, True, "低提单＋低使用"),
        (True, False, "低提单＋高使用"),
        (False, True, "高提单＋低使用"),
        (False, False, "高提单＋高使用"),
    ]:
        f.loc[enough & f.low_hist_rate.eq(a) & f.low_util.eq(b), "rate_util_cell"] = label
    dims = [
        "recent_state",
        "churn_band",
        "loan_count_band",
        "util_band",
        "historical_rate_band",
        "gap_band",
        "idle_excess_band",
        "expired_coupon_band",
        "last_util_trend",
        "rank_band",
        "rate_util_cell",
    ]
    out = {
        "univariate": [],
        "joint": [],
        "long_silent": [],
        "prior_coupon_history": [],
        "source_risk": [],
    }
    for name in [
        "main_offer_simple",
        "extension_offer_simple",
        "main_simple",
        "extension_simple",
    ]:
        z = f[co[name] & f.dose.gt(0)]
        for c in dims:
            for (level, dose), g in z.groupby([c, "dose"]):
                out["univariate"].append(
                    rm.summarize(
                        g, {"cohort": name, "dimension": c, "level": str(level), "dose": dose}
                    )
                )
        for (cell, active, dose), g in z.groupby(["rate_util_cell", "recent_state", "dose"]):
            out["joint"].append(
                rm.summarize(
                    g, {"cohort": name, "cell": cell, "recent_state": active, "dose": dose}
                )
            )
        for risk, mask in [
            ("410≥528", z.score410.ge(528)),
            ("全部风险分层", pd.Series(True, index=z.index)),
        ]:
            zz = z[mask & z.churn_days.ge(91)]
            for (active, rank, dose), g in zz.groupby(["recent_state", "rank_band", "dose"]):
                out["long_silent"].append(
                    rm.summarize(
                        g,
                        {
                            "cohort": name,
                            "risk": risk,
                            "recent_state": active,
                            "rank": rank,
                            "dose": dose,
                        },
                    )
                )
        for (count, used, active, dose), g in z.assign(
            used_prior=z.prior_used_target_coupons30.gt(0)
        ).groupby(["expired_coupon_band", "used_prior", "recent_state", "dose"]):
            out["prior_coupon_history"].append(
                rm.summarize(
                    g,
                    {
                        "cohort": name,
                        "prior_expired": count,
                        "prior_used": bool(used),
                        "recent_state": active,
                        "dose": dose,
                    },
                )
            )
        for (risk, dose), g in z.groupby(["source_risk_level", "dose"]):
            out["source_risk"].append(
                rm.summarize(g, {"cohort": name, "risk_tier": risk, "dose": dose})
            )
    f.to_parquet(PRIVATE / "demand_profiles.parquet", index=False, compression="zstd")
    dump(W / "demand_response_profile_results.json", out)
    mark("demand_profiles_complete", cells=sum(len(v) for v in out.values()))


if __name__ == "__main__":
    run()
