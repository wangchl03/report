"""Test whether pre-issue activity predicts coupon-policy differences, not just response levels.

Use the last four complete days, wholly after clean settlement for the T5/T7
test populations, avoiding the pre-settlement portion of a seven-day baseline.
"""

from core import *
from stats_utils import *

HP = W / "historical_validation" / "private"


def interaction(g, B=2000):
    p = g.groupby(["user_id", "treat", "signal"])[["applied_3"]].agg(["sum", "size"])
    users = sorted(g.user_id.unique())
    idx = {u: i for i, u in enumerate(users)}
    arrays = {}
    for t in [0, 1]:
        for s in [0, 1]:
            a = np.zeros(len(users))
            n = np.zeros(len(users))
            for (u, tt, ss), r in p.iterrows():
                if tt == t and ss == s:
                    a[idx[u]] = r[("applied_3", "sum")]
                    n[idx[u]] = r[("applied_3", "size")]
            if n.sum() == 0:
                return None
            arrays[(t, s)] = (a, n)

    def estimate(w):
        rates = {
            k: np.divide(w @ a, w @ n, out=np.full(w.shape[0], np.nan), where=(w @ n) > 0)
            for k, (a, n) in arrays.items()
        }
        return rates[(1, 1)] - rates[(0, 1)] - rates[(1, 0)] + rates[(0, 0)]

    point = float(estimate(np.ones((1, len(users))))[0])
    rng = np.random.default_rng(20261105)
    draw = []
    for i in range(0, B, 100):
        draw.extend(estimate(rng.poisson(1, (min(100, B - i), len(users)))).tolist())
    return {
        "interaction_difference": point,
        "ci95": np.nanquantile(draw, [0.025, 0.975]).tolist(),
        "users": len(users),
        "bootstrap_draws": B,
    }


def run():
    f = pd.read_parquet(HP / "historical_validated.parquet")
    f["anchor"] = pd.to_datetime(f.anchor)
    f = (
        f[f.qualified]
        .sort_values(["anchor", "episode_id"])
        .drop_duplicates(["study", "user_id", "latest_credit_serial"])
        .copy()
    )
    b = pd.read_parquet(HP / "behavior_new_daily.parquet")
    b["d"] = pd.to_datetime(b.d)
    di = b.set_index(["user_id", "d"])
    out = {"groups": [], "policy_differences": [], "interaction_tests": []}
    for metric, col in [("发券前4天活跃", "logs"), ("发券前4天提单页", "loan_entry_n")]:
        vals = np.zeros(len(f), int)
        for rd in range(-4, 0):
            keys = pd.MultiIndex.from_arrays(
                [f.user_id, f.anchor + pd.Timedelta(days=rd)], names=["user_id", "d"]
            )
            vals += (
                pd.to_numeric(di[col].reindex(keys), errors="coerce")
                .fillna(0)
                .gt(0)
                .to_numpy(int)
            )
        zz = f.assign(signal=(vals > 0).astype(int), dose=f.treat)
        for name, g in zz.groupby("study"):
            for (signal, arm), gg in g.groupby(["signal", "ab_group"]):
                out["groups"].append(
                    {
                        "study": name,
                        "metric": metric,
                        "signal": int(signal),
                        "arm": arm,
                        "events": len(gg),
                        "y_3": int(gg.applied_3.sum()),
                        "rate_3": float(gg.applied_3.mean()),
                    }
                )
            for signal, gg in g.groupby("signal"):
                r = cluster_comparison(gg, "applied_3", groups=(0, 1), B=2000)
                if r:
                    out["policy_differences"].append(
                        {"study": name, "metric": metric, "signal": int(signal), **r}
                    )
            r = interaction(g)
            if r:
                out["interaction_tests"].append({"study": name, "metric": metric, **r})
    dump(W / "preclean_activity_interaction_results.json", out)
    mark("preclean_activity_interaction_complete", tests=len(out["interaction_tests"]))


if __name__ == "__main__":
    run()
