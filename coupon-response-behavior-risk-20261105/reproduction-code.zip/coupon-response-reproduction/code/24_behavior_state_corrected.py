"""Event-time activity profiles, with a baseline uncontaminated by pre-settlement loan state."""

from analysis_contract import *
from stats_utils import *

FIELDS = [
    "new_active",
    "new_loan_entry",
    "new_amount",
    "new_term",
    "new_plan",
    "new_contract",
    "new_submit",
    "new_coupon_open",
    "new_coupon_confirm",
    "legacy_active",
    "legacy_loan_entry",
    "active",
    "loan_entry",
]


def run():
    f = pd.read_parquet(PRIVATE / "episode_analysis.parquet")
    f["anchor"] = pd.to_datetime(f.anchor)
    f, co = cohorts_with_offer_grain(f)
    b = pd.read_parquet(PRIVATE / "behavior_combined_daily.parquet")
    b["d"] = pd.to_datetime(b.d)
    di = b.set_index(["user_id", "d"])
    epochs = [c + "_epoch" for c in FIELDS]
    out = {
        "contract": {
            "primary_all_t7_baseline": "Previous week, matched weekday; all users have >7 clean no-application days.",
            "stable15_baseline": "Two preceding weeks, matched weekday, restricted to churn>=15 so baseline remains after clean settlement.",
            "riskset": "Descriptive only: no previous application and no later coupon by this day; post-treatment selection is not a causal estimate.",
        },
        "profiles": [],
        "periods": [],
        "placebos": [],
        "coverage": [],
    }
    names = [
        "main_offer_simple",
        "extension_offer_simple",
        "main_offer_simple_stable15",
        "extension_offer_simple_stable15",
    ]
    for name in names:
        for h in [3, 7, 15, 30]:
            z = f[co[name] & f[f"observed_{h}"].eq(1) & f.behavior_user_extracted.eq(1)].copy()
            if len(z) == 0:
                continue
            out["coverage"].append(
                {
                    "cohort": name,
                    "window": h,
                    "events": len(z),
                    "churn8_14": int(z.churn_days.lt(15).sum()),
                    "no_history": int(z.no_record_in_available_history.eq(1).sum()),
                }
            )
            ds = z.dose.to_numpy(float)
            cut = z.first_apply_s.fillna(np.inf).to_numpy(float)
            anchor_epoch = (
                z.anchor.dt.tz_localize("America/Belize")
                .astype("datetime64[ns, America/Belize]")
                .astype("int64")
                .to_numpy()
                / 1e9
            )
            assert np.all((anchor_epoch > 1.7e9) & (anchor_epoch < 1.9e9))
            vals = {}
            preapp = {}
            clean_before = {}
            for rd in range(-14, h):
                keys = pd.MultiIndex.from_arrays(
                    [z.user_id.to_numpy(), (z.anchor + pd.Timedelta(days=rd)).to_numpy()],
                    names=["user_id", "d"],
                )
                a = di[FIELDS].reindex(keys).fillna(0).to_numpy("int8")
                tt = di[epochs].reindex(keys).to_numpy(float)
                before = (a > 0) & (tt < cut[:, None])
                clean = (
                    z.next_coupon_day.isna().to_numpy() | z.next_coupon_day.gt(rd).to_numpy()
                )
                risk = (
                    (cut >= anchor_epoch + rd * 86400) & clean
                    if rd >= 0
                    else np.ones(len(z), bool)
                )
                vals[rd] = a
                preapp[rd] = before
                clean_before[rd] = before & clean[:, None] if rd >= 0 else before
                for dose in sorted(set(ds)):
                    ix = ds == dose
                    n = int(ix.sum())
                    riskn = int((ix & risk).sum())
                    for j, k in enumerate(FIELDS):
                        out["profiles"].append(
                            {
                                "cohort": name,
                                "window": h,
                                "day": rd,
                                "dose": dose,
                                "metric": k,
                                "events": n,
                                "rate": float(a[ix, j].mean()),
                                "before_first_app_rate": float(before[ix, j].mean()),
                                "before_app_and_new_coupon_rate": float(
                                    clean_before[rd][ix, j].mean()
                                ),
                                "not_applied_no_new_coupon_n": riskn,
                                "riskset_rate": (
                                    float(before[ix & risk, j].mean()) if riskn else None
                                ),
                            }
                        )
            delta = z[
                ["episode_id", "user_id", "dose", "anchor", "churn_days", "next_coupon_day"]
            ].copy()
            for start, stop, label in [
                (0, 3, "D0—D2"),
                (1, 3, "D1—D2"),
                (3, 7, "D3—D6"),
                (7, 14, "D7—D13"),
                (14, 30, "D14—D29"),
            ]:
                if stop > h:
                    continue
                post = np.mean([vals[d] for d in range(start, stop)], axis=0)
                pre1 = np.mean([vals[d % 7 - 7] for d in range(start, stop)], axis=0)
                pre2 = np.mean(
                    [0.5 * (vals[d % 7 - 7] + vals[d % 7 - 14]) for d in range(start, stop)],
                    axis=0,
                )
                pa = np.mean([preapp[d] for d in range(start, stop)], axis=0)
                cl = np.mean([clean_before[d] for d in range(start, stop)], axis=0)
                for j, k in enumerate(FIELDS):
                    for labelbase, v in [("one_week", pre1), ("two_week", pre2)]:
                        change = post[:, j] - v[:, j]
                        delta[f"{label}_{k}_{labelbase}_delta"] = change
                        delta[f"{label}_{k}_{labelbase}_before_app_delta"] = pa[:, j] - v[:, j]
                        delta[f"{label}_{k}_{labelbase}_before_new_coupon_delta"] = (
                            cl[:, j] - v[:, j]
                        )
                        for dose in sorted(set(ds)):
                            ix = ds == dose
                            out["periods"].append(
                                {
                                    "cohort": name,
                                    "window": h,
                                    "period": label,
                                    "metric": k,
                                    "baseline": labelbase,
                                    "dose": dose,
                                    "events": int(ix.sum()),
                                    "post": float(post[ix, j].mean()),
                                    "baseline_rate": float(v[ix, j].mean()),
                                    "change": float(change[ix].mean()),
                                    "before_app": float(pa[ix, j].mean()),
                                    "before_app_new_coupon": float(cl[ix, j].mean()),
                                }
                            )
            # Stable15 subgroup allows a pre-issue placebo wholly after settlement.
            for k in ["new_active", "new_loan_entry"]:
                j = FIELDS.index(k)
                past = np.mean([vals[d][:, j] for d in [-3, -2, -1]], axis=0)
                older = np.mean([vals[d][:, j] for d in [-10, -9, -8]], axis=0)
                delta[f"placebo_{k}"] = past - older
                for dose in sorted(set(ds)):
                    ix = ds == dose
                    out["placebos"].append(
                        {
                            "cohort": name,
                            "window": h,
                            "metric": k,
                            "dose": dose,
                            "events": int(ix.sum()),
                            "recent_pre": float(past[ix].mean()),
                            "older_pre": float(older[ix].mean()),
                            "change": float((past - older)[ix].mean()),
                        }
                    )
            delta.to_parquet(
                PRIVATE / f"behavior_delta_{name}_{h}d.parquet", index=False, compression="zstd"
            )
            mark("corrected_behavior_complete", cohort=name, window=h, events=len(z))
    dump(W / "behavior_state_corrected_results.json", out)


if __name__ == "__main__":
    run()
