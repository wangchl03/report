from html import escape as esc
import math, json, unicodedata

COLORS = {0.0: "#94a3b8", 0.2: "#38bdf8", 0.3: "#a78bfa", 0.4: "#fb7185"}


def pct(v, d=2):
    return "—" if v is None or not math.isfinite(float(v)) else f"{float(v)*100:.{d}f}%"


def pp(v, d=2):
    return "—" if v is None or not math.isfinite(float(v)) else f"{float(v)*100:+.{d}f}个百分点"


def nfmt(v):
    return "—" if v is None else f"{float(v):,.0f}"


def dose_name(v):
    return "当日未见发券" if float(v) == 0 else f"{float(v)*100:.0f}%券"


def table(headers, rows, title="展开数据表"):
    return (
        '<details class="data-table"><summary>'
        + esc(title)
        + '</summary><div class="table-scroll"><table><thead><tr>'
        + "".join("<th>" + esc(str(x)) + "</th>" for x in headers)
        + "</tr></thead><tbody>"
        + "".join(
            "<tr>" + "".join("<td>" + str(x) + "</td>" for x in row) + "</tr>" for row in rows
        )
        + "</tbody></table></div></details>"
    )


def section(num, title, body, anchor):
    return (
        '<section id="'
        + esc(anchor)
        + '"><h2><b class="section-num">'
        + esc(num)
        + "</b>"
        + esc(title)
        + "</h2>"
        + body
        + "</section>"
    )


def conclusion(items):
    return '<ol class="conclusion">' + "".join("<li>" + v + "</li>" for v in items) + "</ol>"


def card(title, value, detail="", color="#38bdf8"):
    return f'<div class="kpi"><div class="kpi-title">{esc(title)}</div><strong style="color:{color}">{value}</strong><div class="kpi-detail">{detail}</div></div>'


def svg_base(w, h, inside, label="数据可视化"):
    return f'<svg role="img" aria-label="{esc(label)}" viewBox="0 0 {w} {h}" xmlns="http://www.w3.org/2000/svg">{inside}</svg>'


def heatmap(row_labels, col_labels, values, counts=None, title="", percentage=True):
    label_width = max(
        [
            sum(12 if unicodedata.east_asian_width(c) in ["W", "F"] else 7 for c in str(s))
            for s in row_labels
        ]
        or [0]
    )
    w = 1100
    left = min(420, max(150, label_width + 30))
    top = 66
    bottom = 54
    ch = 58
    cw = (w - left - 24) / len(col_labels)
    h = top + len(row_labels) * ch + bottom
    valid = [
        float(v) for row in values for v in row if v is not None and math.isfinite(float(v))
    ]
    mx = max(valid) if valid else 1.0
    mn = min(valid) if valid else 0.0
    a = [f'<text x="18" y="25" class="chart-title">{esc(title)}</text>']
    for j, label in enumerate(col_labels):
        a.append(
            f'<text x="{left+(j+.5)*cw:.1f}" y="51" text-anchor="middle" class="axis">{esc(str(label))}</text>'
        )
    for i, label in enumerate(row_labels):
        a.append(
            f'<text x="{left-14}" y="{top+i*ch+34}" text-anchor="end" class="axis">{esc(str(label))}</text>'
        )
        for j, v in enumerate(values[i]):
            x = left + j * cw + 2
            y = top + i * ch + 2
            validv = v is not None and math.isfinite(float(v))
            q = (float(v) - mn) / (mx - mn) if validv and mx > mn else 0.5
            color = (
                f"rgb({round(17+q*8)},{round(37+q*95)},{round(61+q*115)})"
                if validv
                else "#111b2b"
            )
            value = (
                pct(v, 2)
                if validv and percentage
                else ((f"{float(v):.4f}" if abs(float(v)) < 1 else nfmt(v)) if validv else "—")
            )
            count = "" if counts is None else str(counts[i][j])
            a.append(
                f'<rect x="{x:.1f}" y="{y}" width="{cw-4:.1f}" height="{ch-4}" rx="6" fill="{color}"><title>{esc(str(label))} · {esc(str(col_labels[j]))}: {value} {esc(count)}</title></rect>'
            )
            a.append(
                f'<text x="{x+(cw-4)/2:.1f}" y="{y+24}" text-anchor="middle" class="cell-value">{value}</text>'
            )
            if counts is not None:
                a.append(
                    f'<text x="{x+(cw-4)/2:.1f}" y="{y+43}" text-anchor="middle" class="cell-count">{esc(count)}</text>'
                )
    return '<div class="chart">' + svg_base(w, h, "".join(a), title) + "</div>"


def interval_plot(
    rows,
    value="profit_rate",
    low="profit_ci95",
    labelkey="label",
    title="",
    format_pct=True,
    unit="percent",
):
    w = 1100
    left = 220
    right = 110
    top = 70
    rh = 68
    h = top + rh * len(rows) + 55
    vals = []
    for r in rows:
        if r.get(value) is not None:
            vals.append(r[value])
        if r.get(low):
            vals.extend(r[low])
    vals = [v for v in vals if v is not None and math.isfinite(float(v))]
    lo = min(0, min(vals)) if vals else 0
    hi = max(vals) if vals else 1
    span = hi - lo or 1
    lo -= span * 0.1
    hi += span * 0.15

    def x(v):
        return left + (v - lo) / (hi - lo) * (w - left - right)

    a = [f'<text x="18" y="27" class="chart-title">{esc(title)}</text>']

    def fmt_value(v):
        return f"{v*100:+.2f}pp" if unit == "pp" else (pct(v) if format_pct else nfmt(v))

    for j in range(6):
        v = lo + (hi - lo) * j / 5
        xx = x(v)
        axislabel = f"{v*100:.1f}pp" if unit == "pp" else (pct(v, 0) if format_pct else nfmt(v))
        a.append(
            f'<path d="M{xx:.1f},{top-15} V{h-42}" class="grid"/><text x="{xx:.1f}" y="{h-18}" class="axis" text-anchor="middle">{axislabel}</text>'
        )
    for i, r in enumerate(rows):
        yy = top + i * rh + 20
        color = r.get("color", COLORS.get(float(r.get("dose", 0.2)), "#38bdf8"))
        v = r.get(value)
        a.append(
            f'<text x="{left-20}" y="{yy+4}" text-anchor="end" class="axis">{esc(str(r.get(labelkey,'')))}</text>'
        )
        if v is None:
            continue
        ci = r.get(low)
        if ci and all(z is not None for z in ci):
            l, u = map(x, ci)
            a.append(
                f'<path d="M{l:.1f},{yy} H{u:.1f} M{l:.1f},{yy-6} V{yy+6} M{u:.1f},{yy-6} V{yy+6}" stroke="{color}" stroke-width="2.5" fill="none"/>'
            )
        a.append(
            f'<circle cx="{x(v):.1f}" cy="{yy}" r="6" fill="{color}"/><text x="{w-right+15}" y="{yy+5}" fill="{color}" class="value">{fmt_value(v)}</text>'
        )
        if r.get("note"):
            a.append(f'<text x="{left}" y="{yy+25}" class="axis">{esc(r["note"])}</text>')
    return '<div class="chart">' + svg_base(w, h, "".join(a), title) + "</div>"


CSS = """
:root{color-scheme:dark;--bg:#0b1220;--panel:#111c2e;--panel2:#0e192b;--line:#26364c;--text:#dce7f5;--muted:#94a8c2;--accent:#42c6ef;--purple:#a78bfa;--red:#fb7185;--green:#34d399}
*{box-sizing:border-box}html{scroll-behavior:smooth}body{margin:0;background:var(--bg);color:var(--text);font:15px/1.75 -apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei",sans-serif}a{color:#62d2ef;text-decoration:none}a:hover{text-decoration:underline}main{max-width:1260px;margin:auto;padding:34px 28px 70px}header{text-align:center;padding:28px 12px 30px;border-bottom:1px solid var(--line)}h1{color:#61d2f4;font-size:33px;line-height:1.45;margin:10px 0 12px;font-weight:750}header p{color:var(--muted);margin:8px auto;max-width:900px}.eyebrow{letter-spacing:2px;color:#9eb8d5;font-size:12px}nav{display:flex;gap:10px;flex-wrap:wrap;justify-content:center;margin:22px 0}nav a,.pill{border:1px solid #314661;background:#142238;padding:6px 13px;border-radius:20px;font-size:13px}section{padding:28px 0 12px;scroll-margin-top:18px}h2{display:flex;align-items:center;gap:13px;color:#48c9f0;font-size:24px;line-height:1.5;margin:8px 0 20px}h3{font-size:19px;color:#a7ddf5;margin:24px 0 12px}.section-num{display:inline-flex;align-items:center;justify-content:center;min-width:44px;height:44px;border-radius:11px;border:1px solid #2a8fb4;background:#10344a;color:#6adeff;font-size:23px;flex:0 0 auto}.lead{padding:17px 21px;border-left:4px solid #42c6ef;background:#102336;border-radius:8px;font-size:17px;margin:16px 0}.grid-cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(225px,1fr));gap:15px}.kpi{padding:19px 20px;background:var(--panel);border:1px solid var(--line);border-radius:12px}.kpi-title{color:#9cb0c9;font-size:13px}.kpi strong{display:block;font-size:31px;line-height:1.5;margin:6px 0}.kpi-detail{font-size:13px;color:#a3b7cf}.chart{background:var(--panel);border:1px solid var(--line);border-radius:12px;padding:13px 15px;margin:16px 0;overflow:hidden}.chart svg{width:100%;height:auto;display:block}svg text{font-family:inherit}svg .axis{fill:#a2b5ce;font-size:12px}svg .value{font-size:17px;font-weight:700}svg .chart-title{fill:#c3d9ee;font-size:17px;font-weight:650}svg .grid{stroke:#2b3c52;stroke-width:1;stroke-dasharray:3 5}svg .cell-value{fill:#e1effb;font-size:14px;font-weight:650}svg .cell-count{fill:#bad0e7;font-size:10px}.conclusion{margin:12px 0 20px;padding:14px 19px 14px 40px;background:#0f2032;border:1px solid #25435a;border-radius:9px}.conclusion li{padding:3px 0}.note{color:#9bb0c9;font-size:13px;margin:10px 0}.warning{color:#f5c779}.tag{font-size:12px;color:#a9bdd5;border:1px solid #35506c;padding:3px 7px;border-radius:4px}details{border:1px solid #2a3b52;background:#0e192a;border-radius:9px;margin:14px 0}summary{cursor:pointer;padding:12px 16px;color:#7cd4f3;font-weight:600}details[open]>summary{border-bottom:1px solid var(--line)}.table-scroll{overflow:auto;padding:10px}table{border-collapse:collapse;width:100%;font-variant-numeric:tabular-nums;font-size:13px;white-space:nowrap}th{background:#172941;color:#b9d8f2;text-align:right}td,th{padding:10px 12px;border-bottom:1px solid #24364c}td{text-align:right}td:first-child,th:first-child{text-align:left}tbody tr:hover{background:#14263c}pre{margin:0;padding:18px;font:12px/1.7 ui-monospace,SFMono-Regular,Menlo,monospace;overflow:auto;white-space:pre;color:#bcd2e9}code{font-family:ui-monospace,SFMono-Regular,Menlo,monospace}.controls{display:flex;gap:10px;flex-wrap:wrap;margin:10px 0}.controls label{font-size:13px;color:#a9bbd0}select{padding:7px 11px;margin-left:5px;background:#15273e;color:#d3e7f6;border:1px solid #36516d;border-radius:6px}.report-links{display:grid;grid-template-columns:repeat(auto-fit,minmax(280px,1fr));gap:15px}.report-link{display:block;padding:22px;background:#11243a;border:1px solid #2f5876;border-radius:12px}.report-link b{font-size:21px;display:block;color:#62d5f6}.report-link span{font-size:13px;color:#a6bfd6;display:block;margin-top:10px}.muted{color:var(--muted)}footer{margin-top:35px;border-top:1px solid var(--line);padding-top:20px;color:#8197b2;font-size:12px}.two-col{display:grid;grid-template-columns:1fr 1fr;gap:16px}.red{color:var(--red)}.green{color:var(--green)}@media(max-width:800px){main{padding:18px 13px 40px}h1{font-size:25px}h2{font-size:21px}.two-col{grid-template-columns:1fr}.chart{padding:8px 5px}.kpi strong{font-size:26px}}
"""


def page(title, subtitle, body, nav="", extra_script=""):
    return (
        '<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'
        + esc(title)
        + "</title><style>"
        + CSS
        + '</style></head><body><main><header><div class="eyebrow">用户召回 · 数据验证</div><h1>'
        + esc(title)
        + "</h1><p>"
        + subtitle
        + "</p></header><nav>"
        + nav
        + "</nav>"
        + body
        + "<footer>完整业务日观察截止2026年11月3日；回款、逾期状态采用本次冻结数据。百分比按原始分子、分母计算，展示保留两位小数。</footer></main>"
        + extra_script
        + "</body></html>"
    )
