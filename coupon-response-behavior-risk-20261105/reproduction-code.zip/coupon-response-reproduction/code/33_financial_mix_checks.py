"""Separate current cash profitability, order overdue status, and product/maturity/customer mix."""

from core import *
import importlib.util

spec = importlib.util.spec_from_file_location("_fin", W / "12_finances.py")
fin = importlib.util.module_from_spec(spec)
spec.loader.exec_module(fin)


def run():
    f = pd.read_parquet(PRIVATE / "used_orders_finance.parquet")
    z = f[
        f.whole_mature
        & f.repaid_amt.notna()
        & f.valid_days.eq(3)
        & f.strict_t7.eq(1)
        & f.eligible_offer.eq(1)
        & f.has_amount_coupon.eq(0)
        & f.has_repayment_coupon.eq(0)
        & f.other_application_discount.eq(0)
        & f.fixed_coupon.eq(0)
    ].copy()
    z["age_band"] = pd.cut(
        z.days_past_due,
        [0, 15, 31, 61, 121, np.inf],
        labels=["到期0—14天", "到期15—30天", "到期31—60天", "到期61—120天", "到期121天以上"],
        right=False,
    ).astype(str)
    z["amount_band"] = pd.cut(
        z.remit_amt,
        [0, 2000, 5000, 10000, np.inf],
        labels=["<2,000", "2,000—<5,000", "5,000—<10,000", "≥10,000"],
        right=False,
    ).astype(str)
    z["risk_band"] = (
        pd.cut(
            z.score410,
            [-np.inf, 450, 500, 528, np.inf],
            labels=["<450", "450—499", "500—527", "≥528"],
            right=False,
        )
        .astype(str)
        .where(z.score410.notna(), "缺失")
    )
    out = {
        "by_age": [],
        "by_amount": [],
        "by_product": [],
        "by_risk": [],
        "by_risk_age": [],
        "by_joint": [],
    }
    for dim, key in [
        ("age_band", "by_age"),
        ("amount_band", "by_amount"),
        ("loan_day", "by_product"),
        ("risk_band", "by_risk"),
    ]:
        for (lev, dose), g in z.groupby([dim, "dose"]):
            out[key].append(fin.agg(g, {"level": str(lev), "dose": dose}, ci=len(g) >= 30))
    for (risk, age, dose), g in z.groupby(["risk_band", "age_band", "dose"]):
        out["by_risk_age"].append(fin.agg(g, {"risk": risk, "due_age": age, "dose": dose}))
    for (risk, amount, dose), g in z.groupby(["risk_band", "amount_band", "dose"]):
        out["by_joint"].append(fin.agg(g, {"risk": risk, "amount": amount, "dose": dose}))
    dump(W / "financial_mix_results.json", out)
    mark("financial_mix_complete", mature_orders=len(z))


if __name__ == "__main__":
    run()
