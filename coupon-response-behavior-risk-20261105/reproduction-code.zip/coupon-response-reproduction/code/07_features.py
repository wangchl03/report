"""Reconstruct baseline user histories and response labels from frozen source clocks."""

from core import *
from bisect import bisect_left, bisect_right
from collections import defaultdict

END = pd.Timestamp("2026-11-04")
EPOCH_END = END.tz_localize("America/Belize").timestamp()
DAY = 86400.0


def num(f, cols):
    for k in cols:
        if k in f:
            f[k] = pd.to_numeric(f[k], errors="coerce")
    return f


def dt(f, cols):
    for k in cols:
        if k in f:
            f[k] = pd.to_datetime(f[k], errors="coerce", format="mixed")
    return f


def ns(s):
    return (
        pd.to_datetime(s)
        .dt.tz_localize("America/Belize")
        .dt.tz_convert("UTC")
        .dt.tz_localize(None)
        .astype("datetime64[ns]")
        .astype("int64")
        .to_numpy()
        / 1e9
    )


def prepare():
    audit = {}
    loans = pd.read_parquet(PRIVATE / "loan_histories.parquet")
    loans = num(
        dt(
            loans,
            ["apply_time", "remit_time", "due_time", "due_date", "repaid_time", "apply_date"],
        ),
        [
            "user_id",
            "serial_id",
            "is_remit",
            "is_repaid",
            "remit_amt",
            "apply_amt",
            "repaid_amt",
            "loan_status_code",
            "loan_day",
            "total_term",
            "pre_amt",
            "post_amt",
            "overdue_days",
        ],
    )
    audit["loan_rows"] = len(loans)
    audit["exact_loan_duplicates"] = int(loans.duplicated().sum())
    loans = loans.drop_duplicates()
    conflicts = loans.groupby(["user_id", "serial_id"]).size()
    bad = conflicts[conflicts > 1].index
    audit["conflicting_loan_keys"] = len(bad)
    audit["conflicting_loan_users"] = list(sorted({int(k[0]) for k in bad}))
    if len(bad):
        loans = loans[
            ~pd.MultiIndex.from_frame(loans[["user_id", "serial_id"]]).isin(bad)
        ].copy()
    loans["funded"] = (
        loans.is_remit.eq(1)
        & loans.remit_amt.gt(0)
        & loans.remit_time.notna()
        & loans.remit_time.ge(loans.apply_time)
    )
    loans["valid_settle"] = loans.repaid_time.where(
        (loans.is_repaid.eq(1) | loans.loan_status_code.eq(7))
        & loans.repaid_time.ge(loans.remit_time)
    )
    loans["unknown_settle"] = (
        loans.funded
        & (loans.is_repaid.eq(1) | loans.loan_status_code.eq(7))
        & loans.valid_settle.isna()
    )
    loans["apply_s"] = ns(loans.apply_time)
    loans["fund_s"] = ns(loans.remit_time)
    loans["settle_s"] = ns(loans.valid_settle)
    loans["due_day"] = loans.due_date.dt.normalize()
    offers = pd.read_parquet(PRIVATE / "credit_histories.parquet")
    offers = num(
        offers,
        [
            "user_id",
            "serial_id",
            "vir_unix",
            "is_pass1",
            "loan_type_code",
            "recycle_type",
            "recycle_versions",
            "max_credit_apply_amt",
        ],
    )
    audit["credit_rows"] = len(offers)
    audit["exact_credit_duplicates"] = int(offers.duplicated().sum())
    offers = offers.drop_duplicates()
    offers["credit_time"] = (
        pd.to_datetime(offers.vir_unix, unit="s", utc=True)
        .dt.tz_convert("America/Belize")
        .dt.tz_localize(None)
    )
    offers["credit_s"] = ns(offers.credit_time)
    audit["credit_epoch_max_difference"] = float(
        np.max(np.abs(offers.credit_s - offers.vir_unix))
    )
    assert audit["credit_epoch_max_difference"] < 0.001
    key = ["user_id", "serial_id", "vir_unix"]
    # If the same event has conflicting pass/recycle/amount values, quarantine the event.
    conflict = (
        offers.groupby(key)[["is_pass1", "recycle_type", "max_credit_apply_amt"]]
        .nunique(dropna=False)
        .max(axis=1)
        > 1
    )
    bad = conflict[conflict].index
    audit["conflicting_credit_keys"] = len(bad)
    offers["event_conflict"] = pd.MultiIndex.from_frame(offers[key]).isin(bad)
    offers = offers.drop_duplicates(key).copy()
    # Preserve the latest event clock so an ambiguous latest result never falls back to an older pass.
    offers.loc[offers.event_conflict, ["is_pass1", "recycle_type", "max_credit_apply_amt"]] = (
        np.nan
    )
    offers["qualified"] = (
        offers.is_pass1.eq(1)
        & offers.recycle_type.notna()
        & offers.recycle_type.ne(1)
        & offers.recycle_versions.eq(1)
    )
    models = pd.read_parquet(PRIVATE / "risk_score_histories.parquet")
    models = num(models, list(models.columns))
    scorecols = ["score363", "score405", "score410", "score410cyc"]
    for k in scorecols:
        models[k] = models[k].where(models[k].between(0, 3000))
    agg = models.groupby(["user_id", "serial_id"])[scorecols].agg(["min", "nunique"])
    risk = {}
    for key, row in agg.iterrows():
        risk[key] = {
            s: row[(s, "min")] if row[(s, "nunique")] == 1 else np.nan for s in scorecols
        }
    audit["model_conflicting_keys"] = int(
        (agg.xs("nunique", level=1, axis=1) > 1).any(axis=1).sum()
    )
    # Per-order amount utilization uses the passed credit row no later than that order's application.
    uk = ["user_id", "serial_id"]
    util = loans[uk + ["apply_s", "apply_amt"]].merge(
        offers.loc[offers.is_pass1.eq(1), uk + ["credit_s", "max_credit_apply_amt"]],
        on=uk,
        how="left",
    )
    util = (
        util[util.credit_s.le(util.apply_s)]
        .sort_values("credit_s")
        .drop_duplicates(uk, keep="last")
    )
    util["ratio"] = (util.apply_amt / util.max_credit_apply_amt).where(
        util.max_credit_apply_amt.gt(0) & util.apply_amt.ge(0)
    )
    ratios = util.set_index(uk).ratio.reindex(pd.MultiIndex.from_frame(loans[uk])).to_numpy()
    loans["utilization_raw"] = ratios
    loans["utilization"] = loans.utilization_raw.mask(
        loans.utilization_raw.between(0.97, 1.03), 1.0
    )
    # Link offer to its own order for historical rates. No future application counts in baseline.
    appmap = loans.set_index(["user_id", "serial_id"]).apply_s.to_dict()
    offers["own_apply_s"] = [
        appmap.get((r.user_id, r.serial_id), np.nan) for r in offers.itertuples()
    ]
    loans.to_parquet(PRIVATE / "loans_clean.parquet", index=False, compression="zstd")
    offers.to_parquet(PRIVATE / "credits_clean.parquet", index=False, compression="zstd")
    dump(W / "history_quality_audit.json", audit)
    return loans, offers, risk, audit


def run():
    loans, offers, risk, audit = prepare()
    anchors = pd.read_parquet(PRIVATE / "anchors_unfeatured.parquet")
    anchors["anchor"] = pd.to_datetime(anchors.anchor)
    # All issued application/amount coupons are contamination flags, including unrequested discount levels.
    coupons = pd.read_parquet(PRIVATE / "all_issue_histories.parquet")
    coupons = dt(coupons, ["create_date", "expire_date"])
    coupons = num(coupons, ["user_id", "type", "coupon_id"])
    cg = {
        k: g.sort_values("create_date")
        for k, g in coupons[coupons.type.isin([3, 4])].groupby("user_id", sort=False)
    }
    lg = {
        int(k): g.sort_values(["apply_time", "serial_id"])
        for k, g in loans.groupby("user_id", sort=False)
    }
    og = {
        int(k): g.sort_values(["credit_time", "serial_id"])
        for k, g in offers.groupby("user_id", sort=False)
    }
    records = []
    for uid, aa in anchors.groupby("user_id", sort=False):
        ll = lg.get(int(uid))
        oo = og.get(int(uid))
        cc = cg.get(uid)
        for a in aa.itertuples():
            t = a.anchor.tz_localize("America/Belize").timestamp()
            r = {"episode_id": a.episode_id}
            prior = ll[ll.apply_s < t] if ll is not None else loans.iloc[:0]
            funds = prior[prior.funded & (prior.fund_s < t)]
            settled = funds[funds.valid_settle.notna() & (funds.settle_s <= t)]
            open_ = funds[funds.valid_settle.isna() | (funds.settle_s > t)]
            r.update(
                {
                    "prior_app_n": len(prior),
                    "prior_fund_n": len(funds),
                    "open_n": len(open_),
                    "unknown_settle_n": int(funds.unknown_settle.sum()),
                    "prior_settled_n": len(settled),
                    "open_overdue_n": int((open_.due_day < a.anchor).sum()),
                    "prior_apps30": int((prior.apply_s >= t - 30 * DAY).sum()),
                    "prior_apps90": int((prior.apply_s >= t - 90 * DAY).sum()),
                    "days_since_last_apply": (
                        (t - prior.apply_s.max()) / DAY if len(prior) else np.nan
                    ),
                    "days_since_first_apply": (
                        (t - prior.apply_s.min()) / DAY if len(prior) else np.nan
                    ),
                    "days_since_last_settle": (
                        (t - settled.settle_s.max()) / DAY if len(settled) else np.nan
                    ),
                    "mean_borrow_gap_days": (
                        (funds.fund_s.max() - funds.fund_s.min()) / DAY / (len(funds) - 1)
                        if len(funds) >= 2
                        else np.nan
                    ),
                    "mean_prior_apply_amt": prior.apply_amt.mean(),
                    "last_prior_apply_amt": prior.iloc[-1].apply_amt if len(prior) else np.nan,
                    "mean_prior_fund_amt": funds.remit_amt.mean(),
                    "median_prior_fund_amt": funds.remit_amt.median(),
                    "mean_utilization": prior.utilization.mean(),
                    "last_utilization": prior.iloc[-1].utilization if len(prior) else np.nan,
                    "mean_funded_utilization": funds.utilization.mean(),
                    "mean_funded_utilization_raw": funds.utilization_raw.mean(),
                    "last_funded_utilization": (
                        funds.sort_values("fund_s").iloc[-1].utilization
                        if len(funds)
                        else np.nan
                    ),
                    "mean_utilization90": prior.loc[
                        prior.apply_s >= t - 90 * DAY, "utilization"
                    ].mean(),
                    "utilization_known_n": int(prior.utilization.notna().sum()),
                    "prior_settled_late_n": int(
                        (settled.valid_settle.dt.normalize() > settled.due_day).sum()
                    ),
                    "prior_settled_ever_overdue_n": int(settled.overdue_days.gt(0).sum()),
                    "last_settled_overdue_days": (
                        settled.sort_values("settle_s").iloc[-1].overdue_days
                        if len(settled)
                        else np.nan
                    ),
                    "last_prior_product": prior.iloc[-1].product_no if len(prior) else None,
                    "last_prior_term": prior.iloc[-1].total_term if len(prior) else np.nan,
                }
            )
            r["churn_days"] = (
                (a.anchor - settled.valid_settle.max().normalize()).days
                if not len(open_) and len(settled)
                else np.nan
            )
            r["t7_no_open"] = int(not len(open_) and len(settled) > 0 and r["churn_days"] > 7)
            r["strict_t7"] = int(
                r["t7_no_open"]
                and (not len(prior) or prior.apply_s.max() <= settled.settle_s.max())
            )
            pp = oo[oo.credit_s < t] if oo is not None else offers.iloc[:0]
            latest = pp.iloc[-1] if len(pp) else None
            r.update(
                {
                    "latest_credit_s": latest.credit_s if latest is not None else np.nan,
                    "latest_credit_serial": latest.serial_id if latest is not None else np.nan,
                    "latest_credit_pass": (
                        int(latest.is_pass1 == 1) if latest is not None else 0
                    ),
                    "latest_recycle": latest.recycle_type if latest is not None else np.nan,
                    "latest_credit_qualified": (
                        int(latest.qualified) if latest is not None else 0
                    ),
                    "latest_credit_amt": (
                        latest.max_credit_apply_amt if latest is not None else np.nan
                    ),
                }
            )
            used_before = (
                latest is not None
                and np.isfinite(latest.own_apply_s)
                and latest.own_apply_s < t
            )
            r["latest_credit_already_applied"] = int(used_before)
            r["history_conflict_user"] = int(uid in set(audit["conflicting_loan_users"]))
            r["eligible_offer"] = int(r["latest_credit_qualified"])
            for s in ["score363", "score405", "score410", "score410cyc"]:
                r[s] = risk.get((uid, r["latest_credit_serial"]), {}).get(s, np.nan)
            qualified = pp[pp.qualified]
            # History orders are unique user+serial; agree with an order denominator, not duplicate versions.
            qualified = qualified.sort_values("credit_s").drop_duplicates(
                ["user_id", "serial_id"], keep="last"
            )
            for n in [30, 90, 180]:
                h = qualified[(qualified.credit_s >= t - n * DAY) & (qualified.credit_s < t)]
                validown = h.own_apply_s.ge(h.credit_s) & h.own_apply_s.lt(t)
                # Completed natural day: all these offer days precede the current anchor date.
                own_day = (
                    pd.to_datetime(h.own_apply_s, unit="s", errors="coerce", utc=True)
                    .dt.tz_convert("America/Belize")
                    .dt.tz_localize(None)
                    .dt.normalize()
                )
                credit_day = h.credit_time.dt.normalize()
                r[f"hist_offer_d0_n{n}"] = len(h)
                r[f"hist_offer_d0_y{n}"] = int((validown & (own_day == credit_day)).sum())
                r[f"hist_offer_d0_rate{n}"] = (
                    r[f"hist_offer_d0_y{n}"] / len(h) if len(h) else np.nan
                )
                cd = qualified.credit_time.dt.normalize()
                h7 = qualified[
                    (cd >= a.anchor - pd.Timedelta(days=n + 6))
                    & (cd < a.anchor - pd.Timedelta(days=6))
                ]
                own7 = (
                    pd.to_datetime(h7.own_apply_s, unit="s", errors="coerce", utc=True)
                    .dt.tz_convert("America/Belize")
                    .dt.tz_localize(None)
                    .dt.normalize()
                )
                r[f"hist_offer_d7_n{n}"] = len(h7)
                r[f"hist_offer_d7_y{n}"] = int(
                    (
                        h7.own_apply_s.ge(h7.credit_s)
                        & (own7 < h7.credit_time.dt.normalize() + pd.Timedelta(days=7))
                    ).sum()
                )
                r[f"hist_offer_d7_rate{n}"] = (
                    r[f"hist_offer_d7_y{n}"] / len(h7) if len(h7) else np.nan
                )
            if oo is not None:
                same = oo[(oo.credit_s >= t) & (oo.credit_s < t + DAY)]
                r["same_day_new_credit_n"] = len(same)
                r["same_day_passed_non1_n"] = int(same.qualified.sum())
            else:
                r["same_day_new_credit_n"] = 0
                r["same_day_passed_non1_n"] = 0
            r["same_day_fund_n"] = (
                int(((ll.fund_s >= t) & (ll.fund_s < t + DAY) & ll.funded).sum())
                if ll is not None
                else 0
            )
            r["same_day_settle_n"] = (
                int(
                    (
                        (ll.settle_s >= t) & (ll.settle_s < t + DAY) & ll.valid_settle.notna()
                    ).sum()
                )
                if ll is not None
                else 0
            )
            future = (
                ll[(ll.apply_s >= t) & (ll.apply_s < EPOCH_END)]
                if ll is not None
                else loans.iloc[:0]
            )
            r["first_apply_s"] = future.iloc[0].apply_s if len(future) else np.nan
            r["first_apply_serial"] = future.iloc[0].serial_id if len(future) else np.nan
            for d in [3, 7, 15, 30]:
                mature = t + d * DAY <= EPOCH_END
                r[f"observed_{d}"] = int(mature)
                r[f"applied_{d}"] = (
                    int(len(future) > 0 and future.iloc[0].apply_s < t + d * DAY)
                    if mature
                    else np.nan
                )
            if cc is not None:
                prev = cc[
                    (cc.create_date < a.anchor)
                    & (cc.create_date >= a.anchor - pd.Timedelta(days=30))
                ]
                nxt = cc[cc.create_date > a.anchor]
                r["coupon_sends_prior7"] = int(
                    (prev.create_date >= a.anchor - pd.Timedelta(days=7)).sum()
                )
                r["coupon_sends_prior30"] = len(prev)
                r["prior_coupon_still_valid"] = int((prev.expire_date >= a.anchor).any())
                r["next_coupon_day"] = (
                    (nxt.create_date.min() - a.anchor).days if len(nxt) else np.nan
                )
            else:
                r.update(
                    {
                        "coupon_sends_prior7": 0,
                        "coupon_sends_prior30": 0,
                        "prior_coupon_still_valid": 0,
                        "next_coupon_day": np.nan,
                    }
                )
            records.append(r)
        if len(records) % 5000 < len(aa):
            mark("feature_progress", episodes=len(records))
    result = anchors.merge(pd.DataFrame(records), on="episode_id", validate="one_to_one")
    result["anchor_month"] = result.anchor.dt.strftime("%Y-%m")
    # Same qualified credit order contributes once: first observed contact, before any future outcome is inspected.
    q = result[result.eligible_offer == 1].sort_values(["anchor", "episode_id"])
    result["first_contact_for_offer"] = 0
    ix = q.drop_duplicates(["user_id", "latest_credit_serial"]).index
    result.loc[ix, "first_contact_for_offer"] = 1
    # Main unit is a qualified-offer contact event (user x issue/recall day).
    # Repeated days remain events, with user-clustered uncertainty. The first-contact subset is a robustness check.
    result = apply_eligibility_contract(result)
    result.to_parquet(PRIVATE / "episode_features.parquet", index=False, compression="zstd")
    audit.update(
        {
            "episodes": len(result),
            "eligible_offer_episodes": int(result.eligible_offer.sum()),
            "unique_qualified_credit_orders": int(result.first_contact_for_offer.sum()),
            "t7_no_open": int(result.t7_no_open.sum()),
            "strict_t7": int(result.strict_t7.sum()),
            "unknown_settlement_episodes": int(result.unknown_settle_n.gt(0).sum()),
        }
    )
    dump(W / "feature_audit.json", audit)
    mark("features_complete", **audit)


if __name__ == "__main__":
    run()
