"""Audit an additional utilization view only where whole-order amount-increase use is observed.

The requested original apply/approved-quota indicator is retained unchanged.
No unobserved increase is imputed, and overlapping type4 records are not summed arbitrarily.
"""

from analysis_contract import *


def run():
    c = pd.read_parquet(PRIVATE / "all_issue_histories.parquet")
    for k in ["user_id", "serial_id", "type", "real_use_amount"]:
        c[k] = pd.to_numeric(c[k], errors="coerce")
    a = c[c.type.eq(4) & c.real_use_amount.gt(0) & c.serial_id.notna()].copy()
    size = a.groupby(["user_id", "serial_id"]).size()
    bad = size[size > 1].index
    a = a[~pd.MultiIndex.from_frame(a[["user_id", "serial_id"]]).isin(bad)]
    l = pd.read_parquet(PRIVATE / "loans_clean.parquet")
    z = l[l.funded & l.utilization_raw.notna()].merge(
        a[["user_id", "serial_id", "real_use_amount"]],
        on=["user_id", "serial_id"],
        how="left",
        validate="one_to_one",
    )
    # Recover the same matched pre-application offer limit used in the original raw ratio.
    z["base_quota"] = np.where(z.utilization_raw > 0, z.apply_amt / z.utilization_raw, np.nan)
    z["ratio_with_observed_increase"] = z.apply_amt / (z.base_quota + z.real_use_amount)
    z["ratio_difference"] = z.utilization_raw - z.ratio_with_observed_increase
    q = z[z.real_use_amount.notna()]
    audit = {
        "positive_type4_records": len(a),
        "conflicting_user_order_keys_excluded": len(bad),
        "funded_with_known_original_util": len(z),
        "matched_positive_type4_use": len(q),
        "over103_raw_in_matched": int(q.utilization_raw.gt(1.03).sum()),
        "within97_103_after_observed_increase": int(
            q.ratio_with_observed_increase.between(0.97, 1.03).sum()
        ),
        "over103_after_observed_increase": int(q.ratio_with_observed_increase.gt(1.03).sum()),
        "median_original_util": float(q.utilization_raw.median()),
        "median_with_observed_increase": float(q.ratio_with_observed_increase.median()),
        "median_actual_amount_increase": float(q.real_use_amount.median()),
        "interpretation": "Separate sensitivity, not a replacement of apply_amt / matched original approved amount. Coupon history before May is unavailable.",
    }
    dump(W / "quota_after_amount_coupon_results.json", audit)
    mark("quota_after_amount_coupon_complete", **audit)


if __name__ == "__main__":
    run()
