"""Temporal validation of baseline-only response ranking; it does not estimate incremental coupon effects."""

from core import *
from sklearn.impute import SimpleImputer
from sklearn.preprocessing import StandardScaler
from sklearn.pipeline import Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score, average_precision_score, brier_score_loss, log_loss
from lightgbm import LGBMClassifier, early_stopping, log_evaluation
import importlib.util, joblib

spec = importlib.util.spec_from_file_location("_rates", W / "11_rates.py")
rm = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rm)

GROUPS = {
    "recent_activity": [
        "days_since_last_active",
        "pre7_active_days",
        "pre14_active_days",
        "no_record_in_available_history",
    ],
    "core_demand": [
        "days_since_last_active",
        "pre7_active_days",
        "churn_days",
        "prior_fund_n",
        "mean_borrow_gap_days",
        "last_funded_utilization",
        "mean_funded_utilization",
        "hist_offer_d7_rate90",
        "hist_offer_d7_n90",
        "score410",
        "score363",
        "score405",
        "latest_credit_age_days",
        "latest_credit_amt",
        "dose",
    ],
    "full_baseline": [
        "days_since_last_active",
        "pre7_active_days",
        "pre14_active_days",
        "pre7_loan_entry_days",
        "pre14_loan_entry_days",
        "pre7_amount_days",
        "pre7_term_days",
        "pre7_plan_days",
        "pre7_contract_days",
        "pre7_submit_days",
        "pre7_coupon_open_days",
        "pre7_coupon_confirm_days",
        "pre14_amount_days",
        "pre14_plan_days",
        "pre14_submit_days",
        "pre14_coupon_open_days",
        "pre14_coupon_confirm_days",
        "churn_days",
        "prior_fund_n",
        "mean_borrow_gap_days",
        "days_since_first_apply",
        "prior_apps30",
        "prior_apps90",
        "last_funded_utilization",
        "mean_funded_utilization",
        "mean_utilization90",
        "utilization_known_n",
        "hist_offer_d0_rate90",
        "hist_offer_d0_n90",
        "hist_offer_d7_rate90",
        "hist_offer_d7_n90",
        "hist_offer_d7_rate180",
        "hist_offer_d7_n180",
        "score410",
        "score363",
        "score405",
        "latest_credit_age_days",
        "latest_credit_amt",
        "mean_prior_fund_amt",
        "median_prior_fund_amt",
        "prior_settled_ever_overdue_n",
        "last_settled_overdue_days",
        "prior_late_periods_known",
        "prior_period_late_fraction",
        "coupon_sends_prior7",
        "coupon_sends_prior30",
        "prior_coupon_still_valid",
        "dose",
        "no_record_in_available_history",
        "prior_target_coupon_use_rate30",
        "prior_expired_target_coupons30",
        "historical_clean_gap_median",
        "completed_clean_gap_n",
        "excess_idle_days",
        "borrow_cycle_multiple",
        "last_funded_loan_day",
        "last_funded_fee_rate",
        "last_util_minus_mean",
    ],
}


def metrics(y, p):
    y = np.asarray(y, int)
    p = np.asarray(p, float)
    if len(y) < 2 or len(set(y)) < 2:
        return {"n": len(y), "positives": int(y.sum()), "auc": None}
    k = max(1, int(np.ceil(len(y) * 0.2)))
    order = np.argsort(-p, kind="stable")
    top = y[order[:k]]
    return {
        "n": len(y),
        "positives": int(y.sum()),
        "base_rate": float(y.mean()),
        "auc": float(roc_auc_score(y, p)),
        "pr_auc": float(average_precision_score(y, p)),
        "brier": float(brier_score_loss(y, p)),
        "log_loss": float(log_loss(y, np.clip(p, 1e-6, 1 - 1e-6))),
        "top20_n": k,
        "top20_applicants": int(top.sum()),
        "top20_rate": float(top.mean()),
        "top20_capture": float(top.sum() / y.sum()),
        "predicted_mean": float(p.mean()),
    }


def run():
    f = pd.read_parquet(PRIVATE / "episode_analysis.parquet")
    f["anchor"] = pd.to_datetime(f.anchor)
    f, co = rm.define_cohorts(f)
    z = (
        f[
            co["extension_simple"]
            & f.dose.gt(0)
            & f.observed_3.eq(1)
            & f.behavior_user_extracted.eq(1)
            & f.no_record_in_available_history.eq(0)
        ]
        .copy()
        .sort_values(["anchor", "episode_id"])
    )
    train = z.anchor + pd.Timedelta(days=3) <= pd.Timestamp("2026-09-18")
    valid = (z.anchor >= pd.Timestamp("2026-09-18")) & (
        z.anchor + pd.Timedelta(days=3) <= pd.Timestamp("2026-10-17")
    )
    test = z.anchor >= pd.Timestamp("2026-10-17")
    y = z.applied_3.astype("int8")
    out = {
        "target": "Qualified T7 recipients: any application D0-D2, not coupon incremental response",
        "split": {},
        "models": [],
    }
    for name, mask in [("train", train), ("validation", valid), ("test", test)]:
        g = z[mask]
        out["split"][name] = {
            "events": len(g),
            "users": g.user_id.nunique(),
            "positives": int(g.applied_3.sum()),
            "first_date": str(g.anchor.min()),
            "last_date": str(g.anchor.max()),
        }
    predictions = z[["episode_id", "user_id", "anchor", "dose", "applied_3"]].copy()
    for name, cols in GROUPS.items():
        cols = [c for c in cols if c in z and z.loc[train, c].notna().any()]
        x = z[cols].apply(pd.to_numeric, errors="coerce")
        if name != "full_baseline":
            model = Pipeline(
                [
                    ("missing", SimpleImputer(strategy="median", add_indicator=True)),
                    ("scale", StandardScaler()),
                    ("model", LogisticRegression(C=0.2, max_iter=2000)),
                ]
            )
            model.fit(x[train], y[train])
            prob = model.predict_proba(x)[:, 1]
        else:
            model = LGBMClassifier(
                n_estimators=1000,
                num_leaves=7,
                max_depth=3,
                min_child_samples=150,
                learning_rate=0.025,
                colsample_bytree=0.9,
                subsample=0.85,
                subsample_freq=1,
                reg_lambda=20,
                reg_alpha=1,
                n_jobs=2,
                verbosity=-1,
                random_state=20261105,
            )
            model.fit(
                x[train],
                y[train],
                eval_set=[(x[valid], y[valid])],
                eval_metric="binary_logloss",
                callbacks=[early_stopping(50, verbose=False), log_evaluation(0)],
            )
            prob = model.predict_proba(x)[:, 1]
        seen = set(z.loc[train, "user_id"])
        fresh = ~z.user_id.isin(seen)
        r = {
            "name": name,
            "features": cols,
            "feature_count": len(cols),
            "validation": metrics(y[valid], prob[valid]),
            "test": metrics(y[test], prob[test]),
            "unseen_user_test": metrics(y[test & fresh], prob[test & fresh]),
            "seen_user_test": metrics(y[test & ~fresh], prob[test & ~fresh]),
            "test_monthly": [],
        }
        for date, g in z[test].groupby(z.loc[test, "anchor"].dt.strftime("%Y-%m-%d")):
            ix = z.index.get_indexer(g.index)
            r["test_monthly"].append({"anchor": date, **metrics(y.iloc[ix], prob[ix])})
        if name == "full_baseline":
            r["feature_importance"] = sorted(
                [
                    {"feature": c, "gain": float(v)}
                    for c, v in zip(cols, model.booster_.feature_importance("gain"))
                ],
                key=lambda a: a["gain"],
                reverse=True,
            )
            r["best_iteration"] = model.best_iteration_
        out["models"].append(r)
        predictions[name + "_p"] = prob
        joblib.dump(
            {
                "model": model,
                "features": cols,
                "target": "D0-D2 observed response after issued coupon; not uplift",
            },
            PRIVATE / (name + "_diagnostic_model.joblib"),
        )
        mark(
            "response_ranking_model_complete",
            name=name,
            test=r["test"],
            unseen_test=r["unseen_user_test"],
        )
    choices = sorted(
        out["models"], key=lambda x: x["validation"].get("pr_auc", -1), reverse=True
    )
    best = choices[0]["validation"]["pr_auc"]
    close = [r for r in choices if best - r["validation"]["pr_auc"] <= 0.005]
    out["selected_by_validation"] = min(close, key=lambda r: r["feature_count"])["name"]
    out["selection_rule"] = (
        "Validation PR-AUC; within 0.005 choose fewer features. Test metrics never determine selection."
    )
    dump(W / "response_ranking_results.json", out)
    predictions.to_parquet(
        PRIVATE / "diagnostic_response_predictions.parquet", index=False, compression="zstd"
    )


if __name__ == "__main__":
    run()
