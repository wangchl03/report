from core import *
import ast

src = ast.parse((W / "02_sources.py").read_text())
sql = None
for n in ast.walk(src):
    if (
        isinstance(n, ast.Assign)
        and isinstance(n.value, ast.Constant)
        and isinstance(n.value.value, str)
        and "FROM wangchuanliang.repayment_plan_v2_copy" in n.value.value
    ):
        sql = n.value.value
assert sql
sql = sql.replace(
    "AND apply_date>=DATE '2026-06-01' AND apply_date<%(end)s::date",
    "AND apply_date>=DATE '2000-01-01' AND apply_date<DATE '2026-06-01'",
)
c = connect()
try:
    with c.cursor() as q:
        q.execute("SET application_name='coupon_response_historical_period_source'")
    f = query_large(
        c,
        sql,
        {
            "users": json.loads((PRIVATE / "source_user_ids.json").read_text()),
            "end": "2026-11-04",
        },
        "periods_before_june",
    )
    base = PRIVATE / "period_outcomes.parquet"
    while not base.exists():
        time.sleep(5)
    z = pd.concat([pd.read_parquet(base), f], ignore_index=True)
    z.to_parquet(PRIVATE / "periods_all_history.parquet", index=False, compression="zstd")
    mark(
        "all_period_history_complete",
        rows=len(z),
        old_rows=len(f),
        duplicate_keys=int(z.duplicated(["user_id", "serial_id", "current_term"]).sum()),
    )
finally:
    c.rollback()
    c.close()
