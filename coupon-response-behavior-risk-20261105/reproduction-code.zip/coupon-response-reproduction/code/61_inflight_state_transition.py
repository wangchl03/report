"""Separate outstanding at issue from outstanding at the exact application time."""

from analysis_contract import *


def run():
    f = pd.read_parquet(PRIVATE / "episode_analysis.parquet")
    f["anchor"] = pd.to_datetime(f.anchor)
    f, co = cohorts_with_offer_grain(f)
    z = (
        f[co["extension_outstanding"]]
        .sort_values(["anchor", "episode_id"])
        .drop_duplicates(["user_id", "latest_credit_serial"])
        .copy()
    )
    z = z[
        z.dose.eq(0.2)
        & z.simple_discount
        & z.open_late_periods.eq(0)
        & z.open_overdue_n.eq(0)
        & z.observed_3.eq(1)
    ]
    loans = pd.read_parquet(PRIVATE / "loans_clean.parquet")
    lg = {u: g for u, g in loans[loans.funded].groupby("user_id")}
    pp = pd.read_parquet(PRIVATE / "periods_all_history.parquet").drop_duplicates()
    for col in [
        "user_id",
        "serial_id",
        "current_term",
        "is_repaid_period",
        "loan_status_code_period",
    ]:
        pp[col] = pd.to_numeric(pp[col], errors="coerce")
    bad = pp.groupby(["user_id", "serial_id", "current_term"]).size()
    bad = bad[bad.gt(1)].index
    pp = pp[~pd.MultiIndex.from_frame(pp[["user_id", "serial_id", "current_term"]]).isin(bad)]
    for col in ["due_date_period", "repaid_time_period"]:
        pp[col] = pd.to_datetime(pp[col], errors="coerce", format="mixed")
    pp = pp.merge(
        loans[["user_id", "serial_id", "remit_time"]],
        on=["user_id", "serial_id"],
        validate="many_to_one",
    )
    pp["paid_at"] = pp.repaid_time_period.where(
        (pp.is_repaid_period.eq(1) | pp.loan_status_code_period.eq(7))
        & pp.repaid_time_period.ge(pp.remit_time)
    )
    pg = {u: g for u, g in pp.groupby("user_id")}

    def state(uid, serial, t):
        a = lg.get(uid)
        if a is None:
            return "提单时已无在途"
        b = a[
            a.serial_id.ne(serial) & a.fund_s.lt(t) & (a.valid_settle.isna() | a.settle_s.gt(t))
        ]
        if not len(b):
            return "提单时已无在途"
        dt = pd.Timestamp(t, unit="s", tz="UTC").tz_convert("America/Belize").tz_localize(None)
        day = dt.normalize()
        whole_late = b.due_day.lt(day).any()
        p = pg.get(uid)
        period_late = False
        if p is not None:
            q = p[
                p.serial_id.isin(b.serial_id)
                & p.due_date_period.lt(day)
                & (p.paid_at.isna() | p.paid_at.gt(dt))
            ]
            period_late = len(q) > 0
        return (
            "提单时仍在途但已见逾期" if whole_late or period_late else "提单时仍在途且未见逾期"
        )

    applications = []
    for a in z[z.applied_3.eq(1)].itertuples():
        applications.append({"state": state(a.user_id, a.first_apply_serial, a.first_apply_s)})
    counts = pd.DataFrame(applications).state.value_counts().to_dict()
    finance = pd.read_parquet(PRIVATE / "used_orders_finance.parquet")
    finance = finance.merge(
        f[["episode_id", "open_late_periods", "open_overdue_n"]],
        on="episode_id",
        validate="many_to_one",
    )
    q = finance[
        finance.whole_mature
        & finance.repaid_amt.notna()
        & finance.valid_days.eq(3)
        & finance.eligible_offer.eq(1)
        & finance.open_n.gt(0)
        & finance.open_late_periods.eq(0)
        & finance.open_overdue_n.eq(0)
        & finance.dose.eq(0.2)
        & finance.has_amount_coupon.eq(0)
        & finance.has_repayment_coupon.eq(0)
        & finance.other_application_discount.eq(0)
        & finance.fixed_coupon.eq(0)
    ].copy()
    q["state"] = [
        state(a.user_id, a.serial_id, a.apply_time.tz_localize("America/Belize").timestamp())
        for a in q.itertuples()
    ]
    out = {
        "eligible_issue_offer_orders": len(z),
        "application_orders_3day": len(applications),
        "states_at_first_application": counts,
        "financial_by_application_state": [],
        "financial_detail": [],
        "definition": "Issue-time outstanding/non-overdue is pre-treatment eligibility. Application-time state is a later descriptive transition, not a baseline selection for coupon uplift.",
    }
    for lev, g in q.groupby("state"):
        a = g.remit_amt.sum()
        out["financial_by_application_state"].append(
            {
                "state": lev,
                "mature_orders": len(g),
                "profit_rate": float((g.repaid_amt.sum() - a) / a),
                "order_overdue_rate": float(g.loan_status_code.eq(8).mean()),
                "mean_fund_amt": float(g.remit_amt.mean()),
            }
        )
    q["maturity_band"] = pd.cut(
        q.days_past_due,
        [0, 15, 31, 61, 121, np.inf],
        labels=["到期0—14天", "到期15—30天", "到期31—60天", "到期61—120天", "到期121天以上"],
        right=False,
    ).astype(str)
    for col in ["loan_day", "apply_month", "maturity_band"]:
        for (lev, v), g in q.groupby(["state", col]):
            a = g.remit_amt.sum()
            out["financial_detail"].append(
                {
                    "state": lev,
                    "dimension": col,
                    "level": str(v),
                    "orders": len(g),
                    "profit_rate": float((g.repaid_amt.sum() - a) / a),
                    "order_overdue_rate": float(g.loan_status_code.eq(8).mean()),
                    "mean_fund_amt": float(g.remit_amt.mean()),
                    "score410_mean": float(g.score410.mean()),
                    "score410_median": float(g.score410.median()),
                    "prior_fund_n_median": float(g.prior_fund_n.median()),
                }
            )
    q[["user_id", "serial_id", "episode_id", "create_date", "apply_time", "state"]].to_parquet(
        PRIVATE / "inflight_application_state_finance.parquet", index=False, compression="zstd"
    )
    dump(W / "inflight_state_transition_results.json", out)
    mark(
        "inflight_state_transition_complete",
        eligible_offers=len(z),
        applications=len(applications),
    )


if __name__ == "__main__":
    run()
