"""Separate early response and later-first response on the same 30-day mature cohort."""

from core import *
from stats_utils import *


def run():
    f = pd.read_parquet(W / "historical_validation/private/historical_validated.parquet")
    f["anchor"] = pd.to_datetime(f.anchor)
    f = (
        f[f.qualified]
        .sort_values(["anchor", "episode_id"])
        .drop_duplicates(["study", "user_id", "latest_credit_serial"])
        .copy()
    )
    f = f[f.applied_3.notna() & f.applied_30.notna()].copy()
    f["later_first_response"] = f.applied_30 - f.applied_3
    assert f.later_first_response.isin([0, 1]).all()
    f["dose"] = f.treat
    out = {
        "comparisons": [],
        "arms": [],
        "interpretation": "Same qualified 30-day mature study cohort. Later-first response is first application D3-D29; it is not the conditional rate among day-3 nonresponders.",
    }
    for study, g in f.groupby("study"):
        for arm, gg in g.groupby("ab_group"):
            out["arms"].append(
                {
                    "study": study,
                    "arm": arm,
                    "events": len(gg),
                    "early_applications": int(gg.applied_3.sum()),
                    "later_first_applications": int(gg.later_first_response.sum()),
                    "all_30day_applications": int(gg.applied_30.sum()),
                }
            )
        for col in ["applied_3", "later_first_response", "applied_30"]:
            r = cluster_comparison(g, col, groups=(0, 1), B=4000)
            if r:
                out["comparisons"].append({"study": study, "outcome": col, **r})
    dump(W / "historical_timing_results.json", out)
    mark("historical_timing_check_complete", comparisons=len(out["comparisons"]))


if __name__ == "__main__":
    run()
