"""Freeze historical A/B-marked test lists; assignment labels alone do not prove randomization."""

from core import *
import re

schema = pd.read_parquet(PRIVATE / "historical_test_schema.parquet")
tables = [
    t
    for t in schema.table_name.unique()
    if t.startswith("no_apply_")
    or t in ["user_test_verification_0708", "high_discount_test_0708"]
]
c = connect()
frames = []
try:
    for t in tables:
        names = schema.loc[schema.table_name.eq(t), "column_name"].tolist()
        cols = [n for n in names if n not in ["tcnt", "tcnt_2"]]
        sql = (
            "SELECT "
            + ",".join('"' + n + '"' for n in cols)
            + " FROM wangchuanliang."
            + t
            + " WHERE churn_user_id IS NOT NULL AND NOT (churn_user_id = ANY(%(__excluded_user_ids)s::bigint[]))"
        )
        p = PRIVATE / ("historical_" + t + ".parquet")
        if p.exists():
            f = pd.read_parquet(p)
        else:
            # Some historical rule descriptions contain literal line breaks.
            # Native rows preserve them; splitting an aggregated JSON string does not.
            (SQLDIR / ("historical_" + t + ".sql")).write_text(sql + ";\n")
            with c.cursor() as q:
                q.execute(sql, bound_params({}))
                f = pd.DataFrame(
                    q.fetchall(), columns=[d.name for d in q.description], dtype=object
                )
            f = parquet_safe(f)
            f.to_parquet(p, index=False, compression="zstd")
        m = re.fullmatch(r"no_apply_\d{4}_(\d{4})_30pct", t)
        md = m.group(1) if m else "0708"
        f["anchor"] = pd.Timestamp("2026-" + md[:2] + "-" + md[2:])
        f["batch"] = t
        frames.append(f)
finally:
    c.rollback()
    c.close()
f = parquet_safe(pd.concat(frames, ignore_index=True, sort=False))
f["user_id"] = pd.to_numeric(f.churn_user_id).astype("int64")
f["ab_group"] = f.ab_group.astype(str).str.lower().str.strip()
f.to_parquet(PRIVATE / "historical_ab_list_rows.parquet", index=False, compression="zstd")
known = set(json.loads((PRIVATE / "source_user_ids.json").read_text()))
ids = set(f.user_id)
out = {
    "rows": len(f),
    "users": len(ids),
    "additional_source_users": len(ids - known),
    "tables": [],
}
for t, g in f.groupby("batch"):
    out["tables"].append(
        {
            "table": t,
            "rows": len(g),
            "users": g.user_id.nunique(),
            "groups": g.ab_group.value_counts().to_dict(),
            "conflicting_assignments": int(g.groupby("user_id").ab_group.nunique().gt(1).sum()),
            "source_churn_mean": float(
                pd.to_numeric(
                    g.get("churn_days", g.get("churned_days")), errors="coerce"
                ).mean()
            ),
        }
    )
dump(W / "historical_ab_overview.json", out)
mark("historical_AB_source_complete", **out)
