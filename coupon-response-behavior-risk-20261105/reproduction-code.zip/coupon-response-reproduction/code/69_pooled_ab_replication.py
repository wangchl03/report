"""Pool only the two same-policy August 30%-3day tests; retain every per-round result.
Calendar standardization and between-round difference avoid comparing significance labels.
"""

from core import *
from stats_utils import *


def weighted_cluster(g, y, B=4000):
    sizes = g.groupby(["batch", "dose"]).size()
    batch_n = g.groupby("batch").size()
    total = len(g)
    assert all(g.groupby("batch").dose.nunique().eq(2))
    g = g.copy()
    g["w"] = [batch_n[b] / total / sizes[b, d] for b, d in zip(g.batch, g.dose)]
    p = (
        g.assign(wy=g.w * g[y])
        .groupby(["user_id", "dose"])[["wy", "w"]]
        .sum()
        .unstack("dose")
        .fillna(0)
    )
    rng = np.random.default_rng(20261105)
    arrays = [(p.wy[d].to_numpy(), p.w[d].to_numpy()) for d in [0, 1]]
    rates = [float(a.sum() / n.sum()) for a, n in arrays]
    draws = []
    for i in range(0, B, 100):
        ww = rng.poisson(1, (min(B - i, 100), len(p)))
        v = []
        for a, n in arrays:
            v.append((ww @ a) / (ww @ n))
        draws.extend((v[1] - v[0]).tolist())
    return {
        "rates": rates,
        "difference": rates[1] - rates[0],
        "difference_ci95": np.quantile(draws, [0.025, 0.975]).tolist(),
        "events": len(g),
        "users": g.user_id.nunique(),
        "bootstrap_draws": B,
        "batch_weight_target": "Combined original eligible population share for each source table; same target in both arms.",
    }


def run():
    f = pd.read_parquet(PRIVATE / "expanded_ab_analysis.parquet")
    studies = ["T5_30pct_3day_vs_none_round1", "T5_30pct_3day_vs_none_round2"]
    f = f[f.study.isin(studies)].copy()
    f["dose"] = f.treat
    assert not f.duplicated("user_id").any()
    out = {
        "policy": "August two 30%-3day versus original-control tests; T5, assigned arms, same 30day maturity.",
        "raw": [],
        "calendar_standardized": [],
        "round_difference": [],
        "later_first_response": None,
        "arm_sizes": [],
    }
    for arm, g in f.groupby("ab_group"):
        out["arm_sizes"].append({"arm": arm, "events": len(g), "users": g.user_id.nunique()})
    for h in [3, 7, 15, 30]:
        y = f"applied_{h}"
        out["raw"].append({"window": h, **cluster_comparison(f, y, groups=(0, 1), B=4000)})
        out["calendar_standardized"].append({"window": h, **weighted_cluster(f, y)})
        z = (
            f.groupby(["user_id", "study", "dose"])[y]
            .agg(["sum", "count"])
            .unstack(["study", "dose"])
            .fillna(0)
        )
        arrays = []
        for st in studies:
            for d in [0, 1]:
                arrays.append(
                    (z["sum"][st, d].to_numpy(float), z["count"][st, d].to_numpy(float))
                )
        rng = np.random.default_rng(20261105)
        draws = []
        points = [a.sum() / n.sum() for a, n in arrays]
        for i in range(0, 4000, 100):
            ww = rng.poisson(1, (100, len(z)))
            v = [(ww @ a) / (ww @ n) for a, n in arrays]
            draws.extend(((v[1] - v[0]) - (v[3] - v[2])).tolist())
        out["round_difference"].append(
            {
                "window": h,
                "round1_effect": float(points[1] - points[0]),
                "round2_effect": float(points[3] - points[2]),
                "difference_of_effects": float(
                    (points[1] - points[0]) - (points[3] - points[2])
                ),
                "difference_ci95": np.quantile(draws, [0.025, 0.975]).tolist(),
            }
        )
    f["later_first_response"] = f.applied_30 - f.applied_3
    out["later_first_response"] = cluster_comparison(
        f, "later_first_response", groups=(0, 1), B=4000
    )
    dump(W / "pooled_ab_replication_results.json", out)
    mark(
        "pooled_ab_replication_complete",
        events=len(f),
        raw_3=out["raw"][0]["difference"],
        calendar_3=out["calendar_standardized"][0]["difference"],
    )


if __name__ == "__main__":
    run()
