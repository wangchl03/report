"""Pre-anchor installment history uses due/repayment clocks, not future accumulated overdue days."""

from core import *


def run():
    p = PRIVATE / "episode_analysis.parquet"
    if not p.exists() or not (PRIVATE / "periods_all_history.parquet").exists():
        raise FileNotFoundError("Missing frozen episode or installment history input")
    f = pd.read_parquet(p)
    f["anchor"] = pd.to_datetime(f.anchor)
    pp = pd.read_parquet(PRIVATE / "periods_all_history.parquet")
    before = len(pp)
    pp = pp.drop_duplicates()
    for col in [
        "user_id",
        "serial_id",
        "current_term",
        "is_repaid_period",
        "loan_status_code_period",
        "overdue_days_period",
    ]:
        pp[col] = pd.to_numeric(pp[col], errors="coerce")
    for col in ["due_date_period", "repaid_time_period"]:
        pp[col] = pd.to_datetime(pp[col], errors="coerce", format="mixed")
    bad = pp.groupby(["user_id", "serial_id", "current_term"]).size()
    bad = bad[bad > 1].index
    pp = pp[
        ~pd.MultiIndex.from_frame(pp[["user_id", "serial_id", "current_term"]]).isin(bad)
    ].copy()
    loans = pd.read_parquet(PRIVATE / "loans_clean.parquet")
    pp = pp.merge(
        loans[["user_id", "serial_id", "remit_time", "valid_settle", "funded"]],
        on=["user_id", "serial_id"],
        how="left",
        validate="many_to_one",
    )
    pp["period_paid_time"] = pp.repaid_time_period.where(
        (pp.is_repaid_period.eq(1) | pp.loan_status_code_period.eq(7))
        & pp.repaid_time_period.ge(pp.remit_time)
    )
    pp["period_late_paid"] = pp.period_paid_time.dt.normalize().gt(pp.due_date_period)
    groups = {uid: g for uid, g in pp[pp.funded.eq(True)].groupby("user_id", sort=False)}
    rows = []
    for uid, aa in f.groupby("user_id", sort=False):
        g = groups.get(uid)
        if g is None:
            for a in aa.itertuples():
                rows.append(
                    {
                        "episode_id": a.episode_id,
                        "prior_observed_due_periods": 0,
                        "prior_late_periods_known": 0,
                        "open_late_periods": 0,
                        "prior_period_late_fraction": np.nan,
                    }
                )
            continue
        for a in aa.itertuples():
            past = g[g.remit_time < a.anchor]
            due = past[past.due_date_period < a.anchor]
            late_known = due[(due.period_paid_time <= a.anchor) & due.period_late_paid]
            whole_open = due[due.valid_settle.isna() | (due.valid_settle > a.anchor)]
            active = whole_open[
                whole_open.period_paid_time.isna() | (whole_open.period_paid_time > a.anchor)
            ]
            # Count known historical late periods and currently late periods separately; no future state-8 feature.
            n = len(due)
            late_n = len(late_known) + len(active)
            rows.append(
                {
                    "episode_id": a.episode_id,
                    "prior_observed_due_periods": n,
                    "prior_late_periods_known": len(late_known),
                    "open_late_periods": len(active),
                    "prior_period_late_fraction": late_n / n if n else np.nan,
                }
            )
    cols = [
        "prior_observed_due_periods",
        "prior_late_periods_known",
        "open_late_periods",
        "prior_period_late_fraction",
    ]
    f = f.drop(columns=[c for c in cols if c in f]).merge(
        pd.DataFrame(rows), on="episode_id", validate="one_to_one"
    )
    import importlib.util

    spec = importlib.util.spec_from_file_location(
        "_cycle_extensions", W / "21_customer_cycle_extensions.py"
    )
    cm = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(cm)
    f = cm.extend(f, loans)
    f.to_parquet(p, index=False, compression="zstd")
    dump(
        W / "period_feature_audit.json",
        {
            "source_rows": before,
            "exact_duplicates": before - len(pp),
            "conflicting_period_keys": len(bad),
            "baseline_episodes": len(f),
            "current_late_period_episodes": int(f.open_late_periods.gt(0).sum()),
            "t7_late_period_inconsistencies": int(
                (f.t7_no_open.eq(1) & f.open_late_periods.gt(0)).sum()
            ),
            "future_status8_not_used_in_baseline": True,
        },
    )
    mark(
        "period_features_complete",
        episodes=len(f),
        late_period_episodes=int(f.open_late_periods.gt(0).sum()),
    )


if __name__ == "__main__":
    run()
