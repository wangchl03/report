"""Predefined exposure-definition checks; never relabel recipients by future redemption."""

from analysis_contract import *


def run():
    f = pd.read_parquet(PRIVATE / "episode_analysis.parquet")
    f["anchor"] = pd.to_datetime(f.anchor)
    f, co = cohorts_with_offer_grain(f)
    out = {
        "rates": [],
        "coupon_policy_labels": [],
        "actual_use_dose_check": [],
        "interpretation": "Descriptive checks retain first selected offer contact. Restrictions do not replace it with a later or more favorable contact.",
    }
    for name in ["main_offer_simple", "extension_offer_simple"]:
        z = f[co[name] & f.dose.isin([0.2, 0.3, 0.4])].copy()
        known = (
            z.target_coupon_ids.fillna("")
            .str.split(",")
            .map(lambda ids: bool(ids) and all(x in ["119", "124", "157"] for x in ids))
        )
        firstuser = z.sort_values(["anchor", "episode_id"]).drop_duplicates("user_id").index
        masks = {
            "主口径": pd.Series(True, index=z.index),
            "仅配置可核对的三天券": known,
            "发券日无其他仍有效券": z.prior_coupon_still_valid.eq(0),
            "当日仅一张目标券": z.target_coupon_rows.eq(1),
            "本研究内每人仅首笔获额": z.index.isin(firstuser),
        }
        for label, mask in masks.items():
            for dose, g in z[mask].groupby("dose"):
                out["rates"].append(
                    rm.summarize(g, {"cohort": name, "restriction": label, "dose": dose})
                )
        for (ids, dose), g in z.groupby(["target_coupon_ids", "dose"]):
            out["coupon_policy_labels"].append(
                {
                    "cohort": name,
                    "coupon_ids": ids,
                    "dose": dose,
                    "events": len(g),
                    "y_3": int(g.applied_3.sum()),
                    "rate_3": float(g.applied_3.mean()),
                }
            )
    u = pd.read_parquet(PRIVATE / "used_orders_finance.parquet")
    out["used_order_time_quality"] = {
        "used_orders": len(u),
        "application_before_issue_date": int(
            u.apply_time.dt.normalize().lt(u.create_date).sum()
        ),
        "application_after_expiry_date": int(u.use_after_expiry.sum()),
    }
    for (dose, actual), g in u[u.valid_days.eq(3)].groupby(
        ["dose", "discount_pct"], dropna=False
    ):
        out["actual_use_dose_check"].append(
            {
                "assigned_policy_dose": dose,
                "actual_normalized_discount": actual,
                "used_orders": len(g),
            }
        )
    dump(W / "exposure_definition_sensitivity_results.json", out)
    mark("exposure_definition_checks_complete", checks=len(out["rates"]))


if __name__ == "__main__":
    run()
