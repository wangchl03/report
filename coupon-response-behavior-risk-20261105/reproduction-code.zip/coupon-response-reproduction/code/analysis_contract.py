"""Analysis grains fixed before selecting any future response or redemption."""

from core import *
import importlib.util

spec = importlib.util.spec_from_file_location("_rates_contract", W / "11_rates.py")
rm = importlib.util.module_from_spec(spec)
spec.loader.exec_module(rm)


def cohorts_with_offer_grain(f):
    f, co = rm.define_cohorts(f)
    for base, out in [
        ("main_all_strategy", "main_offer_all"),
        ("extension_all_strategy", "extension_offer_all"),
    ]:
        z = f[co[base]].sort_values(["anchor", "episode_id"])
        ix = z.drop_duplicates(["user_id", "latest_credit_serial"], keep="first").index
        mask = pd.Series(False, index=f.index)
        mask.loc[ix] = True
        co[out] = mask
        # First exposure is selected before restricting a simultaneous strategy.
        # A later discount-only contact must not replace an earlier combined offer.
        co[out.replace("_all", "_simple")] = mask & (f.simple_discount | f.no_coupon_at_anchor)
    for name in [
        "main_simple",
        "extension_simple",
        "main_offer_simple",
        "extension_offer_simple",
    ]:
        co[name + "_stable15"] = co[name] & f.churn_days.ge(15)
    return f, co
