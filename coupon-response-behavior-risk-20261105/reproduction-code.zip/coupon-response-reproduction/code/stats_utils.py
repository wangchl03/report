from core import *
from scipy.stats import norm


def rate(y, n):
    return float(y / n) if n else None


def wilson(y, n):
    if not n:
        return [None, None]
    z = norm.ppf(0.975)
    p = y / n
    den = 1 + z * z / n
    mid = (p + z * z / (2 * n)) / den
    h = z * np.sqrt(p * (1 - p) / n + z * z / (4 * n * n)) / den
    return [max(0.0, mid - h), min(1.0, mid + h)]


def cluster_comparison(
    frame, y_col, group_col="dose", groups=(0.2, 0.3), B=2000, seed=20261105
):
    """Poisson cluster bootstrap; the same user weight is shared across treatments and repeated contacts."""
    f = frame[frame[group_col].isin(groups) & frame[y_col].notna()].copy()
    if not len(f):
        return None
    f["n"] = 1
    p = f.groupby(["user_id", group_col])[[y_col, "n"]].sum().unstack(group_col).fillna(0)
    arrays = []
    points = []
    for g in groups:
        if g not in p[y_col]:
            return None
        a = p[y_col][g].to_numpy(float)
        n = p["n"][g].to_numpy(float)
        arrays.append((a, n))
        points.append(float(a.sum() / n.sum()))
    rng = np.random.default_rng(seed)
    draws = []
    for off in range(0, B, 100):
        ww = rng.poisson(1, size=(min(100, B - off), len(p)))
        vals = []
        for yy, nn in arrays:
            den = ww @ nn
            vals.append(np.divide(ww @ yy, den, out=np.full(len(den), np.nan), where=den > 0))
        draws.extend((vals[1] - vals[0]).tolist())
    return {
        "groups": list(groups),
        "rates": points,
        "difference": points[1] - points[0],
        "difference_ci95": np.nanquantile(draws, [0.025, 0.975]).tolist(),
        "users": len(p),
        "events": len(f),
        "bootstrap_draws": B,
        "interpretation": "Observed association with user-clustered uncertainty; not a randomized incremental effect.",
    }


def financial_bootstrap(frame, B=2000, seed=20261105):
    f = frame.groupby("user_id")[["remit_amt", "repaid_amt", "overdue"]].agg(
        {"remit_amt": "sum", "repaid_amt": "sum", "overdue": "sum"}
    )
    f["n"] = frame.groupby("user_id").size()
    rng = np.random.default_rng(seed)
    res = []
    yy = (f.repaid_amt - f.remit_amt).to_numpy(float)
    amt = f.remit_amt.to_numpy(float)
    od = f.overdue.to_numpy(float)
    n = f.n.to_numpy(float)
    for off in range(0, B, 100):
        ww = rng.poisson(1, (min(100, B - off), len(f)))
        den = ww @ amt
        nn = ww @ n
        pr = np.divide(ww @ yy, den, out=np.full(len(den), np.nan), where=den > 0)
        dr = np.divide(ww @ od, nn, out=np.full(len(nn), np.nan), where=nn > 0)
        res.extend(zip(pr, dr))
    r = np.asarray(res)
    return {
        "profit_ci95": np.nanquantile(r[:, 0], [0.025, 0.975]).tolist(),
        "overdue_ci95": np.nanquantile(r[:, 1], [0.025, 0.975]).tolist(),
        "bootstrap_users": len(f),
        "bootstrap_draws": B,
    }


def smd(x, y):
    x = np.asarray(x, float)
    y = np.asarray(y, float)
    x = x[np.isfinite(x)]
    y = y[np.isfinite(y)]
    if len(x) < 2 or len(y) < 2:
        return None
    sd = np.sqrt((np.var(x, ddof=1) + np.var(y, ddof=1)) / 2)
    return float((np.mean(x) - np.mean(y)) / sd) if sd else 0.0
