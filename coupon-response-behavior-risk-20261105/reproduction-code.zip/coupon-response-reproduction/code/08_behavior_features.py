"""Align two independently measured behavior streams; union only binary user/day flags."""

from core import *

METRICS = [
    "app_start",
    "loan_entry",
    "submit",
    "amount",
    "term",
    "plan",
    "contract",
    "coupon_open",
    "coupon_confirm",
    "coupon_page",
]
END = pd.Timestamp("2026-11-04")
DAY = 86400.0


def run():
    required = [
        "behavior_user_ids.json",
        "episode_features.parquet",
        "behavior_new_daily.parquet",
        "behavior_legacy_daily.parquet",
        "behavior_new_prestart_history.parquet",
        "behavior_legacy_prestart_history.parquet",
    ]
    missing = [name for name in required if not (PRIVATE / name).exists()]
    if missing:
        raise FileNotFoundError("Missing frozen behavior inputs: " + ", ".join(missing))
    queried = set(json.loads((PRIVATE / "behavior_user_ids.json").read_text()))
    histories = []
    for source in ["new", "legacy"]:
        h = pd.read_parquet(PRIVATE / f"behavior_{source}_prestart_history.parquet")
        h["last_active_time"] = pd.to_datetime(h.last_active_time, errors="coerce")
        histories.append(h[["user_id", "last_active_time"]])
    old_last = pd.concat(histories).groupby("user_id").last_active_time.max().to_dict()
    streams = {}
    audit = {}
    for source in ["new", "legacy"]:
        f = pd.read_parquet(PRIVATE / f"behavior_{source}_daily.parquet")
        f["d"] = pd.to_datetime(f.d)
        f["user_id"] = pd.to_numeric(f.user_id).astype("int64")
        for c in f.columns:
            if c not in ["d", "user_id"]:
                f[c] = pd.to_numeric(f[c], errors="coerce")
        assert not f.duplicated(["user_id", "d"]).any()
        audit[source] = {
            "user_days": len(f),
            "users": f.user_id.nunique(),
            "logs": int(f.logs.sum()),
            "days": f.d.nunique(),
            "date_mismatch_logs": int(f.date_mismatch_n.sum()),
        }
        if "epoch_mismatch_n" in f:
            audit[source]["epoch_mismatch_logs"] = int(f.epoch_mismatch_n.sum())
        if "device_clock_far_n" in f:
            audit[source]["device_clock_far_logs"] = int(f.device_clock_far_n.sum())
        f = f.set_index(["user_id", "d"])
        streams[source] = f
    union = streams["new"].index.union(streams["legacy"].index)
    out = pd.DataFrame(index=union)
    for source, f in streams.items():
        for m in ["active"] + METRICS:
            count = f.logs if m == "active" else f[m + "_n"]
            epoch = f.first_active_epoch if m == "active" else f[m + "_epoch"]
            out[source + "_" + m] = (count > 0).reindex(union, fill_value=False).astype("int8")
            out[source + "_" + m + "_epoch"] = epoch.reindex(union)
    for m in ["active"] + METRICS:
        out[m] = out["new_" + m] | out["legacy_" + m]
        out[m + "_epoch"] = out[["new_" + m + "_epoch", "legacy_" + m + "_epoch"]].min(
            axis=1, skipna=True
        )
    out = out.reset_index().sort_values(["user_id", "d"])
    out.to_parquet(PRIVATE / "behavior_combined_daily.parquet", index=False, compression="zstd")
    audit["union_user_days"] = len(out)
    audit["both_source_active_days"] = int((out.new_active & out.legacy_active).sum())
    audit["global_day_source_coverage"] = (
        out.groupby("d")[["new_active", "legacy_active", "active"]]
        .sum()
        .reset_index()
        .to_dict("records")
    )
    anchors = pd.read_parquet(PRIVATE / "episode_features.parquet")
    anchors["anchor"] = pd.to_datetime(anchors.anchor)
    anchors = apply_eligibility_contract(anchors)
    metric_names = ["active"] + METRICS
    byuser = {}
    for uid, g in out.groupby("user_id", sort=False):
        days = g.d.to_numpy(dtype="datetime64[D]").astype("int64")
        vals = g[metric_names].to_numpy(dtype="int16")
        prefix = np.vstack(
            [
                np.zeros((1, len(metric_names)), dtype="int32"),
                np.cumsum(vals, axis=0, dtype="int32"),
            ]
        )
        epochs = g[[m + "_epoch" for m in metric_names]].to_numpy(dtype="float64")
        byuser[uid] = (days, vals, prefix, epochs)
    rows = []
    start_day = np.datetime64("2026-05-18", "D").astype("int64")
    empty = (
        np.array([], dtype="int64"),
        np.zeros((0, len(metric_names)), dtype="int16"),
        np.zeros((1, len(metric_names)), dtype="int32"),
        np.zeros((0, len(metric_names))),
    )
    for a in anchors.itertuples():
        days, vals, prefix, epochs = byuser.get(a.user_id, empty)
        ad = a.anchor.to_datetime64().astype("datetime64[D]").astype("int64")
        ix = np.searchsorted(days, ad)
        r = {"episode_id": a.episode_id}
        seen = []
        if ix:
            seen.append(int(days[ix - 1]))
        old = old_last.get(a.user_id, pd.NaT)
        if pd.notna(old):
            seen.append(int(np.datetime64(old, "D").astype("int64")))
        r["behavior_user_extracted"] = int(a.user_id in queried)
        r["days_since_last_active"] = int(ad - max(seen)) if seen else np.nan
        r["no_record_in_available_history"] = int(not seen) if a.user_id in queried else np.nan
        for n in [7, 14, 30]:
            complete = a.user_id in queried and ad - n >= start_day
            r[f"pre{n}_complete"] = int(complete)
            counts = prefix[ix] - prefix[np.searchsorted(days, ad - n)]
            for m, value in zip(metric_names, counts):
                r[f"pre{n}_{m}_days"] = int(value) if complete else np.nan
        for d in [3, 7, 15, 30]:
            if not a.__getattribute__(f"observed_{d}") or a.user_id not in queried:
                for m in metric_names:
                    r[f"post{d}_{m}_days"] = np.nan
                    r[f"post{d}_{m}_before_app_days"] = np.nan
                continue
            end = np.searchsorted(days, ad + d)
            counts = prefix[end] - prefix[ix]
            cutoff = a.first_apply_s if np.isfinite(a.first_apply_s) else np.inf
            before = np.sum((vals[ix:end] > 0) & (epochs[ix:end] < cutoff), axis=0)
            for j, m in enumerate(metric_names):
                r[f"post{d}_{m}_days"] = int(counts[j])
                r[f"post{d}_{m}_before_app_days"] = int(before[j])
        rows.append(r)
        if len(rows) % 20000 == 0:
            mark("behavior_feature_progress", episodes=len(rows))
    enriched = anchors.merge(pd.DataFrame(rows), on="episode_id", validate="one_to_one")
    enriched.to_parquet(PRIVATE / "episode_analysis.parquet", index=False, compression="zstd")
    dump(
        W / "eligibility_audit.json",
        {
            "all_contact_events": len(enriched),
            "qualified_credit_contacts": int(enriched.eligible_offer.sum()),
            "latest_result_not_passed": int(enriched.latest_credit_pass.ne(1).sum()),
            "latest_recycle1_contacts": int(enriched.latest_recycle.eq(1).sum()),
            "qualified_previously_applied_credit_contacts": int(
                (
                    enriched.eligible_offer.eq(1) & enriched.latest_credit_already_applied.eq(1)
                ).sum()
            ),
            "qualified_zero_missing_credit_amount_contacts": int(
                (enriched.eligible_offer.eq(1) & enriched.positive_credit_amount.ne(1)).sum()
            ),
            "history_unknown_contacts": int(enriched.history_state_known.ne(1).sum()),
            "t7_contacts": int(enriched.t7_no_open.sum()),
            "already_applied_credit_not_excluded": True,
        },
    )
    dump(W / "behavior_quality_audit.json", audit)
    mark(
        "behavior_features_complete",
        episodes=len(enriched),
        union_user_days=len(out),
        overlap=audit["both_source_active_days"],
    )


if __name__ == "__main__":
    run()
