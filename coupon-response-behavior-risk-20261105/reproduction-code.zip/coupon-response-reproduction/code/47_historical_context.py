"""Independent historical A/B context, with its own private namespace and as-of reconstruction."""

from core import *
import ast, importlib.util

H = W / "historical_validation"
HP = H / "private"
HP.mkdir(parents=True, exist_ok=True)


def run(offline=False):
    a = pd.read_parquet(PRIVATE / "historical_ab_list_rows.parquet")
    a["anchor"] = pd.to_datetime(a.anchor)
    if "churn_days" in a:
        a = a.rename(columns={"churn_days": "source_churn_days"})
    bad = a.groupby(["batch", "user_id"]).ab_group.nunique()
    bad = bad[bad > 1].index
    a = (
        a[~pd.MultiIndex.from_frame(a[["batch", "user_id"]]).isin(bad)]
        .drop_duplicates(["batch", "user_id"])
        .copy()
    )
    users = sorted(set(a.user_id))
    old = set(json.loads((PRIVATE / "source_user_ids.json").read_text()))
    extra = sorted(set(users) - old)
    known_behavior = set(json.loads((PRIVATE / "behavior_user_ids.json").read_text()))
    extra_behavior = sorted(set(users) - known_behavior)
    if not offline:
        c = connect()
        try:
            with c.cursor() as q:
                q.execute(
                    "SET application_name='coupon_response_independent_historical_context'"
                )
                q.execute("SET statement_timeout=1800000")
            for name in [
                "loan_histories",
                "credit_histories",
                "risk_score_histories",
                "all_issue_histories",
            ]:
                sql = (SQLDIR / (name + ".sql")).read_text()
                more = (
                    query_large(
                        c,
                        sql,
                        {"users": extra, "end": "2026-11-04"},
                        "historical_extra_" + name,
                        buckets=16,
                    )
                    if extra
                    else pd.DataFrame()
                )
                base = pd.read_parquet(PRIVATE / (name + ".parquet"))
                base = base[base.user_id.isin(users)]
                full = parquet_safe(
                    pd.concat([base, more], ignore_index=True)
                ).drop_duplicates()
                full.to_parquet(HP / (name + ".parquet"), index=False, compression="zstd")
            # Extract only missing behavior users. Existing full-day sources are reused.
            known = set(json.loads((PRIVATE / "behavior_user_ids.json").read_text()))
            extra_behavior = sorted(set(users) - known)
            module = ast.parse((W / "06_behavior_sources.py").read_text())
            nodes = []
            for node in module.body:
                if isinstance(node, ast.Assign) and any(
                    isinstance(t, ast.Name) and t.id in ["new_flags", "legacy_flags"]
                    for t in node.targets
                ):
                    nodes.append(node)
                if isinstance(node, ast.FunctionDef) and node.name == "make_sql":
                    nodes.append(node)
            ns = {}
            exec(compile(ast.Module(body=nodes, type_ignores=[]), "behavior_defs", "exec"), ns)
            for source in ["new", "legacy"]:
                base = pd.read_parquet(PRIVATE / f"behavior_{source}_daily.parquet")
                base = base[base.user_id.isin(users)]
                more = (
                    query_large(
                        c,
                        ns["make_sql"](source),
                        {"users": extra_behavior, "start": "2026-06-24", "end": "2026-10-19"},
                        "historical_extra_behavior_" + source,
                        buckets=16,
                    )
                    if extra_behavior
                    else pd.DataFrame()
                )
                z = parquet_safe(pd.concat([base, more], ignore_index=True)).drop_duplicates()
                assert not z.duplicated(["user_id", "d"]).any()
                z.to_parquet(
                    HP / f"behavior_{source}_daily.parquet", index=False, compression="zstd"
                )
        finally:
            c.rollback()
            c.close()
    # As-of histories and outcome labels reuse the same audited reconstruction implementation.
    keep = [
        "user_id",
        "anchor",
        "batch",
        "ab_group",
        "source_churn_days",
        "churned_days",
        "utilization_type",
        "user_type",
        "interest_type",
    ]
    a = a[[v for v in keep if v in a]].copy()
    a["user_id"] = a.user_id.astype("int64")
    a = a.sort_values(["user_id", "anchor", "batch"]).reset_index(drop=True)
    a["episode_id"] = np.arange(1, len(a) + 1)
    a["in_recall"] = 1
    a["nominal_discount"] = np.nan
    a["coupon_rows"] = 0
    a["is_target_send"] = 0
    a["valid_days"] = np.nan
    a["has_amount_coupon"] = 0
    a["has_repayment_coupon"] = 0
    a["other_application_discount"] = 0
    a["fixed_coupon"] = 0
    a.to_parquet(HP / "anchors_unfeatured.parquet", index=False, compression="zstd")
    spec = importlib.util.spec_from_file_location("_hist_features", W / "07_features.py")
    m = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(m)
    m.PRIVATE = HP
    m.W = H
    m.run()
    # Daily behavior baseline only needs a complete 14-day window; unknown older
    # last-active history is not used to compare these A/B cohorts.
    daily = {}
    for source in ["new", "legacy"]:
        x = pd.read_parquet(HP / f"behavior_{source}_daily.parquet")
        x["d"] = pd.to_datetime(x.d)
        daily[source] = x.set_index(["user_id", "d"])
    f = pd.read_parquet(HP / "episode_features.parquet")
    f["anchor"] = pd.to_datetime(f.anchor)
    for days in [7, 14]:
        for source in ["new", "legacy"]:
            for metric, field in [("active", "logs"), ("loan_entry", "loan_entry_n")]:
                counts = np.zeros(len(f), int)
                for rd in range(-days, 0):
                    key = pd.MultiIndex.from_arrays(
                        [f.user_id, (f.anchor + pd.Timedelta(days=rd))], names=["user_id", "d"]
                    )
                    counts += (
                        pd.to_numeric(daily[source][field].reindex(key), errors="coerce")
                        .fillna(0)
                        .gt(0)
                        .to_numpy(int)
                    )
                f[f"pre{days}_{source}_{metric}_days"] = counts
    f.to_parquet(HP / "historical_analysis.parquet", index=False, compression="zstd")
    dump(
        W / "historical_context_audit.json",
        {
            "events": len(f),
            "users": len(users),
            "additional_source_users": len(extra),
            "additional_behavior_users": len(extra_behavior),
            "behavior_window_start": "2026-06-24",
            "earliest_anchor": "2026-07-08",
            "baseline_before_anchor": True,
            "conflicting_assignments_quarantined": len(bad),
        },
    )
    mark(
        "historical_context_complete",
        events=len(f),
        extra_users=len(extra),
        extra_behavior_users=len(extra_behavior),
    )


if __name__ == "__main__":
    import os

    run(offline=os.environ.get("RECALL_OFFLINE") == "1")
