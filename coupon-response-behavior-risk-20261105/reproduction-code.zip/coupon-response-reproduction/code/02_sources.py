from core import *

END = "2026-11-04"
c = connect()
audit = {}
try:
    with c.cursor() as q:
        q.execute("SET application_name='coupon_response_issued_and_history_readonly'")
    target_ids = [119, 124, 141, 153, 157, 160, 163, 164, 166]
    sends = query(
        c,
        """SELECT user_id,serial_id,coupon_id,TRIM(coupon_no) AS coupon_no,
        type,amount,real_use_amount,used_date,create_date,expire_date
        FROM wangchuanliang.coupon_user_copy
        WHERE user_id IS NOT NULL AND NOT (user_id = ANY(%(__excluded_user_ids)s::bigint[])) AND type=3
          AND coupon_id=ANY(%(ids)s) AND create_date>=DATE '2026-06-01'
          AND create_date<%(end)s::date""",
        {"ids": target_ids, "end": END},
        "target_coupon_issues",
    )
    cohort = pd.read_parquet(PRIVATE / "recall_batch_features.parquet")
    users = sorted(set(map(int, sends.user_id)) | set(map(int, cohort.churn_user_id)))
    audit["source_users"] = len(users)
    dump(PRIVATE / "source_user_ids.json", users)
    p = {"users": users, "end": END}
    sql = """SELECT user_id,serial_id,coupon_id,TRIM(coupon_no) AS coupon_no,
        type,amount,real_use_amount,used_date,create_date,expire_date
        FROM wangchuanliang.coupon_user_copy
        WHERE user_id IN(SELECT unnest(%(users)s::bigint[]))
          AND create_date>=DATE '2026-05-01' AND create_date<%(end)s::date"""
    other = query_large(c, sql, p, "all_issue_histories")
    sql = """SELECT user_id,serial_id,reg_date,loan_day,product_no,loan_type,
        apply_unix,apply_time,apply_date,apply_amt,
        remit_unix,remit_time,remit_date,remit_amt,is_remit,
        due_unix,due_time,due_date,repaid_time,repaid_date,is_repaid,repaid_amt,
        pre_amt,post_amt,total_term,overdue_days,loan_status_code,
        apply_rnb,remit_succ_rnb,loan_coupon_amt,repaid_coupon_amt,discount_amount
        FROM wangchuanliang.order_loan_f_v2_copy
        WHERE user_id IN(SELECT unnest(%(users)s::bigint[]))
          AND apply_time>=TIMESTAMP '2000-01-01' AND apply_time<%(end)s::timestamp"""
    loans = query_large(c, sql, p, "loan_histories")
    sql = """WITH r AS (
        SELECT serial_id,MIN(recycle_type) AS recycle_type,
            COUNT(DISTINCT recycle_type) AS recycle_versions
        FROM wangchuanliang.side_recycle_type_copy GROUP BY serial_id
    )
    SELECT v.user_id,v.serial_id,v.vir_unix,v.vir_date,v.vir_version,v.vir_rnb,
        v.is_pass1,v.is_can_apply,v.loan_type_code,v.max_credit_apply_amt,
        v.total_term,v.risk_product,r.recycle_type,r.recycle_versions
    FROM wangchuanliang.order_vir_f_copy v
    LEFT JOIN r ON r.serial_id=v.serial_id
    WHERE v.user_id IN(SELECT unnest(%(users)s::bigint[]))
      AND v.vir_date>=DATE '2025-01-01' AND v.vir_date<%(end)s::date
      AND v.vir_unix>0"""
    offers = query_large(c, sql, p, "credit_histories")
    sql = """SELECT user_id,serial_id,
        kabybxgboost363dpd7cre AS score363,
        kabybxgboost405apd7crecyc AS score405,
        kabybmerge410fpd7cre AS score410,
        kabybmerge410fpd7cyc AS score410cyc
        FROM wangchuanliang.model_result_copy
        WHERE user_id IN(SELECT unnest(%(users)s::bigint[]))"""
    models = query_large(c, sql, p, "risk_score_histories")
    # Whole-order finances are extracted once; period outcomes used only as secondary labels.
    sql = """SELECT user_id,serial_id,current_term,total_term,
        due_date_period,due_time_period,repaid_time_period,is_repaid_period,
        overdue_days_period,loan_status_code_period,apply_amt_period,remit_amt_period,
        repaid_amt_period,expect_repay_amt_period
        FROM wangchuanliang.repayment_plan_v2_copy
        WHERE user_id IN(SELECT unnest(%(users)s::bigint[]))
          AND apply_date>=DATE '2026-06-01' AND apply_date<%(end)s::date
          AND is_remit=1 AND remit_amt>0"""
    periods = query_large(c, sql, p, "period_outcomes")
    audit.update(
        {
            "coupon_issues": len(sends),
            "all_coupon_rows": len(other),
            "loans": len(loans),
            "offers": len(offers),
            "models": len(models),
            "periods": len(periods),
            "complete_day_upper": END,
        }
    )
finally:
    c.rollback()
    c.close()
dump(W / "source_extraction_audit.json", audit)
mark("source_extraction_complete", **audit)
