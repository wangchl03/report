-- Read-only; America/Belize; bound parameters supplied by the extraction program.
WITH arr AS
    (SELECT %(users)s::bigint[] AS users, %(serials)s::bigint[] AS serials, %(epochs)s::double precision[] AS epochs), ix AS
    (SELECT GENERATE_SUBSCRIPTS(users, 1) AS i
     FROM arr),
     anchors AS
    (SELECT a.users[x.i] AS user_id,a.serials[x.i] AS serial_id,
            TO_TIMESTAMP(a.epochs[x.i]) AT TIME ZONE 'AMERICA/BELIZE' AS app_time
     FROM arr a
     CROSS JOIN ix x),
     loan AS
    (SELECT o.*,
            CASE
                WHEN (o.is_repaid=1
                      OR o.loan_status_code=7)
                     AND o.repaid_time>=o.remit_time THEN o.repaid_time
            END AS settled_at
     FROM wangchuanliang.order_loan_f_v2_copy o
     WHERE o.user_id=ANY(%(unique_users)s::bigint[])),
     open_loan AS
    (SELECT a.user_id,a.serial_id AS target_serial_id,a.app_time, o.serial_id AS old_serial_id,
            o.due_date,o.remit_time AS old_remit_time
     FROM anchors a
     JOIN loan o ON o.user_id=a.user_id
     AND o.serial_id<>a.serial_id
     AND o.is_remit=1
     AND o.remit_amt>0
     AND o.remit_time>=o.apply_time
     AND o.remit_time<a.app_time
     AND (o.settled_at IS NULL
          OR o.settled_at>a.app_time)),
     late_period AS
    (SELECT DISTINCT o.user_id,o.target_serial_id
     FROM open_loan o
     JOIN wangchuanliang.repayment_plan_v2_copy p ON p.user_id=o.user_id
     AND p.serial_id=o.old_serial_id
     WHERE p.due_date_period<o.app_time::date
         AND NOT (COALESCE((p.is_repaid_period=1
                            OR p.loan_status_code_period=7)
                           AND p.repaid_time_period>=o.old_remit_time
                           AND p.repaid_time_period<=o.app_time, FALSE)))
SELECT a.user_id,a.serial_id,COUNT(o.old_serial_id) AS old_open_n,
       SUM(CASE WHEN o.due_date<a.app_time::date THEN 1 ELSE 0
           END) AS late_whole_n,
       MAX(CASE WHEN l.target_serial_id IS NOT NULL THEN 1 ELSE 0
           END) AS late_period_flag, MAX(n.remit_amt) AS remit_amt,MAX(n.repaid_amt) AS repaid_amt,
       MAX(n.loan_status_code) AS current_order_state
FROM anchors a
LEFT JOIN open_loan o ON o.user_id=a.user_id
AND o.target_serial_id=a.serial_id
LEFT JOIN late_period l ON l.user_id=a.user_id
AND l.target_serial_id=a.serial_id
LEFT JOIN loan n ON n.user_id=a.user_id
AND n.serial_id=a.serial_id
GROUP BY a.user_id,a.serial_id;
