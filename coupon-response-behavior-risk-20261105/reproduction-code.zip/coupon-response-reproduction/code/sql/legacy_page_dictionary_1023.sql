-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT page_name,event_type,COUNT(*) AS logs,COUNT(DISTINCT user_id) AS users,
       MIN(create_time) AS first_time,MAX(create_time) AS last_time, MIN(event_start_time) AS start_min,
       MAX(event_start_time) AS start_max, MIN(event_end_time) AS end_min,MAX(event_end_time) AS end_max
FROM wangchuanliang.event_track_record
WHERE create_date=DATE '2026-10-23'
GROUP BY page_name,event_type;
