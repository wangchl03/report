-- Read-only source SQL; bound parameters supplied by extraction program.

SELECT user_id,serial_id,coupon_id,TRIM(coupon_no) AS coupon_no, TYPE,amount,real_use_amount,
       used_date,create_date,expire_date
FROM wangchuanliang.coupon_user_copy
WHERE user_id IN
        (SELECT unnest(%(users)s::bigint[]))
    AND create_date>=DATE '2026-05-01'
    AND create_date<%(end)s::date;
