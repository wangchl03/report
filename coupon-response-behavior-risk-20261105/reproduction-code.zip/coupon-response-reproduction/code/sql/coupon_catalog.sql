-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT *
FROM wangchuanliang.coupon_cat;
