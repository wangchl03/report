-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT split_part(element_id, '_', 1) AS event_base,
       CASE
           WHEN POSITION('_' IN element_id)>0 THEN SUBSTRING(element_id
                                                             FROM POSITION('_' IN element_id)+1) ELSE ''
       END AS suffix, COUNT(*) AS EVENTS,COUNT(DISTINCT user_id) AS users,MIN(event_time) AS first_time,
       MAX(event_time) AS last_time
FROM wangchuanliang.user_behavior_track_record
WHERE event_date>=DATE '2026-10-23'
    AND event_date<DATE '2026-11-04'
    AND event_type='element_click'
    AND NOT (user_id = ANY(%(__excluded_user_ids)s::bigint[]))
    AND split_part(element_id, '_', 1) IN ('boxyvbuxjvvehiiq','osuxshhfbtlprnip','njczumqdckrtekmt',
                                           'hpbbbamiacefkwgl','vrnfgqufsxosxwgp','vcicilykcblxxksh')
GROUP BY split_part(element_id, '_', 1),
         CASE
             WHEN POSITION('_' IN element_id)>0 THEN SUBSTRING(element_id
                                                               FROM POSITION('_' IN element_id)+1) ELSE ''
         END
ORDER BY COUNT(*) DESC;
