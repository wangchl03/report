-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT user_id,serial_id,product_no,apply_time,apply_date,apply_amt, coupon_id,
       TRIM(coupon_no) AS coupon_no,real_use_amount,used_date,total_fee, product_fee_amount,discount_pct_raw,
       discount_pct,calc_status,create_date,expire_date,valid_days
FROM wangchuanliang.coupon_use_record
WHERE coupon_type=3
    AND real_use_amount>0
    AND coupon_id IN(119,124,141,153,157,160,163,164,166)
    AND create_date>=DATE '2026-06-01'
    AND create_date<DATE '2026-11-01'
    AND NOT (user_id = ANY(%(__excluded_user_ids)s::bigint[]));
