-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT "churn_user_id","score","strat","churn_days"
FROM wangchuanliang.t7recalllist_active0910
WHERE "churn_user_id" IS NOT NULL
    AND "churn_user_id"<> ALL(%(__excluded_user_ids)s::bigint[]);
