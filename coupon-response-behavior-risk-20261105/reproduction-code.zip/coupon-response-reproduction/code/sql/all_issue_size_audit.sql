-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT TYPE,COUNT(*) AS n,COUNT(DISTINCT user_id) AS users
FROM wangchuanliang.coupon_user_copy
WHERE user_id IN
        (SELECT unnest(%(users)s::bigint[]))
    AND create_date>=DATE '2026-05-01'
    AND create_date<DATE '2026-11-04'
GROUP BY TYPE;
