-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT event_type,page_id,COUNT(*) AS logs,COUNT(DISTINCT user_id) AS users
FROM wangchuanliang.user_behavior_track_record
WHERE event_date=DATE '2026-10-23'
GROUP BY event_type,page_id;
