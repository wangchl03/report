-- Read-only; America/Belize; bound parameters supplied by the extraction program.
WITH arrays AS
    (SELECT %(ids)s::bigint[] AS ids,%(users)s::bigint[] AS users,%(epochs)s::double precision[] AS epochs), ix AS
    (SELECT generate_subscripts(ids, 1) AS i
     FROM arrays),
     anchors AS
    (SELECT a.ids[x.i] AS episode_id,a.users[x.i] AS user_id,
            TO_TIMESTAMP(a.epochs[x.i]) AT TIME ZONE 'AMERICA/BELIZE' AS anchor
     FROM arrays a
     CROSS JOIN ix x),
     h AS
    (SELECT o.*,
            CASE
                WHEN (o.is_repaid=1
                      OR o.loan_status_code=7)
                     AND o.repaid_time>=o.remit_time THEN o.repaid_time
            END AS settle
     FROM wangchuanliang.order_loan_f_v2_copy o
     WHERE o.user_id=ANY(%(users)s::bigint[])
         AND o.apply_time>=TIMESTAMP '2000-01-01'),
     calc AS
    (SELECT a.episode_id,COUNT(o.serial_id) AS prior_app_n,
            SUM(CASE
                    WHEN o.is_remit=1
                         AND o.remit_amt>0
                         AND o.remit_time>=o.apply_time
                         AND o.remit_time<a.anchor THEN 1 ELSE 0
                END) AS prior_fund_n,
            SUM(CASE
                    WHEN o.is_remit=1
                         AND o.remit_amt>0
                         AND o.remit_time>=o.apply_time
                         AND o.remit_time<a.anchor
                         AND (o.settle IS NULL
                              OR o.settle>a.anchor) THEN 1 ELSE 0
                END) AS open_n,
            SUM(CASE WHEN o.apply_time>=a.anchor-INTERVAL '30 days' THEN 1 ELSE 0
                END) AS prior_apps30
     FROM anchors a
     LEFT JOIN h o ON o.user_id=a.user_id
     AND o.apply_time<a.anchor
     GROUP BY a.episode_id)
SELECT *
FROM calc;
