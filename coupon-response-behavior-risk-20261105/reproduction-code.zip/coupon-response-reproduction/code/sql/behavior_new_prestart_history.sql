-- Read-only source SQL; bound parameters supplied by extraction program.

SELECT user_id,MIN(event_time) AS first_active_time,MAX(event_time) AS last_active_time,
       COUNT(DISTINCT event_date) AS active_days,COUNT(*) AS logs
FROM wangchuanliang.user_behavior_track_record
WHERE event_date>=DATE '2025-11-01'
    AND event_date<DATE '2026-05-18'
    AND event_time>=TIMESTAMP '2025-11-01'
    AND event_time<TIMESTAMP '2026-05-18'
    AND user_id IN
        (SELECT unnest(%(users)s::bigint[]))
GROUP BY user_id;
