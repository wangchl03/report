-- Read-only source SQL; bound parameters supplied by extraction program.

SELECT user_id,serial_id, kabybxgboost363dpd7cre AS score363, kabybxgboost405apd7crecyc AS score405,
       kabybmerge410fpd7cre AS score410, kabybmerge410fpd7cyc AS score410cyc
FROM wangchuanliang.model_result_copy
WHERE user_id IN
        (SELECT unnest(%(users)s::bigint[]));
