-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT TABLE_NAME
FROM information_schema.tables
WHERE table_schema='wangchuanliang'
    AND (TABLE_NAME LIKE '%%recall%%'
         OR TABLE_NAME LIKE '%%coupon%%')
ORDER BY TABLE_NAME;
