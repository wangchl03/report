-- Read-only source SQL; bound parameters supplied by extraction program.
WITH r AS
    (SELECT serial_id,MIN(recycle_type) AS recycle_type,
            COUNT(DISTINCT recycle_type) AS recycle_versions
     FROM wangchuanliang.side_recycle_type_copy
     GROUP BY serial_id)
SELECT v.user_id,v.serial_id,v.vir_unix,v.vir_date,v.vir_version,v.vir_rnb, v.is_pass1,
       v.is_can_apply,v.loan_type_code,v.max_credit_apply_amt, v.total_term,v.risk_product,r.recycle_type,
       r.recycle_versions
FROM wangchuanliang.order_vir_f_copy v
LEFT JOIN r ON r.serial_id=v.serial_id
WHERE v.user_id IN
        (SELECT unnest(%(users)s::bigint[]))
    AND v.vir_date>=DATE '2025-01-01'
    AND v.vir_date<%(end)s::date
    AND v.vir_unix>0;
