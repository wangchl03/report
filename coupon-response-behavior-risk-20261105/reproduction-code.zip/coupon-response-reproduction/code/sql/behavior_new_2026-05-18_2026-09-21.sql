-- Read-only; America/Belize; bound parameters supplied by the extraction program.
WITH RAW AS
    (SELECT user_id,event_date AS d,event_time AS t,event_unix,event_type,page_type,element_type,
            split_part(page_id, '_', 1) AS page_base,split_part(element_id,
                                                         '_', 1) AS element_base
     FROM wangchuanliang.user_behavior_track_record
     WHERE event_date>=%(start)s::date
         AND event_date<%(end)s::date
         AND event_time>=%(start)s::timestamp
         AND event_time<%(end)s::timestamp
         AND user_id IN
             (SELECT unnest(%(users)s::bigint[])))
SELECT user_id, d, COUNT(*) AS logs,
       MIN(EXTRACT(EPOCH
                   FROM t AT TIME ZONE 'AMERICA/BELIZE')) AS first_active_epoch, MAX(EXTRACT(EPOCH
                                                                                             FROM t AT TIME ZONE 'AMERICA/BELIZE')) AS last_active_epoch,
       SUM(CASE WHEN t::date<>d THEN 1 ELSE 0
           END) AS date_mismatch_n,
       SUM(CASE
               WHEN ABS(event_unix/1000.0-EXTRACT(EPOCH
                                                  FROM t AT TIME ZONE 'AMERICA/BELIZE'))>1 THEN 1 ELSE 0
           END) AS epoch_mismatch_n, SUM(CASE WHEN (event_type='app_start') THEN 1 ELSE 0
                                         END) AS app_start_n,
       MIN(CASE
               WHEN (event_type='app_start') THEN EXTRACT(EPOCH
                                                          FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS app_start_epoch,
       SUM(CASE
               WHEN (event_type='page_view'
                     AND page_type='page_view_in'
                     AND page_base IN ('xyrsaqxpwmedzlsm',
                                       'vdecaucgiowzpoeh')) THEN 1 ELSE 0
           END) AS loan_entry_n,
       MIN(CASE
               WHEN (event_type='page_view'
                     AND page_type='page_view_in'
                     AND page_base IN ('xyrsaqxpwmedzlsm',
                                       'vdecaucgiowzpoeh')) THEN EXTRACT(EPOCH
                                                                         FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS loan_entry_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('hfmgyiwihoavrqzv',
                                          'udopwuxjursbmvcm')) THEN 1 ELSE 0
           END) AS submit_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('hfmgyiwihoavrqzv',
                                          'udopwuxjursbmvcm')) THEN EXTRACT(EPOCH
                                                                            FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS submit_epoch,
       SUM(CASE
               WHEN ((event_type='text_change'
                      AND element_type='editing'
                      AND element_base='gbyukfclsrdmxaon')
                     OR (event_type='slider_change'
                         AND element_base='jrocyutivyeqdxrx')
                     OR (event_type='element_click'
                         AND element_base IN ('xhwhgrqsxqkfwpoj',
                                              'saynozmunkdceoya', 'gwexsotywwgsvrgv'))) THEN 1 ELSE 0
           END) AS amount_n,
       MIN(CASE
               WHEN ((event_type='text_change'
                      AND element_type='editing'
                      AND element_base='gbyukfclsrdmxaon')
                     OR (event_type='slider_change'
                         AND element_base='jrocyutivyeqdxrx')
                     OR (event_type='element_click'
                         AND element_base IN ('xhwhgrqsxqkfwpoj',
                                              'saynozmunkdceoya', 'gwexsotywwgsvrgv'))) THEN EXTRACT(EPOCH
                                                                                                     FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS amount_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('zfmdsmjpuslrcchx',
                                          'denkhhpvgqgwethb', 'rdapttngylaiuvth',
                                          'gfelmnelmexljaiv')) THEN 1 ELSE 0
           END) AS term_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('zfmdsmjpuslrcchx',
                                          'denkhhpvgqgwethb', 'rdapttngylaiuvth',
                                          'gfelmnelmexljaiv')) THEN EXTRACT(EPOCH
                                                                            FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS term_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('omuwccqjaovwdwyx',
                                          'gemkzaypdtcrwdkg')) THEN 1 ELSE 0
           END) AS plan_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('omuwccqjaovwdwyx',
                                          'gemkzaypdtcrwdkg')) THEN EXTRACT(EPOCH
                                                                            FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS plan_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('oflwqlzkgvyvhltd',
                                          'gwhhjdfmvnpjaouh')) THEN 1 ELSE 0
           END) AS contract_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('oflwqlzkgvyvhltd',
                                          'gwhhjdfmvnpjaouh')) THEN EXTRACT(EPOCH
                                                                            FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS contract_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('ejknnzgmqlepvxuy',
                                          'gbjnaljcxrmlvpwo')) THEN 1 ELSE 0
           END) AS coupon_open_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('ejknnzgmqlepvxuy',
                                          'gbjnaljcxrmlvpwo')) THEN EXTRACT(EPOCH
                                                                            FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS coupon_open_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('dmadzxixvpamlgpg',
                                          'mpjlvbjrygzfqxvo')) THEN 1 ELSE 0
           END) AS coupon_confirm_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('dmadzxixvpamlgpg',
                                          'mpjlvbjrygzfqxvo')) THEN EXTRACT(EPOCH
                                                                            FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS coupon_confirm_epoch,
       SUM(CASE
               WHEN (event_type='page_view'
                     AND page_type='page_view_in'
                     AND page_base='iqsvfjcxwpqtsrbj') THEN 1 ELSE 0
           END) AS coupon_page_n,
       MIN(CASE
               WHEN (event_type='page_view'
                     AND page_type='page_view_in'
                     AND page_base='iqsvfjcxwpqtsrbj') THEN EXTRACT(EPOCH
                                                                    FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS coupon_page_epoch
FROM RAW
GROUP BY user_id,d;
