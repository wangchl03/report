-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT "churn_user_id"
FROM wangchuanliang.user_test_inactive_0710
WHERE "churn_user_id" IS NOT NULL
    AND "churn_user_id"<> ALL(%(__excluded_user_ids)s::bigint[]);
