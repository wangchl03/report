-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT "churn_user_id","ab_group","churn_days"
FROM wangchuanliang.no_apply_0821_0826_30pct
WHERE "churn_user_id" IS NOT NULL
    AND "churn_user_id"<> ALL(%(__excluded_user_ids)s::bigint[]);
