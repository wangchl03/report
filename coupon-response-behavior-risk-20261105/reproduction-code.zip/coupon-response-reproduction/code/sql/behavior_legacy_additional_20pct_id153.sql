-- Read-only source SQL; bound parameters supplied by extraction program.
WITH RAW AS
    (SELECT user_id,create_date AS d,create_time AS t,create_unix,event_type,props_id,
            event_start_time,event_end_time
     FROM wangchuanliang.event_track_record
     WHERE create_date>=%(start)s::date
         AND create_date<%(end)s::date
         AND create_time>=%(start)s::timestamp
         AND create_time<%(end)s::timestamp
         AND user_id IN
             (SELECT unnest(%(users)s::bigint[])))
SELECT user_id, d, COUNT(*) AS logs,
       MIN(EXTRACT(EPOCH
                   FROM t AT TIME ZONE 'AMERICA/BELIZE')) AS first_active_epoch, MAX(EXTRACT(EPOCH
                                                                                             FROM t AT TIME ZONE 'AMERICA/BELIZE')) AS last_active_epoch,
       SUM(CASE WHEN t::date<>d THEN 1 ELSE 0
           END) AS date_mismatch_n,
       SUM(CASE
               WHEN event_end_time>0
                    AND ABS(event_end_time/1000.0-EXTRACT(EPOCH
                                                          FROM t AT TIME ZONE 'AMERICA/BELIZE'))>86400 THEN 1 ELSE 0
           END) AS device_clock_far_n, SUM(CASE WHEN (event_type='app_start') THEN 1 ELSE 0
                                           END) AS app_start_n,
       MIN(CASE
               WHEN (event_type='app_start') THEN EXTRACT(EPOCH
                                                          FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS app_start_epoch,
       SUM(CASE
               WHEN (event_type='page_view_in'
                     AND props_id IN ('Loan_newpage',
                                      'Loan_newpage_select')) THEN 1 ELSE 0
           END) AS loan_entry_n,
       MIN(CASE
               WHEN (event_type='page_view_in'
                     AND props_id IN ('Loan_newpage',
                                      'Loan_newpage_select')) THEN EXTRACT(EPOCH
                                                                           FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS loan_entry_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND props_id IN ('Loan_newconfirm',
                                      'Loan_newconfirm_select')) THEN 1 ELSE 0
           END) AS submit_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND props_id IN ('Loan_newconfirm',
                                      'Loan_newconfirm_select')) THEN EXTRACT(EPOCH
                                                                              FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS submit_epoch,
       SUM(CASE
               WHEN (props_id IN ('amount_modification',
                                  'loan_form_loan_amount_selectionn_new',
                                  'loan_form_loan_amount_selectionn_new_select')) THEN 1 ELSE 0
           END) AS amount_n,
       MIN(CASE
               WHEN (props_id IN ('amount_modification',
                                  'loan_form_loan_amount_selectionn_new',
                                  'loan_form_loan_amount_selectionn_new_select')) THEN EXTRACT(EPOCH
                                                                                               FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS amount_epoch,
       SUM(CASE
               WHEN (props_id IN ('loan_form_term_selection_new',
                                  'loan_form_term_selection_new_select')) THEN 1 ELSE 0
           END) AS term_n,
       MIN(CASE
               WHEN (props_id IN ('loan_form_term_selection_new',
                                  'loan_form_term_selection_new_select')) THEN EXTRACT(EPOCH
                                                                                       FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS term_epoch,
       SUM(CASE
               WHEN (props_id IN ('Loan_plan_newdetails',
                                  'Loan_plan_newdetails_select')) THEN 1 ELSE 0
           END) AS plan_n,
       MIN(CASE
               WHEN (props_id IN ('Loan_plan_newdetails',
                                  'Loan_plan_newdetails_select')) THEN EXTRACT(EPOCH
                                                                               FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS plan_epoch,
       SUM(CASE
               WHEN (props_id IN ('Loan_contract_newdetails',
                                  'Loan_contract_newdetails_select')) THEN 1 ELSE 0
           END) AS contract_n,
       MIN(CASE
               WHEN (props_id IN ('Loan_contract_newdetails',
                                  'Loan_contract_newdetails_select')) THEN EXTRACT(EPOCH
                                                                                   FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS contract_epoch,
       SUM(CASE
               WHEN (props_id IN ('Order_coupons_page',
                                  'Order_coupons_page_select')) THEN 1 ELSE 0
           END) AS coupon_open_n,
       MIN(CASE
               WHEN (props_id IN ('Order_coupons_page',
                                  'Order_coupons_page_select')) THEN EXTRACT(EPOCH
                                                                             FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS coupon_open_epoch,
       SUM(CASE
               WHEN (props_id IN ('Order_coupons_confirm',
                                  'Order_coupons_confirm_select')) THEN 1 ELSE 0
           END) AS coupon_confirm_n,
       MIN(CASE
               WHEN (props_id IN ('Order_coupons_confirm',
                                  'Order_coupons_confirm_select')) THEN EXTRACT(EPOCH
                                                                                FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS coupon_confirm_epoch,
       SUM(CASE
               WHEN (props_id IN ('Order_coupons_page',
                                  'Order_coupons_page_select')) THEN 1 ELSE 0
           END) AS coupon_page_n,
       MIN(CASE
               WHEN (props_id IN ('Order_coupons_page',
                                  'Order_coupons_page_select')) THEN EXTRACT(EPOCH
                                                                             FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS coupon_page_epoch
FROM RAW
GROUP BY user_id,d;
