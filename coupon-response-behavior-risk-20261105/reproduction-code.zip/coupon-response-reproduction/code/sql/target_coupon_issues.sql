-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT user_id,serial_id,coupon_id,TRIM(coupon_no) AS coupon_no, TYPE,amount,real_use_amount,
       used_date,create_date,expire_date
FROM wangchuanliang.coupon_user_copy
WHERE user_id IS NOT NULL
    AND NOT (user_id = ANY(%(__excluded_user_ids)s::bigint[]))
    AND TYPE=3
    AND coupon_id=ANY(%(ids)s)
    AND create_date>=DATE '2026-06-01'
    AND create_date<%(end)s::date;
