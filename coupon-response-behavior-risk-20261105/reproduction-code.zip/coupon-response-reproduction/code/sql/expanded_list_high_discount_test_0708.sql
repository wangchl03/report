-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT "churn_user_id","ab_group","churned_days","interest_type"
FROM wangchuanliang.high_discount_test_0708
WHERE "churn_user_id" IS NOT NULL
    AND "churn_user_id"<> ALL(%(__excluded_user_ids)s::bigint[]);
