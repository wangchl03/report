-- Read-only source SQL; bound parameters supplied by extraction program.

SELECT user_id,serial_id,current_term,total_term, due_date_period,due_time_period,
       repaid_time_period,is_repaid_period, overdue_days_period,loan_status_code_period,apply_amt_period,
       remit_amt_period, repaid_amt_period,expect_repay_amt_period
FROM wangchuanliang.repayment_plan_v2_copy
WHERE user_id IN
        (SELECT unnest(%(users)s::bigint[]))
    AND apply_date>=DATE '2026-06-01'
    AND apply_date<%(end)s::date
    AND is_remit=1
    AND remit_amt>0;
