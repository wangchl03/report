-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT "churn_user_id","ab_group","interest_type","max_repaid_date","churned_days","reg_date","apply_rnb",
       "remit_rnb","remit_amt","als","max_over_due","overdue_cnt","overdue_term_cnt","vir_amt",
       "apply_amt","utilization_rate","last_remit_utilization_rate","high_interest_rate",
       "last_remit_product_no","last_remit_interest_type","last_remit_total_term","last_remit_overdue_days",
       "last_vir_amt","last_vir_risk_product","last_vir_total_term","active_days_cnt","last_active_date",
       "days_since_last_active","newpage_cnt","newconfirm_cnt","amount_selection_cnt","term_selection_cnt",
       "plan_newdetails_cnt","contract_newdetails_cnt","purpose_newdetails_cnt","coupons_page_cnt",
       "coupons_confirm_cnt","send_coupon_d_cnt","send_coupon_r_cnt","last_send_coupon_date",
       "days_since_last_send_coupon"
FROM wangchuanliang.high_discount_test_0708
WHERE churn_user_id IS NOT NULL
    AND NOT (churn_user_id = ANY(%(__excluded_user_ids)s::bigint[]));
