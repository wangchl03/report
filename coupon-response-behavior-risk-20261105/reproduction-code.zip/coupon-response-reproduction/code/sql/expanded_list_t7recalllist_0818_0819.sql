-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT "churn_user_id","coupon_level_2","strat","churn_days"
FROM wangchuanliang.t7recalllist_0818_0819
WHERE "churn_user_id" IS NOT NULL
    AND "churn_user_id"<> ALL(%(__excluded_user_ids)s::bigint[]);
