-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT TABLE_NAME
FROM information_schema.tables
WHERE table_schema='wangchuanliang'
    AND (TABLE_NAME LIKE 'no_apply_%%'
         OR TABLE_NAME LIKE '%%0708%%'
         OR TABLE_NAME LIKE '%%0707%%'
         OR TABLE_NAME LIKE '%%test%%')
ORDER BY TABLE_NAME;
