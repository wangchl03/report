-- Read-only source SQL; bound parameters supplied by extraction program.

SELECT user_id,MIN(create_time) AS first_active_time,MAX(create_time) AS last_active_time,
       COUNT(DISTINCT create_date) AS active_days,COUNT(*) AS logs
FROM wangchuanliang.event_track_record
WHERE create_date>=DATE '2025-11-01'
    AND create_date<DATE '2026-05-18'
    AND create_time>=TIMESTAMP '2025-11-01'
    AND create_time<TIMESTAMP '2026-05-18'
    AND user_id IN
        (SELECT unnest(%(users)s::bigint[]))
GROUP BY user_id;
