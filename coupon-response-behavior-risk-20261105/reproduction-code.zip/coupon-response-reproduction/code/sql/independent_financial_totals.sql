-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT CASE WHEN c.coupon_id IN(119,141,153,163,166) THEN 0.20 WHEN c.coupon_id IN(157,160) THEN 0.30 ELSE 0.40
       END AS dose, c.valid_days,COUNT(*) AS orders,SUM(o.remit_amt) AS funded_amt,
       SUM(o.repaid_amt) AS repaid_amt, SUM(CASE WHEN o.loan_status_code=8 THEN 1 ELSE 0
                                            END) AS overdue_orders,
       SUM(c.real_use_amount) AS coupon_used_amt
FROM wangchuanliang.coupon_use_record c
JOIN wangchuanliang.order_loan_f_v2_copy o ON o.user_id=c.user_id
AND o.serial_id=c.serial_id
WHERE c.coupon_type=3
    AND c.real_use_amount>0
    AND c.coupon_id IN(119,124,141,153,157,160,163,164,166)
    AND c.create_date>=DATE '2026-06-01'
    AND c.create_date<DATE '2026-11-01'
    AND NOT (c.user_id = ANY(%(__excluded_user_ids)s::bigint[]))
    AND o.is_remit=1
    AND o.remit_amt>0
    AND o.due_date<DATE '2026-11-04'
GROUP BY 1,c.valid_days
ORDER BY 1,c.valid_days;
