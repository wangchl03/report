-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT TABLE_NAME
FROM information_schema.tables
WHERE table_schema='wangchuanliang'
    AND (TABLE_NAME ILIKE '%%recall%%'
         OR TABLE_NAME ILIKE '%%test%%'
         OR TABLE_NAME ILIKE 'no_apply_%%')
ORDER BY TABLE_NAME;
