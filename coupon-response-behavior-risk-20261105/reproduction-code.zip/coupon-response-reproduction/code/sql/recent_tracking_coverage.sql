-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT 'new'::text AS SOURCE,event_date::text AS event_date, COUNT(*) AS ROWS,COUNT(DISTINCT user_id) AS users,
       MIN(event_time)::text AS first_time,MAX(event_time)::text AS last_time
FROM wangchuanliang.user_behavior_track_record
WHERE event_date>=DATE '2026-11-04'-2
    AND event_date<=DATE '2026-11-04'
GROUP BY event_date
UNION ALL
SELECT 'legacy'::text,create_date::text,COUNT(*),COUNT(DISTINCT user_id),MIN(create_time)::text,
       MAX(create_time)::text
FROM wangchuanliang.event_track_record
WHERE create_date>=DATE '2026-11-04'-2
    AND create_date<=DATE '2026-11-04'
GROUP BY create_date;
