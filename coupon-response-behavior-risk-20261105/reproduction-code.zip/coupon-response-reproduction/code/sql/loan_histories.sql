-- Read-only source SQL; bound parameters supplied by extraction program.

SELECT user_id,serial_id,reg_date,loan_day,product_no,loan_type, apply_unix,apply_time,apply_date,
       apply_amt, remit_unix,remit_time,remit_date,remit_amt,is_remit, due_unix,due_time,due_date,
       repaid_time,repaid_date,is_repaid,repaid_amt, pre_amt,post_amt,total_term,overdue_days,
       loan_status_code, apply_rnb,remit_succ_rnb,loan_coupon_amt,repaid_coupon_amt,discount_amount
FROM wangchuanliang.order_loan_f_v2_copy
WHERE user_id IN
        (SELECT unnest(%(users)s::bigint[]))
    AND apply_time>=TIMESTAMP '2000-01-01'
    AND apply_time<%(end)s::timestamp;
