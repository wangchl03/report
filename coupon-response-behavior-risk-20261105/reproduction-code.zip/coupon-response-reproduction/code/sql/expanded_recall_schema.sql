-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT TABLE_NAME,COLUMN_NAME,data_type,ordinal_position
FROM information_schema.columns
WHERE table_schema='wangchuanliang'
    AND TABLE_NAME=ANY(%(tables)s)
ORDER BY TABLE_NAME,ordinal_position;
