-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT coupon_id::text AS coupon_id,create_date::text AS send_date, expire_date-create_date+1 AS valid_days,
       COUNT(*) AS coupons, COUNT(DISTINCT user_id) AS users,
       SUM(CASE WHEN real_use_amount>0 THEN 1 ELSE 0
           END) AS used_coupons
FROM wangchuanliang.coupon_user_copy
WHERE TYPE=3
    AND coupon_id NOT IN (126,149)
    AND NOT (user_id = ANY(%(__excluded_user_ids)s::bigint[]))
    AND create_date>=DATE '2026-06-01'
    AND create_date<DATE '2026-11-04'
GROUP BY coupon_id,create_date,expire_date-create_date+1
ORDER BY create_date,coupon_id;
