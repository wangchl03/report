-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT MAX(apply_time) AS last_apply,MAX(remit_time) AS last_remit,MAX(repaid_time) AS last_repaid,
       SUM(CASE WHEN apply_date=DATE '2026-11-03' THEN 1 ELSE 0
           END) AS nov3_apply_n, SUM(CASE WHEN apply_date=DATE '2026-11-04' THEN 1 ELSE 0
                                     END) AS nov4_apply_n
FROM wangchuanliang.order_loan_f_v2_copy
WHERE apply_date>=DATE '2026-11-01';
