-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT "churn_user_id","coupon_level_2","score","prod_risk_level","strat","churn_days"
FROM wangchuanliang.t7recalllist_0930
WHERE "churn_user_id" IS NOT NULL
    AND "churn_user_id"<> ALL(%(__excluded_user_ids)s::bigint[]);
