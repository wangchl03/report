-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT "churn_user_id","ab_group","churn_days","utilization_type","user_type"
FROM wangchuanliang.user_test_verification_0708
WHERE "churn_user_id" IS NOT NULL
    AND "churn_user_id"<> ALL(%(__excluded_user_ids)s::bigint[]);
