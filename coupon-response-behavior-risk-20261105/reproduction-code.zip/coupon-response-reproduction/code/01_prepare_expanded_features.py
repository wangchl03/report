"""Re-use frozen point-in-time features and enrich only recall-list provenance."""

from core import *
import os


def run():
    frozen = PRIVATE / "frozen_episode_analysis_input.parquet"
    if not frozen.exists():
        import shutil

        shutil.copy2(PRIVATE / "episode_analysis.parquet", frozen)
    source = (
        frozen
        if os.environ.get("RECALL_REUSE_FROZEN_FEATURES") == "1"
        else PRIVATE / "episode_analysis.parquet"
    )
    f = pd.read_parquet(source)
    f["anchor"] = pd.to_datetime(f.anchor)
    lists = pd.read_parquet(PRIVATE / "expanded_recall_lists.parquet")
    lists["list_date"] = pd.to_datetime(lists.list_date)
    scores = pd.to_numeric(lists.score, errors="coerce").where(lambda x: x.between(0, 3000))
    lists["list_score_rank"] = scores.groupby(lists.batch).rank(pct=True, method="average")
    rows = []
    for (uid, day), g in lists[lists.list_date.notna()].groupby(["user_id", "list_date"]):
        risk = (
            sorted(set(g.prod_risk_level.dropna().astype(str)))
            if "prod_risk_level" in g
            else []
        )
        active = g.batch.str.contains("active")
        kind = (
            "mixed"
            if active.any() and (~active).any()
            else "active" if active.any() else "regular"
        )
        rows.append(
            {
                "user_id": uid,
                "anchor": day,
                "new_source_tables": "|".join(sorted(set(g.batch))),
                "new_risk_tier": "|".join(risk) if risk else None,
                "new_recall_kind": kind,
                "new_intent_rank": (
                    float(g.list_score_rank.mean())
                    if g.list_score_rank.notna().any()
                    else np.nan
                ),
            }
        )
    meta = pd.DataFrame(rows)
    f = f.merge(meta, on=["user_id", "anchor"], how="left", validate="many_to_one")
    for old, new in [
        ("recall_batches", "new_source_tables"),
        ("source_risk_level", "new_risk_tier"),
        ("recall_kind", "new_recall_kind"),
        ("intent_rank", "new_intent_rank"),
    ]:
        f[old] = f[old].where(f[old].notna(), f[new])
    f["recall_kind"] = f.recall_kind.fillna("issue_record")
    f["source_risk_level"] = f.source_risk_level.fillna("unknown")
    f["recall_batches"] = f.recall_batches.fillna(
        "actual_issue_" + f.anchor.dt.strftime("%Y%m%d")
    )
    f = f.drop(columns=list(meta.columns.difference(["user_id", "anchor"])))
    f.to_parquet(PRIVATE / "episode_analysis.parquet", index=False, compression="zstd")
    period = f.anchor.ge(pd.Timestamp("2026-06-15")) & f.anchor.lt(pd.Timestamp("2026-10-31"))
    dump(
        W / "expanded_feature_provenance.json",
        {
            "input_rows": len(f),
            "period_rows": int(period.sum()),
            "period_target_issue_rows": int((period & f.is_target_send.eq(1)).sum()),
            "point_in_time_feature_values_reused": True,
            "metadata_only_enrichment": True,
            "unlisted_issue_records_not_discarded": True,
            "original_frozen_feature_sha256": hashlib.sha256(frozen.read_bytes()).hexdigest(),
        },
    )
    mark("expanded_features_prepared", rows=len(f), period_rows=int(period.sum()))


if __name__ == "__main__":
    run()
