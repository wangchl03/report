from core import *

c = connect()
out = {}
try:
    sql = """SELECT table_name FROM information_schema.tables WHERE table_schema='wangchuanliang'
       AND (table_name LIKE '%%recall%%' OR table_name LIKE '%%coupon%%') ORDER BY table_name"""
    out["tables"] = query(c, sql, {}, "related_tables").table_name.tolist()
    sql = """SELECT page_name,event_type,COUNT(*) AS logs,COUNT(DISTINCT user_id) AS users,
       MIN(create_time) AS first_time,MAX(create_time) AS last_time,
       MIN(event_start_time) AS start_min,MAX(event_start_time) AS start_max,
       MIN(event_end_time) AS end_min,MAX(event_end_time) AS end_max
       FROM wangchuanliang.event_track_record
       WHERE create_date=DATE '2026-10-23' GROUP BY page_name,event_type"""
    legacy = query(c, sql, {}, "legacy_page_dictionary_1023")
    out["legacy_pages"] = legacy.to_dict("records")
    sql = """SELECT event_type,page_id,COUNT(*) AS logs,COUNT(DISTINCT user_id) AS users
       FROM wangchuanliang.user_behavior_track_record
       WHERE event_date=DATE '2026-10-23' GROUP BY event_type,page_id"""
    new = query(c, sql, {}, "new_page_dictionary_1023")
    out["new_page_rows"] = len(new)
    sql = """SELECT MAX(apply_time) AS last_apply,MAX(remit_time) AS last_remit,MAX(repaid_time) AS last_repaid,
       SUM(CASE WHEN apply_date=DATE '2026-11-03' THEN 1 ELSE 0 END) AS nov3_apply_n,
       SUM(CASE WHEN apply_date=DATE '2026-11-04' THEN 1 ELSE 0 END) AS nov4_apply_n
       FROM wangchuanliang.order_loan_f_v2_copy WHERE apply_date>=DATE '2026-11-01'"""
    out["freshness"] = query(c, sql, {}, "order_freshness").to_dict("records")
finally:
    c.rollback()
    c.close()
dump(W / "metadata_audit.json", out)
print(
    json.dumps(
        {
            "related_tables": out["tables"],
            "legacy_rows": len(legacy),
            "new_rows": len(new),
            "freshness": out["freshness"],
        },
        default=str,
    )
)
