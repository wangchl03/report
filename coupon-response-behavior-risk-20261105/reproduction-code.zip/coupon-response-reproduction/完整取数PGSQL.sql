-- 完整只读取数SQL。命名参数由代码绑定，不在公开文件中展开用户名单。
-- 业务时区 America/Belize；完整日上界 2026-11-04。

-- ======================================================================
-- all_issue_histories.sql
-- ======================================================================
-- Read-only source SQL; bound parameters supplied by extraction program.

SELECT user_id,serial_id,coupon_id,TRIM(coupon_no) AS coupon_no, TYPE,amount,real_use_amount,
       used_date,create_date,expire_date
FROM wangchuanliang.coupon_user_copy
WHERE user_id IN
        (SELECT unnest(%(users)s::bigint[]))
    AND create_date>=DATE '2026-05-01'
    AND create_date<%(end)s::date;

-- ======================================================================
-- all_issue_size_audit.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT TYPE,COUNT(*) AS n,COUNT(DISTINCT user_id) AS users
FROM wangchuanliang.coupon_user_copy
WHERE user_id IN
        (SELECT unnest(%(users)s::bigint[]))
    AND create_date>=DATE '2026-05-01'
    AND create_date<DATE '2026-11-04'
GROUP BY TYPE;

-- ======================================================================
-- behavior_legacy_2026-05-18_2026-09-21.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.
WITH RAW AS
    (SELECT user_id,create_date AS d,create_time AS t,create_unix,event_type,props_id,
            event_start_time,event_end_time
     FROM wangchuanliang.event_track_record
     WHERE create_date>=%(start)s::date
         AND create_date<%(end)s::date
         AND create_time>=%(start)s::timestamp
         AND create_time<%(end)s::timestamp
         AND user_id IN
             (SELECT unnest(%(users)s::bigint[])))
SELECT user_id, d, COUNT(*) AS logs,
       MIN(EXTRACT(EPOCH
                   FROM t AT TIME ZONE 'AMERICA/BELIZE')) AS first_active_epoch, MAX(EXTRACT(EPOCH
                                                                                             FROM t AT TIME ZONE 'AMERICA/BELIZE')) AS last_active_epoch,
       SUM(CASE WHEN t::date<>d THEN 1 ELSE 0
           END) AS date_mismatch_n,
       SUM(CASE
               WHEN event_end_time>0
                    AND ABS(event_end_time/1000.0-EXTRACT(EPOCH
                                                          FROM t AT TIME ZONE 'AMERICA/BELIZE'))>86400 THEN 1 ELSE 0
           END) AS device_clock_far_n, SUM(CASE WHEN (event_type='app_start') THEN 1 ELSE 0
                                           END) AS app_start_n,
       MIN(CASE
               WHEN (event_type='app_start') THEN EXTRACT(EPOCH
                                                          FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS app_start_epoch,
       SUM(CASE
               WHEN (event_type='page_view_in'
                     AND props_id IN ('Loan_newpage',
                                      'Loan_newpage_select')) THEN 1 ELSE 0
           END) AS loan_entry_n,
       MIN(CASE
               WHEN (event_type='page_view_in'
                     AND props_id IN ('Loan_newpage',
                                      'Loan_newpage_select')) THEN EXTRACT(EPOCH
                                                                           FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS loan_entry_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND props_id IN ('Loan_newconfirm',
                                      'Loan_newconfirm_select')) THEN 1 ELSE 0
           END) AS submit_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND props_id IN ('Loan_newconfirm',
                                      'Loan_newconfirm_select')) THEN EXTRACT(EPOCH
                                                                              FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS submit_epoch,
       SUM(CASE
               WHEN (props_id IN ('amount_modification',
                                  'loan_form_loan_amount_selectionn_new',
                                  'loan_form_loan_amount_selectionn_new_select')) THEN 1 ELSE 0
           END) AS amount_n,
       MIN(CASE
               WHEN (props_id IN ('amount_modification',
                                  'loan_form_loan_amount_selectionn_new',
                                  'loan_form_loan_amount_selectionn_new_select')) THEN EXTRACT(EPOCH
                                                                                               FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS amount_epoch,
       SUM(CASE
               WHEN (props_id IN ('loan_form_term_selection_new',
                                  'loan_form_term_selection_new_select')) THEN 1 ELSE 0
           END) AS term_n,
       MIN(CASE
               WHEN (props_id IN ('loan_form_term_selection_new',
                                  'loan_form_term_selection_new_select')) THEN EXTRACT(EPOCH
                                                                                       FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS term_epoch,
       SUM(CASE
               WHEN (props_id IN ('Loan_plan_newdetails',
                                  'Loan_plan_newdetails_select')) THEN 1 ELSE 0
           END) AS plan_n,
       MIN(CASE
               WHEN (props_id IN ('Loan_plan_newdetails',
                                  'Loan_plan_newdetails_select')) THEN EXTRACT(EPOCH
                                                                               FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS plan_epoch,
       SUM(CASE
               WHEN (props_id IN ('Loan_contract_newdetails',
                                  'Loan_contract_newdetails_select')) THEN 1 ELSE 0
           END) AS contract_n,
       MIN(CASE
               WHEN (props_id IN ('Loan_contract_newdetails',
                                  'Loan_contract_newdetails_select')) THEN EXTRACT(EPOCH
                                                                                   FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS contract_epoch,
       SUM(CASE
               WHEN (props_id IN ('Order_coupons_page',
                                  'Order_coupons_page_select')) THEN 1 ELSE 0
           END) AS coupon_open_n,
       MIN(CASE
               WHEN (props_id IN ('Order_coupons_page',
                                  'Order_coupons_page_select')) THEN EXTRACT(EPOCH
                                                                             FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS coupon_open_epoch,
       SUM(CASE
               WHEN (props_id IN ('Order_coupons_confirm',
                                  'Order_coupons_confirm_select')) THEN 1 ELSE 0
           END) AS coupon_confirm_n,
       MIN(CASE
               WHEN (props_id IN ('Order_coupons_confirm',
                                  'Order_coupons_confirm_select')) THEN EXTRACT(EPOCH
                                                                                FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS coupon_confirm_epoch,
       SUM(CASE
               WHEN (props_id IN ('Order_coupons_page',
                                  'Order_coupons_page_select')) THEN 1 ELSE 0
           END) AS coupon_page_n,
       MIN(CASE
               WHEN (props_id IN ('Order_coupons_page',
                                  'Order_coupons_page_select')) THEN EXTRACT(EPOCH
                                                                             FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS coupon_page_epoch
FROM RAW
GROUP BY user_id,d;

-- ======================================================================
-- behavior_legacy_2026-09-21_2026-10-01.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.
WITH RAW AS
    (SELECT user_id,create_date AS d,create_time AS t,create_unix,event_type,props_id,
            event_start_time,event_end_time
     FROM wangchuanliang.event_track_record
     WHERE create_date>=%(start)s::date
         AND create_date<%(end)s::date
         AND create_time>=%(start)s::timestamp
         AND create_time<%(end)s::timestamp
         AND user_id IN
             (SELECT unnest(%(users)s::bigint[])))
SELECT user_id, d, COUNT(*) AS logs,
       MIN(EXTRACT(EPOCH
                   FROM t AT TIME ZONE 'AMERICA/BELIZE')) AS first_active_epoch, MAX(EXTRACT(EPOCH
                                                                                             FROM t AT TIME ZONE 'AMERICA/BELIZE')) AS last_active_epoch,
       SUM(CASE WHEN t::date<>d THEN 1 ELSE 0
           END) AS date_mismatch_n,
       SUM(CASE
               WHEN event_end_time>0
                    AND ABS(event_end_time/1000.0-EXTRACT(EPOCH
                                                          FROM t AT TIME ZONE 'AMERICA/BELIZE'))>86400 THEN 1 ELSE 0
           END) AS device_clock_far_n, SUM(CASE WHEN (event_type='app_start') THEN 1 ELSE 0
                                           END) AS app_start_n,
       MIN(CASE
               WHEN (event_type='app_start') THEN EXTRACT(EPOCH
                                                          FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS app_start_epoch,
       SUM(CASE
               WHEN (event_type='page_view_in'
                     AND props_id IN ('Loan_newpage',
                                      'Loan_newpage_select')) THEN 1 ELSE 0
           END) AS loan_entry_n,
       MIN(CASE
               WHEN (event_type='page_view_in'
                     AND props_id IN ('Loan_newpage',
                                      'Loan_newpage_select')) THEN EXTRACT(EPOCH
                                                                           FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS loan_entry_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND props_id IN ('Loan_newconfirm',
                                      'Loan_newconfirm_select')) THEN 1 ELSE 0
           END) AS submit_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND props_id IN ('Loan_newconfirm',
                                      'Loan_newconfirm_select')) THEN EXTRACT(EPOCH
                                                                              FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS submit_epoch,
       SUM(CASE
               WHEN (props_id IN ('amount_modification',
                                  'loan_form_loan_amount_selectionn_new',
                                  'loan_form_loan_amount_selectionn_new_select')) THEN 1 ELSE 0
           END) AS amount_n,
       MIN(CASE
               WHEN (props_id IN ('amount_modification',
                                  'loan_form_loan_amount_selectionn_new',
                                  'loan_form_loan_amount_selectionn_new_select')) THEN EXTRACT(EPOCH
                                                                                               FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS amount_epoch,
       SUM(CASE
               WHEN (props_id IN ('loan_form_term_selection_new',
                                  'loan_form_term_selection_new_select')) THEN 1 ELSE 0
           END) AS term_n,
       MIN(CASE
               WHEN (props_id IN ('loan_form_term_selection_new',
                                  'loan_form_term_selection_new_select')) THEN EXTRACT(EPOCH
                                                                                       FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS term_epoch,
       SUM(CASE
               WHEN (props_id IN ('Loan_plan_newdetails',
                                  'Loan_plan_newdetails_select')) THEN 1 ELSE 0
           END) AS plan_n,
       MIN(CASE
               WHEN (props_id IN ('Loan_plan_newdetails',
                                  'Loan_plan_newdetails_select')) THEN EXTRACT(EPOCH
                                                                               FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS plan_epoch,
       SUM(CASE
               WHEN (props_id IN ('Loan_contract_newdetails',
                                  'Loan_contract_newdetails_select')) THEN 1 ELSE 0
           END) AS contract_n,
       MIN(CASE
               WHEN (props_id IN ('Loan_contract_newdetails',
                                  'Loan_contract_newdetails_select')) THEN EXTRACT(EPOCH
                                                                                   FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS contract_epoch,
       SUM(CASE
               WHEN (props_id IN ('Order_coupons_page',
                                  'Order_coupons_page_select')) THEN 1 ELSE 0
           END) AS coupon_open_n,
       MIN(CASE
               WHEN (props_id IN ('Order_coupons_page',
                                  'Order_coupons_page_select')) THEN EXTRACT(EPOCH
                                                                             FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS coupon_open_epoch,
       SUM(CASE
               WHEN (props_id IN ('Order_coupons_confirm',
                                  'Order_coupons_confirm_select')) THEN 1 ELSE 0
           END) AS coupon_confirm_n,
       MIN(CASE
               WHEN (props_id IN ('Order_coupons_confirm',
                                  'Order_coupons_confirm_select')) THEN EXTRACT(EPOCH
                                                                                FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS coupon_confirm_epoch,
       SUM(CASE
               WHEN (props_id IN ('Order_coupons_page',
                                  'Order_coupons_page_select')) THEN 1 ELSE 0
           END) AS coupon_page_n,
       MIN(CASE
               WHEN (props_id IN ('Order_coupons_page',
                                  'Order_coupons_page_select')) THEN EXTRACT(EPOCH
                                                                             FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS coupon_page_epoch
FROM RAW
GROUP BY user_id,d;

-- ======================================================================
-- behavior_legacy_2026-10-01_2026-10-16.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.
WITH RAW AS
    (SELECT user_id,create_date AS d,create_time AS t,create_unix,event_type,props_id,
            event_start_time,event_end_time
     FROM wangchuanliang.event_track_record
     WHERE create_date>=%(start)s::date
         AND create_date<%(end)s::date
         AND create_time>=%(start)s::timestamp
         AND create_time<%(end)s::timestamp
         AND user_id IN
             (SELECT unnest(%(users)s::bigint[])))
SELECT user_id, d, COUNT(*) AS logs,
       MIN(EXTRACT(EPOCH
                   FROM t AT TIME ZONE 'AMERICA/BELIZE')) AS first_active_epoch, MAX(EXTRACT(EPOCH
                                                                                             FROM t AT TIME ZONE 'AMERICA/BELIZE')) AS last_active_epoch,
       SUM(CASE WHEN t::date<>d THEN 1 ELSE 0
           END) AS date_mismatch_n,
       SUM(CASE
               WHEN event_end_time>0
                    AND ABS(event_end_time/1000.0-EXTRACT(EPOCH
                                                          FROM t AT TIME ZONE 'AMERICA/BELIZE'))>86400 THEN 1 ELSE 0
           END) AS device_clock_far_n, SUM(CASE WHEN (event_type='app_start') THEN 1 ELSE 0
                                           END) AS app_start_n,
       MIN(CASE
               WHEN (event_type='app_start') THEN EXTRACT(EPOCH
                                                          FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS app_start_epoch,
       SUM(CASE
               WHEN (event_type='page_view_in'
                     AND props_id IN ('Loan_newpage',
                                      'Loan_newpage_select')) THEN 1 ELSE 0
           END) AS loan_entry_n,
       MIN(CASE
               WHEN (event_type='page_view_in'
                     AND props_id IN ('Loan_newpage',
                                      'Loan_newpage_select')) THEN EXTRACT(EPOCH
                                                                           FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS loan_entry_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND props_id IN ('Loan_newconfirm',
                                      'Loan_newconfirm_select')) THEN 1 ELSE 0
           END) AS submit_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND props_id IN ('Loan_newconfirm',
                                      'Loan_newconfirm_select')) THEN EXTRACT(EPOCH
                                                                              FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS submit_epoch,
       SUM(CASE
               WHEN (props_id IN ('amount_modification',
                                  'loan_form_loan_amount_selectionn_new',
                                  'loan_form_loan_amount_selectionn_new_select')) THEN 1 ELSE 0
           END) AS amount_n,
       MIN(CASE
               WHEN (props_id IN ('amount_modification',
                                  'loan_form_loan_amount_selectionn_new',
                                  'loan_form_loan_amount_selectionn_new_select')) THEN EXTRACT(EPOCH
                                                                                               FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS amount_epoch,
       SUM(CASE
               WHEN (props_id IN ('loan_form_term_selection_new',
                                  'loan_form_term_selection_new_select')) THEN 1 ELSE 0
           END) AS term_n,
       MIN(CASE
               WHEN (props_id IN ('loan_form_term_selection_new',
                                  'loan_form_term_selection_new_select')) THEN EXTRACT(EPOCH
                                                                                       FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS term_epoch,
       SUM(CASE
               WHEN (props_id IN ('Loan_plan_newdetails',
                                  'Loan_plan_newdetails_select')) THEN 1 ELSE 0
           END) AS plan_n,
       MIN(CASE
               WHEN (props_id IN ('Loan_plan_newdetails',
                                  'Loan_plan_newdetails_select')) THEN EXTRACT(EPOCH
                                                                               FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS plan_epoch,
       SUM(CASE
               WHEN (props_id IN ('Loan_contract_newdetails',
                                  'Loan_contract_newdetails_select')) THEN 1 ELSE 0
           END) AS contract_n,
       MIN(CASE
               WHEN (props_id IN ('Loan_contract_newdetails',
                                  'Loan_contract_newdetails_select')) THEN EXTRACT(EPOCH
                                                                                   FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS contract_epoch,
       SUM(CASE
               WHEN (props_id IN ('Order_coupons_page',
                                  'Order_coupons_page_select')) THEN 1 ELSE 0
           END) AS coupon_open_n,
       MIN(CASE
               WHEN (props_id IN ('Order_coupons_page',
                                  'Order_coupons_page_select')) THEN EXTRACT(EPOCH
                                                                             FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS coupon_open_epoch,
       SUM(CASE
               WHEN (props_id IN ('Order_coupons_confirm',
                                  'Order_coupons_confirm_select')) THEN 1 ELSE 0
           END) AS coupon_confirm_n,
       MIN(CASE
               WHEN (props_id IN ('Order_coupons_confirm',
                                  'Order_coupons_confirm_select')) THEN EXTRACT(EPOCH
                                                                                FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS coupon_confirm_epoch,
       SUM(CASE
               WHEN (props_id IN ('Order_coupons_page',
                                  'Order_coupons_page_select')) THEN 1 ELSE 0
           END) AS coupon_page_n,
       MIN(CASE
               WHEN (props_id IN ('Order_coupons_page',
                                  'Order_coupons_page_select')) THEN EXTRACT(EPOCH
                                                                             FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS coupon_page_epoch
FROM RAW
GROUP BY user_id,d;

-- ======================================================================
-- behavior_legacy_2026-10-16_2026-11-04.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.
WITH RAW AS
    (SELECT user_id,create_date AS d,create_time AS t,create_unix,event_type,props_id,
            event_start_time,event_end_time
     FROM wangchuanliang.event_track_record
     WHERE create_date>=%(start)s::date
         AND create_date<%(end)s::date
         AND create_time>=%(start)s::timestamp
         AND create_time<%(end)s::timestamp
         AND user_id IN
             (SELECT unnest(%(users)s::bigint[])))
SELECT user_id, d, COUNT(*) AS logs,
       MIN(EXTRACT(EPOCH
                   FROM t AT TIME ZONE 'AMERICA/BELIZE')) AS first_active_epoch, MAX(EXTRACT(EPOCH
                                                                                             FROM t AT TIME ZONE 'AMERICA/BELIZE')) AS last_active_epoch,
       SUM(CASE WHEN t::date<>d THEN 1 ELSE 0
           END) AS date_mismatch_n,
       SUM(CASE
               WHEN event_end_time>0
                    AND ABS(event_end_time/1000.0-EXTRACT(EPOCH
                                                          FROM t AT TIME ZONE 'AMERICA/BELIZE'))>86400 THEN 1 ELSE 0
           END) AS device_clock_far_n, SUM(CASE WHEN (event_type='app_start') THEN 1 ELSE 0
                                           END) AS app_start_n,
       MIN(CASE
               WHEN (event_type='app_start') THEN EXTRACT(EPOCH
                                                          FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS app_start_epoch,
       SUM(CASE
               WHEN (event_type='page_view_in'
                     AND props_id IN ('Loan_newpage',
                                      'Loan_newpage_select')) THEN 1 ELSE 0
           END) AS loan_entry_n,
       MIN(CASE
               WHEN (event_type='page_view_in'
                     AND props_id IN ('Loan_newpage',
                                      'Loan_newpage_select')) THEN EXTRACT(EPOCH
                                                                           FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS loan_entry_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND props_id IN ('Loan_newconfirm',
                                      'Loan_newconfirm_select')) THEN 1 ELSE 0
           END) AS submit_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND props_id IN ('Loan_newconfirm',
                                      'Loan_newconfirm_select')) THEN EXTRACT(EPOCH
                                                                              FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS submit_epoch,
       SUM(CASE
               WHEN (props_id IN ('amount_modification',
                                  'loan_form_loan_amount_selectionn_new',
                                  'loan_form_loan_amount_selectionn_new_select')) THEN 1 ELSE 0
           END) AS amount_n,
       MIN(CASE
               WHEN (props_id IN ('amount_modification',
                                  'loan_form_loan_amount_selectionn_new',
                                  'loan_form_loan_amount_selectionn_new_select')) THEN EXTRACT(EPOCH
                                                                                               FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS amount_epoch,
       SUM(CASE
               WHEN (props_id IN ('loan_form_term_selection_new',
                                  'loan_form_term_selection_new_select')) THEN 1 ELSE 0
           END) AS term_n,
       MIN(CASE
               WHEN (props_id IN ('loan_form_term_selection_new',
                                  'loan_form_term_selection_new_select')) THEN EXTRACT(EPOCH
                                                                                       FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS term_epoch,
       SUM(CASE
               WHEN (props_id IN ('Loan_plan_newdetails',
                                  'Loan_plan_newdetails_select')) THEN 1 ELSE 0
           END) AS plan_n,
       MIN(CASE
               WHEN (props_id IN ('Loan_plan_newdetails',
                                  'Loan_plan_newdetails_select')) THEN EXTRACT(EPOCH
                                                                               FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS plan_epoch,
       SUM(CASE
               WHEN (props_id IN ('Loan_contract_newdetails',
                                  'Loan_contract_newdetails_select')) THEN 1 ELSE 0
           END) AS contract_n,
       MIN(CASE
               WHEN (props_id IN ('Loan_contract_newdetails',
                                  'Loan_contract_newdetails_select')) THEN EXTRACT(EPOCH
                                                                                   FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS contract_epoch,
       SUM(CASE
               WHEN (props_id IN ('Order_coupons_page',
                                  'Order_coupons_page_select')) THEN 1 ELSE 0
           END) AS coupon_open_n,
       MIN(CASE
               WHEN (props_id IN ('Order_coupons_page',
                                  'Order_coupons_page_select')) THEN EXTRACT(EPOCH
                                                                             FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS coupon_open_epoch,
       SUM(CASE
               WHEN (props_id IN ('Order_coupons_confirm',
                                  'Order_coupons_confirm_select')) THEN 1 ELSE 0
           END) AS coupon_confirm_n,
       MIN(CASE
               WHEN (props_id IN ('Order_coupons_confirm',
                                  'Order_coupons_confirm_select')) THEN EXTRACT(EPOCH
                                                                                FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS coupon_confirm_epoch,
       SUM(CASE
               WHEN (props_id IN ('Order_coupons_page',
                                  'Order_coupons_page_select')) THEN 1 ELSE 0
           END) AS coupon_page_n,
       MIN(CASE
               WHEN (props_id IN ('Order_coupons_page',
                                  'Order_coupons_page_select')) THEN EXTRACT(EPOCH
                                                                             FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS coupon_page_epoch
FROM RAW
GROUP BY user_id,d;

-- ======================================================================
-- behavior_legacy_additional_20pct_id153.sql
-- ======================================================================
-- Read-only source SQL; bound parameters supplied by extraction program.
WITH RAW AS
    (SELECT user_id,create_date AS d,create_time AS t,create_unix,event_type,props_id,
            event_start_time,event_end_time
     FROM wangchuanliang.event_track_record
     WHERE create_date>=%(start)s::date
         AND create_date<%(end)s::date
         AND create_time>=%(start)s::timestamp
         AND create_time<%(end)s::timestamp
         AND user_id IN
             (SELECT unnest(%(users)s::bigint[])))
SELECT user_id, d, COUNT(*) AS logs,
       MIN(EXTRACT(EPOCH
                   FROM t AT TIME ZONE 'AMERICA/BELIZE')) AS first_active_epoch, MAX(EXTRACT(EPOCH
                                                                                             FROM t AT TIME ZONE 'AMERICA/BELIZE')) AS last_active_epoch,
       SUM(CASE WHEN t::date<>d THEN 1 ELSE 0
           END) AS date_mismatch_n,
       SUM(CASE
               WHEN event_end_time>0
                    AND ABS(event_end_time/1000.0-EXTRACT(EPOCH
                                                          FROM t AT TIME ZONE 'AMERICA/BELIZE'))>86400 THEN 1 ELSE 0
           END) AS device_clock_far_n, SUM(CASE WHEN (event_type='app_start') THEN 1 ELSE 0
                                           END) AS app_start_n,
       MIN(CASE
               WHEN (event_type='app_start') THEN EXTRACT(EPOCH
                                                          FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS app_start_epoch,
       SUM(CASE
               WHEN (event_type='page_view_in'
                     AND props_id IN ('Loan_newpage',
                                      'Loan_newpage_select')) THEN 1 ELSE 0
           END) AS loan_entry_n,
       MIN(CASE
               WHEN (event_type='page_view_in'
                     AND props_id IN ('Loan_newpage',
                                      'Loan_newpage_select')) THEN EXTRACT(EPOCH
                                                                           FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS loan_entry_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND props_id IN ('Loan_newconfirm',
                                      'Loan_newconfirm_select')) THEN 1 ELSE 0
           END) AS submit_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND props_id IN ('Loan_newconfirm',
                                      'Loan_newconfirm_select')) THEN EXTRACT(EPOCH
                                                                              FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS submit_epoch,
       SUM(CASE
               WHEN (props_id IN ('amount_modification',
                                  'loan_form_loan_amount_selectionn_new',
                                  'loan_form_loan_amount_selectionn_new_select')) THEN 1 ELSE 0
           END) AS amount_n,
       MIN(CASE
               WHEN (props_id IN ('amount_modification',
                                  'loan_form_loan_amount_selectionn_new',
                                  'loan_form_loan_amount_selectionn_new_select')) THEN EXTRACT(EPOCH
                                                                                               FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS amount_epoch,
       SUM(CASE
               WHEN (props_id IN ('loan_form_term_selection_new',
                                  'loan_form_term_selection_new_select')) THEN 1 ELSE 0
           END) AS term_n,
       MIN(CASE
               WHEN (props_id IN ('loan_form_term_selection_new',
                                  'loan_form_term_selection_new_select')) THEN EXTRACT(EPOCH
                                                                                       FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS term_epoch,
       SUM(CASE
               WHEN (props_id IN ('Loan_plan_newdetails',
                                  'Loan_plan_newdetails_select')) THEN 1 ELSE 0
           END) AS plan_n,
       MIN(CASE
               WHEN (props_id IN ('Loan_plan_newdetails',
                                  'Loan_plan_newdetails_select')) THEN EXTRACT(EPOCH
                                                                               FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS plan_epoch,
       SUM(CASE
               WHEN (props_id IN ('Loan_contract_newdetails',
                                  'Loan_contract_newdetails_select')) THEN 1 ELSE 0
           END) AS contract_n,
       MIN(CASE
               WHEN (props_id IN ('Loan_contract_newdetails',
                                  'Loan_contract_newdetails_select')) THEN EXTRACT(EPOCH
                                                                                   FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS contract_epoch,
       SUM(CASE
               WHEN (props_id IN ('Order_coupons_page',
                                  'Order_coupons_page_select')) THEN 1 ELSE 0
           END) AS coupon_open_n,
       MIN(CASE
               WHEN (props_id IN ('Order_coupons_page',
                                  'Order_coupons_page_select')) THEN EXTRACT(EPOCH
                                                                             FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS coupon_open_epoch,
       SUM(CASE
               WHEN (props_id IN ('Order_coupons_confirm',
                                  'Order_coupons_confirm_select')) THEN 1 ELSE 0
           END) AS coupon_confirm_n,
       MIN(CASE
               WHEN (props_id IN ('Order_coupons_confirm',
                                  'Order_coupons_confirm_select')) THEN EXTRACT(EPOCH
                                                                                FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS coupon_confirm_epoch,
       SUM(CASE
               WHEN (props_id IN ('Order_coupons_page',
                                  'Order_coupons_page_select')) THEN 1 ELSE 0
           END) AS coupon_page_n,
       MIN(CASE
               WHEN (props_id IN ('Order_coupons_page',
                                  'Order_coupons_page_select')) THEN EXTRACT(EPOCH
                                                                             FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS coupon_page_epoch
FROM RAW
GROUP BY user_id,d;

-- ======================================================================
-- behavior_legacy_prestart_history.sql
-- ======================================================================
-- Read-only source SQL; bound parameters supplied by extraction program.

SELECT user_id,MIN(create_time) AS first_active_time,MAX(create_time) AS last_active_time,
       COUNT(DISTINCT create_date) AS active_days,COUNT(*) AS logs
FROM wangchuanliang.event_track_record
WHERE create_date>=DATE '2025-11-01'
    AND create_date<DATE '2026-05-18'
    AND create_time>=TIMESTAMP '2025-11-01'
    AND create_time<TIMESTAMP '2026-05-18'
    AND user_id IN
        (SELECT unnest(%(users)s::bigint[]))
GROUP BY user_id;

-- ======================================================================
-- behavior_new_2026-05-18_2026-09-21.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.
WITH RAW AS
    (SELECT user_id,event_date AS d,event_time AS t,event_unix,event_type,page_type,element_type,
            split_part(page_id, '_', 1) AS page_base,split_part(element_id,
                                                         '_', 1) AS element_base
     FROM wangchuanliang.user_behavior_track_record
     WHERE event_date>=%(start)s::date
         AND event_date<%(end)s::date
         AND event_time>=%(start)s::timestamp
         AND event_time<%(end)s::timestamp
         AND user_id IN
             (SELECT unnest(%(users)s::bigint[])))
SELECT user_id, d, COUNT(*) AS logs,
       MIN(EXTRACT(EPOCH
                   FROM t AT TIME ZONE 'AMERICA/BELIZE')) AS first_active_epoch, MAX(EXTRACT(EPOCH
                                                                                             FROM t AT TIME ZONE 'AMERICA/BELIZE')) AS last_active_epoch,
       SUM(CASE WHEN t::date<>d THEN 1 ELSE 0
           END) AS date_mismatch_n,
       SUM(CASE
               WHEN ABS(event_unix/1000.0-EXTRACT(EPOCH
                                                  FROM t AT TIME ZONE 'AMERICA/BELIZE'))>1 THEN 1 ELSE 0
           END) AS epoch_mismatch_n, SUM(CASE WHEN (event_type='app_start') THEN 1 ELSE 0
                                         END) AS app_start_n,
       MIN(CASE
               WHEN (event_type='app_start') THEN EXTRACT(EPOCH
                                                          FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS app_start_epoch,
       SUM(CASE
               WHEN (event_type='page_view'
                     AND page_type='page_view_in'
                     AND page_base IN ('xyrsaqxpwmedzlsm',
                                       'vdecaucgiowzpoeh')) THEN 1 ELSE 0
           END) AS loan_entry_n,
       MIN(CASE
               WHEN (event_type='page_view'
                     AND page_type='page_view_in'
                     AND page_base IN ('xyrsaqxpwmedzlsm',
                                       'vdecaucgiowzpoeh')) THEN EXTRACT(EPOCH
                                                                         FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS loan_entry_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('hfmgyiwihoavrqzv',
                                          'udopwuxjursbmvcm')) THEN 1 ELSE 0
           END) AS submit_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('hfmgyiwihoavrqzv',
                                          'udopwuxjursbmvcm')) THEN EXTRACT(EPOCH
                                                                            FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS submit_epoch,
       SUM(CASE
               WHEN ((event_type='text_change'
                      AND element_type='editing'
                      AND element_base='gbyukfclsrdmxaon')
                     OR (event_type='slider_change'
                         AND element_base='jrocyutivyeqdxrx')
                     OR (event_type='element_click'
                         AND element_base IN ('xhwhgrqsxqkfwpoj',
                                              'saynozmunkdceoya', 'gwexsotywwgsvrgv'))) THEN 1 ELSE 0
           END) AS amount_n,
       MIN(CASE
               WHEN ((event_type='text_change'
                      AND element_type='editing'
                      AND element_base='gbyukfclsrdmxaon')
                     OR (event_type='slider_change'
                         AND element_base='jrocyutivyeqdxrx')
                     OR (event_type='element_click'
                         AND element_base IN ('xhwhgrqsxqkfwpoj',
                                              'saynozmunkdceoya', 'gwexsotywwgsvrgv'))) THEN EXTRACT(EPOCH
                                                                                                     FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS amount_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('zfmdsmjpuslrcchx',
                                          'denkhhpvgqgwethb', 'rdapttngylaiuvth',
                                          'gfelmnelmexljaiv')) THEN 1 ELSE 0
           END) AS term_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('zfmdsmjpuslrcchx',
                                          'denkhhpvgqgwethb', 'rdapttngylaiuvth',
                                          'gfelmnelmexljaiv')) THEN EXTRACT(EPOCH
                                                                            FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS term_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('omuwccqjaovwdwyx',
                                          'gemkzaypdtcrwdkg')) THEN 1 ELSE 0
           END) AS plan_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('omuwccqjaovwdwyx',
                                          'gemkzaypdtcrwdkg')) THEN EXTRACT(EPOCH
                                                                            FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS plan_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('oflwqlzkgvyvhltd',
                                          'gwhhjdfmvnpjaouh')) THEN 1 ELSE 0
           END) AS contract_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('oflwqlzkgvyvhltd',
                                          'gwhhjdfmvnpjaouh')) THEN EXTRACT(EPOCH
                                                                            FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS contract_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('ejknnzgmqlepvxuy',
                                          'gbjnaljcxrmlvpwo')) THEN 1 ELSE 0
           END) AS coupon_open_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('ejknnzgmqlepvxuy',
                                          'gbjnaljcxrmlvpwo')) THEN EXTRACT(EPOCH
                                                                            FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS coupon_open_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('dmadzxixvpamlgpg',
                                          'mpjlvbjrygzfqxvo')) THEN 1 ELSE 0
           END) AS coupon_confirm_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('dmadzxixvpamlgpg',
                                          'mpjlvbjrygzfqxvo')) THEN EXTRACT(EPOCH
                                                                            FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS coupon_confirm_epoch,
       SUM(CASE
               WHEN (event_type='page_view'
                     AND page_type='page_view_in'
                     AND page_base='iqsvfjcxwpqtsrbj') THEN 1 ELSE 0
           END) AS coupon_page_n,
       MIN(CASE
               WHEN (event_type='page_view'
                     AND page_type='page_view_in'
                     AND page_base='iqsvfjcxwpqtsrbj') THEN EXTRACT(EPOCH
                                                                    FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS coupon_page_epoch
FROM RAW
GROUP BY user_id,d;

-- ======================================================================
-- behavior_new_2026-09-21_2026-10-01.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.
WITH RAW AS
    (SELECT user_id,event_date AS d,event_time AS t,event_unix,event_type,page_type,element_type,
            split_part(page_id, '_', 1) AS page_base,split_part(element_id,
                                                         '_', 1) AS element_base
     FROM wangchuanliang.user_behavior_track_record
     WHERE event_date>=%(start)s::date
         AND event_date<%(end)s::date
         AND event_time>=%(start)s::timestamp
         AND event_time<%(end)s::timestamp
         AND user_id IN
             (SELECT unnest(%(users)s::bigint[])))
SELECT user_id, d, COUNT(*) AS logs,
       MIN(EXTRACT(EPOCH
                   FROM t AT TIME ZONE 'AMERICA/BELIZE')) AS first_active_epoch, MAX(EXTRACT(EPOCH
                                                                                             FROM t AT TIME ZONE 'AMERICA/BELIZE')) AS last_active_epoch,
       SUM(CASE WHEN t::date<>d THEN 1 ELSE 0
           END) AS date_mismatch_n,
       SUM(CASE
               WHEN ABS(event_unix/1000.0-EXTRACT(EPOCH
                                                  FROM t AT TIME ZONE 'AMERICA/BELIZE'))>1 THEN 1 ELSE 0
           END) AS epoch_mismatch_n, SUM(CASE WHEN (event_type='app_start') THEN 1 ELSE 0
                                         END) AS app_start_n,
       MIN(CASE
               WHEN (event_type='app_start') THEN EXTRACT(EPOCH
                                                          FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS app_start_epoch,
       SUM(CASE
               WHEN (event_type='page_view'
                     AND page_type='page_view_in'
                     AND page_base IN ('xyrsaqxpwmedzlsm',
                                       'vdecaucgiowzpoeh')) THEN 1 ELSE 0
           END) AS loan_entry_n,
       MIN(CASE
               WHEN (event_type='page_view'
                     AND page_type='page_view_in'
                     AND page_base IN ('xyrsaqxpwmedzlsm',
                                       'vdecaucgiowzpoeh')) THEN EXTRACT(EPOCH
                                                                         FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS loan_entry_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('hfmgyiwihoavrqzv',
                                          'udopwuxjursbmvcm')) THEN 1 ELSE 0
           END) AS submit_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('hfmgyiwihoavrqzv',
                                          'udopwuxjursbmvcm')) THEN EXTRACT(EPOCH
                                                                            FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS submit_epoch,
       SUM(CASE
               WHEN ((event_type='text_change'
                      AND element_type='editing'
                      AND element_base='gbyukfclsrdmxaon')
                     OR (event_type='slider_change'
                         AND element_base='jrocyutivyeqdxrx')
                     OR (event_type='element_click'
                         AND element_base IN ('xhwhgrqsxqkfwpoj',
                                              'saynozmunkdceoya', 'gwexsotywwgsvrgv'))) THEN 1 ELSE 0
           END) AS amount_n,
       MIN(CASE
               WHEN ((event_type='text_change'
                      AND element_type='editing'
                      AND element_base='gbyukfclsrdmxaon')
                     OR (event_type='slider_change'
                         AND element_base='jrocyutivyeqdxrx')
                     OR (event_type='element_click'
                         AND element_base IN ('xhwhgrqsxqkfwpoj',
                                              'saynozmunkdceoya', 'gwexsotywwgsvrgv'))) THEN EXTRACT(EPOCH
                                                                                                     FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS amount_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('zfmdsmjpuslrcchx',
                                          'denkhhpvgqgwethb', 'rdapttngylaiuvth',
                                          'gfelmnelmexljaiv')) THEN 1 ELSE 0
           END) AS term_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('zfmdsmjpuslrcchx',
                                          'denkhhpvgqgwethb', 'rdapttngylaiuvth',
                                          'gfelmnelmexljaiv')) THEN EXTRACT(EPOCH
                                                                            FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS term_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('omuwccqjaovwdwyx',
                                          'gemkzaypdtcrwdkg')) THEN 1 ELSE 0
           END) AS plan_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('omuwccqjaovwdwyx',
                                          'gemkzaypdtcrwdkg')) THEN EXTRACT(EPOCH
                                                                            FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS plan_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('oflwqlzkgvyvhltd',
                                          'gwhhjdfmvnpjaouh')) THEN 1 ELSE 0
           END) AS contract_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('oflwqlzkgvyvhltd',
                                          'gwhhjdfmvnpjaouh')) THEN EXTRACT(EPOCH
                                                                            FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS contract_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('ejknnzgmqlepvxuy',
                                          'gbjnaljcxrmlvpwo')) THEN 1 ELSE 0
           END) AS coupon_open_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('ejknnzgmqlepvxuy',
                                          'gbjnaljcxrmlvpwo')) THEN EXTRACT(EPOCH
                                                                            FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS coupon_open_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('dmadzxixvpamlgpg',
                                          'mpjlvbjrygzfqxvo')) THEN 1 ELSE 0
           END) AS coupon_confirm_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('dmadzxixvpamlgpg',
                                          'mpjlvbjrygzfqxvo')) THEN EXTRACT(EPOCH
                                                                            FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS coupon_confirm_epoch,
       SUM(CASE
               WHEN (event_type='page_view'
                     AND page_type='page_view_in'
                     AND page_base='iqsvfjcxwpqtsrbj') THEN 1 ELSE 0
           END) AS coupon_page_n,
       MIN(CASE
               WHEN (event_type='page_view'
                     AND page_type='page_view_in'
                     AND page_base='iqsvfjcxwpqtsrbj') THEN EXTRACT(EPOCH
                                                                    FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS coupon_page_epoch
FROM RAW
GROUP BY user_id,d;

-- ======================================================================
-- behavior_new_2026-10-01_2026-10-16.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.
WITH RAW AS
    (SELECT user_id,event_date AS d,event_time AS t,event_unix,event_type,page_type,element_type,
            split_part(page_id, '_', 1) AS page_base,split_part(element_id,
                                                         '_', 1) AS element_base
     FROM wangchuanliang.user_behavior_track_record
     WHERE event_date>=%(start)s::date
         AND event_date<%(end)s::date
         AND event_time>=%(start)s::timestamp
         AND event_time<%(end)s::timestamp
         AND user_id IN
             (SELECT unnest(%(users)s::bigint[])))
SELECT user_id, d, COUNT(*) AS logs,
       MIN(EXTRACT(EPOCH
                   FROM t AT TIME ZONE 'AMERICA/BELIZE')) AS first_active_epoch, MAX(EXTRACT(EPOCH
                                                                                             FROM t AT TIME ZONE 'AMERICA/BELIZE')) AS last_active_epoch,
       SUM(CASE WHEN t::date<>d THEN 1 ELSE 0
           END) AS date_mismatch_n,
       SUM(CASE
               WHEN ABS(event_unix/1000.0-EXTRACT(EPOCH
                                                  FROM t AT TIME ZONE 'AMERICA/BELIZE'))>1 THEN 1 ELSE 0
           END) AS epoch_mismatch_n, SUM(CASE WHEN (event_type='app_start') THEN 1 ELSE 0
                                         END) AS app_start_n,
       MIN(CASE
               WHEN (event_type='app_start') THEN EXTRACT(EPOCH
                                                          FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS app_start_epoch,
       SUM(CASE
               WHEN (event_type='page_view'
                     AND page_type='page_view_in'
                     AND page_base IN ('xyrsaqxpwmedzlsm',
                                       'vdecaucgiowzpoeh')) THEN 1 ELSE 0
           END) AS loan_entry_n,
       MIN(CASE
               WHEN (event_type='page_view'
                     AND page_type='page_view_in'
                     AND page_base IN ('xyrsaqxpwmedzlsm',
                                       'vdecaucgiowzpoeh')) THEN EXTRACT(EPOCH
                                                                         FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS loan_entry_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('hfmgyiwihoavrqzv',
                                          'udopwuxjursbmvcm')) THEN 1 ELSE 0
           END) AS submit_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('hfmgyiwihoavrqzv',
                                          'udopwuxjursbmvcm')) THEN EXTRACT(EPOCH
                                                                            FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS submit_epoch,
       SUM(CASE
               WHEN ((event_type='text_change'
                      AND element_type='editing'
                      AND element_base='gbyukfclsrdmxaon')
                     OR (event_type='slider_change'
                         AND element_base='jrocyutivyeqdxrx')
                     OR (event_type='element_click'
                         AND element_base IN ('xhwhgrqsxqkfwpoj',
                                              'saynozmunkdceoya', 'gwexsotywwgsvrgv'))) THEN 1 ELSE 0
           END) AS amount_n,
       MIN(CASE
               WHEN ((event_type='text_change'
                      AND element_type='editing'
                      AND element_base='gbyukfclsrdmxaon')
                     OR (event_type='slider_change'
                         AND element_base='jrocyutivyeqdxrx')
                     OR (event_type='element_click'
                         AND element_base IN ('xhwhgrqsxqkfwpoj',
                                              'saynozmunkdceoya', 'gwexsotywwgsvrgv'))) THEN EXTRACT(EPOCH
                                                                                                     FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS amount_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('zfmdsmjpuslrcchx',
                                          'denkhhpvgqgwethb', 'rdapttngylaiuvth',
                                          'gfelmnelmexljaiv')) THEN 1 ELSE 0
           END) AS term_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('zfmdsmjpuslrcchx',
                                          'denkhhpvgqgwethb', 'rdapttngylaiuvth',
                                          'gfelmnelmexljaiv')) THEN EXTRACT(EPOCH
                                                                            FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS term_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('omuwccqjaovwdwyx',
                                          'gemkzaypdtcrwdkg')) THEN 1 ELSE 0
           END) AS plan_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('omuwccqjaovwdwyx',
                                          'gemkzaypdtcrwdkg')) THEN EXTRACT(EPOCH
                                                                            FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS plan_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('oflwqlzkgvyvhltd',
                                          'gwhhjdfmvnpjaouh')) THEN 1 ELSE 0
           END) AS contract_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('oflwqlzkgvyvhltd',
                                          'gwhhjdfmvnpjaouh')) THEN EXTRACT(EPOCH
                                                                            FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS contract_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('ejknnzgmqlepvxuy',
                                          'gbjnaljcxrmlvpwo')) THEN 1 ELSE 0
           END) AS coupon_open_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('ejknnzgmqlepvxuy',
                                          'gbjnaljcxrmlvpwo')) THEN EXTRACT(EPOCH
                                                                            FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS coupon_open_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('dmadzxixvpamlgpg',
                                          'mpjlvbjrygzfqxvo')) THEN 1 ELSE 0
           END) AS coupon_confirm_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('dmadzxixvpamlgpg',
                                          'mpjlvbjrygzfqxvo')) THEN EXTRACT(EPOCH
                                                                            FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS coupon_confirm_epoch,
       SUM(CASE
               WHEN (event_type='page_view'
                     AND page_type='page_view_in'
                     AND page_base='iqsvfjcxwpqtsrbj') THEN 1 ELSE 0
           END) AS coupon_page_n,
       MIN(CASE
               WHEN (event_type='page_view'
                     AND page_type='page_view_in'
                     AND page_base='iqsvfjcxwpqtsrbj') THEN EXTRACT(EPOCH
                                                                    FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS coupon_page_epoch
FROM RAW
GROUP BY user_id,d;

-- ======================================================================
-- behavior_new_2026-10-16_2026-11-04.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.
WITH RAW AS
    (SELECT user_id,event_date AS d,event_time AS t,event_unix,event_type,page_type,element_type,
            split_part(page_id, '_', 1) AS page_base,split_part(element_id,
                                                         '_', 1) AS element_base
     FROM wangchuanliang.user_behavior_track_record
     WHERE event_date>=%(start)s::date
         AND event_date<%(end)s::date
         AND event_time>=%(start)s::timestamp
         AND event_time<%(end)s::timestamp
         AND user_id IN
             (SELECT unnest(%(users)s::bigint[])))
SELECT user_id, d, COUNT(*) AS logs,
       MIN(EXTRACT(EPOCH
                   FROM t AT TIME ZONE 'AMERICA/BELIZE')) AS first_active_epoch, MAX(EXTRACT(EPOCH
                                                                                             FROM t AT TIME ZONE 'AMERICA/BELIZE')) AS last_active_epoch,
       SUM(CASE WHEN t::date<>d THEN 1 ELSE 0
           END) AS date_mismatch_n,
       SUM(CASE
               WHEN ABS(event_unix/1000.0-EXTRACT(EPOCH
                                                  FROM t AT TIME ZONE 'AMERICA/BELIZE'))>1 THEN 1 ELSE 0
           END) AS epoch_mismatch_n, SUM(CASE WHEN (event_type='app_start') THEN 1 ELSE 0
                                         END) AS app_start_n,
       MIN(CASE
               WHEN (event_type='app_start') THEN EXTRACT(EPOCH
                                                          FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS app_start_epoch,
       SUM(CASE
               WHEN (event_type='page_view'
                     AND page_type='page_view_in'
                     AND page_base IN ('xyrsaqxpwmedzlsm',
                                       'vdecaucgiowzpoeh')) THEN 1 ELSE 0
           END) AS loan_entry_n,
       MIN(CASE
               WHEN (event_type='page_view'
                     AND page_type='page_view_in'
                     AND page_base IN ('xyrsaqxpwmedzlsm',
                                       'vdecaucgiowzpoeh')) THEN EXTRACT(EPOCH
                                                                         FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS loan_entry_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('hfmgyiwihoavrqzv',
                                          'udopwuxjursbmvcm')) THEN 1 ELSE 0
           END) AS submit_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('hfmgyiwihoavrqzv',
                                          'udopwuxjursbmvcm')) THEN EXTRACT(EPOCH
                                                                            FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS submit_epoch,
       SUM(CASE
               WHEN ((event_type='text_change'
                      AND element_type='editing'
                      AND element_base='gbyukfclsrdmxaon')
                     OR (event_type='slider_change'
                         AND element_base='jrocyutivyeqdxrx')
                     OR (event_type='element_click'
                         AND element_base IN ('xhwhgrqsxqkfwpoj',
                                              'saynozmunkdceoya', 'gwexsotywwgsvrgv'))) THEN 1 ELSE 0
           END) AS amount_n,
       MIN(CASE
               WHEN ((event_type='text_change'
                      AND element_type='editing'
                      AND element_base='gbyukfclsrdmxaon')
                     OR (event_type='slider_change'
                         AND element_base='jrocyutivyeqdxrx')
                     OR (event_type='element_click'
                         AND element_base IN ('xhwhgrqsxqkfwpoj',
                                              'saynozmunkdceoya', 'gwexsotywwgsvrgv'))) THEN EXTRACT(EPOCH
                                                                                                     FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS amount_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('zfmdsmjpuslrcchx',
                                          'denkhhpvgqgwethb', 'rdapttngylaiuvth',
                                          'gfelmnelmexljaiv')) THEN 1 ELSE 0
           END) AS term_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('zfmdsmjpuslrcchx',
                                          'denkhhpvgqgwethb', 'rdapttngylaiuvth',
                                          'gfelmnelmexljaiv')) THEN EXTRACT(EPOCH
                                                                            FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS term_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('omuwccqjaovwdwyx',
                                          'gemkzaypdtcrwdkg')) THEN 1 ELSE 0
           END) AS plan_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('omuwccqjaovwdwyx',
                                          'gemkzaypdtcrwdkg')) THEN EXTRACT(EPOCH
                                                                            FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS plan_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('oflwqlzkgvyvhltd',
                                          'gwhhjdfmvnpjaouh')) THEN 1 ELSE 0
           END) AS contract_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('oflwqlzkgvyvhltd',
                                          'gwhhjdfmvnpjaouh')) THEN EXTRACT(EPOCH
                                                                            FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS contract_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('ejknnzgmqlepvxuy',
                                          'gbjnaljcxrmlvpwo')) THEN 1 ELSE 0
           END) AS coupon_open_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('ejknnzgmqlepvxuy',
                                          'gbjnaljcxrmlvpwo')) THEN EXTRACT(EPOCH
                                                                            FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS coupon_open_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('dmadzxixvpamlgpg',
                                          'mpjlvbjrygzfqxvo')) THEN 1 ELSE 0
           END) AS coupon_confirm_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('dmadzxixvpamlgpg',
                                          'mpjlvbjrygzfqxvo')) THEN EXTRACT(EPOCH
                                                                            FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS coupon_confirm_epoch,
       SUM(CASE
               WHEN (event_type='page_view'
                     AND page_type='page_view_in'
                     AND page_base='iqsvfjcxwpqtsrbj') THEN 1 ELSE 0
           END) AS coupon_page_n,
       MIN(CASE
               WHEN (event_type='page_view'
                     AND page_type='page_view_in'
                     AND page_base='iqsvfjcxwpqtsrbj') THEN EXTRACT(EPOCH
                                                                    FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS coupon_page_epoch
FROM RAW
GROUP BY user_id,d;

-- ======================================================================
-- behavior_new_additional_20pct_id153.sql
-- ======================================================================
-- Read-only source SQL; bound parameters supplied by extraction program.
WITH RAW AS
    (SELECT user_id,event_date AS d,event_time AS t,event_unix,event_type,page_type,element_type,
            split_part(page_id, '_', 1) AS page_base,split_part(element_id,
                                                         '_', 1) AS element_base
     FROM wangchuanliang.user_behavior_track_record
     WHERE event_date>=%(start)s::date
         AND event_date<%(end)s::date
         AND event_time>=%(start)s::timestamp
         AND event_time<%(end)s::timestamp
         AND user_id IN
             (SELECT unnest(%(users)s::bigint[])))
SELECT user_id, d, COUNT(*) AS logs,
       MIN(EXTRACT(EPOCH
                   FROM t AT TIME ZONE 'AMERICA/BELIZE')) AS first_active_epoch, MAX(EXTRACT(EPOCH
                                                                                             FROM t AT TIME ZONE 'AMERICA/BELIZE')) AS last_active_epoch,
       SUM(CASE WHEN t::date<>d THEN 1 ELSE 0
           END) AS date_mismatch_n,
       SUM(CASE
               WHEN ABS(event_unix/1000.0-EXTRACT(EPOCH
                                                  FROM t AT TIME ZONE 'AMERICA/BELIZE'))>1 THEN 1 ELSE 0
           END) AS epoch_mismatch_n, SUM(CASE WHEN (event_type='app_start') THEN 1 ELSE 0
                                         END) AS app_start_n,
       MIN(CASE
               WHEN (event_type='app_start') THEN EXTRACT(EPOCH
                                                          FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS app_start_epoch,
       SUM(CASE
               WHEN (event_type='page_view'
                     AND page_type='page_view_in'
                     AND page_base IN ('xyrsaqxpwmedzlsm',
                                       'vdecaucgiowzpoeh')) THEN 1 ELSE 0
           END) AS loan_entry_n,
       MIN(CASE
               WHEN (event_type='page_view'
                     AND page_type='page_view_in'
                     AND page_base IN ('xyrsaqxpwmedzlsm',
                                       'vdecaucgiowzpoeh')) THEN EXTRACT(EPOCH
                                                                         FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS loan_entry_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('hfmgyiwihoavrqzv',
                                          'udopwuxjursbmvcm')) THEN 1 ELSE 0
           END) AS submit_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('hfmgyiwihoavrqzv',
                                          'udopwuxjursbmvcm')) THEN EXTRACT(EPOCH
                                                                            FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS submit_epoch,
       SUM(CASE
               WHEN ((event_type='text_change'
                      AND element_type='editing'
                      AND element_base='gbyukfclsrdmxaon')
                     OR (event_type='slider_change'
                         AND element_base='jrocyutivyeqdxrx')
                     OR (event_type='element_click'
                         AND element_base IN ('xhwhgrqsxqkfwpoj',
                                              'saynozmunkdceoya', 'gwexsotywwgsvrgv'))) THEN 1 ELSE 0
           END) AS amount_n,
       MIN(CASE
               WHEN ((event_type='text_change'
                      AND element_type='editing'
                      AND element_base='gbyukfclsrdmxaon')
                     OR (event_type='slider_change'
                         AND element_base='jrocyutivyeqdxrx')
                     OR (event_type='element_click'
                         AND element_base IN ('xhwhgrqsxqkfwpoj',
                                              'saynozmunkdceoya', 'gwexsotywwgsvrgv'))) THEN EXTRACT(EPOCH
                                                                                                     FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS amount_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('zfmdsmjpuslrcchx',
                                          'denkhhpvgqgwethb', 'rdapttngylaiuvth',
                                          'gfelmnelmexljaiv')) THEN 1 ELSE 0
           END) AS term_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('zfmdsmjpuslrcchx',
                                          'denkhhpvgqgwethb', 'rdapttngylaiuvth',
                                          'gfelmnelmexljaiv')) THEN EXTRACT(EPOCH
                                                                            FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS term_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('omuwccqjaovwdwyx',
                                          'gemkzaypdtcrwdkg')) THEN 1 ELSE 0
           END) AS plan_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('omuwccqjaovwdwyx',
                                          'gemkzaypdtcrwdkg')) THEN EXTRACT(EPOCH
                                                                            FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS plan_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('oflwqlzkgvyvhltd',
                                          'gwhhjdfmvnpjaouh')) THEN 1 ELSE 0
           END) AS contract_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('oflwqlzkgvyvhltd',
                                          'gwhhjdfmvnpjaouh')) THEN EXTRACT(EPOCH
                                                                            FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS contract_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('ejknnzgmqlepvxuy',
                                          'gbjnaljcxrmlvpwo')) THEN 1 ELSE 0
           END) AS coupon_open_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('ejknnzgmqlepvxuy',
                                          'gbjnaljcxrmlvpwo')) THEN EXTRACT(EPOCH
                                                                            FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS coupon_open_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('dmadzxixvpamlgpg',
                                          'mpjlvbjrygzfqxvo')) THEN 1 ELSE 0
           END) AS coupon_confirm_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('dmadzxixvpamlgpg',
                                          'mpjlvbjrygzfqxvo')) THEN EXTRACT(EPOCH
                                                                            FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS coupon_confirm_epoch,
       SUM(CASE
               WHEN (event_type='page_view'
                     AND page_type='page_view_in'
                     AND page_base='iqsvfjcxwpqtsrbj') THEN 1 ELSE 0
           END) AS coupon_page_n,
       MIN(CASE
               WHEN (event_type='page_view'
                     AND page_type='page_view_in'
                     AND page_base='iqsvfjcxwpqtsrbj') THEN EXTRACT(EPOCH
                                                                    FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS coupon_page_epoch
FROM RAW
GROUP BY user_id,d;

-- ======================================================================
-- behavior_new_prestart_history.sql
-- ======================================================================
-- Read-only source SQL; bound parameters supplied by extraction program.

SELECT user_id,MIN(event_time) AS first_active_time,MAX(event_time) AS last_active_time,
       COUNT(DISTINCT event_date) AS active_days,COUNT(*) AS logs
FROM wangchuanliang.user_behavior_track_record
WHERE event_date>=DATE '2025-11-01'
    AND event_date<DATE '2026-05-18'
    AND event_time>=TIMESTAMP '2025-11-01'
    AND event_time<TIMESTAMP '2026-05-18'
    AND user_id IN
        (SELECT unnest(%(users)s::bigint[]))
GROUP BY user_id;

-- ======================================================================
-- coupon_catalog.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT *
FROM wangchuanliang.coupon_cat;

-- ======================================================================
-- coupon_daily_allocation.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT coupon_id::text AS coupon_id,create_date::text AS send_date, expire_date-create_date+1 AS valid_days,
       COUNT(*) AS coupons, COUNT(DISTINCT user_id) AS users,
       SUM(CASE WHEN real_use_amount>0 THEN 1 ELSE 0
           END) AS used_coupons
FROM wangchuanliang.coupon_user_copy
WHERE TYPE=3
    AND coupon_id NOT IN (126,149)
    AND NOT (user_id = ANY(%(__excluded_user_ids)s::bigint[]))
    AND create_date>=DATE '2026-06-01'
    AND create_date<DATE '2026-11-04'
GROUP BY coupon_id,create_date,expire_date-create_date+1
ORDER BY create_date,coupon_id;

-- ======================================================================
-- coupon_instance_selection_daily.sql
-- ======================================================================
-- Read-only source SQL; bound parameters supplied by extraction program.
WITH EVENTS AS
    (SELECT user_id,event_time,event_date,split_part(element_id,
                                              '_', 1) AS event_base,
            SUBSTRING(element_id
                      FROM POSITION('_' IN element_id)+1) AS coupon_no
     FROM wangchuanliang.user_behavior_track_record
     WHERE event_date>=DATE '2026-06-01'
         AND event_date<DATE '2026-11-04'
         AND event_time>=TIMESTAMP '2026-06-01'
         AND event_time<TIMESTAMP '2026-11-04'
         AND event_type='element_click'
         AND user_id IN
             (SELECT unnest(%(users)s::bigint[]))
         AND split_part(element_id, '_', 1) IN ('boxyvbuxjvvehiiq','osuxshhfbtlprnip','vrnfgqufsxosxwgp',
                                                'vcicilykcblxxksh')), coupons AS
    (SELECT user_id,TRIM(coupon_no) AS coupon_no,coupon_id,create_date,expire_date
     FROM wangchuanliang.coupon_user_copy
     WHERE user_id IN
             (SELECT unnest(%(users)s::bigint[]))
         AND NOT (user_id = ANY(%(__excluded_user_ids)s::bigint[]))
         AND TYPE=3
         AND coupon_id IN(119,124,153,157)
         AND create_date>=DATE '2026-06-01'
         AND create_date<DATE '2026-11-01')
SELECT e.user_id,c.coupon_no,c.coupon_id,c.create_date,c.expire_date, e.event_date,e.event_base,
       COUNT(*) AS logs, MIN(EXTRACT(EPOCH
                                     FROM e.event_time AT TIME ZONE 'AMERICA/BELIZE')) AS first_epoch,
       MAX(EXTRACT(EPOCH
                   FROM e.event_time AT TIME ZONE 'AMERICA/BELIZE')) AS last_epoch
FROM EVENTS e
JOIN coupons c ON e.user_id=c.user_id
AND e.coupon_no=c.coupon_no
WHERE e.event_time>=c.create_date::timestamp
    AND e.event_date<c.create_date+15
GROUP BY e.user_id,c.coupon_no,c.coupon_id,c.create_date,c.expire_date,e.event_date,e.event_base;

-- ======================================================================
-- coupon_selection_suffix_probe.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT split_part(element_id, '_', 1) AS event_base,
       CASE
           WHEN POSITION('_' IN element_id)>0 THEN SUBSTRING(element_id
                                                             FROM POSITION('_' IN element_id)+1) ELSE ''
       END AS suffix, COUNT(*) AS EVENTS,COUNT(DISTINCT user_id) AS users,MIN(event_time) AS first_time,
       MAX(event_time) AS last_time
FROM wangchuanliang.user_behavior_track_record
WHERE event_date>=DATE '2026-10-23'
    AND event_date<DATE '2026-11-04'
    AND event_type='element_click'
    AND NOT (user_id = ANY(%(__excluded_user_ids)s::bigint[]))
    AND split_part(element_id, '_', 1) IN ('boxyvbuxjvvehiiq','osuxshhfbtlprnip','njczumqdckrtekmt',
                                           'hpbbbamiacefkwgl','vrnfgqufsxosxwgp','vcicilykcblxxksh')
GROUP BY split_part(element_id, '_', 1),
         CASE
             WHEN POSITION('_' IN element_id)>0 THEN SUBSTRING(element_id
                                                               FROM POSITION('_' IN element_id)+1) ELSE ''
         END
ORDER BY COUNT(*) DESC;

-- ======================================================================
-- credit_histories.sql
-- ======================================================================
-- Read-only source SQL; bound parameters supplied by extraction program.
WITH r AS
    (SELECT serial_id,MIN(recycle_type) AS recycle_type,
            COUNT(DISTINCT recycle_type) AS recycle_versions
     FROM wangchuanliang.side_recycle_type_copy
     GROUP BY serial_id)
SELECT v.user_id,v.serial_id,v.vir_unix,v.vir_date,v.vir_version,v.vir_rnb, v.is_pass1,
       v.is_can_apply,v.loan_type_code,v.max_credit_apply_amt, v.total_term,v.risk_product,r.recycle_type,
       r.recycle_versions
FROM wangchuanliang.order_vir_f_copy v
LEFT JOIN r ON r.serial_id=v.serial_id
WHERE v.user_id IN
        (SELECT unnest(%(users)s::bigint[]))
    AND v.vir_date>=DATE '2025-01-01'
    AND v.vir_date<%(end)s::date
    AND v.vir_unix>0;

-- ======================================================================
-- historical_extra_all_issue_histories.sql
-- ======================================================================
-- Read-only source SQL; bound parameters supplied by extraction program.
-- Read-only source SQL; bound parameters supplied by extraction program.

SELECT user_id,serial_id,coupon_id,TRIM(coupon_no) AS coupon_no, TYPE,amount,real_use_amount,
       used_date,create_date,expire_date
FROM wangchuanliang.coupon_user_copy
WHERE user_id IN
        (SELECT unnest(%(users)s::bigint[]))
    AND create_date>=DATE '2026-05-01'
    AND create_date<%(end)s::date;

;

-- ======================================================================
-- historical_extra_behavior_legacy.sql
-- ======================================================================
-- Read-only source SQL; bound parameters supplied by extraction program.
WITH RAW AS
    (SELECT user_id,create_date AS d,create_time AS t,create_unix,event_type,props_id,
            event_start_time,event_end_time
     FROM wangchuanliang.event_track_record
     WHERE create_date>=%(start)s::date
         AND create_date<%(end)s::date
         AND create_time>=%(start)s::timestamp
         AND create_time<%(end)s::timestamp
         AND user_id IN
             (SELECT unnest(%(users)s::bigint[])))
SELECT user_id, d, COUNT(*) AS logs,
       MIN(EXTRACT(EPOCH
                   FROM t AT TIME ZONE 'AMERICA/BELIZE')) AS first_active_epoch, MAX(EXTRACT(EPOCH
                                                                                             FROM t AT TIME ZONE 'AMERICA/BELIZE')) AS last_active_epoch,
       SUM(CASE WHEN t::date<>d THEN 1 ELSE 0
           END) AS date_mismatch_n,
       SUM(CASE
               WHEN event_end_time>0
                    AND ABS(event_end_time/1000.0-EXTRACT(EPOCH
                                                          FROM t AT TIME ZONE 'AMERICA/BELIZE'))>86400 THEN 1 ELSE 0
           END) AS device_clock_far_n, SUM(CASE WHEN (event_type='app_start') THEN 1 ELSE 0
                                           END) AS app_start_n,
       MIN(CASE
               WHEN (event_type='app_start') THEN EXTRACT(EPOCH
                                                          FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS app_start_epoch,
       SUM(CASE
               WHEN (event_type='page_view_in'
                     AND props_id IN ('Loan_newpage',
                                      'Loan_newpage_select')) THEN 1 ELSE 0
           END) AS loan_entry_n,
       MIN(CASE
               WHEN (event_type='page_view_in'
                     AND props_id IN ('Loan_newpage',
                                      'Loan_newpage_select')) THEN EXTRACT(EPOCH
                                                                           FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS loan_entry_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND props_id IN ('Loan_newconfirm',
                                      'Loan_newconfirm_select')) THEN 1 ELSE 0
           END) AS submit_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND props_id IN ('Loan_newconfirm',
                                      'Loan_newconfirm_select')) THEN EXTRACT(EPOCH
                                                                              FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS submit_epoch,
       SUM(CASE
               WHEN (props_id IN ('amount_modification',
                                  'loan_form_loan_amount_selectionn_new',
                                  'loan_form_loan_amount_selectionn_new_select')) THEN 1 ELSE 0
           END) AS amount_n,
       MIN(CASE
               WHEN (props_id IN ('amount_modification',
                                  'loan_form_loan_amount_selectionn_new',
                                  'loan_form_loan_amount_selectionn_new_select')) THEN EXTRACT(EPOCH
                                                                                               FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS amount_epoch,
       SUM(CASE
               WHEN (props_id IN ('loan_form_term_selection_new',
                                  'loan_form_term_selection_new_select')) THEN 1 ELSE 0
           END) AS term_n,
       MIN(CASE
               WHEN (props_id IN ('loan_form_term_selection_new',
                                  'loan_form_term_selection_new_select')) THEN EXTRACT(EPOCH
                                                                                       FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS term_epoch,
       SUM(CASE
               WHEN (props_id IN ('Loan_plan_newdetails',
                                  'Loan_plan_newdetails_select')) THEN 1 ELSE 0
           END) AS plan_n,
       MIN(CASE
               WHEN (props_id IN ('Loan_plan_newdetails',
                                  'Loan_plan_newdetails_select')) THEN EXTRACT(EPOCH
                                                                               FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS plan_epoch,
       SUM(CASE
               WHEN (props_id IN ('Loan_contract_newdetails',
                                  'Loan_contract_newdetails_select')) THEN 1 ELSE 0
           END) AS contract_n,
       MIN(CASE
               WHEN (props_id IN ('Loan_contract_newdetails',
                                  'Loan_contract_newdetails_select')) THEN EXTRACT(EPOCH
                                                                                   FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS contract_epoch,
       SUM(CASE
               WHEN (props_id IN ('Order_coupons_page',
                                  'Order_coupons_page_select')) THEN 1 ELSE 0
           END) AS coupon_open_n,
       MIN(CASE
               WHEN (props_id IN ('Order_coupons_page',
                                  'Order_coupons_page_select')) THEN EXTRACT(EPOCH
                                                                             FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS coupon_open_epoch,
       SUM(CASE
               WHEN (props_id IN ('Order_coupons_confirm',
                                  'Order_coupons_confirm_select')) THEN 1 ELSE 0
           END) AS coupon_confirm_n,
       MIN(CASE
               WHEN (props_id IN ('Order_coupons_confirm',
                                  'Order_coupons_confirm_select')) THEN EXTRACT(EPOCH
                                                                                FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS coupon_confirm_epoch,
       SUM(CASE
               WHEN (props_id IN ('Order_coupons_page',
                                  'Order_coupons_page_select')) THEN 1 ELSE 0
           END) AS coupon_page_n,
       MIN(CASE
               WHEN (props_id IN ('Order_coupons_page',
                                  'Order_coupons_page_select')) THEN EXTRACT(EPOCH
                                                                             FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS coupon_page_epoch
FROM RAW
GROUP BY user_id,d;

-- ======================================================================
-- historical_extra_behavior_new.sql
-- ======================================================================
-- Read-only source SQL; bound parameters supplied by extraction program.
WITH RAW AS
    (SELECT user_id,event_date AS d,event_time AS t,event_unix,event_type,page_type,element_type,
            split_part(page_id, '_', 1) AS page_base,split_part(element_id,
                                                         '_', 1) AS element_base
     FROM wangchuanliang.user_behavior_track_record
     WHERE event_date>=%(start)s::date
         AND event_date<%(end)s::date
         AND event_time>=%(start)s::timestamp
         AND event_time<%(end)s::timestamp
         AND user_id IN
             (SELECT unnest(%(users)s::bigint[])))
SELECT user_id, d, COUNT(*) AS logs,
       MIN(EXTRACT(EPOCH
                   FROM t AT TIME ZONE 'AMERICA/BELIZE')) AS first_active_epoch, MAX(EXTRACT(EPOCH
                                                                                             FROM t AT TIME ZONE 'AMERICA/BELIZE')) AS last_active_epoch,
       SUM(CASE WHEN t::date<>d THEN 1 ELSE 0
           END) AS date_mismatch_n,
       SUM(CASE
               WHEN ABS(event_unix/1000.0-EXTRACT(EPOCH
                                                  FROM t AT TIME ZONE 'AMERICA/BELIZE'))>1 THEN 1 ELSE 0
           END) AS epoch_mismatch_n, SUM(CASE WHEN (event_type='app_start') THEN 1 ELSE 0
                                         END) AS app_start_n,
       MIN(CASE
               WHEN (event_type='app_start') THEN EXTRACT(EPOCH
                                                          FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS app_start_epoch,
       SUM(CASE
               WHEN (event_type='page_view'
                     AND page_type='page_view_in'
                     AND page_base IN ('xyrsaqxpwmedzlsm',
                                       'vdecaucgiowzpoeh')) THEN 1 ELSE 0
           END) AS loan_entry_n,
       MIN(CASE
               WHEN (event_type='page_view'
                     AND page_type='page_view_in'
                     AND page_base IN ('xyrsaqxpwmedzlsm',
                                       'vdecaucgiowzpoeh')) THEN EXTRACT(EPOCH
                                                                         FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS loan_entry_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('hfmgyiwihoavrqzv',
                                          'udopwuxjursbmvcm')) THEN 1 ELSE 0
           END) AS submit_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('hfmgyiwihoavrqzv',
                                          'udopwuxjursbmvcm')) THEN EXTRACT(EPOCH
                                                                            FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS submit_epoch,
       SUM(CASE
               WHEN ((event_type='text_change'
                      AND element_type='editing'
                      AND element_base='gbyukfclsrdmxaon')
                     OR (event_type='slider_change'
                         AND element_base='jrocyutivyeqdxrx')
                     OR (event_type='element_click'
                         AND element_base IN ('xhwhgrqsxqkfwpoj',
                                              'saynozmunkdceoya', 'gwexsotywwgsvrgv'))) THEN 1 ELSE 0
           END) AS amount_n,
       MIN(CASE
               WHEN ((event_type='text_change'
                      AND element_type='editing'
                      AND element_base='gbyukfclsrdmxaon')
                     OR (event_type='slider_change'
                         AND element_base='jrocyutivyeqdxrx')
                     OR (event_type='element_click'
                         AND element_base IN ('xhwhgrqsxqkfwpoj',
                                              'saynozmunkdceoya', 'gwexsotywwgsvrgv'))) THEN EXTRACT(EPOCH
                                                                                                     FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS amount_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('zfmdsmjpuslrcchx',
                                          'denkhhpvgqgwethb', 'rdapttngylaiuvth',
                                          'gfelmnelmexljaiv')) THEN 1 ELSE 0
           END) AS term_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('zfmdsmjpuslrcchx',
                                          'denkhhpvgqgwethb', 'rdapttngylaiuvth',
                                          'gfelmnelmexljaiv')) THEN EXTRACT(EPOCH
                                                                            FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS term_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('omuwccqjaovwdwyx',
                                          'gemkzaypdtcrwdkg')) THEN 1 ELSE 0
           END) AS plan_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('omuwccqjaovwdwyx',
                                          'gemkzaypdtcrwdkg')) THEN EXTRACT(EPOCH
                                                                            FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS plan_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('oflwqlzkgvyvhltd',
                                          'gwhhjdfmvnpjaouh')) THEN 1 ELSE 0
           END) AS contract_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('oflwqlzkgvyvhltd',
                                          'gwhhjdfmvnpjaouh')) THEN EXTRACT(EPOCH
                                                                            FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS contract_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('ejknnzgmqlepvxuy',
                                          'gbjnaljcxrmlvpwo')) THEN 1 ELSE 0
           END) AS coupon_open_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('ejknnzgmqlepvxuy',
                                          'gbjnaljcxrmlvpwo')) THEN EXTRACT(EPOCH
                                                                            FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS coupon_open_epoch,
       SUM(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('dmadzxixvpamlgpg',
                                          'mpjlvbjrygzfqxvo')) THEN 1 ELSE 0
           END) AS coupon_confirm_n,
       MIN(CASE
               WHEN (event_type='element_click'
                     AND element_base IN ('dmadzxixvpamlgpg',
                                          'mpjlvbjrygzfqxvo')) THEN EXTRACT(EPOCH
                                                                            FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS coupon_confirm_epoch,
       SUM(CASE
               WHEN (event_type='page_view'
                     AND page_type='page_view_in'
                     AND page_base='iqsvfjcxwpqtsrbj') THEN 1 ELSE 0
           END) AS coupon_page_n,
       MIN(CASE
               WHEN (event_type='page_view'
                     AND page_type='page_view_in'
                     AND page_base='iqsvfjcxwpqtsrbj') THEN EXTRACT(EPOCH
                                                                    FROM t AT TIME ZONE 'AMERICA/BELIZE')
           END) AS coupon_page_epoch
FROM RAW
GROUP BY user_id,d;

-- ======================================================================
-- historical_extra_credit_histories.sql
-- ======================================================================
-- Read-only source SQL; bound parameters supplied by extraction program.
-- Read-only source SQL; bound parameters supplied by extraction program.
WITH r AS
    (SELECT serial_id,MIN(recycle_type) AS recycle_type,
            COUNT(DISTINCT recycle_type) AS recycle_versions
     FROM wangchuanliang.side_recycle_type_copy
     GROUP BY serial_id)
SELECT v.user_id,v.serial_id,v.vir_unix,v.vir_date,v.vir_version,v.vir_rnb, v.is_pass1,
       v.is_can_apply,v.loan_type_code,v.max_credit_apply_amt, v.total_term,v.risk_product,r.recycle_type,
       r.recycle_versions
FROM wangchuanliang.order_vir_f_copy v
LEFT JOIN r ON r.serial_id=v.serial_id
WHERE v.user_id IN
        (SELECT unnest(%(users)s::bigint[]))
    AND v.vir_date>=DATE '2025-01-01'
    AND v.vir_date<%(end)s::date
    AND v.vir_unix>0;

;

-- ======================================================================
-- historical_extra_loan_histories.sql
-- ======================================================================
-- Read-only source SQL; bound parameters supplied by extraction program.
-- Read-only source SQL; bound parameters supplied by extraction program.

SELECT user_id,serial_id,reg_date,loan_day,product_no,loan_type, apply_unix,apply_time,apply_date,
       apply_amt, remit_unix,remit_time,remit_date,remit_amt,is_remit, due_unix,due_time,due_date,
       repaid_time,repaid_date,is_repaid,repaid_amt, pre_amt,post_amt,total_term,overdue_days,
       loan_status_code, apply_rnb,remit_succ_rnb,loan_coupon_amt,repaid_coupon_amt,discount_amount
FROM wangchuanliang.order_loan_f_v2_copy
WHERE user_id IN
        (SELECT unnest(%(users)s::bigint[]))
    AND apply_time>=TIMESTAMP '2000-01-01'
    AND apply_time<%(end)s::timestamp;

;

-- ======================================================================
-- historical_extra_risk_score_histories.sql
-- ======================================================================
-- Read-only source SQL; bound parameters supplied by extraction program.
-- Read-only source SQL; bound parameters supplied by extraction program.

SELECT user_id,serial_id, kabybxgboost363dpd7cre AS score363, kabybxgboost405apd7crecyc AS score405,
       kabybmerge410fpd7cre AS score410, kabybmerge410fpd7cyc AS score410cyc
FROM wangchuanliang.model_result_copy
WHERE user_id IN
        (SELECT unnest(%(users)s::bigint[]));

;

-- ======================================================================
-- historical_high_discount_test_0708.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT "churn_user_id","ab_group","interest_type","max_repaid_date","churned_days","reg_date","apply_rnb",
       "remit_rnb","remit_amt","als","max_over_due","overdue_cnt","overdue_term_cnt","vir_amt",
       "apply_amt","utilization_rate","last_remit_utilization_rate","high_interest_rate",
       "last_remit_product_no","last_remit_interest_type","last_remit_total_term","last_remit_overdue_days",
       "last_vir_amt","last_vir_risk_product","last_vir_total_term","active_days_cnt","last_active_date",
       "days_since_last_active","newpage_cnt","newconfirm_cnt","amount_selection_cnt","term_selection_cnt",
       "plan_newdetails_cnt","contract_newdetails_cnt","purpose_newdetails_cnt","coupons_page_cnt",
       "coupons_confirm_cnt","send_coupon_d_cnt","send_coupon_r_cnt","last_send_coupon_date",
       "days_since_last_send_coupon"
FROM wangchuanliang.high_discount_test_0708
WHERE churn_user_id IS NOT NULL
    AND NOT (churn_user_id = ANY(%(__excluded_user_ids)s::bigint[]));

-- ======================================================================
-- historical_no_apply_0716_0721_30pct.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT "churn_user_id","max_repaid_date","ab_group","churn_days","reg_date","total_apply_rnb",
       "total_remit_rnb","total_remit_amt","als","max_over_due","overdue_cnt","overdue_term_cnt",
       "total_vir_amt","total_apply_amt","utilization_rate","last_remit_utilization_rate",
       "high_interest_rate","last_remit_product_no","last_remit_interest_type","last_remit_total_term",
       "last_remit_overdue_days","last_vir_amt","last_vir_risk_product","last_vir_total_term","active_days_cnt",
       "last_active_date","days_since_last_active","newpage_cnt","newconfirm_cnt","amount_selection_cnt",
       "term_selection_cnt","plan_newdetails_cnt","contract_newdetails_cnt","purpose_newdetails_cnt",
       "coupons_page_cnt","coupons_confirm_cnt","send_coupon_d_cnt","send_coupon_r_cnt",
       "last_send_coupon_date","days_since_last_send_coupon"
FROM wangchuanliang.no_apply_0716_0721_30pct
WHERE churn_user_id IS NOT NULL
    AND NOT (churn_user_id = ANY(%(__excluded_user_ids)s::bigint[]));

-- ======================================================================
-- historical_no_apply_0717_0722_30pct.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT "churn_user_id","max_repaid_date","ab_group","churn_days","reg_date","total_apply_rnb",
       "total_remit_rnb","total_remit_amt","als","max_over_due","overdue_cnt","overdue_term_cnt",
       "total_vir_amt","total_apply_amt","utilization_rate","last_remit_utilization_rate",
       "high_interest_rate","last_remit_product_no","last_remit_interest_type","last_remit_total_term",
       "last_remit_overdue_days","last_vir_amt","last_vir_risk_product","last_vir_total_term","active_days_cnt",
       "last_active_date","days_since_last_active","newpage_cnt","newconfirm_cnt","amount_selection_cnt",
       "term_selection_cnt","plan_newdetails_cnt","contract_newdetails_cnt","purpose_newdetails_cnt",
       "coupons_page_cnt","coupons_confirm_cnt","send_coupon_d_cnt","send_coupon_r_cnt",
       "last_send_coupon_date","days_since_last_send_coupon"
FROM wangchuanliang.no_apply_0717_0722_30pct
WHERE churn_user_id IS NOT NULL
    AND NOT (churn_user_id = ANY(%(__excluded_user_ids)s::bigint[]));

-- ======================================================================
-- historical_no_apply_0718_0723_30pct.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT "churn_user_id","max_repaid_date","ab_group","churn_days","reg_date","total_apply_rnb",
       "total_remit_rnb","total_remit_amt","als","max_over_due","overdue_cnt","overdue_term_cnt",
       "total_vir_amt","total_apply_amt","utilization_rate","last_remit_utilization_rate",
       "high_interest_rate","last_remit_product_no","last_remit_interest_type","last_remit_total_term",
       "last_remit_overdue_days","last_vir_amt","last_vir_risk_product","last_vir_total_term","active_days_cnt",
       "last_active_date","days_since_last_active","newpage_cnt","newconfirm_cnt","amount_selection_cnt",
       "term_selection_cnt","plan_newdetails_cnt","contract_newdetails_cnt","purpose_newdetails_cnt",
       "coupons_page_cnt","coupons_confirm_cnt","send_coupon_d_cnt","send_coupon_r_cnt",
       "last_send_coupon_date","days_since_last_send_coupon"
FROM wangchuanliang.no_apply_0718_0723_30pct
WHERE churn_user_id IS NOT NULL
    AND NOT (churn_user_id = ANY(%(__excluded_user_ids)s::bigint[]));

-- ======================================================================
-- historical_no_apply_0719_0724_30pct.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT "churn_user_id","max_repaid_date","ab_group","churn_days","reg_date","total_apply_rnb",
       "total_remit_rnb","total_remit_amt","als","max_over_due","overdue_cnt","overdue_term_cnt",
       "total_vir_amt","total_apply_amt","utilization_rate","last_remit_utilization_rate",
       "high_interest_rate","last_remit_product_no","last_remit_interest_type","last_remit_total_term",
       "last_remit_overdue_days","last_vir_amt","last_vir_risk_product","last_vir_total_term","active_days_cnt",
       "last_active_date","days_since_last_active","newpage_cnt","newconfirm_cnt","amount_selection_cnt",
       "term_selection_cnt","plan_newdetails_cnt","contract_newdetails_cnt","purpose_newdetails_cnt",
       "coupons_page_cnt","coupons_confirm_cnt","send_coupon_d_cnt","send_coupon_r_cnt",
       "last_send_coupon_date","days_since_last_send_coupon"
FROM wangchuanliang.no_apply_0719_0724_30pct
WHERE churn_user_id IS NOT NULL
    AND NOT (churn_user_id = ANY(%(__excluded_user_ids)s::bigint[]));

-- ======================================================================
-- historical_no_apply_0730_0804_30pct.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT "churn_user_id","ab_group","max_repaid_date","churn_days","reg_date","total_apply_rnb",
       "total_remit_rnb","total_remit_amt","als","max_over_due","overdue_cnt","overdue_term_cnt",
       "total_vir_amt","total_apply_amt","utilization_rate","last_remit_utilization_rate",
       "high_interest_rate","last_remit_product_no","last_remit_interest_type","last_remit_total_term",
       "last_remit_overdue_days","last_vir_amt","last_vir_risk_product","last_vir_total_term","active_days_cnt",
       "last_active_date","days_since_last_active","newpage_cnt","newconfirm_cnt","amount_selection_cnt",
       "term_selection_cnt","plan_newdetails_cnt","contract_newdetails_cnt","purpose_newdetails_cnt",
       "coupons_page_cnt","coupons_confirm_cnt","send_coupon_d_cnt","send_coupon_r_cnt",
       "last_send_coupon_date","days_since_last_send_coupon"
FROM wangchuanliang.no_apply_0730_0804_30pct
WHERE churn_user_id IS NOT NULL
    AND NOT (churn_user_id = ANY(%(__excluded_user_ids)s::bigint[]));

-- ======================================================================
-- historical_no_apply_0731_0805_30pct.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT "churn_user_id","ab_group","max_repaid_date","churn_days","reg_date","total_apply_rnb",
       "total_remit_rnb","total_remit_amt","als","max_over_due","overdue_cnt","overdue_term_cnt",
       "total_vir_amt","total_apply_amt","utilization_rate","last_remit_utilization_rate",
       "high_interest_rate","last_remit_product_no","last_remit_interest_type","last_remit_total_term",
       "last_remit_overdue_days","last_vir_amt","last_vir_risk_product","last_vir_total_term","active_days_cnt",
       "last_active_date","days_since_last_active","newpage_cnt","newconfirm_cnt","amount_selection_cnt",
       "term_selection_cnt","plan_newdetails_cnt","contract_newdetails_cnt","purpose_newdetails_cnt",
       "coupons_page_cnt","coupons_confirm_cnt","send_coupon_d_cnt","send_coupon_r_cnt",
       "last_send_coupon_date","days_since_last_send_coupon"
FROM wangchuanliang.no_apply_0731_0805_30pct
WHERE churn_user_id IS NOT NULL
    AND NOT (churn_user_id = ANY(%(__excluded_user_ids)s::bigint[]));

-- ======================================================================
-- historical_no_apply_0801_0806_30pct.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT "churn_user_id","ab_group","max_repaid_date","churn_days","reg_date","total_apply_rnb",
       "total_remit_rnb","total_remit_amt","als","max_over_due","overdue_cnt","overdue_term_cnt",
       "total_vir_amt","total_apply_amt","utilization_rate","last_remit_utilization_rate",
       "high_interest_rate","last_remit_product_no","last_remit_interest_type","last_remit_total_term",
       "last_remit_overdue_days","last_vir_amt","last_vir_risk_product","last_vir_total_term","active_days_cnt",
       "last_active_date","days_since_last_active","newpage_cnt","newconfirm_cnt","amount_selection_cnt",
       "term_selection_cnt","plan_newdetails_cnt","contract_newdetails_cnt","purpose_newdetails_cnt",
       "coupons_page_cnt","coupons_confirm_cnt","send_coupon_d_cnt","send_coupon_r_cnt",
       "last_send_coupon_date","days_since_last_send_coupon"
FROM wangchuanliang.no_apply_0801_0806_30pct
WHERE churn_user_id IS NOT NULL
    AND NOT (churn_user_id = ANY(%(__excluded_user_ids)s::bigint[]));

-- ======================================================================
-- historical_no_apply_0802_0807_30pct.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT "churn_user_id","ab_group","max_repaid_date","churn_days","reg_date","total_apply_rnb",
       "total_remit_rnb","total_remit_amt","als","max_over_due","overdue_cnt","overdue_term_cnt",
       "total_vir_amt","total_apply_amt","utilization_rate","last_remit_utilization_rate",
       "high_interest_rate","last_remit_product_no","last_remit_interest_type","last_remit_total_term",
       "last_remit_overdue_days","last_vir_amt","last_vir_risk_product","last_vir_total_term","active_days_cnt",
       "last_active_date","days_since_last_active","newpage_cnt","newconfirm_cnt","amount_selection_cnt",
       "term_selection_cnt","plan_newdetails_cnt","contract_newdetails_cnt","purpose_newdetails_cnt",
       "coupons_page_cnt","coupons_confirm_cnt","send_coupon_d_cnt","send_coupon_r_cnt",
       "last_send_coupon_date","days_since_last_send_coupon"
FROM wangchuanliang.no_apply_0802_0807_30pct
WHERE churn_user_id IS NOT NULL
    AND NOT (churn_user_id = ANY(%(__excluded_user_ids)s::bigint[]));

-- ======================================================================
-- historical_no_apply_0813_0818_30pct.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT "churn_user_id","ab_group","max_repaid_date","churn_days","reg_date","total_apply_rnb",
       "total_remit_rnb","total_remit_amt","als","max_over_due","overdue_cnt","overdue_term_cnt",
       "total_vir_amt","total_apply_amt","utilization_rate","last_remit_utilization_rate",
       "high_interest_rate","last_remit_product_no","last_remit_interest_type","last_remit_total_term",
       "last_remit_overdue_days","last_vir_amt","last_vir_risk_product","last_vir_total_term","active_days_cnt",
       "last_active_date","days_since_last_active","newpage_cnt","newconfirm_cnt","amount_selection_cnt",
       "term_selection_cnt","plan_newdetails_cnt","contract_newdetails_cnt","purpose_newdetails_cnt",
       "coupons_page_cnt","coupons_confirm_cnt","send_coupon_d_cnt","send_coupon_r_cnt",
       "last_send_coupon_date","days_since_last_send_coupon"
FROM wangchuanliang.no_apply_0813_0818_30pct
WHERE churn_user_id IS NOT NULL
    AND NOT (churn_user_id = ANY(%(__excluded_user_ids)s::bigint[]));

-- ======================================================================
-- historical_no_apply_0815_0820_30pct.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT "churn_user_id","ab_group","max_repaid_date","churn_days","reg_date","total_apply_rnb",
       "total_remit_rnb","total_remit_amt","als","max_over_due","overdue_cnt","overdue_term_cnt",
       "total_vir_amt","total_apply_amt","utilization_rate","last_remit_utilization_rate",
       "high_interest_rate","last_remit_product_no","last_remit_interest_type","last_remit_total_term",
       "last_remit_overdue_days","last_vir_amt","last_vir_risk_product","last_vir_total_term","active_days_cnt",
       "last_active_date","days_since_last_active","newpage_cnt","newconfirm_cnt","amount_selection_cnt",
       "term_selection_cnt","plan_newdetails_cnt","contract_newdetails_cnt","purpose_newdetails_cnt",
       "coupons_page_cnt","coupons_confirm_cnt","send_coupon_d_cnt","send_coupon_r_cnt",
       "last_send_coupon_date","days_since_last_send_coupon"
FROM wangchuanliang.no_apply_0815_0820_30pct
WHERE churn_user_id IS NOT NULL
    AND NOT (churn_user_id = ANY(%(__excluded_user_ids)s::bigint[]));

-- ======================================================================
-- historical_no_apply_0816_0821_30pct.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT "churn_user_id","ab_group","max_repaid_date","churn_days","reg_date","total_apply_rnb",
       "total_remit_rnb","total_remit_amt","als","max_over_due","overdue_cnt","overdue_term_cnt",
       "total_vir_amt","total_apply_amt","utilization_rate","last_remit_utilization_rate",
       "high_interest_rate","last_remit_product_no","last_remit_interest_type","last_remit_total_term",
       "last_remit_overdue_days","last_vir_amt","last_vir_risk_product","last_vir_total_term","active_days_cnt",
       "last_active_date","days_since_last_active","newpage_cnt","newconfirm_cnt","amount_selection_cnt",
       "term_selection_cnt","plan_newdetails_cnt","contract_newdetails_cnt","purpose_newdetails_cnt",
       "coupons_page_cnt","coupons_confirm_cnt","send_coupon_d_cnt","send_coupon_r_cnt",
       "last_send_coupon_date","days_since_last_send_coupon"
FROM wangchuanliang.no_apply_0816_0821_30pct
WHERE churn_user_id IS NOT NULL
    AND NOT (churn_user_id = ANY(%(__excluded_user_ids)s::bigint[]));

-- ======================================================================
-- historical_no_apply_0821_0826_30pct.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT "churn_user_id","ab_group","max_repaid_date","churn_days","reg_date","total_apply_rnb",
       "total_remit_rnb","total_remit_amt","als","max_over_due","overdue_cnt","overdue_term_cnt",
       "total_vir_amt","total_apply_amt","utilization_rate","last_remit_utilization_rate",
       "high_interest_rate","last_remit_product_no","last_remit_interest_type","last_remit_total_term",
       "last_remit_overdue_days","last_vir_amt","last_vir_risk_product","last_vir_total_term","active_days_cnt",
       "last_active_date","days_since_last_active","newpage_cnt","newconfirm_cnt","amount_selection_cnt",
       "term_selection_cnt","plan_newdetails_cnt","contract_newdetails_cnt","purpose_newdetails_cnt",
       "coupons_page_cnt","coupons_confirm_cnt","send_coupon_d_cnt","send_coupon_r_cnt",
       "last_send_coupon_date","days_since_last_send_coupon"
FROM wangchuanliang.no_apply_0821_0826_30pct
WHERE churn_user_id IS NOT NULL
    AND NOT (churn_user_id = ANY(%(__excluded_user_ids)s::bigint[]));

-- ======================================================================
-- historical_no_apply_0822_0827_30pct.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT "churn_user_id","ab_group","max_repaid_date","churn_days","reg_date","total_apply_rnb",
       "total_remit_rnb","total_remit_amt","als","max_over_due","overdue_cnt","overdue_term_cnt",
       "total_vir_amt","total_apply_amt","utilization_rate","last_remit_utilization_rate",
       "high_interest_rate","last_remit_product_no","last_remit_interest_type","last_remit_total_term",
       "last_remit_overdue_days","last_vir_amt","last_vir_risk_product","last_vir_total_term","active_days_cnt",
       "last_active_date","days_since_last_active","newpage_cnt","newconfirm_cnt","amount_selection_cnt",
       "term_selection_cnt","plan_newdetails_cnt","contract_newdetails_cnt","purpose_newdetails_cnt",
       "coupons_page_cnt","coupons_confirm_cnt","send_coupon_d_cnt","send_coupon_r_cnt",
       "last_send_coupon_date","days_since_last_send_coupon"
FROM wangchuanliang.no_apply_0822_0827_30pct
WHERE churn_user_id IS NOT NULL
    AND NOT (churn_user_id = ANY(%(__excluded_user_ids)s::bigint[]));

-- ======================================================================
-- historical_no_apply_0823_0828_30pct.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT "churn_user_id","ab_group","max_repaid_date","churn_days","reg_date","total_apply_rnb",
       "total_remit_rnb","total_remit_amt","als","max_over_due","overdue_cnt","overdue_term_cnt",
       "total_vir_amt","total_apply_amt","utilization_rate","last_remit_utilization_rate",
       "high_interest_rate","last_remit_product_no","last_remit_interest_type","last_remit_total_term",
       "last_remit_overdue_days","last_vir_amt","last_vir_risk_product","last_vir_total_term","active_days_cnt",
       "last_active_date","days_since_last_active","newpage_cnt","newconfirm_cnt","amount_selection_cnt",
       "term_selection_cnt","plan_newdetails_cnt","contract_newdetails_cnt","purpose_newdetails_cnt",
       "coupons_page_cnt","coupons_confirm_cnt","send_coupon_d_cnt","send_coupon_r_cnt",
       "last_send_coupon_date","days_since_last_send_coupon"
FROM wangchuanliang.no_apply_0823_0828_30pct
WHERE churn_user_id IS NOT NULL
    AND NOT (churn_user_id = ANY(%(__excluded_user_ids)s::bigint[]));

-- ======================================================================
-- historical_no_apply_0913_0918_30pct.sql
-- ======================================================================
SELECT "churn_user_id","ab_group","max_repaid_date","churn_days","reg_date","total_apply_rnb",
       "total_remit_rnb","total_remit_amt","als","max_over_due","overdue_cnt","overdue_term_cnt",
       "total_vir_amt","total_apply_amt","utilization_rate","last_remit_utilization_rate",
       "high_interest_rate","last_remit_product_no","last_remit_interest_type","last_remit_total_term",
       "last_remit_overdue_days","last_vir_amt","last_vir_risk_product","last_vir_total_term","active_days_cnt",
       "last_active_date","days_since_last_active","newpage_cnt","newconfirm_cnt","amount_selection_cnt",
       "term_selection_cnt","plan_newdetails_cnt","contract_newdetails_cnt","purpose_newdetails_cnt",
       "coupons_page_cnt","coupons_confirm_cnt","send_coupon_d_cnt","send_coupon_r_cnt",
       "last_send_coupon_date","days_since_last_send_coupon","strat","strategy_rule"
FROM wangchuanliang.no_apply_0913_0918_30pct
WHERE churn_user_id IS NOT NULL
    AND NOT (churn_user_id = ANY(%(__excluded_user_ids)s::bigint[]));

-- ======================================================================
-- historical_test_schema.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT TABLE_NAME,COLUMN_NAME,data_type,ordinal_position
FROM information_schema.columns
WHERE table_schema='wangchuanliang'
    AND TABLE_NAME=ANY(%(tables)s)
ORDER BY TABLE_NAME,ordinal_position;

-- ======================================================================
-- historical_test_tables.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT TABLE_NAME
FROM information_schema.tables
WHERE table_schema='wangchuanliang'
    AND (TABLE_NAME LIKE 'no_apply_%%'
         OR TABLE_NAME LIKE '%%0708%%'
         OR TABLE_NAME LIKE '%%0707%%'
         OR TABLE_NAME LIKE '%%test%%')
ORDER BY TABLE_NAME;

-- ======================================================================
-- historical_user_test_verification_0708.sql
-- ======================================================================
SELECT "churn_user_id","utilization_type","user_type","ab_group","max_repaid_date","churn_days",
       "reg_date","total_apply_rnb","total_remit_rnb","total_remit_amt","als","max_over_due",
       "overdue_cnt","overdue_term_cnt","total_vir_amt","total_apply_amt","utilization_rate",
       "last_remit_utilization_rate","high_interest_rate","last_remit_product_no","last_remit_interest_type",
       "last_remit_total_term","last_remit_overdue_days","last_vir_amt","last_vir_risk_product",
       "last_vir_total_term","active_days_cnt","last_active_date","days_since_last_active","newpage_cnt",
       "newconfirm_cnt","amount_selection_cnt","term_selection_cnt","plan_newdetails_cnt",
       "contract_newdetails_cnt","purpose_newdetails_cnt","coupons_page_cnt","coupons_confirm_cnt",
       "send_coupon_d_cnt","send_coupon_r_cnt","last_send_coupon_date","days_since_last_send_coupon"
FROM wangchuanliang.user_test_verification_0708
WHERE churn_user_id IS NOT NULL
    AND NOT (churn_user_id = ANY(%(__excluded_user_ids)s::bigint[]));

-- ======================================================================
-- independent_financial_totals.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT CASE WHEN c.coupon_id IN(119,141,153,163,166) THEN 0.20 WHEN c.coupon_id IN(157,160) THEN 0.30 ELSE 0.40
       END AS dose, c.valid_days,COUNT(*) AS orders,SUM(o.remit_amt) AS funded_amt,
       SUM(o.repaid_amt) AS repaid_amt, SUM(CASE WHEN o.loan_status_code=8 THEN 1 ELSE 0
                                            END) AS overdue_orders,
       SUM(c.real_use_amount) AS coupon_used_amt
FROM wangchuanliang.coupon_use_record c
JOIN wangchuanliang.order_loan_f_v2_copy o ON o.user_id=c.user_id
AND o.serial_id=c.serial_id
WHERE c.coupon_type=3
    AND c.real_use_amount>0
    AND c.coupon_id IN(119,124,141,153,157,160,163,164,166)
    AND c.create_date>=DATE '2026-06-01'
    AND c.create_date<DATE '2026-11-01'
    AND NOT (c.user_id = ANY(%(__excluded_user_ids)s::bigint[]))
    AND o.is_remit=1
    AND o.remit_amt>0
    AND o.due_date<DATE '2026-11-04'
GROUP BY 1,c.valid_days
ORDER BY 1,c.valid_days;

-- ======================================================================
-- independent_inflight_application_state.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.
WITH arr AS
    (SELECT %(users)s::bigint[] AS users, %(serials)s::bigint[] AS serials, %(epochs)s::double precision[] AS epochs), ix AS
    (SELECT GENERATE_SUBSCRIPTS(users, 1) AS i
     FROM arr),
     anchors AS
    (SELECT a.users[x.i] AS user_id,a.serials[x.i] AS serial_id,
            TO_TIMESTAMP(a.epochs[x.i]) AT TIME ZONE 'AMERICA/BELIZE' AS app_time
     FROM arr a
     CROSS JOIN ix x),
     loan AS
    (SELECT o.*,
            CASE
                WHEN (o.is_repaid=1
                      OR o.loan_status_code=7)
                     AND o.repaid_time>=o.remit_time THEN o.repaid_time
            END AS settled_at
     FROM wangchuanliang.order_loan_f_v2_copy o
     WHERE o.user_id=ANY(%(unique_users)s::bigint[])),
     open_loan AS
    (SELECT a.user_id,a.serial_id AS target_serial_id,a.app_time, o.serial_id AS old_serial_id,
            o.due_date,o.remit_time AS old_remit_time
     FROM anchors a
     JOIN loan o ON o.user_id=a.user_id
     AND o.serial_id<>a.serial_id
     AND o.is_remit=1
     AND o.remit_amt>0
     AND o.remit_time>=o.apply_time
     AND o.remit_time<a.app_time
     AND (o.settled_at IS NULL
          OR o.settled_at>a.app_time)),
     late_period AS
    (SELECT DISTINCT o.user_id,o.target_serial_id
     FROM open_loan o
     JOIN wangchuanliang.repayment_plan_v2_copy p ON p.user_id=o.user_id
     AND p.serial_id=o.old_serial_id
     WHERE p.due_date_period<o.app_time::date
         AND NOT (COALESCE((p.is_repaid_period=1
                            OR p.loan_status_code_period=7)
                           AND p.repaid_time_period>=o.old_remit_time
                           AND p.repaid_time_period<=o.app_time, FALSE)))
SELECT a.user_id,a.serial_id,COUNT(o.old_serial_id) AS old_open_n,
       SUM(CASE WHEN o.due_date<a.app_time::date THEN 1 ELSE 0
           END) AS late_whole_n,
       MAX(CASE WHEN l.target_serial_id IS NOT NULL THEN 1 ELSE 0
           END) AS late_period_flag, MAX(n.remit_amt) AS remit_amt,MAX(n.repaid_amt) AS repaid_amt,
       MAX(n.loan_status_code) AS current_order_state
FROM anchors a
LEFT JOIN open_loan o ON o.user_id=a.user_id
AND o.target_serial_id=a.serial_id
LEFT JOIN late_period l ON l.user_id=a.user_id
AND l.target_serial_id=a.serial_id
LEFT JOIN loan n ON n.user_id=a.user_id
AND n.serial_id=a.serial_id
GROUP BY a.user_id,a.serial_id;

-- ======================================================================
-- independent_pilot_baseline_counts.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.
WITH arrays AS
    (SELECT %(ids)s::bigint[] AS ids,%(users)s::bigint[] AS users,%(epochs)s::double precision[] AS epochs), ix AS
    (SELECT generate_subscripts(ids, 1) AS i
     FROM arrays),
     anchors AS
    (SELECT a.ids[x.i] AS episode_id,a.users[x.i] AS user_id,
            TO_TIMESTAMP(a.epochs[x.i]) AT TIME ZONE 'AMERICA/BELIZE' AS anchor
     FROM arrays a
     CROSS JOIN ix x),
     h AS
    (SELECT o.*,
            CASE
                WHEN (o.is_repaid=1
                      OR o.loan_status_code=7)
                     AND o.repaid_time>=o.remit_time THEN o.repaid_time
            END AS settle
     FROM wangchuanliang.order_loan_f_v2_copy o
     WHERE o.user_id=ANY(%(users)s::bigint[])
         AND o.apply_time>=TIMESTAMP '2000-01-01'),
     calc AS
    (SELECT a.episode_id,COUNT(o.serial_id) AS prior_app_n,
            SUM(CASE
                    WHEN o.is_remit=1
                         AND o.remit_amt>0
                         AND o.remit_time>=o.apply_time
                         AND o.remit_time<a.anchor THEN 1 ELSE 0
                END) AS prior_fund_n,
            SUM(CASE
                    WHEN o.is_remit=1
                         AND o.remit_amt>0
                         AND o.remit_time>=o.apply_time
                         AND o.remit_time<a.anchor
                         AND (o.settle IS NULL
                              OR o.settle>a.anchor) THEN 1 ELSE 0
                END) AS open_n,
            SUM(CASE WHEN o.apply_time>=a.anchor-INTERVAL '30 days' THEN 1 ELSE 0
                END) AS prior_apps30
     FROM anchors a
     LEFT JOIN h o ON o.user_id=a.user_id
     AND o.apply_time<a.anchor
     GROUP BY a.episode_id)
SELECT *
FROM calc;

-- ======================================================================
-- legacy_page_dictionary_1023.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT page_name,event_type,COUNT(*) AS logs,COUNT(DISTINCT user_id) AS users,
       MIN(create_time) AS first_time,MAX(create_time) AS last_time, MIN(event_start_time) AS start_min,
       MAX(event_start_time) AS start_max, MIN(event_end_time) AS end_min,MAX(event_end_time) AS end_max
FROM wangchuanliang.event_track_record
WHERE create_date=DATE '2026-10-23'
GROUP BY page_name,event_type;

-- ======================================================================
-- loan_histories.sql
-- ======================================================================
-- Read-only source SQL; bound parameters supplied by extraction program.

SELECT user_id,serial_id,reg_date,loan_day,product_no,loan_type, apply_unix,apply_time,apply_date,
       apply_amt, remit_unix,remit_time,remit_date,remit_amt,is_remit, due_unix,due_time,due_date,
       repaid_time,repaid_date,is_repaid,repaid_amt, pre_amt,post_amt,total_term,overdue_days,
       loan_status_code, apply_rnb,remit_succ_rnb,loan_coupon_amt,repaid_coupon_amt,discount_amount
FROM wangchuanliang.order_loan_f_v2_copy
WHERE user_id IN
        (SELECT unnest(%(users)s::bigint[]))
    AND apply_time>=TIMESTAMP '2000-01-01'
    AND apply_time<%(end)s::timestamp;

-- ======================================================================
-- new_page_dictionary_1023.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT event_type,page_id,COUNT(*) AS logs,COUNT(DISTINCT user_id) AS users
FROM wangchuanliang.user_behavior_track_record
WHERE event_date=DATE '2026-10-23'
GROUP BY event_type,page_id;

-- ======================================================================
-- order_freshness.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT MAX(apply_time) AS last_apply,MAX(remit_time) AS last_remit,MAX(repaid_time) AS last_repaid,
       SUM(CASE WHEN apply_date=DATE '2026-11-03' THEN 1 ELSE 0
           END) AS nov3_apply_n, SUM(CASE WHEN apply_date=DATE '2026-11-04' THEN 1 ELSE 0
                                     END) AS nov4_apply_n
FROM wangchuanliang.order_loan_f_v2_copy
WHERE apply_date>=DATE '2026-11-01';

-- ======================================================================
-- period_outcomes.sql
-- ======================================================================
-- Read-only source SQL; bound parameters supplied by extraction program.

SELECT user_id,serial_id,current_term,total_term, due_date_period,due_time_period,
       repaid_time_period,is_repaid_period, overdue_days_period,loan_status_code_period,apply_amt_period,
       remit_amt_period, repaid_amt_period,expect_repay_amt_period
FROM wangchuanliang.repayment_plan_v2_copy
WHERE user_id IN
        (SELECT unnest(%(users)s::bigint[]))
    AND apply_date>=DATE '2026-06-01'
    AND apply_date<%(end)s::date
    AND is_remit=1
    AND remit_amt>0;

-- ======================================================================
-- periods_before_june.sql
-- ======================================================================
-- Read-only source SQL; bound parameters supplied by extraction program.

SELECT user_id,serial_id,current_term,total_term, due_date_period,due_time_period,
       repaid_time_period,is_repaid_period, overdue_days_period,loan_status_code_period,apply_amt_period,
       remit_amt_period, repaid_amt_period,expect_repay_amt_period
FROM wangchuanliang.repayment_plan_v2_copy
WHERE user_id IN
        (SELECT unnest(%(users)s::bigint[]))
    AND apply_date>=DATE '2000-01-01'
    AND apply_date<DATE '2026-06-01'
    AND is_remit=1
    AND remit_amt>0;

-- ======================================================================
-- recent_tracking_coverage.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT 'new'::text AS SOURCE,event_date::text AS event_date, COUNT(*) AS ROWS,COUNT(DISTINCT user_id) AS users,
       MIN(event_time)::text AS first_time,MAX(event_time)::text AS last_time
FROM wangchuanliang.user_behavior_track_record
WHERE event_date>=DATE '2026-11-04'-2
    AND event_date<=DATE '2026-11-04'
GROUP BY event_date
UNION ALL
SELECT 'legacy'::text,create_date::text,COUNT(*),COUNT(DISTINCT user_id),MIN(create_time)::text,
       MAX(create_time)::text
FROM wangchuanliang.event_track_record
WHERE create_date>=DATE '2026-11-04'-2
    AND create_date<=DATE '2026-11-04'
GROUP BY create_date;

-- ======================================================================
-- related_tables.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT TABLE_NAME
FROM information_schema.tables
WHERE table_schema='wangchuanliang'
    AND (TABLE_NAME LIKE '%%recall%%'
         OR TABLE_NAME LIKE '%%coupon%%')
ORDER BY TABLE_NAME;

-- ======================================================================
-- risk_score_histories.sql
-- ======================================================================
-- Read-only source SQL; bound parameters supplied by extraction program.

SELECT user_id,serial_id, kabybxgboost363dpd7cre AS score363, kabybxgboost405apd7crecyc AS score405,
       kabybmerge410fpd7cre AS score410, kabybmerge410fpd7cyc AS score410cyc
FROM wangchuanliang.model_result_copy
WHERE user_id IN
        (SELECT unnest(%(users)s::bigint[]));

-- ======================================================================
-- t7recalllist_0930.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT "churn_user_id","max_repaid_date","churn_days","reg_date","total_apply_rnb","total_remit_rnb",
       "total_remit_amt","als","max_over_due","overdue_cnt","overdue_term_cnt","total_vir_amt",
       "total_apply_amt","utilization_rate","last_remit_utilization_rate","high_interest_rate",
       "last_remit_product_no","last_remit_interest_type","last_remit_total_term","last_remit_overdue_days",
       "last_vir_amt","last_vir_risk_product","last_vir_total_term","active_days_cnt","last_active_date",
       "days_since_last_active","newpage_cnt","newconfirm_cnt","amount_selection_cnt","term_selection_cnt",
       "plan_newdetails_cnt","contract_newdetails_cnt","purpose_newdetails_cnt","coupons_page_cnt",
       "coupons_confirm_cnt","send_coupon_d_cnt","send_coupon_r_cnt","last_send_coupon_date",
       "days_since_last_send_coupon","od_flag","diff15_fa_flag","af_flag","score_flag","fpd7_score","td_score_flag",
       "coupon_level_2","prod_risk_level","strat","score","priority_group"
FROM wangchuanliang.t7recalllist_0930
WHERE churn_user_id IS NOT NULL
    AND NOT (churn_user_id = ANY(%(__excluded_user_ids)s::bigint[]));

-- ======================================================================
-- t7recalllist_1010.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT "churn_user_id","max_repaid_date","churn_days","reg_date","total_apply_rnb","total_remit_rnb",
       "total_remit_amt","als","max_over_due","overdue_cnt","overdue_term_cnt","total_vir_amt",
       "total_apply_amt","utilization_rate","last_remit_utilization_rate","high_interest_rate",
       "last_remit_product_no","last_remit_interest_type","last_remit_total_term","last_remit_overdue_days",
       "last_vir_amt","last_vir_risk_product","last_vir_total_term","active_days_cnt","last_active_date",
       "days_since_last_active","newpage_cnt","newconfirm_cnt","amount_selection_cnt","term_selection_cnt",
       "plan_newdetails_cnt","contract_newdetails_cnt","purpose_newdetails_cnt","coupons_page_cnt",
       "coupons_confirm_cnt","send_coupon_d_cnt","send_coupon_r_cnt","last_send_coupon_date",
       "days_since_last_send_coupon","od_flag","diff15_fa_flag","af_flag","score_flag","fpd7_score","td_score_flag",
       "coupon_level_2","prod_risk_level","score","priority_group","strat"
FROM wangchuanliang.t7recalllist_1010
WHERE churn_user_id IS NOT NULL
    AND NOT (churn_user_id = ANY(%(__excluded_user_ids)s::bigint[]));

-- ======================================================================
-- t7recalllist_1016.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT "churn_user_id","max_repaid_date","churn_days","reg_date","total_apply_rnb","total_remit_rnb",
       "total_remit_amt","als","max_over_due","overdue_cnt","overdue_term_cnt","total_vir_amt",
       "total_apply_amt","utilization_rate","last_remit_utilization_rate","high_interest_rate",
       "last_remit_product_no","last_remit_interest_type","last_remit_total_term","last_remit_overdue_days",
       "last_vir_amt","last_vir_risk_product","last_vir_total_term","active_days_cnt","last_active_date",
       "days_since_last_active","newpage_cnt","newconfirm_cnt","amount_selection_cnt","term_selection_cnt",
       "plan_newdetails_cnt","contract_newdetails_cnt","purpose_newdetails_cnt","coupons_page_cnt",
       "coupons_confirm_cnt","send_coupon_d_cnt","send_coupon_r_cnt","last_send_coupon_date",
       "days_since_last_send_coupon","od_flag","diff15_fa_flag","af_flag","score_flag","fpd7_score","dpd7_score",
       "td_score_flag","coupon_level_2","prod_risk_level","score","priority_group","strat"
FROM wangchuanliang.t7recalllist_1016
WHERE churn_user_id IS NOT NULL
    AND NOT (churn_user_id = ANY(%(__excluded_user_ids)s::bigint[]));

-- ======================================================================
-- t7recalllist_1023.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT "churn_user_id","max_repaid_date","churn_days","reg_date","total_apply_rnb","total_remit_rnb",
       "total_remit_amt","als","max_over_due","overdue_cnt","overdue_term_cnt","total_vir_amt",
       "total_apply_amt","utilization_rate","last_remit_utilization_rate","high_interest_rate",
       "last_remit_product_no","last_remit_interest_type","last_remit_total_term","last_remit_overdue_days",
       "last_vir_amt","last_vir_risk_product","last_vir_total_term","active_days_cnt","last_active_date",
       "days_since_last_active","newpage_cnt","newconfirm_cnt","amount_selection_cnt","term_selection_cnt",
       "plan_newdetails_cnt","contract_newdetails_cnt","purpose_newdetails_cnt","coupons_page_cnt",
       "coupons_confirm_cnt","send_coupon_d_cnt","send_coupon_r_cnt","last_send_coupon_date",
       "days_since_last_send_coupon","od_flag","diff15_fa_flag","af_flag","score_flag","fpd7_score","dpd7_score",
       "td_score_flag","coupon_level_2","prod_risk_level","score","priority_group","strat"
FROM wangchuanliang.t7recalllist_1023
WHERE churn_user_id IS NOT NULL
    AND NOT (churn_user_id = ANY(%(__excluded_user_ids)s::bigint[]));

-- ======================================================================
-- t7recalllist_1030.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT "churn_user_id","max_repaid_date","churn_days","reg_date","total_apply_rnb","total_remit_rnb",
       "total_remit_amt","als","max_over_due","overdue_cnt","overdue_term_cnt","total_vir_amt",
       "total_apply_amt","utilization_rate","last_remit_utilization_rate","high_interest_rate",
       "last_remit_product_no","last_remit_interest_type","last_remit_total_term","last_remit_overdue_days",
       "last_vir_amt","last_vir_risk_product","last_vir_total_term","active_days_cnt","last_active_date",
       "days_since_last_active","newpage_cnt","newconfirm_cnt","amount_selection_cnt","term_selection_cnt",
       "plan_newdetails_cnt","contract_newdetails_cnt","purpose_newdetails_cnt","coupons_page_cnt",
       "coupons_confirm_cnt","send_coupon_d_cnt","send_coupon_r_cnt","last_send_coupon_date",
       "days_since_last_send_coupon","od_flag","diff15_fa_flag","af_flag","score_flag","fpd7_score","dpd7_score",
       "td_score_flag","coupon_level_2","td_gap15_score","prod_risk_level","score","priority_group",
       "strat"
FROM wangchuanliang.t7recalllist_1030
WHERE churn_user_id IS NOT NULL
    AND NOT (churn_user_id = ANY(%(__excluded_user_ids)s::bigint[]));

-- ======================================================================
-- t7recalllist_active0918.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT "churn_user_id","max_repaid_date","churn_days","reg_date","total_apply_rnb","total_remit_rnb",
       "total_remit_amt","als","max_over_due","overdue_cnt","overdue_term_cnt","total_vir_amt",
       "total_apply_amt","utilization_rate","last_remit_utilization_rate","high_interest_rate",
       "last_remit_product_no","last_remit_interest_type","last_remit_total_term","last_remit_overdue_days",
       "last_vir_amt","last_vir_risk_product","last_vir_total_term","active_days_cnt","last_active_date",
       "days_since_last_active","newpage_cnt","newconfirm_cnt","amount_selection_cnt","term_selection_cnt",
       "plan_newdetails_cnt","contract_newdetails_cnt","purpose_newdetails_cnt","coupons_page_cnt",
       "coupons_confirm_cnt","send_coupon_d_cnt","send_coupon_r_cnt","last_send_coupon_date",
       "days_since_last_send_coupon","od_flag","diff15_fa_flag","af_flag","score_flag","fpd7_score","td_score_flag",
       "coupon_level_2","prod_risk_level","score","v2_group","tier","strat"
FROM wangchuanliang.t7recalllist_active0918
WHERE churn_user_id IS NOT NULL
    AND NOT (churn_user_id = ANY(%(__excluded_user_ids)s::bigint[]));

-- ======================================================================
-- t7recalllist_active1010.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT "churn_user_id","max_repaid_date","churn_days","reg_date","total_apply_rnb","total_remit_rnb",
       "total_remit_amt","als","max_over_due","overdue_cnt","overdue_term_cnt","total_vir_amt",
       "total_apply_amt","utilization_rate","last_remit_utilization_rate","high_interest_rate",
       "last_remit_product_no","last_remit_interest_type","last_remit_total_term","last_remit_overdue_days",
       "last_vir_amt","last_vir_risk_product","last_vir_total_term","active_days_cnt","last_active_date",
       "days_since_last_active","newpage_cnt","newconfirm_cnt","amount_selection_cnt","term_selection_cnt",
       "plan_newdetails_cnt","contract_newdetails_cnt","purpose_newdetails_cnt","coupons_page_cnt",
       "coupons_confirm_cnt","send_coupon_d_cnt","send_coupon_r_cnt","last_send_coupon_date",
       "days_since_last_send_coupon","od_flag","diff15_fa_flag","af_flag","score_flag","fpd7_score","td_score_flag",
       "coupon_level_2","prod_risk_level","score","priority_group","strat"
FROM wangchuanliang.t7recalllist_active1010
WHERE churn_user_id IS NOT NULL
    AND NOT (churn_user_id = ANY(%(__excluded_user_ids)s::bigint[]));

-- ======================================================================
-- t7recalllist_active1016.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT "churn_user_id","max_repaid_date","churn_days","reg_date","total_apply_rnb","total_remit_rnb",
       "total_remit_amt","als","max_over_due","overdue_cnt","overdue_term_cnt","total_vir_amt",
       "total_apply_amt","utilization_rate","last_remit_utilization_rate","high_interest_rate",
       "last_remit_product_no","last_remit_interest_type","last_remit_total_term","last_remit_overdue_days",
       "last_vir_amt","last_vir_risk_product","last_vir_total_term","active_days_cnt","last_active_date",
       "days_since_last_active","newpage_cnt","newconfirm_cnt","amount_selection_cnt","term_selection_cnt",
       "plan_newdetails_cnt","contract_newdetails_cnt","purpose_newdetails_cnt","coupons_page_cnt",
       "coupons_confirm_cnt","send_coupon_d_cnt","send_coupon_r_cnt","last_send_coupon_date",
       "days_since_last_send_coupon","od_flag","diff15_fa_flag","af_flag","score_flag","fpd7_score","dpd7_score",
       "td_score_flag","coupon_level_2","prod_risk_level","score","priority_group","strat"
FROM wangchuanliang.t7recalllist_active1016
WHERE churn_user_id IS NOT NULL
    AND NOT (churn_user_id = ANY(%(__excluded_user_ids)s::bigint[]));

-- ======================================================================
-- t7recalllist_active1023.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT "churn_user_id","max_repaid_date","churn_days","reg_date","total_apply_rnb","total_remit_rnb",
       "total_remit_amt","als","max_over_due","overdue_cnt","overdue_term_cnt","total_vir_amt",
       "total_apply_amt","utilization_rate","last_remit_utilization_rate","high_interest_rate",
       "last_remit_product_no","last_remit_interest_type","last_remit_total_term","last_remit_overdue_days",
       "last_vir_amt","last_vir_risk_product","last_vir_total_term","active_days_cnt","last_active_date",
       "last_active_date_2","days_since_last_active","newpage_cnt","newconfirm_cnt","amount_selection_cnt",
       "term_selection_cnt","plan_newdetails_cnt","contract_newdetails_cnt","purpose_newdetails_cnt",
       "coupons_page_cnt","coupons_confirm_cnt","send_coupon_d_cnt","send_coupon_r_cnt",
       "last_send_coupon_date","days_since_last_send_coupon","od_flag","diff15_fa_flag","af_flag","score_flag",
       "fpd7_score","dpd7_score","td_score_flag","coupon_level_2","prod_risk_level","score",
       "priority_group","strat"
FROM wangchuanliang.t7recalllist_active1023
WHERE churn_user_id IS NOT NULL
    AND NOT (churn_user_id = ANY(%(__excluded_user_ids)s::bigint[]));

-- ======================================================================
-- t7recalllist_active1030.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT "churn_user_id","max_repaid_date","churn_days","reg_date","total_apply_rnb","total_remit_rnb",
       "total_remit_amt","als","max_over_due","overdue_cnt","overdue_term_cnt","total_vir_amt",
       "total_apply_amt","utilization_rate","last_remit_utilization_rate","high_interest_rate",
       "last_remit_product_no","last_remit_interest_type","last_remit_total_term","last_remit_overdue_days",
       "last_vir_amt","last_vir_risk_product","last_vir_total_term","active_days_cnt","last_active_date",
       "days_since_last_active","newpage_cnt","newconfirm_cnt","amount_selection_cnt","term_selection_cnt",
       "plan_newdetails_cnt","contract_newdetails_cnt","purpose_newdetails_cnt","coupons_page_cnt",
       "coupons_confirm_cnt","send_coupon_d_cnt","send_coupon_r_cnt","last_send_coupon_date",
       "days_since_last_send_coupon","od_flag","diff15_fa_flag","af_flag","score_flag","fpd7_score","dpd7_score",
       "td_score_flag","coupon_level_2","td_gap15_score","prod_risk_level","score","priority_group",
       "strat"
FROM wangchuanliang.t7recalllist_active1030
WHERE churn_user_id IS NOT NULL
    AND NOT (churn_user_id = ANY(%(__excluded_user_ids)s::bigint[]));

-- ======================================================================
-- target_coupon_issues.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT user_id,serial_id,coupon_id,TRIM(coupon_no) AS coupon_no, TYPE,amount,real_use_amount,
       used_date,create_date,expire_date
FROM wangchuanliang.coupon_user_copy
WHERE user_id IS NOT NULL
    AND NOT (user_id = ANY(%(__excluded_user_ids)s::bigint[]))
    AND TYPE=3
    AND coupon_id=ANY(%(ids)s)
    AND create_date>=DATE '2026-06-01'
    AND create_date<%(end)s::date;

-- ======================================================================
-- used_target_orders.sql
-- ======================================================================
-- Read-only; America/Belize; bound parameters supplied by the extraction program.

SELECT user_id,serial_id,product_no,apply_time,apply_date,apply_amt, coupon_id,
       TRIM(coupon_no) AS coupon_no,real_use_amount,used_date,total_fee, product_fee_amount,discount_pct_raw,
       discount_pct,calc_status,create_date,expire_date,valid_days
FROM wangchuanliang.coupon_use_record
WHERE coupon_type=3
    AND real_use_amount>0
    AND coupon_id IN(119,124,141,153,157,160,163,164,166)
    AND create_date>=DATE '2026-06-01'
    AND create_date<DATE '2026-11-01'
    AND NOT (user_id = ANY(%(__excluded_user_ids)s::bigint[]));

