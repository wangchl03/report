from pathlib import Path
import argparse, os, subprocess, sys

ROOT = Path(__file__).resolve().parent
CODE = ROOT / "code"
EXTRACT = [
    "00_probe.py", "01_scope.py", "02_sources.py", "03_dictionary.py", "04_metadata.py",
    "06_behavior_sources.py", "15_behavior_history_supplement.py", "16_period_history_source.py",
    "10_used_orders.py", "41_instance_selection_source.py", "45_historical_test_probe.py",
    "46_historical_test_sources.py", "47_historical_context.py",
]
ANALYZE = [
    "05_cohort.py", "07_features.py", "08_behavior_features.py", "17_period_features.py",
    "11_rates.py", "12_finances.py", "14_subgroups.py", "20_response_ranking_validation.py",
    "23_offer_grain_audit.py", "24_behavior_state_corrected.py", "26_repeat_contact_audit.py",
    "27_model_paired_uncertainty.py", "30_strict_assignment_comparisons.py",
    "31_covariate_calibration.py", "32_demand_response_profiles.py", "33_financial_mix_checks.py",
    "34_utilization_quality.py", "35_validation_group_importance.py", "36_overquota_context.py",
    "37_calibrated_behavior_validation.py", "38_quota_after_amount_coupon.py",
    "39_period_amount_risk.py", "42_instance_selection_analysis.py", "43_contact_order_route_audit.py",
    "44_cash_profit_bridge.py", "47_historical_context.py", "48_historical_ab_validation.py",
    "49_historical_strata_behavior.py",
    "54_inflight_separate_validation.py",
    "55_preclean_activity_interaction.py", "56_demand_threshold_sensitivity.py",
    "57_approved_product_supply_check.py",
    "58_exposure_definition_sensitivity.py",
    "59_historical_timing_check.py",
    "61_inflight_state_transition.py", "63_transition_customer_profile.py",
]

def execute(files, offline=False):
    env = os.environ.copy()
    env.setdefault("OPENBLAS_NUM_THREADS", "1")
    env.setdefault("OMP_NUM_THREADS", "1")
    if offline: env["RECALL_OFFLINE"] = "1"
    for name in files:
        print("RUN", name, flush=True)
        subprocess.run([sys.executable, str(CODE / name)], cwd=ROOT, env=env, check=True)

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--extract", action="store_true", help="Read-only extraction from authorized source tables")
    p.add_argument("--analyze", action="store_true", help="Rebuild results from frozen inputs")
    p.add_argument("--render", action="store_true", help="Verify frozen reference aggregates, then rebuild the HTML reports")
    p.add_argument("--from-step", default=None, help="Resume analysis at a named Python file")
    a = p.parse_args()
    if not a.extract and not a.analyze and not a.render: p.error("Specify --extract, --analyze and/or --render")
    if a.extract:
        if not os.environ.get("DATABASE_URL") or not os.environ.get("RECALL_EXCLUSION_FILE"):
            p.error("Extraction requires DATABASE_URL and RECALL_EXCLUSION_FILE")
        execute(EXTRACT)
    if a.analyze:
        steps = ANALYZE[ANALYZE.index(a.from_step):] if a.from_step else ANALYZE
        execute(steps, offline=True)
    if a.render:
        execute(["52_build_reports.py"], offline=True)

if __name__ == "__main__": main()
