"""Frozen T0 V4 targeting replay: D3 probability selection vs D0 non-application.

No training, no database access, no threshold optimization. All times are local
America/Belize and the outcome cutoff is 2026-10-25 00:00:00 exclusive.
"""
from __future__ import annotations

import hashlib
import importlib.util
import json
import os
from pathlib import Path

os.environ.setdefault("OPENBLAS_NUM_THREADS", "2")
os.environ.setdefault("OMP_NUM_THREADS", "2")
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
VALIDATION = ROOT.parent / "t0_v4_validation_20261024_20261025"
BOOTSTRAP = 500
SEED = 20261025
RATES = {
    "selection_coverage": ("selected_events", "cohort_events"),
    "ppv_no_d0": ("selected_d0_noapply", "selected_d0_known"),
    "d0_false_offer_rate": ("selected_d0_apply", "selected_d0_known"),
    "npv_d3": ("selected_d3_noapply", "selected_d3_known"),
    "d3_false_nonapply_rate": ("selected_d3_apply", "selected_d3_known"),
    "baseline_no_d0": ("cohort_d0_noapply", "cohort_d0_known"),
    "baseline_no_d3": ("cohort_d3_noapply", "cohort_d3_known"),
    "d0_noapply_capture": ("selected_d0_noapply", "cohort_d0_noapply"),
    "d1_3_natural_apply_share": ("selected_d1_3_apply", "selected_d3_known"),
    "d3_nonapply_capture": ("selected_d3_noapply", "cohort_d3_noapply"),
}


def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def clean(v):
    if isinstance(v, dict):
        return {str(k): clean(x) for k, x in v.items()}
    if isinstance(v, (list, tuple)):
        return [clean(x) for x in v]
    if isinstance(v, np.integer):
        return int(v)
    if isinstance(v, (np.floating, float)):
        return float(v) if np.isfinite(v) else None
    if isinstance(v, (pd.Timestamp, np.datetime64)):
        return str(v)
    return v


def count_vectors(df, selected):
    """Columns are additive event counts; allows exact user cluster bootstrap."""
    n = len(df)
    s = np.asarray(selected, float)
    y0 = df.y_d0.to_numpy(float)
    y3 = df.y_d3.to_numpy(float)
    z0, o0, z3, o3 = y0 == 0, y0 == 1, y3 == 0, y3 == 1
    return {
        "cohort_events": np.ones(n),
        "cohort_d0_known": (z0 | o0).astype(float),
        "cohort_d0_noapply": z0.astype(float),
        "cohort_d0_apply": o0.astype(float),
        "cohort_d3_known": (z3 | o3).astype(float),
        "cohort_d3_noapply": z3.astype(float),
        "cohort_d3_apply": o3.astype(float),
        "selected_events": s,
        "selected_d0_known": s * (z0 | o0),
        "selected_d0_noapply": s * z0,
        "selected_d0_apply": s * o0,
        "selected_d3_known": s * (z3 | o3),
        "selected_d3_noapply": s * z3,
        "selected_d3_apply": s * o3,
        "selected_d1_3_apply": s * z0 * o3,
        # D3 confusion matrix: predicted application is probability >= threshold.
        "d3_tn": s * z3,
        "d3_fn": s * o3,
        "d3_fp": (1-s) * z3,
        "d3_tp": (1-s) * o3,
        # D0 decision confusion matrix: target=actual no application today.
        "d0_target_tp": s * z0,
        "d0_target_fp": s * o0,
        "d0_target_fn": (1-s) * z0,
        "d0_target_tn": (1-s) * o0,
    }


def rates(counts):
    r = {}
    for name, (a, b) in RATES.items():
        r[name] = np.divide(counts[a], counts[b], out=np.full_like(np.asarray(counts[b], float), np.nan), where=np.asarray(counts[b]) > 0)
    r["d0_nonapply_lift_pp"] = 100 * (r["ppv_no_d0"] - r["baseline_no_d0"])
    r["d3_nonapply_lift_pp"] = 100 * (r["npv_d3"] - r["baseline_no_d3"])
    return r


def lowest_weights(p, k):
    """Random allocation in an exact score tie, expressed as expected quota."""
    p = np.asarray(p, float)
    if k == 0:
        return np.zeros(len(p))
    if k == len(p):
        return np.ones(len(p))
    boundary = np.partition(p, k-1)[k-1]
    below = p < boundary
    tied = p == boundary
    weights = below.astype(float)
    weights[tied] = (k - below.sum()) / tied.sum()
    assert abs(weights.sum() - k) < 1e-7
    return weights


def analyze_cohort(df, cohort_name, seed):
    """Replay prespecified probability thresholds and descriptive low-score caps."""
    df = df.sort_values(["p_v4_d3", "event_id"], kind="stable").reset_index(drop=True)
    if not len(df):
        raise ValueError(f"Empty cohort {cohort_name}")
    codes, users = pd.factorize(df.user_id, sort=True)
    u = len(users)
    rng = np.random.default_rng(seed)
    # Same resampled users under every rule and the baseline enables paired CIs.
    boot_weights = rng.multinomial(u, np.full(u, 1/u), size=BOOTSTRAP)
    specs = [("probability_threshold", f"p_d3<{t:.1f}", float(t), None, df.p_v4_d3.to_numpy() < t)
             for t in [i / 10 for i in range(1, 10)]]
    for pct in range(10, 100, 10):
        k = int(np.floor(len(df) * pct / 100))
        specs.append(("lowest_probability_share", f"lowest_d3_{pct}%", None, pct, lowest_weights(df.p_v4_d3.to_numpy(), k)))
    # D0 direct ranking at the same volume as the prespecified D3 0.5 rule.
    k = int((df.p_v4_d3 < .5).sum())
    match0 = lowest_weights(df.p_v4_d0.to_numpy(), k)
    specs.append(("direct_d0_same_volume_diagnostic", "lowest_d0_same_volume_as_d3_lt_0.5", None, None, match0))
    for d0_threshold in (.1, .2, .3):
        gate = (df.p_v4_d3.to_numpy() < .5) & (df.p_v4_d0.to_numpy() < d0_threshold)
        specs.append(("combined_d3_and_d0_threshold_diagnostic", f"p_d3<0.5_and_p_d0<{d0_threshold:.1f}", .5, None, gate))
    out = []
    main_selection = None
    for kind, name, threshold, pct, selected in specs:
        cols = count_vectors(df, selected)
        keys = list(cols)
        mat = np.column_stack([cols[k] for k in keys])
        base = dict(zip(keys, mat.sum(axis=0)))
        point = rates(base)
        user_mat = np.column_stack([np.bincount(codes, weights=cols[k], minlength=u) for k in keys])
        bootstrap_counts_matrix = boot_weights @ user_mat
        boot_counts = {k: bootstrap_counts_matrix[:, i] for i, k in enumerate(keys)}
        boot_rates = rates(boot_counts)
        row = {"cohort": cohort_name, "rule_type": kind, "rule": name, "threshold": threshold,
               "requested_low_share_percent": pct,
               **{k: (int(round(v)) if abs(v-round(v)) < 1e-8 else float(v)) for k, v in base.items()},
               "cohort_users": u, "selected_users": int(df.loc[np.asarray(selected)>0, "user_id"].nunique()),
               "selected_users_count_status": "Exact" if set(np.unique(selected)).issubset({0, 1}) else "Users with any positive allocation; boundary tie event counts are expected quotas",
               "selected_min_p_d3": float(df.loc[np.asarray(selected)>0, "p_v4_d3"].min()) if selected.any() else None,
               "selected_max_p_d3": float(df.loc[np.asarray(selected)>0, "p_v4_d3"].max()) if selected.any() else None,
               "selected_mean_p_d0": float(np.average(df.p_v4_d0, weights=selected)) if selected.any() else None,
               "selected_mean_p_d3": float(np.average(df.p_v4_d3, weights=selected)) if selected.any() else None,
               **{k: float(v) for k, v in point.items()}}
        for metric, values in boot_rates.items():
            values = np.asarray(values, float)
            finite = values[np.isfinite(values)]
            row[f"{metric}_ci95_low"] = float(np.quantile(finite, .025)) if len(finite) else None
            row[f"{metric}_ci95_high"] = float(np.quantile(finite, .975)) if len(finite) else None
            row[f"{metric}_bootstrap_valid"] = len(finite)
        row["d0_no_observed_failures_sparse_warning"] = bool(base["selected_d0_apply"] == 0 and base["selected_d0_known"] > 0)
        if name == "p_d3<0.5":
            main_selection = df.assign(selected_d3_lt_0_5=selected)
        out.append(row)
    assert main_selection is not None
    return out, main_selection


def equal_volume_pair(df):
    """Paired D0-low vs D3-low comparison using the same user bootstrap draws."""
    df = df.sort_values(["p_v4_d3", "event_id"], kind="stable").reset_index(drop=True)
    s3 = (df.p_v4_d3.to_numpy() < .5).astype(float)
    s0 = lowest_weights(df.p_v4_d0.to_numpy(), int(s3.sum()))
    codes, users = pd.factorize(df.user_id, sort=True)
    rng = np.random.default_rng(SEED)
    boots = rng.multinomial(len(users), np.full(len(users), 1/len(users)), size=BOOTSTRAP)
    rs = []
    for selection in (s3, s0):
        columns = count_vectors(df, selection)
        cc = {k: boots @ np.bincount(codes, weights=v, minlength=len(users)) for k, v in columns.items()}
        point = rates({k: v.sum() for k, v in columns.items()})
        bs = rates(cc)
        rs.append((point, bs))
    comparisons = {}
    for metric in ("ppv_no_d0", "d0_false_offer_rate", "npv_d3", "d1_3_natural_apply_share"):
        delta = 100 * (rs[1][1][metric] - rs[0][1][metric])
        comparisons[metric] = {
            "d0_rule_minus_d3_rule_pp": float(100*(rs[1][0][metric] - rs[0][0][metric])),
            "paired_cluster_ci95_low_pp": float(np.nanquantile(delta, .025)),
            "paired_cluster_ci95_high_pp": float(np.nanquantile(delta, .975)),
        }
    return {
        "cohort": "main_d3_mature_20261009_20261021", "equal_event_quota": int(s3.sum()),
        "tie_allocation": "Equal expected quota within boundary score ties, no outcome-based tie break",
        "comparisons": comparisons,
        "interpretation": "The D0-specific output aligns directly to avoiding same-day natural applications. Its observed same-volume gain must be judged with this paired interval and independently confirmed; it is not a proven incentive-uplift model.",
    }


def flow(df, requested, name):
    d = df[requested]
    return {"cohort": name, "events_requested": len(d), "users_requested": d.user_id.nunique(),
            "d0_mature_events": int(d.mature_d0.sum()), "d3_mature_events": int(d.mature_d3.sum()),
            "d0_known_events": int(d.y_d0.notna().sum()), "d3_known_events": int(d.y_d3.notna().sum()),
            "d0_censored_events": int(d.censored_d0.sum()), "d3_censored_events": int(d.censored_d3.sum()),
            "p_d3_missing_events": int(d.p_v4_d3.isna().sum()),
            "date_min": str(d.offer_date.min()), "date_max": str(d.offer_date.max())}


def main():
    source = VALIDATION / "events_predictions.parquet"
    labeled = VALIDATION / "evaluation/labels_evaluated.parquet"
    df = pd.read_parquet(labeled)
    events = pd.read_parquet(source)
    # Rebuild the labels with the frozen validation contract, not inferred silence.
    spec = importlib.util.spec_from_file_location("old_validation", VALIDATION / "evaluate_validation.py")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    rebuilt, _ = module.prepare_labels(events)
    r = rebuilt.set_index("event_id").sort_index()
    s = df.set_index("event_id").sort_index()
    for c in ("y_d0", "y_d3", "mature_d0", "mature_d3", "censored_d0", "censored_d3"):
        np.testing.assert_equal(s[c].to_numpy(), r[c].to_numpy())
    assert not df.event_id.duplicated().any()
    assert not ((df.y_d0 == 1) & (df.y_d3 == 0)).any()
    primary_requested = (df.offer_date >= "2026-10-09") & (df.offer_date <= "2026-10-24")
    matured_requested = (df.offer_date >= "2026-10-09") & (df.offer_date <= "2026-10-21")
    supp_requested = (df.offer_date >= "2026-09-22") & (df.offer_date <= "2026-10-08")
    main_mask = matured_requested & df.mature_d3 & df.y_d3.notna() & df.p_v4_d3.notna()
    all_d0_mask = primary_requested & df.mature_d0 & df.y_d0.notna() & df.p_v4_d3.notna()
    sensitivity_mask = all_d0_mask & (df.offer_date != "2026-10-24")
    supplement_mask = supp_requested & df.mature_d3 & df.y_d3.notna() & df.p_v4_d3.notna()
    cohorts = {
        "main_d3_mature_20261009_20261021": main_mask,
        "supplement_d0_mature_20261009_20261024": all_d0_mask,
        "sensitivity_exclude_oct24_20261009_20261023": sensitivity_mask,
        "historical_supplement_20260922_20261008": supplement_mask,
    }
    all_rows = []
    selections = []
    for i, (name, mask) in enumerate(cohorts.items()):
        rows, selected = analyze_cohort(df.loc[mask].copy(), name, SEED + i)
        all_rows.extend(rows)
        selected["targeting_cohort"] = name
        selections.append(selected)
        headline = next(x for x in rows if x["rule"] == "p_d3<0.5")
        print(name, json.dumps(clean(headline), ensure_ascii=False), flush=True)
    results = pd.DataFrame(all_rows)
    results.to_csv(ROOT / "model_targeting.csv", index=False)
    pd.concat(selections, ignore_index=True).to_parquet(ROOT / "model_targeting_event_replay.parquet", index=False)
    headline = {name: next(x for x in all_rows if x["cohort"] == name and x["rule"] == "p_d3<0.5") for name in cohorts}
    original = df.loc[matured_requested & df.mature_d3 & df.p_v4_d3.notna()].copy()
    censored = original[original.y_d3.isna()]
    censored_selected = censored[censored.p_v4_d3 < .5]
    flow_rows = [flow(df, primary_requested, "primary_requested_20261009_20261024"),
                 flow(df, matured_requested, "main_date_range_20261009_20261021"),
                 flow(df, supp_requested, "historical_supplement_20260922_20261008")]
    result = {
        "generated_utc": str(pd.Timestamp.now(tz="UTC")),
        "contract": {
            "model": "frozen T0 application timing V4",
            "d3_definition": "From passed T0 offer timestamp through the end of its third following calendar day; event_date + 4 days exclusive (D0-D3, four calendar dates). Not rolling 72 hours.",
            "d0_definition": "From the passed T0 offer timestamp to event_date + 1 day exclusive.",
            "label": "First actual user application, any serial ID; not loan disbursement.",
            "cutoff_exclusive": "2026-10-25 00:00:00 America/Belize",
            "selection": "p_v4_d3 < threshold; threshold equality belongs to predicted application.",
            "low_share_rules": "Exact floor(n * percentage / 100) expected event quota by ascending p_v4_d3; equal probabilities receive equal fractional selection weights at the boundary (no outcome-based tie break). Descriptive current-cohort capacities, not an optimized operational threshold.",
            "main_denominator": "2026-10-09 to 2026-10-21 events, D3 fully mature, D3 label known, score nonmissing. No conditioning on D0 outcome.",
            "censoring": "The next strict T0 censors this event; if it precedes D3 and no valid application has been observed, D3 label is unknown. These events are excluded from the main D3-label-known cohort and quantified separately.",
            "supplement": "All 2026-10-09 to 2026-10-24 D0 mature/known events. D3 metrics only use its D3 mature/known subset; late cohorts are not filled with negative labels.",
            "bootstrap": f"{BOOTSTRAP} percentile user-cluster bootstrap replicates, all repeated events for a user resampled together; paired baseline and rules. Fixed observed eligibility and selection; does not quantify censoring or model/source bias.",
            "seed": SEED,
            "threshold_status": "Prespecified descriptive grid; no selection of best threshold on this test set.",
            "oct24_sensitivity": "All 588 Oct24 events lacked source risk-model rows in prior audit. A separate D0 cohort excludes that date; the main D3 mature cohort never includes Oct24.",
            "evidence_level": "Retrospective replay from frozen models and reconstructed features; not a prospective randomized incentive or verified contemporaneous online-score trial.",
        },
        "source_files": {str(source): sha(source), str(labeled): sha(labeled)},
        "label_consistency_check": "All 22,365 event IDs and D0/D3 labels, maturity and censoring indicators match independent regeneration from the prior frozen evaluation code.",
        "flow": flow_rows,
        "main_d3_censored_exclusion": {
            "events": len(censored), "users": censored.user_id.nunique(),
            "selected_by_p_d3_lt_0_5_events": len(censored_selected),
            "selected_d0_known_events": int(censored_selected.y_d0.notna().sum()),
            "selected_d0_apply_events": int((censored_selected.y_d0 == 1).sum()),
            "selected_d0_noapply_events": int((censored_selected.y_d0 == 0).sum()),
        },
        "headlines_at_threshold_0_5": headline,
        "equal_volume_d0_vs_d3": equal_volume_pair(df.loc[main_mask].copy()),
        "results": all_rows,
        "operational_interpretation": [
            "D0 non-application precision measures avoidance of customers who would apply on the same day under observed historical conditions. It is not incentive uplift, profit uplift, or proof that the remaining users need a discount.",
            "D1-D3 natural applicants may also be subsidized or accelerated; include this economic leakage when comparing incremental profits.",
            "The observed usual policies are not an untreated counterfactual. The same-day leakage is an operational proxy under historical policy, not a causal estimate of wasted coupons.",
            "p(D3 application) < 0.5 does not mean guaranteed no application. Raising the threshold buys more coverage with lower precision; choose using an independently designed experiment and expected incremental profit.",
            "If the actual objective is only D0 non-application, direct p(D0) ranking at equal coverage is an aligned diagnostic; do not pick a winning targeting rule on this same replay without independent confirmation.",
            "At very low probability thresholds, an observed zero D0 failure count can make percentile cluster-bootstrap intervals degenerate at 100%. This does not prove 100% future precision; explicitly inspect selected counts and require larger prospective samples.",
        ],
    }
    (ROOT / "model_targeting.json").write_text(json.dumps(clean(result), ensure_ascii=False, indent=2), encoding="utf-8")
    pd.DataFrame(flow_rows).to_csv(ROOT / "model_targeting_flow.csv", index=False)
    print("WROTE", ROOT / "model_targeting.json", flush=True)


if __name__ == "__main__":
    main()
