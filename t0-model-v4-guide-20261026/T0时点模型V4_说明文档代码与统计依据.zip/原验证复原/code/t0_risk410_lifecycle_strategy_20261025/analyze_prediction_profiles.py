"""Frozen low-pD3 targeting crossed with original-offer 410 and lifecycle profiles.

All candidate rules are descriptive. No training, threshold optimization, causal
uplift claim, or database access occurs here. Original validation files are read
only; unknown/censored labels are never filled as non-application.
"""
from __future__ import annotations
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','2')
os.environ.setdefault('OMP_NUM_THREADS','2')
from pathlib import Path
import argparse,hashlib,json
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent
OLD=ROOT.parent/'t0_v4_validation_20261024_20261025'
SEED=20261025
REPLICATES=500
SCORE_BANDS=['HIGH20','MID30','LOW50','NO_RECORD','NULL_SCORE','INVALID','CONFLICT','UNMAPPED']
LIFE_BANDS=['1','2','3','4','5','6-10','11-20','21+','UNKNOWN','UNMAPPED']


def safe(x):
    if isinstance(x,dict):return {str(k):safe(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [safe(v) for v in x]
    if isinstance(x,np.integer):return int(x)
    if isinstance(x,(float,np.floating)):return float(x) if np.isfinite(x) else None
    if isinstance(x,(pd.Timestamp,np.datetime64)):return str(x)
    return x


def ratio(a,b):
    a,b=np.asarray(a,float),np.asarray(b,float)
    return np.divide(a,b,out=np.full_like(b,np.nan),where=b>0)


def json_write(path,data):
    path.write_text(json.dumps(safe(data),ensure_ascii=False,indent=2),encoding='utf-8')


def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()


def local_time(s):
    x=pd.to_datetime(s,errors='coerce',format='mixed')
    if isinstance(x.dtype,pd.DatetimeTZDtype):x=x.dt.tz_convert('America/Belize').dt.tz_localize(None)
    return x


def add_profiles(events,mapping):
    required=['event_id','user_id','vir_time','score_410','score_status','score_band','settled_loan_seq','lifecycle_band']
    missing=[c for c in required if c not in mapping]
    if missing:raise ValueError(f'Mapping missing required columns: {missing}')
    if mapping.event_id.isna().any() or mapping.event_id.duplicated().any():raise ValueError('Mapping event_id must be unique and non-NULL')
    if mapping.user_id.isna().any():raise ValueError('Mapping user_id must be non-NULL')
    m=mapping.rename(columns={'user_id':'profile_user_id','vir_time':'profile_vir_time'})
    # Keep all profile columns, giving any existing validation columns precedence.
    data=events.merge(m,on='event_id',how='left',validate='one_to_one',indicator='_profile_join',suffixes=('','_profile'))
    found=data._profile_join.eq('both')
    user_bad=found & data.user_id.ne(data.profile_user_id)
    if user_bad.any():raise ValueError(f'{int(user_bad.sum())} event IDs map to different users; cannot use those profiles')
    data['profile_vir_time']=local_time(data.profile_vir_time)
    delta=(data.profile_vir_time-data.as_of_time).abs().dt.total_seconds()
    time_unknown=found & data.profile_vir_time.isna()
    time_bad=found & delta.gt(1)
    data['profile_mapped']=found & ~time_unknown & ~time_bad
    data['profile_key_status']=np.select([~found,time_unknown,time_bad],['UNMAPPED','MISSING_OFFER_TIME','OFFER_TIME_MISMATCH'],default='MATCHED')
    for c in ['score_band','lifecycle_band','score_status']:
        data[c]=data[c].astype('string').fillna('UNKNOWN')
        data.loc[~data.profile_mapped,c]='UNMAPPED'
    data['lifecycle_band']=data.lifecycle_band.str.replace('—','-',regex=False).str.replace('–','-',regex=False)
    invalid_bands=set(data.score_band.unique())-set(SCORE_BANDS)
    invalid_life=set(data.lifecycle_band.unique())-set(LIFE_BANDS)
    if invalid_bands:raise ValueError(f'Unexpected score_band values: {invalid_bands}')
    if invalid_life:raise ValueError(f'Unexpected lifecycle_band values: {invalid_life}')
    if 'score_time' in data:
        score_time=local_time(data.score_time)
        score_future=data.profile_mapped & score_time.notna() & score_time.gt(data.as_of_time)
        if score_future.any():raise ValueError(f'{int(score_future.sum())} profile scores are timestamped after the event')
        score_time_known=int((data.profile_mapped & score_time.notna()).sum())
    else:score_time_known=0
    quality={
      'events':len(data),'users':int(data.user_id.nunique()),'mapping_rows_input':len(mapping),
      'matched_event_id_events':int(found.sum()),'profile_mapped_events':int(data.profile_mapped.sum()),
      'unmatched_event_id_events':int((~found).sum()),'mapping_time_missing_events':int(time_unknown.sum()),
      'mapping_time_mismatch_over_one_second_events':int(time_bad.sum()),'mapping_user_mismatch_events':0,
      'profile_mapping_coverage':float(data.profile_mapped.mean()),'score_generation_time_known_events':score_time_known,
      'known_valid_score_events':int(data.score_band.isin(['HIGH20','MID30','LOW50']).sum()),
      'lifecycle_unknown_events':int(data.lifecycle_band.eq('UNKNOWN').sum()),
      'time_tolerance_seconds':1,
      'profile_timing_limitation':'Profiles attach to the original T0 offer event/order. Absent score generation/version timestamps prevent full proof that the current score snapshot was available at the event. No missing profile is filled using future outcomes.',
    }
    return data,quality


def count_arrays(d,eligible,selected):
    e=np.asarray(eligible,bool);s=np.asarray(selected,bool)
    y0=d.y_d0.to_numpy(float);y3=d.y_d3.to_numpy(float)
    k0=np.isfinite(y0);k3=np.isfinite(y3)
    mapped=d.profile_mapped.to_numpy(bool)
    valid=d.score_band.isin(['HIGH20','MID30','LOW50']).to_numpy(bool)
    return {
      'cohort_events':np.ones(len(d)),'cohort_d0_known':k0,'cohort_d0_noapply':y0==0,
      'eligible_events':e,'eligible_d0_known':e&k0,'eligible_d0_noapply':e&(y0==0),
      'selected_all_events':s,'selected_profile_mapped_events':s&mapped,
      'selected_valid_410_events':s&valid,'selected_d0_known_events':s&k0,
      'selected_d0_unknown_events':s&~k0,'selected_d0_noapply_events':s&(y0==0),
      'selected_d0_apply_events':s&(y0==1),'selected_d3_known_events':s&k3,
      'selected_d3_unknown_events':s&~k3,'selected_d3_noapply_events':s&(y3==0),
      'selected_d3_apply_events':s&(y3==1),'selected_d1_3_apply_events':s&(y0==0)&(y3==1),
    }


def derive(counts,lowp_all):
    pairs={
      'selection_coverage_all_scored':('selected_all_events','cohort_events'),
      'profile_mapping_coverage':('selected_profile_mapped_events','selected_all_events'),
      'selected_valid_410_share':('selected_valid_410_events','selected_all_events'),
      'd0_nonapply_precision':('selected_d0_noapply_events','selected_d0_known_events'),
      'd0_apply_proxy_leakage':('selected_d0_apply_events','selected_d0_known_events'),
      'd3_nonapply_precision_known_only':('selected_d3_noapply_events','selected_d3_known_events'),
      'd1_3_apply_share_known_d3_only':('selected_d1_3_apply_events','selected_d3_known_events'),
      'baseline_d0_nonapply_all_scored_known':('cohort_d0_noapply','cohort_d0_known'),
      'baseline_d0_nonapply_eligible_known':('eligible_d0_noapply','eligible_d0_known'),
      'd0_nonapply_capture_all_scored_known':('selected_d0_noapply_events','cohort_d0_noapply'),
    }
    result={k:ratio(counts[a],counts[b]) for k,(a,b) in pairs.items()}
    result['selection_share_of_all_lowp_candidates']=ratio(counts['selected_all_events'],lowp_all)
    result['d0_precision_lift_vs_global_baseline_pp']=100*(result['d0_nonapply_precision']-result['baseline_d0_nonapply_all_scored_known'])
    result['d0_precision_lift_vs_eligible_baseline_pp']=100*(result['d0_nonapply_precision']-result['baseline_d0_nonapply_eligible_known'])
    return result


def rule_specs(d):
    all_=np.ones(len(d),bool)
    score=d.score_band
    life=d.lifecycle_band
    high=score.eq('HIGH20').to_numpy(bool)
    mid=score.eq('MID30').to_numpy(bool)
    low=score.eq('LOW50').to_numpy(bool)
    six=life.isin(['6-10','11-20','21+']).to_numpy(bool)
    eleven=life.isin(['11-20','21+']).to_numpy(bool)
    rules=[('LOWP_ALL','低pD3全部候选',all_),('LOWP_HIGH20','低pD3且410高分前20%',high),
      ('LOWP_MID30','低pD3且410中间20%—50%',mid),('LOWP_HIGHMID50','低pD3且410高分前50%',high|mid),
      ('LOWP_LOW50','低pD3且410后50%',low),
      ('LOWP_INVALID_OR_MISSING_410','低pD3且410不可有效分档',~(high|mid|low)),
      ('LOWP_LIFE6PLUS','低pD3且本次结清为第6笔及以上',six),
      ('LOWP_LIFE11PLUS','低pD3且本次结清为第11笔及以上',eleven),
      ('LOWP_HIGHMID50_LIFE6PLUS','低pD3且410前50%且第6笔及以上', (high|mid)&six),
      ('LOWP_HIGH20_LIFE6PLUS','低pD3且410前20%且第6笔及以上',high&six),
      ('LOWP_HIGHMID50_LIFE11PLUS','低pD3且410前50%且第11笔及以上',(high|mid)&eleven),
      ('LOWP_HIGH20_LIFE11PLUS','低pD3且410前20%且第11笔及以上',high&eleven),
      ('LOWP_PROFILE_UNMAPPED','低pD3但画像无法可靠关联',~d.profile_mapped.to_numpy(bool))]
    rules +=[(f'LOWP_LIFE_{b}','低pD3且本次结清生命周期档'+b,life.eq(b).to_numpy(bool)) for b in LIFE_BANDS if b!='UNMAPPED']
    return rules


def analyze_rules(d):
    lowp=d.p_v4_d3.to_numpy(float)<.5
    codes,users=pd.factorize(d.user_id,sort=True)
    u=len(users);rng=np.random.default_rng(SEED)
    boot=rng.multinomial(u,np.full(u,1/u),size=REPLICATES)
    lowp_user=np.bincount(codes,weights=lowp,minlength=u)
    boot_lowp=boot@lowp_user
    rows=[]
    for name,label,eligible in rule_specs(d):
        selected=eligible&lowp
        arrays=count_arrays(d,eligible,selected)
        counts={k:float(np.sum(v)) for k,v in arrays.items()}
        point=derive(counts,int(lowp.sum()))
        keys=list(arrays)
        user_matrix=np.column_stack([np.bincount(codes,weights=arrays[k],minlength=u) for k in keys])
        samples=boot@user_matrix
        bc={k:samples[:,i] for i,k in enumerate(keys)}
        bmetrics=derive(bc,boot_lowp)
        row={'rule':name,'description':label,**{k:int(v) for k,v in counts.items()},
             'cohort_users':u,'eligible_users':int(d.loc[eligible,'user_id'].nunique()),
             'selected_all_users':int(d.loc[selected,'user_id'].nunique()),
             'selected_d0_evaluable_users':int(d.loc[selected&d.y_d0.notna().to_numpy(),'user_id'].nunique()),
             'selected_d3_evaluable_users':int(d.loc[selected&d.y_d3.notna().to_numpy(),'user_id'].nunique()),
             **{k:float(v) for k,v in point.items()}}
        for k,v in bmetrics.items():
            f=np.asarray(v)[np.isfinite(v)]
            row[k+'_ci95_low']=float(np.quantile(f,.025)) if len(f) else None
            row[k+'_ci95_high']=float(np.quantile(f,.975)) if len(f) else None
            row[k+'_bootstrap_valid']=len(f)
        row['zero_observed_d0_error_warning']=bool(counts['selected_d0_known_events']>0 and counts['selected_d0_apply_events']==0)
        rows.append(row)
    return rows


def compositions(d):
    out=[]
    for name,mask in [('ALL_SCORED',np.ones(len(d),bool)),('LOWP_D3_LT_0_5',d.p_v4_d3.to_numpy()<.5)]:
        z=d.loc[mask];n=len(z);v=z.score_band.isin(['HIGH20','MID30','LOW50']).sum()
        for field,bands in [('score_band',SCORE_BANDS),('lifecycle_band',LIFE_BANDS)]:
            for b in bands:
                q=z[field].eq(b);valid=b in ['HIGH20','MID30','LOW50'] if field=='score_band' else False
                out.append({'population':name,'dimension':field,'band':b,'events':int(q.sum()),
                  'users':int(z.loc[q,'user_id'].nunique()),'population_events':n,'event_share':float(q.sum()/n) if n else None,
                  'valid_410_denominator':int(v) if field=='score_band' else None,
                  'share_among_valid_410_only':float(q.sum()/v) if valid and v else None})
    return out


def report_aliases(row,population='full8866'):
    """Stable short names for the shared report/Excel interface."""
    return {**row,'population':population,'name':row['description'],
      'all_candidates':row['selected_all_events'],'all_candidate_users':row['selected_all_users'],
      'known_d0':row['selected_d0_known_events'],'unknown_d0':row['selected_d0_unknown_events'],
      'no_d0':row['selected_d0_noapply_events'],'ppv_no_d0':row['d0_nonapply_precision'],
      'ci95_low':row['d0_nonapply_precision_ci95_low'],'ci95_high':row['d0_nonapply_precision_ci95_high'],
      'd0_apply':row['selected_d0_apply_events'],'d1_d3_apply':row['selected_d1_3_apply_events'],
      'd3_known':row['selected_d3_known_events'],'d3_unknown':row['selected_d3_unknown_events'],
      'd3_noapply':row['selected_d3_noapply_events'],'npv_d3':row['d3_nonapply_precision_known_only'],
      'all_candidate_coverage':row['selection_coverage_all_scored'],
      'share_of_model_lowp_candidates':row['selection_share_of_all_lowp_candidates']}


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--mapping',type=Path,default=ROOT/'validation_mapping.parquet');args=parser.parse_args()
    mapping=pd.read_parquet(args.mapping)
    source=OLD/'events_predictions.parquet';labels=OLD/'evaluation/labels_evaluated.parquet'
    pred=pd.read_parquet(source);d=pd.read_parquet(labels)
    if pred.event_id.duplicated().any() or d.event_id.duplicated().any():raise ValueError('Duplicate original validation event IDs')
    # Verify labels and probabilities used here are exactly the prior frozen data.
    a=pred.set_index('event_id').sort_index();b=d.set_index('event_id').sort_index()
    np.testing.assert_equal(a.index.to_numpy(),b.index.to_numpy())
    for c in ['user_id','as_of_time','p_v4_d0','p_v4_d3']:
        np.testing.assert_equal(a[c].to_numpy(),b[c].to_numpy())
    d=d[(d.offer_date>='2026-10-09')&(d.offer_date<='2026-10-21')].copy()
    assert len(d)==8866 and int((d.mature_d3&d.y_d3.notna()).sum())==8717
    assert not ((d.y_d0==1)&(d.y_d3==0)).any()
    d,quality=add_profiles(d,mapping)
    thresholds_path=ROOT/'thresholds.json'
    thresholds=json.loads(thresholds_path.read_text())
    v=d.score_band.isin(['HIGH20','MID30','LOW50'])
    score=pd.to_numeric(d.score_410,errors='coerce')
    expected=np.select([score.ge(thresholds['q80']),score.ge(thresholds['q50'])],['HIGH20','MID30'],default='LOW50')
    if (v & d.score_band.ne(expected)).any():raise ValueError('Supplied score_band disagrees with frozen full-cohort cutpoints')
    rows=[report_aliases(x) for x in analyze_rules(d)];comp=compositions(d)
    main_rows=[report_aliases(x,'main8717') for x in analyze_rules(d.loc[d.mature_d3&d.y_d3.notna()].copy())]
    allrow=next(x for x in rows if x['rule']=='LOWP_ALL')
    assert allrow['selected_all_events']==3701
    assert allrow['selected_d0_known_events']==3656
    assert allrow['selected_d0_noapply_events']==3143
    assert allrow['selected_d0_apply_events']==513
    assert allrow['selected_d3_unknown_events']==45
    assert allrow['selected_d1_3_apply_events']==655
    (ROOT/'prediction_profiles.csv').write_text(pd.DataFrame(rows).to_csv(index=False),encoding='utf-8')
    (ROOT/'prediction_profile_composition.csv').write_text(pd.DataFrame(comp).to_csv(index=False),encoding='utf-8')
    (ROOT/'prediction_profile_mapping_quality.csv').write_text(pd.DataFrame([quality]).to_csv(index=False),encoding='utf-8')
    keep=['event_id','user_id','as_of_time','p_v4_d0','p_v4_d3','y_d0','y_d3','mature_d3','profile_key_status','score_410','score_status','score_band','settled_loan_seq','lifecycle_band']
    d[keep].to_parquet(ROOT/'prediction_profiles_event_audit.parquet',index=False)
    result={
      'contract':{
        'model':'Frozen T0 timing V4; no retraining or recalibration',
        'population':'All 8,866 scored strict T0 events on October9-21, including149 events with unknown outcomes; 8,717 D3 mature and label-known events form the principal evaluable cohort.',
        'selection':'Original unnormalized p_v4_d3<0.5; all3,701 candidates retained, including45 unknown outcomes. No outcome is required for selection.',
        'horizon':'D0 is after offer until next local midnight. D3 is D0-D3 through event_date+4days exclusive, not rolling72hours.',
        'cutoff':'2026-10-25 00:00:00 America/Belize exclusive',
        'd0_precision_denominator':'Selected events with known D0 outcome; unknown not imputed. Complete candidate counts/coverage are shown separately.',
        'd3_precision_and_delay_denominator':'Selected events with known D3 outcome, not the entire selected candidate count. D1-D3 is yD0=0,yD3=1.',
        'profile_source':'Risk band and settled-loan sequence from original passed T0 order mapping; score410 cutpoints are fixed from the full January-October population before outcomes. No per-stage or per-model-subset quantile refitting.',
        'life_sequence_definition':'Use supplied settled_loan_seq of the clean-settlement order triggering this T0. It is not a current/future lifetime total and not inferred from subsequent borrowing.',
        'rules_status':'All joint eligibility rules are candidate descriptions. No optimal threshold or production rollout is chosen from this replay.',
        'missing_profile_policy':'Unmatched/time-mismatched profiles remain UNMAPPED. Missing/out-of-range/conflicted410 is never automatically treated as favorable. UNKNOWN lifecycle not forced to another band.',
        'bootstrap':f'{REPLICATES} user-cluster percentile resamples, all events for the same user together, fixed eligibility rules and source mapping. CIs do not resolve missing/profile-time/source bias. Sparse zero-failure groups can have degenerate percentile intervals.',
        'seed':SEED,
        'causal_limit':'Observed non-application under historical policies is not a measure of incentive responsiveness or incremental profit. High risk score/lifecycle retention does not itself demonstrate safe or profitable extra lending.',
      },
      'source_files':{str(source):sha(source),str(labels):sha(labels),str(args.mapping):sha(args.mapping),str(thresholds_path):sha(thresholds_path)},
      'score_band_frozen_metadata':thresholds,
      'mapping_quality':quality,'match_quality':quality,'rules':rows,'compositions':comp,
      'rules_main_evaluable':main_rows,
      'group_composition':[{**x,
        'population':{'ALL_SCORED':'full8866','LOWP_D3_LT_0_5':'selected3701'}[x['population']],
        'dimension':{'score_band':'risk','lifecycle_band':'life'}[x['dimension']],
        'share':x['event_share']} for x in comp],
      'crosscheck_original_targeting':{
        'all_scored':len(d),'evaluable_d3':int(d.y_d3.notna().sum()),
        'all_candidates':allrow['selected_all_events'],'candidate_d0_known':allrow['selected_d0_known_events'],
        'candidate_d0_noapply':allrow['selected_d0_noapply_events'],'candidate_d0_apply':allrow['selected_d0_apply_events'],
        'candidate_d3_unknown':allrow['selected_d3_unknown_events'],'passed':True,
      },
    }
    result['meta']=result['contract']
    result['meta']['q50']=thresholds['q50']
    result['meta']['q80']=thresholds['q80']
    result['meta']['valid_cutpoint_population_events']=thresholds['valid_n']
    keyed={(x['population'],x['dimension'],x['band']):x for x in comp}
    contrast=[]
    for dimension,bands in [('score_band',SCORE_BANDS),('lifecycle_band',LIFE_BANDS)]:
        for band in bands:
            full=keyed['ALL_SCORED',dimension,band]
            selected=keyed['LOWP_D3_LT_0_5',dimension,band]
            contrast.append({'dimension':{'score_band':'risk','lifecycle_band':'life'}[dimension],
              'band':band,'all_scored_events':full['events'],'lowp_candidate_events':selected['events'],
              'all_scored_share':full['event_share'],'lowp_candidate_share':selected['event_share'],
              'lowp_minus_full_share_pp':100*(selected['event_share']-full['event_share'])})
    result['composition_contrast']=contrast
    json_write(ROOT/'prediction_profiles.json',result)
    print(json.dumps(safe({'output':str(ROOT/'prediction_profiles.json'),'mapping_quality':quality,'rules':len(rows),'all_candidates':allrow['selected_all_events']}),ensure_ascii=False))


if __name__=='__main__':main()
