"""Frozen T0 V3/V4 feature replay, with no writes to the original versions.

Run with system python3 (numpy 2 / pandas 2), not the Anaconda numpy 1 runtime.
Only source CSV/parquet/pickle inputs are read. The SQL/extraction stage is separate.
The original pure function bodies are compiled from their AST: their path setup,
directory creation, DB imports and executable pipeline entrypoints never run.
"""
from __future__ import annotations
import argparse, ast, hashlib, json, multiprocessing, time
from functools import lru_cache
from pathlib import Path
import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
ORIGINAL = Path('/Users/wangchuanliang/Documents/Codex/2026-09-21/ji-x/outputs')
V1, V2, V3, V4 = [ORIGINAL / ('T0提单时点预测模型_V' + str(i)) for i in [1,2,3,4]]
PAGES = ['newpage','amount','contract','term','confirm','plan','purpose','coupon_back','coupon_confirm','coupon_page','repayment_page']
BEH = ['events'] + PAGES + ['duration','apply_duration']
_CTX = None

def pure_module(path, constants=None):
    """Load definitions only, never import original common/db or execute its main."""
    tree = ast.parse(Path(path).read_text())
    keep = [n for n in tree.body if isinstance(n, (ast.FunctionDef, ast.ClassDef))]
    ns = {'np': np, 'pd': pd, 'lru_cache': lru_cache}
    ns.update(constants or {})
    exec(compile(ast.Module(body=keep, type_ignores=[]), str(path), 'exec'), ns)
    return ns

V1F = pure_module(V1/'model.py', {'CORE':[], 'RISK':[], 'CATEGORIES':[],
    'HORIZONS':[0,3,7,15], 'END_DAYS':[1,4,8,16], 'START_DAYS':[0,1,4,8]})
# The frozen constants are declarative literals; no old module imports execute.
for node in ast.parse((V1/'model.py').read_text()).body:
    if isinstance(node, ast.Assign) and any(isinstance(z,ast.Name) and z.id in ['CORE','RISK','CATEGORIES'] for z in node.targets):
        exec(compile(ast.Module(body=[node],type_ignores=[]),str(V1/'model.py'),'exec'),V1F)
V2F = pure_module(V2/'build_features.py', {'WINDOWS':[1,3,7,14,30,60,90], 'BEH':BEH, 'DAY_NS':86400*10**9})
V3F = pure_module(V3/'history_features.py', {'SPECS':{}, 'DAY':86400.,
    'SCOPES':['life','last3','last5','30d','90d','180d'],
    'SCOPE_CN':{'life':'全可观察历史','last3':'最近3次资格/事件','last5':'最近5次资格/事件','30d':'最近30天','90d':'最近90天','180d':'最近180天'}})
V4F = pure_module(V4/'product_features.py', {'ATTRS':['fee','daily','days','terms'],
    'ATTR_CN':{'fee':'息费率','daily':'日息','days':'账期天数','terms':'期次'}, 'SPECS':{}})

def digest(p):
    h=hashlib.sha256()
    with Path(p).open('rb') as f:
        for z in iter(lambda:f.read(1048576),b''):h.update(z)
    return h.hexdigest()

def read_frame(path, **kwargs):
    path=Path(path)
    if path.suffix=='.parquet':return pd.read_parquet(path)
    if '.pkl' in path.name:return pd.read_pickle(path,compression='infer')
    return pd.read_csv(path,**kwargs)

def times(frame, cols):
    frame=frame.copy()
    for c in cols:
        if c in frame:frame[c]=pd.to_datetime(frame[c],format='mixed',errors='coerce')
    return frame

def require(frame, cols, name):
    absent=sorted(set(cols)-set(frame.columns))
    if absent:raise ValueError(name+' is structurally incomplete: '+','.join(absent))

def enrich_histories(orders, credits, payments):
    """Exact V2 load_histories transformations, returning in memory only."""
    orders=times(orders,['reg_date','apply_time','apply_date','remit_time','remit_date','repaid_time','repaid_date','due_date'])
    credits=times(credits,['credit_time'])
    payments=times(payments,['payin_date'])
    require(orders,['user_id','serial_id','reg_date','apply_amt','remit_amt','pre_amt','post_amt','loan_day',
        'total_term','is_remit','is_repaid','loan_status_code','remit_succ_rnb','product_no','loan_type'], 'orders')
    require(credits,['user_id','serial_id','credit_time','credit_amt','is_pass1','risk_product'],'credits')
    require(payments,['user_id','serial_id','payin_date','payin_time','amount','source_rows'],'payments')
    if orders.duplicated(['user_id','serial_id']).any():raise ValueError('Duplicate order snapshots must be resolved by extractor')
    if orders.apply_time.isna().any():raise ValueError('Order apply_time missing; original merge_asof contract cannot reconstruct these rows')
    orders=orders.sort_values(['user_id','apply_time','serial_id']).reset_index(drop=True)
    credits=credits.sort_values(['user_id','credit_time','serial_id']).reset_index(drop=True)
    if credits.credit_time.isna().any():raise ValueError('Missing historical credit timestamp')
    unix=pd.to_numeric(payments.payin_time,errors='coerce');seconds=unix.where(unix<10**11,unix/1000)
    payments['payment_time']=pd.to_datetime(seconds,unit='s',utc=True,errors='coerce').dt.tz_convert('America/Belize').dt.tz_localize(None)
    payments['timestamp_valid']=(payments.payment_time.dt.normalize()==payments.payin_date)&(seconds>946684800)
    payments=payments.sort_values(['user_id','payment_time','serial_id']).reset_index(drop=True)
    approved=credits.loc[credits.is_pass1.eq(1),['user_id','serial_id','credit_time','credit_amt']].sort_values('credit_time')
    joined=pd.merge_asof(orders[['user_id','serial_id','apply_time']].assign(original_row=np.arange(len(orders))).sort_values('apply_time'),
        approved,left_on='apply_time',right_on='credit_time',by=['user_id','serial_id'],direction='backward')
    orders['credit_amt']=joined.sort_values('original_row').credit_amt.to_numpy()
    orders['utilization']=(orders.apply_amt/orders.credit_amt.where(orders.credit_amt>0)).where(orders.apply_amt>0)
    orders['fee_rate']=(orders.pre_amt+orders.post_amt)/orders.remit_amt.where(orders.remit_amt>0)
    orders['daily_rate']=orders.fee_rate/orders.loan_day.where(orders.loan_day>0)
    known=orders.loc[orders.repaid_time.gt(pd.Timestamp('2000-01-01'))&((orders.is_repaid==1)|(orders.loan_status_code==7)),['user_id','serial_id','repaid_time','repaid_date']]
    ledger=payments.loc[payments.timestamp_valid].merge(known,on=['user_id','serial_id'],how='inner',validate='many_to_one')
    ledger=ledger.loc[ledger.payment_time.le(ledger.repaid_time)]
    aggregate=ledger.groupby('serial_id').agg(flow_settle_time=('payment_time','max'),settle_cash=('amount','sum'),
        settle_payment_n=('source_rows','sum'),settle_payment_days=('payin_date','nunique'))
    orders=orders.merge(aggregate,left_on='serial_id',right_index=True,how='left',validate='one_to_one')
    bad=orders.flow_settle_time.dt.normalize().ne(orders.repaid_date)
    orders.loc[bad,'flow_settle_time']=pd.NaT
    orders.loc[bad,['settle_cash','settle_payment_n','settle_payment_days']]=np.nan
    orders['early_days']=(orders.due_date-orders.flow_settle_time.dt.normalize()).dt.days
    orders['apply_settle_days']=(orders.flow_settle_time-orders.apply_time).dt.total_seconds()/86400
    orders['remit_settle_days']=(orders.flow_settle_time-orders.remit_time).dt.total_seconds()/86400
    orders['settle_cash_remit_ratio']=orders.settle_cash/orders.remit_amt.where(orders.remit_amt>0)
    return orders,credits,payments

def old_monthly_profiles(events, profile_daily):
    """V1's month-lag prior-contract profiles; never current product_info."""
    p=times(profile_daily,['profile_date'])
    require(p,['profile_date','product_no','orders','remit_sum','fee_sum','day_sum','day_n','term_sum','term_n'],'profiles')
    rows=[]
    for month in sorted(events.vir_date.dt.to_period('M').dt.to_timestamp().unique()):
        g=p.loc[p.profile_date<pd.Timestamp(month)].groupby('product_no').sum(numeric_only=True)
        g['fee_rate']=g.fee_sum/g.remit_sum;g['loan_days']=g.day_sum/g.day_n;g['terms']=g.term_sum/g.term_n
        g['daily_rate']=g.fee_rate/g.loan_days
        em=events.loc[events.vir_date.dt.to_period('M').dt.to_timestamp().eq(month)]
        for e in em.itertuples():
            tokens=[x.strip() for x in str(e.risk_product).split(',') if x.strip() and x!='nan']
            valid=g.loc[g.index.intersection(tokens)]
            rows.append({'event_id':e.event_id,'current_product_profile_match_n':len(valid),
                'current_history_min_fee_rate':valid.fee_rate.min() if len(valid) else np.nan,
                'current_history_min_daily_rate':valid.daily_rate.min() if len(valid) else np.nan,
                'current_history_max_loan_days':valid.loan_days.max() if len(valid) else np.nan,
                'current_history_max_terms':valid.terms.max() if len(valid) else np.nan})
    return pd.DataFrame(rows)

def prepare_base(events, behavior_v1, profile_daily):
    events=times(events,['as_of_time','vir_date','first_apply_time','followup_end','next_t0_time','data_cutoff_ts'])
    require(events,['event_id','user_id','as_of_time','vir_date','settled_serial_id','credit_serial_id',
        'risk_product','vir_version','previous_product_no','current_total_term'], 'event_features')
    if events.event_id.duplicated().any():raise ValueError('Event IDs not unique')
    prof=old_monthly_profiles(events,profile_daily)
    drop=[c for c in prof if c!='event_id' and c in events]
    base=events.drop(columns=drop).merge(prof,on='event_id',how='left',validate='one_to_one')
    require(behavior_v1,['event_id','beh_events_7d','beh_active_days_7d','beh_events_1d','beh_events_3d','beh_newpage_7d',
        'beh_amount_7d','beh_plan_7d','beh_term_7d','beh_confirm_7d','beh_duration_7d','days_since_active'],'behavior_v1')
    if set(base.event_id)!=set(behavior_v1.event_id):raise ValueError('V1 rolling7-day behavior must cover every event, including zero-activity events')
    base=base.drop(columns=[c for c in behavior_v1 if c!='event_id' and c in base]).merge(behavior_v1,on='event_id',how='left',validate='one_to_one')
    base['beh_source_available']=base.beh_events_7d.notna().astype(int)
    prepared=V1F['prepare'](base)
    needed=[n for n in V1F['CORE']+V1F['RISK'] if not n.startswith('interval_')]+V1F['CATEGORIES']
    require(prepared,needed,'prepared V1 core')
    return prepared

def product_histories(credits, offers, orders):
    c=credits.loc[credits.is_pass1.eq(1)].sort_values(['user_id','credit_time','serial_id'])
    if c.duplicated(['user_id','serial_id']).any():raise ValueError('Repeated approved credit snapshots: need timestamp-aware source resolution')
    eligible=offers.loc[offers.loan_type_code.eq(2)&(offers.has_type2.eq(1)|offers.has_type3.eq(1)),['user_id','serial_id']].drop_duplicates()
    c=c.merge(eligible,on=['user_id','serial_id'],how='inner',validate='one_to_one')
    c=c.merge(orders[['user_id','serial_id','apply_time','product_no']],on=['user_id','serial_id'],how='left',validate='one_to_one')
    groups={}
    for uid,g in c.groupby('user_id',sort=False):
        g=g.sort_values(['credit_time','serial_id'])
        batch=(g.credit_time.diff().gt(pd.Timedelta(seconds=20))|g.credit_time.diff().isna()).cumsum()
        starts=g.groupby(batch).credit_time.min();final=g.loc[~batch.duplicated(keep='last')].copy()
        final['batch_start']=batch.loc[final.index].map(starts)
        recs=[(r.credit_time,V4F['tokens'](r.risk_product),int(r.serial_id),r.apply_time,str(r.product_no) if pd.notna(r.product_no) else '') for r in final.itertuples()]
        groups[int(uid)]=(final.batch_start.to_numpy('datetime64[ns]'),final.credit_time.to_numpy('datetime64[ns]'),recs)
    return groups

def one_row(i):
    c=_CTX;e=c['events'][i];uid=int(e.user_id)
    o,cr,p,d,v=[g.get(uid,z) for g,z in zip(c['groups'],c['empty'])]
    row=V2F['loan_features'](o,p,cr,e.as_of_time,e.settled_serial_id,e.current_credit_amt,e.previous_credit_amt)
    eq=o.loc[o.repaid_time.eq(e.as_of_time)&o.is_remit.eq(1)&o.remit_amt.gt(0)&o.remit_time.le(e.as_of_time)&((o.is_repaid==1)|(o.loan_status_code==7)),'serial_id'].tolist()
    row.update(V2F['behavior_features'](d,c['prefix'].loc[e.event_id].to_dict(),p,e.as_of_time,o.reg_date.min(),eq))
    row['current_total_term_known']=e.current_total_term if e.current_total_term>0 else np.nan
    for new,current,previous in [('term','current_history_max_terms','previous_total_term'),('days','current_history_max_loan_days','previous_loan_day'),
        ('fee','current_history_min_fee_rate','previous_fee_rate'),('daily','current_history_min_daily_rate','previous_daily_rate')]:
        row['current_'+new+'_to_previous']=V2F['safe'](getattr(e,current),getattr(e,previous))
    change=e.current_credit_amt-e.previous_credit_amt
    row['current_credit_change_abs_band']=int(np.digitize(abs(change),[500,1000,2000,3000])) if np.isfinite(change) else np.nan
    ratio=V2F['safe'](abs(change),e.previous_credit_amt)
    row['current_credit_change_relative_band']=int(np.digitize(ratio,[.1,.25,.5,1])) if np.isfinite(ratio) else np.nan
    for metric,tol in [('fee_rate',.01),('daily_rate',.0005)]:
        value=np.round(getattr(e,metric+'_change'),12)
        row['current_'+metric+'_direction_tolerance']=float(np.sign(value)) if np.isfinite(value) and abs(value)>=tol else (0 if np.isfinite(value) else np.nan)
    if set(row)!=set(c['v2_names']):raise AssertionError('Frozen V2 feature schema changed')
    hist,audit=V3F['snapshot'](v,o,e.as_of_time,e.event_id,e.current_credit_amt,e.previous_utilization,e.successful_loan_count,e.credit_direction)
    if set(hist)!=set(c['v3_new_names']):raise AssertionError('Frozen V3 feature schema changed')
    g=c['products'].get(uid)
    if g:
        starts,ts,recs=g;k=np.searchsorted(ts,e.as_of_time.to_datetime64(),side='right')
        current_start=starts[k-1] if k and ts[k-1]==e.as_of_time.to_datetime64() else e.as_of_time.to_datetime64()
        h=np.searchsorted(ts,current_start,side='left');ph=recs[:h]
    else:ph=[]
    prod,paudit=V4F['snapshot'](ph,e.as_of_time,e.risk_product,c['profiles'],
        [e.previous_fee_rate,e.previous_daily_rate,e.previous_loan_day,e.previous_total_term],e.successful_loan_count)
    if set(prod)!=set(c['product_names']) or paudit['future_history_used']:raise AssertionError('Frozen V4 product schema/time changed')
    allvals={**row,**hist,**prod}
    # V3 base category values use its frozen training maps, not fresh levels.
    for n in c['base_names']:
        if n.startswith('interval_'):allvals[n]=0
        elif n in c['maps']:allvals[n]=c['maps'][n].get(str(getattr(e,n)) ,np.nan)
        else:allvals[n]=getattr(e,n)
    v3=np.array([allvals[n] for n in c['v3_names']],dtype='float32')
    v4=np.array([allvals[n] for n in c['v4_names']],dtype='float32')
    v3[np.isinf(v3)]=np.nan;v4[np.isinf(v4)]=np.nan
    audit.update(event_id=int(e.event_id),life_funded_n=row['life_funded_n'],cached_funded_n=e.successful_loan_count,
        prefix_last_active=str(c['prefix'].loc[e.event_id,'last_active_time']))
    return v3,v4,audit

def chunk(bounds):
    a,b=bounds;vals=[one_row(i) for i in range(a,b)]
    return a,b,np.stack([x[0] for x in vals]),np.stack([x[1] for x in vals]),[x[2] for x in vals]

def build_replay(inputs, output_dir, workers=4, chunk_size=500):
    """inputs: dict of named DataFrames; returns matrix paths and audit dictionary."""
    global _CTX
    at=time.time();out=Path(output_dir).resolve()
    if ORIGINAL.resolve() in out.parents:raise ValueError('Never write into original versions')
    out.mkdir(parents=True,exist_ok=True)
    orders,credits,payments=enrich_histories(inputs['orders'],inputs['credits'],inputs['payments'])
    offers=times(inputs['history_offers'],['credit_time','vir_date'])
    require(offers,['user_id','serial_id','credit_time','vir_date','credit_amt','loan_type_code','has_type2','has_type3','type_distinct_n','export_id'],'history_offers')
    if not offers.type_distinct_n.le(1).all():raise ValueError('Ambiguous historical recycle types')
    daily=times(inputs['daily_behavior'],['create_date','last_active_time'])
    require(daily,['user_id','create_date','last_active_time']+BEH,'daily_behavior')
    if daily.duplicated(['user_id','create_date']).any():raise ValueError('Daily source rows duplicated; frozen/incremental overlap must be resolved')
    bad=daily.last_active_time.ge(daily.create_date+pd.Timedelta(days=1))|daily.last_active_time.lt(daily.create_date)
    bad_n=int(bad.sum());daily=daily.loc[~bad].sort_values(['user_id','create_date'])
    prefix=times(inputs['prefix_behavior'],['last_active_time']).set_index('event_id',verify_integrity=True)
    require(prefix,['last_active_time']+BEH,'prefix_behavior')
    profile=inputs['product_profiles_daily'].copy();profile['product_no']=profile.product_no.astype(str)
    base=prepare_base(inputs['events'],inputs['behavior_v1'],profile)
    if set(prefix.index)!=set(base.event_id):raise ValueError('Prefix must contain every event exactly once')
    aligned=prefix.reindex(base.event_id)
    if not (aligned.last_active_time.isna().to_numpy()|(aligned.last_active_time.to_numpy()<base.as_of_time.to_numpy())).all():raise ValueError('Future behavior in current-day prefix')
    v2_names=json.loads((V2/'datasets/lifecycle_feature_names.json').read_text())
    v3_names=json.loads((V3/'datasets/model_feature_names.json').read_text())
    v3_life=json.loads((V3/'datasets/lifecycle_feature_names.json').read_text())
    product_names=json.loads((V4/'datasets/product_feature_names.json').read_text())
    v4_names=json.loads((V4/'datasets/numeric_feature_names.json').read_text())
    base_names=[n for n in v3_names if n not in set(v3_life)]
    require(base,[n for n in base_names if not n.startswith('interval_')],'frozen base input')
    groups=[{int(u):g for u,g in f.groupby('user_id',sort=False)} for f in [orders,credits,payments,daily,offers]]
    _CTX={'events':tuple(base.itertuples()),'groups':groups,'empty':[f.iloc[0:0] for f in [orders,credits,payments,daily,offers]],
        'prefix':prefix,'products':product_histories(credits,offers,orders),'profiles':V4F['Profiles'](profile),
        'v2_names':v2_names,'v3_new_names':v3_life[len(v2_names):], 'v3_names':v3_names,'v4_names':v4_names,
        'base_names':base_names,'product_names':product_names,'maps':json.loads((V3/'datasets/categorical_mappings.json').read_text())}
    a3=np.lib.format.open_memmap(out/'v3_model_features.npy',mode='w+',dtype='float32',shape=(len(base),len(v3_names)))
    a4=np.lib.format.open_memmap(out/'v4_numeric_features.npy',mode='w+',dtype='float32',shape=(len(base),len(v4_names)))
    bounds=[(a,min(a+chunk_size,len(base))) for a in range(0,len(base),chunk_size)];audits=[]
    if workers>1:
        with multiprocessing.get_context('fork').Pool(workers) as pool:
            for start,stop,x3,x4,au in pool.imap(chunk,bounds,chunksize=1):
                a3[start:stop]=x3;a4[start:stop]=x4;audits.extend(au);a3.flush();a4.flush()
                print('REPLAY_FEATURES',stop,len(base),'seconds',round(time.time()-at),flush=True)
    else:
        for start,stop,x3,x4,au in map(chunk,bounds):
            a3[start:stop]=x3;a4[start:stop]=x4;audits.extend(au);a3.flush();a4.flush()
            print('REPLAY_FEATURES',stop,len(base),'seconds',round(time.time()-at),flush=True)
    base.to_pickle(out/'base_with_labels.pkl.gz',compression='gzip')
    for file,names in [('v3_feature_names.json',v3_names),('v4_numeric_names.json',v4_names)]:
        (out/file).write_text(json.dumps(names,ensure_ascii=False,indent=2))
    audit_df=pd.DataFrame(audits);audit_df.to_csv(out/'event_feature_audits.csv.gz',index=False,compression='gzip')
    audit={'events':len(base),'users':int(base.user_id.nunique()),'v3_columns':len(v3_names),'v4_numeric_columns':len(v4_names),
        'invalid_daily_timestamp_groups_removed':bad_n,'invalid_payment_timestamp_rows':int((~payments.timestamp_valid).sum()),
        'funded_count_mismatch_events':int(audit_df.life_funded_n.ne(audit_df.cached_funded_n).sum()),
        'seconds':round(time.time()-at,1),'no_old_directory_writes':True,'structural_missing_feature_fill':False,
        'v3_missing_share':float(np.isnan(a3).mean()),'v4_missing_share':float(np.isnan(a4).mean()),
        'code_fingerprints':{str(p):digest(p) for p in [V1/'model.py',V2/'build_features.py',V3/'history_features.py',V4/'product_features.py',Path(__file__)]},
        'limitations':['Risk scores have no availability timestamp, same as frozen model.',
            'Recycle-type and contract fields may be mutable; current extracts are retrospective reconstruction, not contemporaneously stored snapshots.',
            'Daily behavior available from 2024-01-01; pre-2024 registrations are explicitly left-censored.',
            'Missing numeric values are genuine frozen formulas (no history/zero denominator), not a missing-column workaround.']}
    (out/'feature_replay_audit.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2))
    return audit

def main():
    p=argparse.ArgumentParser();p.add_argument('--manifest',required=True);p.add_argument('--output-dir',required=True)
    p.add_argument('--workers',type=int,default=4);p.add_argument('--chunk-size',type=int,default=500);args=p.parse_args()
    manifest=json.loads(Path(args.manifest).read_text());paths=manifest.get('sources',manifest)
    inputs={}
    for name in ['events','orders','credits','payments','daily_behavior','prefix_behavior','history_offers','product_profiles_daily','behavior_v1']:
        path=paths[name]
        if isinstance(path,list):inputs[name]=pd.concat([read_frame(x,dtype={'product_no':str,'risk_product':str,'loan_type':str,'vir_version':str,'previous_product_no':str}) for x in path],ignore_index=True)
        else:inputs[name]=read_frame(path,dtype={'product_no':str,'risk_product':str,'loan_type':str,'vir_version':str,'previous_product_no':str})
    print(json.dumps(build_replay(inputs,args.output_dir,args.workers,args.chunk_size),ensure_ascii=False,indent=2))

if __name__=='__main__':main()
