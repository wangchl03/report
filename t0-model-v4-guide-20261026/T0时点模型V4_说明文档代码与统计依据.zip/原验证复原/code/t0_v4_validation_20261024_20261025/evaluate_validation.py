"""Evaluate frozen T0 predictions on fully mature event cohorts, without training.

Clock contract: all naive timestamps are America/Belize local time. Aware
timestamps are converted to this zone and made naive. End boundaries are
exclusive. Labels are reconstructed here rather than trusting cached y_d*.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

HORIZONS = (0, 3, 7, 15)
CUTOFF = pd.Timestamp("2026-10-25 00:00:00")
TZ = "America/Belize"
COHORTS = {
    "main": (pd.Timestamp("2026-10-09"), CUTOFF),
    "supplemental": (pd.Timestamp("2026-09-22"), pd.Timestamp("2026-10-09")),
}
METRICS = ["auc", "pr_ap", "ks", "brier", "logloss", "actual_rate", "mean_prediction"] + [
    f"top{k}_{suffix}" for k in (5, 10, 20) for suffix in ("precision", "recall", "lift")
]


def local_time(series: pd.Series) -> pd.Series:
    out = pd.to_datetime(series, errors="coerce", format="mixed")
    if isinstance(out.dtype, pd.DatetimeTZDtype):
        out = out.dt.tz_convert(TZ).dt.tz_localize(None)
    if not pd.api.types.is_datetime64_any_dtype(out.dtype):
        raise ValueError(f"{series.name}: mixed aware/naive timestamps are not accepted")
    return out


def prepare_labels(events: pd.DataFrame) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Require chronological maturity BEFORE permitting an early positive label."""
    df = events.copy()
    if "next_t0_time" not in df and "next_t0" in df:
        df = df.rename(columns={"next_t0": "next_t0_time"})
    required = ["event_id", "user_id", "as_of_time", "next_t0_time", "first_apply_time"]
    missing = [c for c in required if c not in df]
    if missing:
        raise ValueError(f"Missing input columns: {missing}")
    if df.event_id.isna().any() or df.event_id.duplicated().any():
        raise ValueError("event_id must be non-null and globally unique")
    if df.user_id.isna().any():
        raise ValueError("user_id must not be missing")
    for c in ["as_of_time", "next_t0_time", "first_apply_time", "followup_end", "data_cutoff_ts"]:
        if c in df:
            original_nonnull = df[c].notna()
            df[c] = local_time(df[c])
            if (original_nonnull & df[c].isna()).any():
                raise ValueError(f"Unparseable timestamp in {c}")
    if df.as_of_time.isna().any():
        raise ValueError("as_of_time must be present")
    if (df.next_t0_time.notna() & (df.next_t0_time <= df.as_of_time)).any():
        raise ValueError("next_t0_time must be strictly later than as_of_time")
    if (df.first_apply_time.notna() & (df.first_apply_time < df.as_of_time)).any():
        raise ValueError("first_apply_time must not precede the event")
    df["offer_date"] = df.as_of_time.dt.normalize()
    df["offer_week"] = (df.offer_date - pd.to_timedelta(df.offer_date.dt.dayofweek, unit="D")).dt.strftime("%Y-%m-%d")
    # These are administrative observation limits, not last-seen activity times.
    df["administrative_cutoff"] = CUTOFF
    if "data_cutoff_ts" in df:
        mask = df.data_cutoff_ts.notna() & (df.data_cutoff_ts < CUTOFF)
        df.loc[mask, "administrative_cutoff"] = df.loc[mask, "data_cutoff_ts"]
    if (df.administrative_cutoff <= df.as_of_time).any():
        raise ValueError("Observation cutoff must be later than every scored event")
    df["effective_followup_end"] = df.administrative_cutoff
    for c in ["next_t0_time", "followup_end"]:
        if c in df:
            mask = df[c].notna() & (df[c] < df.effective_followup_end)
            df.loc[mask, "effective_followup_end"] = df.loc[mask, c]
    if (df.effective_followup_end <= df.as_of_time).any():
        raise ValueError("Follow-up end must be later than every event")
    apply_after_next = df.first_apply_time.notna() & df.next_t0_time.notna() & (df.first_apply_time >= df.next_t0_time)
    apply_after_admin = df.first_apply_time.notna() & (df.first_apply_time >= df.administrative_cutoff)
    # Do not let a later T0's application leak backwards to the prior event.
    valid_hit_time = df.first_apply_time.notna() & (df.first_apply_time < df.effective_followup_end)
    audit: dict[str, Any] = {
        "input_events": len(df), "input_users": df.user_id.nunique(),
        "first_apply_at_or_after_next_t0_ignored": int(apply_after_next.sum()),
        "first_apply_at_or_after_administrative_cutoff_ignored": int(apply_after_admin.sum()),
        "probability_nonfinite_or_missing": {}, "probability_monotonicity_violations": {},
    }
    for h in HORIZONS:
        boundary = df.offer_date + pd.Timedelta(days=h + 1)
        mature = boundary <= df.administrative_cutoff
        hit = valid_hit_time & (df.first_apply_time < boundary)
        complete = df.effective_followup_end >= boundary
        df[f"boundary_d{h}"] = boundary
        df[f"mature_d{h}"] = mature
        df[f"censored_d{h}"] = mature & ~hit & ~complete
        df[f"y_d{h}"] = np.where(mature & hit, 1.0, np.where(mature & complete, 0.0, np.nan))
        for model in ("v4", "v3"):
            c = f"p_{model}_d{h}"
            if c not in df:
                df[c] = np.nan
            values = pd.to_numeric(df[c], errors="coerce")
            if ((values < 0) | (values > 1)).any():
                raise ValueError(f"Probability outside [0,1] in {c}")
            values = values.where(np.isfinite(values))
            df[c] = values
            audit["probability_nonfinite_or_missing"][c] = int(values.isna().sum())
    for model in ("v4", "v3"):
        matrix = df[[f"p_{model}_d{h}" for h in HORIZONS]].to_numpy(float)
        bad = np.isfinite(matrix[:, :-1]) & np.isfinite(matrix[:, 1:]) & (matrix[:, :-1] > matrix[:, 1:] + 1e-10)
        audit["probability_monotonicity_violations"][model] = int(np.any(bad, axis=1).sum())
        if audit["probability_monotonicity_violations"][model]:
            raise ValueError(f"Non-monotone cumulative predictions for {model}")
    # Segments are snapshots at T0; no future state/current loan count is permitted.
    if "successful_loan_count" in df and "seg_loan_count" not in df:
        n = pd.to_numeric(df.successful_loan_count, errors="coerce")
        df["seg_loan_count"] = pd.cut(n, [0, 1, 3, 5, 10, np.inf], labels=["1次", "2—3次", "4—5次", "6—10次", "11次及以上"]).astype("string").fillna("缺失/非正次数")
    if "product_count" in df and "seg_product_count" not in df:
        n = pd.to_numeric(df.product_count, errors="coerce")
        df["seg_product_count"] = np.select([n.eq(1), n.eq(2), n.gt(2)], ["单产品", "双产品", "三产品及以上"], default="缺失/无产品")
    if "credit_direction" in df and "seg_credit_direction" not in df:
        n = pd.to_numeric(df.credit_direction, errors="coerce")
        df["seg_credit_direction"] = np.select([n.gt(0), n.eq(0), n.lt(0)], ["提额", "额度不变", "降额"], default="缺失")
    for c in ["risk_405_group", "risk_363_group", "history_cycle_group", "activity_group"]:
        if c in df and f"seg_{c}" not in df:
            df[f"seg_{c}"] = df[c].astype("string").fillna("缺失")
    return df, audit


class SortedMetrics:
    """Fixed score order, weighted tie groups, reusable in cluster bootstrap."""
    def __init__(self, y: np.ndarray, p: np.ndarray):
        self.y = np.asarray(y, float)
        self.p = np.asarray(p, float)
        if len(y) == 0:
            self.order = np.array([], dtype=int)
            self.starts = np.array([], dtype=int)
            self.scores = np.array([], dtype=float)
        else:
            self.order = np.argsort(-self.p, kind="stable")
            sorted_p = self.p[self.order]
            self.starts = np.r_[0, 1 + np.flatnonzero(sorted_p[1:] != sorted_p[:-1])]
            self.scores = sorted_p[self.starts]
        clipped = np.clip(self.p, 1e-15, 1 - 1e-15)
        self.squared_error = (self.p - self.y) ** 2
        self.cross_entropy = -(self.y * np.log(clipped) + (1 - self.y) * np.log1p(-clipped))

    def groups(self, weights: np.ndarray | None = None) -> tuple[np.ndarray, np.ndarray]:
        if weights is None:
            weights = np.ones(len(self.y))
        sw = weights[self.order]
        return np.add.reduceat(sw, self.starts), np.add.reduceat(sw * self.y[self.order], self.starts)

    @staticmethod
    def band(cw: np.ndarray, gp: np.ndarray, lower: float, upper: float) -> tuple[float, float, np.ndarray]:
        before = np.r_[0.0, cw[:-1]]
        mass = cw - before
        overlap = np.maximum(0, np.minimum(cw, upper) - np.maximum(before, lower))
        fractions = np.divide(overlap, mass, out=np.zeros_like(overlap), where=mass > 0)
        return float(overlap.sum()), float(np.dot(fractions, gp)), fractions

    def compute(self, weights: np.ndarray | None = None) -> dict[str, float]:
        if len(self.y) == 0:
            return {k: np.nan for k in METRICS}
        if weights is None:
            weights = np.ones(len(self.y))
        n = float(weights.sum())
        if n <= 0:
            return {k: np.nan for k in METRICS}
        group_n, group_y = self.groups(weights)
        cw = np.cumsum(group_n)
        tp = np.cumsum(group_y)
        positives = float(tp[-1])
        negatives = n - positives
        result = {"actual_rate": positives / n,
                  "mean_prediction": float(np.dot(weights, self.p) / n),
                  "brier": float(np.dot(weights, self.squared_error) / n),
                  "logloss": float(np.dot(weights, self.cross_entropy) / n)}
        if positives > 0:
            precision = np.divide(tp, cw, out=np.zeros_like(tp), where=cw > 0)
            result["pr_ap"] = float(np.dot(precision, group_y) / positives)
        else:
            result["pr_ap"] = np.nan
        if positives > 0 and negatives > 0:
            tpr = np.r_[0, tp / positives]
            fpr = np.r_[0, (cw - tp) / negatives]
            result["auc"] = float(np.sum((tpr[1:] + tpr[:-1]) * np.diff(fpr) / 2))
            result["ks"] = float(np.max(tpr - fpr))
        else:
            result["auc"] = result["ks"] = np.nan
        for k in (5, 10, 20):
            selected_n, selected_y, _ = self.band(cw, group_y, 0, n * k / 100)
            rate = selected_y / selected_n if selected_n else np.nan
            result[f"top{k}_precision"] = rate
            result[f"top{k}_recall"] = selected_y / positives if positives else np.nan
            result[f"top{k}_lift"] = rate / result["actual_rate"] if positives else np.nan
        return result

    def deciles(self) -> list[dict[str, Any]]:
        if len(self.y) == 0:
            return []
        gn, gy = self.groups()
        cw = np.cumsum(gn)
        n = float(cw[-1])
        total_y = float(gy.sum())
        result = []
        cumulative_y = 0.0
        for d in range(10):
            count, positives, fractions = self.band(cw, gy, n * d / 10, n * (d + 1) / 10)
            used = fractions > 0
            predicted = float(np.dot(fractions * gn, self.scores) / count)
            actual = positives / count
            cumulative_y += positives
            result.append({"decile": d + 1, "event_weight": count, "positive_weight": positives,
                           "actual_rate": actual, "mean_prediction": predicted,
                           "calibration_gap": predicted - actual,
                           "score_max": float(self.scores[used].max()), "score_min": float(self.scores[used].min()),
                           "coverage": positives / total_y if total_y else np.nan,
                           "cumulative_coverage": cumulative_y / total_y if total_y else np.nan,
                           "lift": actual / (total_y / n) if total_y else np.nan})
        return result


def summary(frame: pd.DataFrame, model: str, h: int) -> dict[str, Any]:
    pcol, ycol = f"p_{model}_d{h}", f"y_d{h}"
    g = frame[frame[ycol].notna() & frame[pcol].notna()]
    score = SortedMetrics(g[ycol].to_numpy(float), g[pcol].to_numpy(float))
    metrics = score.compute()
    rate = metrics["actual_rate"]
    constant_brier = rate * (1 - rate)
    constant_logloss = -(rate * np.log(rate) + (1 - rate) * np.log1p(-rate)) if 0 < rate < 1 else (0.0 if np.isfinite(rate) else np.nan)
    return {"n": len(g), "users": g.user_id.nunique(), "positives": int(g[ycol].sum()),
            "status": "ok" if len(g) else "no_evaluable_scores", **metrics,
            "constant_brier": constant_brier, "constant_logloss": constant_logloss,
            "brier_skill": 1 - metrics["brier"] / constant_brier if constant_brier > 0 else np.nan}


def bootstrap_intervals(frame: pd.DataFrame, h: int, n_boot: int, seed: int, paired: bool) -> list[dict[str, Any]]:
    models = ("v4", "v3") if paired else ("v4",)
    mask = frame[f"y_d{h}"].notna()
    for model in models:
        mask &= frame[f"p_{model}_d{h}"].notna()
    g = frame[mask]
    if len(g) == 0 or n_boot <= 0:
        return []
    y = g[f"y_d{h}"].to_numpy(float)
    prepared = {m: SortedMetrics(y, g[f"p_{m}_d{h}"].to_numpy(float)) for m in models}
    point = {m: obj.compute() for m, obj in prepared.items()}
    cluster, users = pd.factorize(g.user_id, sort=True)
    n_users = len(users)
    rng = np.random.default_rng(seed)
    storage = {m: {metric: [] for metric in METRICS} for m in models}
    if paired:
        storage["v4_minus_v3"] = {metric: [] for metric in METRICS}
    for _ in range(n_boot):
        # Resample users, carrying all their T0 events. The same resample is used
        # for both models; repeated users weight their complete event histories.
        cluster_counts = np.bincount(rng.integers(0, n_users, size=n_users), minlength=n_users)
        weights = cluster_counts[cluster].astype(float)
        metrics = {m: obj.compute(weights) for m, obj in prepared.items()}
        for m in models:
            for metric in METRICS:
                storage[m][metric].append(metrics[m][metric])
        if paired:
            for metric in METRICS:
                storage["v4_minus_v3"][metric].append(metrics["v4"][metric] - metrics["v3"][metric])
    rows = []
    for comparison, values in storage.items():
        for metric, sample in values.items():
            sample = np.asarray(sample)
            sample = sample[np.isfinite(sample)]
            estimate = point["v4"][metric] - point["v3"][metric] if comparison == "v4_minus_v3" else point[comparison][metric]
            rows.append({"comparison": comparison, "metric": metric, "estimate": estimate,
                         "ci_low": float(np.quantile(sample, .025)) if len(sample) else np.nan,
                         "ci_high": float(np.quantile(sample, .975)) if len(sample) else np.nan,
                         "n_boot_valid": len(sample), "n_boot_requested": n_boot, "n": len(g), "users": n_users,
                         "sample": "paired" if paired else "v4_available", "seed": seed})
    return rows


def evaluate(events: pd.DataFrame, n_boot: int = 500, seed: int = 20261025) -> tuple[dict[str, Any], pd.DataFrame]:
    df, audit = prepare_labels(events)
    result: dict[str, Any] = {k: [] for k in ["overall", "flow", "weekly", "deciles", "calibration", "subgroups", "pairwise", "confidence_intervals"]}
    for ci, (cohort, (start, end)) in enumerate(COHORTS.items()):
        cohort_df = df[(df.as_of_time >= start) & (df.as_of_time < end)]
        for hi, h in enumerate(HORIZONS):
            ycol = f"y_d{h}"
            mature = cohort_df[f"mature_d{h}"]
            known = cohort_df[ycol].notna()
            scored = known & cohort_df[f"p_v4_d{h}"].notna()
            paired = scored & cohort_df[f"p_v3_d{h}"].notna()
            mature_df = cohort_df[mature]
            key = {"cohort": cohort, "horizon": h}
            result["flow"].append({**key, "total_events": len(cohort_df), "total_users": cohort_df.user_id.nunique(),
                "mature_events": int(mature.sum()), "immature_events": int((~mature).sum()),
                "censored_events": int(cohort_df[f"censored_d{h}"].sum()),
                "censored_without_hit": int(cohort_df[f"censored_d{h}"].sum()),
                "evaluable_events": int(known.sum()), "positives": int(cohort_df[ycol].sum()),
                "scored_v4_events": int(scored.sum()), "paired_events": int(paired.sum()),
                "first_offer_date": str(mature_df.offer_date.min().date()) if len(mature_df) else None,
                "last_offer_date": str(mature_df.offer_date.max().date()) if len(mature_df) else None})
            for model in ("v4", "v3"):
                if not cohort_df[f"p_{model}_d{h}"].notna().any():
                    continue
                result["overall"].append({**key, "model": model, **summary(cohort_df, model, h)})
                g = cohort_df[known & cohort_df[f"p_{model}_d{h}"].notna()]
                score = SortedMetrics(g[ycol].to_numpy(float), g[f"p_{model}_d{h}"].to_numpy(float))
                dec = [{**key, "model": model, **row} for row in score.deciles()]
                result["deciles"].extend(dec)
                result["calibration"].extend(dec)
                for week, wg in cohort_df.groupby("offer_week", dropna=False):
                    result["weekly"].append({**key, "model": model, "week": week, "total_events": len(wg),
                        "mature_events": int(wg[f"mature_d{h}"].sum()), "censored_events": int(wg[f"censored_d{h}"].sum()),
                        **summary(wg, model, h)})
                for segment in [c for c in df if c.startswith("seg_")]:
                    for value, sg in cohort_df.groupby(segment, dropna=False):
                        result["subgroups"].append({**key, "model": model, "grouping": segment, "group": str(value),
                            "total_events": len(sg), "mature_events": int(sg[f"mature_d{h}"].sum()), **summary(sg, model, h)})
            paired_df = cohort_df[paired]
            if len(paired_df):
                new, old = summary(paired_df, "v4", h), summary(paired_df, "v3", h)
                result["pairwise"].append({**key, "n": len(paired_df), "users": paired_df.user_id.nunique(),
                    **{f"v4_{m}": new[m] for m in METRICS}, **{f"v3_{m}": old[m] for m in METRICS},
                    **{f"delta_{m}": new[m] - old[m] for m in METRICS}})
            base_seed = seed + ci * 100 + hi * 10
            intervals = bootstrap_intervals(cohort_df, h, n_boot, base_seed, paired=False)
            intervals += bootstrap_intervals(cohort_df, h, n_boot, base_seed + 1, paired=True)
            result["confidence_intervals"].extend([{**key, **row} for row in intervals])
    result["meta"] = {
        "timezone": TZ, "cutoff_exclusive": str(CUTOFF), "bootstrap_replicates": n_boot, "bootstrap_seed": seed,
        "cohorts": {c: {"start_inclusive": str(a), "end_exclusive": str(b)} for c, (a, b) in COHORTS.items()},
        "maturity_latest_offer_dates": {str(h): str((CUTOFF - pd.Timedelta(days=h+1)).date()) for h in HORIZONS},
        "maturity": "First require offer-date + (h+1) natural days <= administrative cutoff; early positives from immature events are excluded.",
        "label": "First user application at/after T0, strictly before next T0, administrative cutoff and horizon end; no application plus complete followup is 0; otherwise censored/unknown.",
        "metric_unit": "T0 event; users may have repeated events. Events, not users, form Top-% lists.",
        "top_ties": "Exact probability ties share inclusion weight equally at each rank boundary; Top-x% uses expected fractional event/positive counts with budget x% * N. No outcome or ID breaks ties.",
        "decile_ties": "Ten equal expected-size score-ranked bins, 1=highest; tied events crossing a boundary split proportionally. Event_weight/positive_weight may be noninteger.",
        "ci": "95% percentile user-cluster bootstrap; resample users with replacement and carry all user events. V4-V3 uses identical paired events and resamples. No multiplicity correction; exploratory subgroup estimates.",
        "pr_ap": "Average precision, sum(score-threshold precision * positive recall increment); not trapezoidal PR AUC.",
        "calibration_gap": "mean_prediction - actual_rate, positive means overprediction",
        "constant_reference": "constant_brier=actual_rate*(1-actual_rate); constant_logloss=entropy(actual_rate); brier_skill=1-model_brier/constant_brier. Outcome-fitted constant on the same evaluation sample is a calibration diagnostic, not a deployable prior or tuning baseline.",
        "grouping_definitions": {
            "seg_loan_count": "Successful loan count available at T0, grouped 1 / 2-3 / 4-5 / 6-10 / 11+; missing/nonpositive separately; no future lifecycle count is used.",
            "seg_product_count": "Number of distinct products in the T0 approved risk_product set: one / two / three or more; missing or empty separately.",
            "seg_credit_direction": "Sign of the current T0 approved credit amount minus previous approved credit amount; rise / unchanged / fall / missing.",
            "seg_history_cycle": "Frozen original cyc_ever_eligible/cyc_ever_applied features computed using strictly prior cycle-loan credit offers and observed applications at T0: ever applied / eligible but never applied / no eligible history; missing kept separate.",
        },
        "audit": audit,
    }
    result["limitations"] = [
        "This is a retrospective replay unless timestamped original scores and feature snapshots are independently established.",
        "Fully mature then evaluable events are assessed; next-T0 censoring can be informative. Complete-case metrics do not identify performance among censored events.",
        "The main cohort D15 only has October 9 mature; it cannot establish temporal stability.",
        "Supplemental dates precede the claimed model completion date and are diagnostic, not independent post-freeze verification.",
        "Actual label availability and historical feature availability must be audited separately; reconstructed features cannot prove online point-in-time availability.",
        "Top-percent metrics measure association/prediction. They are not evidence that recall operations cause incremental applications or profit.",
        "Subgroup and weekly small-sample/single-class metrics are reported as missing where undefined; confidence intervals describe sampling uncertainty conditional on observed data.",
    ]
    return result, df


def json_safe(obj: Any) -> Any:
    if isinstance(obj, dict):
        return {str(k): json_safe(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return [json_safe(v) for v in obj]
    if isinstance(obj, (np.integer,)):
        return int(obj)
    if isinstance(obj, (float, np.floating)):
        return float(obj) if np.isfinite(obj) else None
    if isinstance(obj, (pd.Timestamp,)):
        return str(obj)
    return obj


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", type=Path, required=True)
    parser.add_argument("--out", type=Path, required=True)
    parser.add_argument("--bootstrap", type=int, default=500)
    parser.add_argument("--seed", type=int, default=20261025)
    args = parser.parse_args()
    events = pd.read_parquet(args.input)
    results, labeled = evaluate(events, args.bootstrap, args.seed)
    results["meta"]["input_path"] = str(args.input.resolve())
    results["meta"]["input_sha256"] = hashlib.sha256(args.input.read_bytes()).hexdigest()
    args.out.mkdir(parents=True, exist_ok=True)
    (args.out / "metrics.json").write_text(json.dumps(json_safe(results), ensure_ascii=False, indent=2), encoding="utf-8")
    for name in ["overall", "flow", "weekly", "deciles", "calibration", "subgroups", "pairwise", "confidence_intervals"]:
        pd.DataFrame(results[name]).to_csv(args.out / f"{name}.csv", index=False)
    labeled.to_parquet(args.out / "labels_evaluated.parquet", index=False)
    print(json.dumps({"output": str(args.out), "events": len(labeled), "overall_rows": len(results["overall"]), "bootstrap": args.bootstrap}))


if __name__ == "__main__":
    main()
