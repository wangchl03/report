"""Score frozen T0 V3/V4 snapshots, then rebuild observation labels locally.

No DB access, training, calibration fitting or writes to original artifacts.
Run with system python3 / numpy 2. Frozen pure scoring function bodies are
compiled from AST so importing old common modules cannot create directories.
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import sys
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent
OLD = Path("/Users/wangchuanliang/Documents/Codex/2026-09-21/ji-x/outputs")
V1, V3, V4 = [OLD / f"T0提单时点预测模型_V{i}" for i in [1, 3, 4]]
HORIZONS, START_DAYS, END_DAYS = [0, 3, 7, 15], [0, 1, 4, 8], [1, 4, 8, 16]
CUTOFF = pd.Timestamp("2026-10-25 00:00:00")
sys.path.insert(0, str(V1 / "runtime"))
import joblib


def digest(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def definitions(path: Path, names: list[str], globals_: dict[str, Any]) -> dict[str, Any]:
    tree = ast.parse(path.read_text())
    selected = [node for node in tree.body if isinstance(node, (ast.FunctionDef, ast.ClassDef)) and node.name in names]
    if {node.name for node in selected} != set(names):
        raise ValueError(f"Missing frozen scoring functions in {path}")
    namespace = {"np": np, "pd": pd, "HORIZONS": HORIZONS, "START_DAYS": START_DAYS, "END_DAYS": END_DAYS}
    namespace.update(globals_)
    exec(compile(ast.Module(body=selected, type_ignores=[]), str(path), "exec"), namespace)
    return namespace


def scoring_functions():
    tokens = definitions(V4 / "product_features.py", ["tokens"], {})["tokens"]
    v4 = definitions(V4 / "model_v4.py", ["encode", "apply_calibration", "predict"],
                     {"tokens": tokens, "CATS": ["vir_version", "previous_product_no", "risk_product"]})
    v3 = definitions(V3 / "train_v3.py", ["predict"], {})
    return v3["predict"], v4["predict"]


def assert_probabilities(p: np.ndarray, n: int, name: str) -> None:
    if p.shape != (n, 4) or not np.isfinite(p).all() or (p < 0).any() or (p > 1).any():
        raise ValueError(f"Invalid probability matrix: {name} {p.shape}, expected ({n},4)")
    if (np.diff(p, axis=1) < -1e-10).any():
        raise ValueError(f"Cumulative probability monotonicity violated: {name}")


def timestamps(frame: pd.DataFrame, columns: list[str]) -> pd.DataFrame:
    frame = frame.copy()
    for c in columns:
        if c in frame:
            valid = frame[c].notna()
            frame[c] = pd.to_datetime(frame[c], format="mixed", errors="coerce")
            if (valid & frame[c].isna()).any():
                raise ValueError(f"Unparseable timestamps in {c}")
    return frame


def id_check(frame: pd.DataFrame, name: str) -> None:
    if frame.event_id.isna().any() or frame.event_id.duplicated().any():
        raise ValueError(f"{name}: event ids must be present and unique")
    if frame.user_id.isna().any() or frame.as_of_time.isna().any():
        raise ValueError(f"{name}: user/event time missing")


def check_identity(a: pd.DataFrame, b: pd.DataFrame, name: str, require_same_order: bool = True) -> None:
    if require_same_order and not np.array_equal(a.event_id.to_numpy(), b.event_id.to_numpy()):
        raise ValueError(f"{name}: event-id order changed")
    aligned = b.set_index("event_id").reindex(a.event_id)
    if aligned.user_id.isna().any():
        raise ValueError(f"{name}: event id missing")
    if not np.array_equal(a.user_id.to_numpy(), aligned.user_id.to_numpy()):
        raise ValueError(f"{name}: event/user identity mismatch")
    if not np.array_equal(a.as_of_time.to_numpy(), aligned.as_of_time.to_numpy()):
        raise ValueError(f"{name}: event/as-of identity mismatch")


def old_september() -> tuple[pd.DataFrame, dict[str, Any], pd.DataFrame]:
    base4_path = V4 / "datasets/base_with_labels.pkl.gz"
    base3_path = V3 / "datasets/base_with_labels.pkl.gz"
    base = timestamps(pd.read_pickle(base4_path, compression="gzip"), ["as_of_time", "vir_date"])
    b3 = timestamps(pd.read_pickle(base3_path, compression="gzip"), ["as_of_time", "vir_date"])
    id_check(base, "V4 old mother")
    id_check(b3, "V3 old mother")
    check_identity(base, b3, "V3 vs V4 old mothers")
    p4_path = V4 / "datasets/event_predictions.npy"
    p4 = np.load(p4_path, mmap_mode="r")
    assert_probabilities(p4, len(base), "V4 stored")
    columns = ["event_id", "user_id", "as_of_time"] + [f"p_apply_d{h}" for h in HORIZONS]
    p3_path = V3 / "T0提单时点预测模型_V3_全量预测结果.csv.gz"
    p4_csv_path = V4 / "T0提单时点预测模型_V4_全量预测结果.csv.gz"
    csv3 = timestamps(pd.read_csv(p3_path, usecols=columns), ["as_of_time"])
    csv4 = timestamps(pd.read_csv(p4_csv_path, usecols=columns), ["as_of_time"])
    id_check(csv3, "V3 stored prediction CSV")
    id_check(csv4, "V4 stored prediction CSV")
    check_identity(base, csv3, "V3 stored predictions")
    check_identity(base, csv4, "V4 stored prediction row order")
    np.testing.assert_allclose(p4, csv4[[f"p_apply_d{h}" for h in HORIZONS]].to_numpy(float), rtol=1e-12, atol=1e-12)
    p3 = csv3[[f"p_apply_d{h}" for h in HORIZONS]].to_numpy(float)
    assert_probabilities(p3, len(base), "V3 stored")
    mask = (base.as_of_time >= pd.Timestamp("2026-09-22")) & (base.as_of_time < pd.Timestamp("2026-10-01"))
    selected = base.loc[mask].copy()
    for j, h in enumerate(HORIZONS):
        selected[f"p_v4_d{h}"] = p4[np.flatnonzero(mask), j]
        selected[f"p_v3_d{h}"] = p3[mask, j]
    selected["prediction_source"] = "original_saved_historical_predictions"
    selected["prediction_time_status"] = "historical snapshot prediction saved in original artifacts; not certified as online contemporaneous scoring"
    # Pull only frozen pre-T0 cycle flags needed for the subgroup labels.
    old_names = json.loads((V3 / "datasets/model_feature_names.json").read_text())
    old_x = np.load(V3 / "datasets/model_features.npy", mmap_mode="r")
    for c in ["cyc_ever_eligible", "cyc_ever_applied"]:
        if c not in old_names:
            raise ValueError(f"Missing frozen cycle-history feature {c}")
        selected[c] = old_x[np.flatnonzero(mask), old_names.index(c)]
    audit = {"old_mother_identity_and_order_equal": True, "v4_npy_equals_csv": True,
             "v3_saved_prediction_format": "CSV; original V3 did not save event_predictions.npy",
             "september_events": len(selected), "september_users": selected.user_id.nunique(),
             "sha256": {str(p): digest(p) for p in [base4_path, base3_path, p4_path, p3_path, p4_csv_path]}}
    return selected, audit, base


def score_october(features: Path) -> tuple[pd.DataFrame, dict[str, Any]]:
    base_path = features / "base_with_labels.pkl.gz"
    frame = timestamps(pd.read_pickle(base_path, compression="gzip"), ["as_of_time", "vir_date", "first_apply_time", "next_t0_time"])
    id_check(frame, "October replay snapshots")
    if not ((frame.as_of_time >= pd.Timestamp("2026-10-01")) & (frame.as_of_time < CUTOFF)).all():
        raise ValueError("October replay frame outside locked dates")
    x3_path, x4_path = features / "v3_model_features.npy", features / "v4_numeric_features.npy"
    names3_path, names4_path = features / "v3_feature_names.json", features / "v4_numeric_names.json"
    x3, x4 = np.load(x3_path, mmap_mode="r"), np.load(x4_path, mmap_mode="r")
    names3, names4 = json.loads(names3_path.read_text()), json.loads(names4_path.read_text())
    expected3 = json.loads((V3 / "datasets/model_feature_names.json").read_text())
    expected4 = json.loads((V4 / "datasets/numeric_feature_names.json").read_text())
    if names3 != expected3 or names4 != expected4:
        raise ValueError("Feature names/order differ from frozen model contract")
    if x3.shape != (len(frame), len(names3)) or x4.shape != (len(frame), len(names4)):
        raise ValueError("Feature matrix rows or columns differ from snapshots")
    models = {"v3": V3 / "models/t0_application_timing_v3.joblib", "v4": V4 / "models/t0_application_timing_v4.joblib"}
    sha_before = {m: digest(p) for m, p in models.items()}
    bundle3, bundle4 = joblib.load(models["v3"]), joblib.load(models["v4"])
    predict3, predict4 = scoring_functions()
    if bundle4["numeric_names"] != names4:
        raise ValueError("V4 numeric names differ from saved bundle")
    p3, hazard3 = predict3(bundle3, x3)
    p4, hazard4 = predict4(bundle4, x4, frame)
    assert_probabilities(p3, len(frame), "V3 October replay")
    assert_probabilities(p4, len(frame), "V4 October replay")
    for j, h in enumerate(HORIZONS):
        frame[f"p_v3_d{h}"] = p3[:, j]
        frame[f"p_v4_d{h}"] = p4[:, j]
    for c in ["cyc_ever_eligible", "cyc_ever_applied"]:
        frame[c] = x3[:, names3.index(c)]
    frame["prediction_source"] = "frozen_model_retrospective_feature_replay"
    frame["prediction_time_status"] = "scored now using reconstructed historical snapshots; not original online predictions"
    sha_after = {m: digest(p) for m, p in models.items()}
    if sha_before != sha_after:
        raise AssertionError("Frozen model files changed")
    audit = {"october_events": len(frame), "october_users": frame.user_id.nunique(),
             "model_sha256_before": sha_before, "model_sha256_after": sha_after, "models_unchanged": True,
             "model_versions": {"v3": bundle3["version"], "v4": bundle4["version"]},
             "scoring_function_ast_only": True, "monotonic_predictions": True,
             "original_model_training_or_calibration_run": False,
             "input_sha256": {str(p): digest(p) for p in [base_path, x3_path, x4_path, names3_path, names4_path]},
             "score_code_sha256": {str(p): digest(p) for p in [V3 / "train_v3.py", V4 / "model_v4.py", V4 / "product_features.py"]}}
    return frame, audit


def rebuild_observation(events: pd.DataFrame, old_mother: pd.DataFrame, october: pd.DataFrame,
                        orders: pd.DataFrame, change_audit_path: Path | None = None) -> tuple[pd.DataFrame, dict[str, Any]]:
    """Use original retained T0 IDs and all order apply times, never row numbers."""
    events = events.copy()
    keys = ["event_id", "user_id", "as_of_time"]
    mother = pd.concat([old_mother[keys], october[keys]], ignore_index=True)
    id_check(mother, "Combined original strict T0 mother")
    mother = mother.sort_values(["user_id", "as_of_time", "event_id"])
    if mother.duplicated(["user_id", "as_of_time"]).any():
        raise ValueError("Combined retained T0 mother has tied user/as_of_time; verify 20-second dedup")
    mother["next_t0_time"] = mother.groupby("user_id", sort=False).as_of_time.shift(-1)
    next_by_id = mother.set_index("event_id").next_t0_time
    cached_apply = pd.to_datetime(events.first_apply_time, errors="coerce") if "first_apply_time" in events else pd.Series(pd.NaT, index=events.index)
    cached_sources = pd.concat([old_mother, october], ignore_index=True).set_index("event_id")
    def cached_column(name):
        # Keep original stored boundaries, including the old October 7 cutoff.
        # The original September labels can contain an October-support next T0
        # even though the saved formal mother itself stops at September 30.
        if name in events:
            return pd.to_datetime(events[name], errors="coerce")
        if name in cached_sources:
            return pd.to_datetime(events.event_id.map(cached_sources[name]), errors="coerce")
        return pd.Series(pd.NaT, index=events.index, dtype="datetime64[ns]")
    cached_next = cached_column("next_t0_time")
    cached_cutoff = cached_column("data_cutoff_ts")
    cached_followup = cached_column("followup_end")
    events["next_t0_time"] = events.event_id.map(next_by_id)
    orders = timestamps(orders, ["apply_time"])
    required = ["user_id", "serial_id", "apply_time"]
    if not set(required).issubset(orders):
        raise ValueError(f"Order extract lacks {required}")
    if orders["user_id"].isna().any() or orders["apply_time"].isna().any():
        raise ValueError("Order extract has missing user_id or apply_time")
    if orders.duplicated(["user_id", "serial_id"]).any():
        raise ValueError("Order extract duplicates user/order identity")
    missing_users = set(events.user_id) - set(orders.user_id)
    if missing_users:
        raise ValueError(f"Historical order extract omits {len(missing_users)} scored users")
    followup = pd.Series(CUTOFF, index=events.index, dtype="datetime64[ns]")
    for cap in [events.next_t0_time, events.as_of_time.dt.normalize() + pd.Timedelta(days=16)]:
        mask = cap.notna() & (cap < followup)
        followup.loc[mask] = cap.loc[mask]
    apply = pd.Series(pd.NaT, index=events.index, dtype="datetime64[ns]")
    event_groups = events.groupby("user_id", sort=False).groups
    examined = 0
    for uid, og in orders.groupby("user_id", sort=False):
        if uid not in event_groups:
            continue
        ix = event_groups[uid]
        a = np.sort(og.apply_time.to_numpy("datetime64[ns]"))
        t = events.loc[ix, "as_of_time"].to_numpy("datetime64[ns]")
        where = np.searchsorted(a, t, side="left")
        valid = where < len(a)
        positions = np.flatnonzero(valid)
        if len(positions):
            candidate = a[where[positions]]
            before_end = candidate < followup.loc[ix].to_numpy("datetime64[ns]")[positions]
            chosen = np.asarray(ix)[positions[before_end]]
            apply.loc[chosen] = candidate[before_end]
        examined += len(ix)
    if examined != len(events):
        raise AssertionError("Not all event user histories were examined")
    equals = (cached_apply == apply) | (cached_apply.isna() & apply.isna())
    october_mask = events.as_of_time >= pd.Timestamp("2026-10-01")
    changed = ~equals
    added = cached_apply.isna() & apply.notna()
    removed = cached_apply.notna() & apply.isna()
    moved = cached_apply.notna() & apply.notna() & (cached_apply != apply)
    next_cutoff_removed = removed & events.next_t0_time.notna() & (cached_apply >= events.next_t0_time)
    category = pd.Series("unchanged", index=events.index, dtype="string")
    category.loc[added] = "newly_observed_application"
    category.loc[next_cutoff_removed] = "old_application_removed_by_reconstructed_next_t0_boundary"
    category.loc[removed & ~next_cutoff_removed] = "old_application_removed_other_reason"
    category.loc[moved] = "application_time_changed_both_observed"
    category.loc[changed & category.eq("unchanged")] = "other_change"
    added_after_original = added & cached_cutoff.notna() & (apply >= cached_cutoff)
    added_before_original = added & cached_cutoff.notna() & (apply < cached_cutoff)
    next_boundary_changed = ~((cached_next == events.next_t0_time) | (cached_next.isna() & events.next_t0_time.isna()))
    change_rows = pd.DataFrame({
        "event_id": events.event_id, "event_time": events.as_of_time,
        "period": np.where(october_mask, "october", "september_saved"),
        "change_category": category, "cached_first_apply_time": cached_apply,
        "rebuilt_first_apply_time": apply, "cached_next_t0_time": cached_next,
        "rebuilt_next_t0_time": events.next_t0_time,
        "cached_data_cutoff_ts": cached_cutoff, "cached_followup_end": cached_followup,
        "rebuilt_followup_end": followup,
        "new_hit_at_or_after_original_cutoff": added_after_original,
        "new_hit_before_original_cutoff": added_before_original,
        "new_hit_at_or_after_20261007": added & (apply >= pd.Timestamp("2026-10-07")),
        "next_t0_boundary_changed": next_boundary_changed,
    }).loc[changed].copy()
    if len(change_rows) != int(changed.sum()) or int(category.ne("unchanged").sum()) != int(changed.sum()):
        raise AssertionError("Changed-label audit categories do not reconcile")
    if change_audit_path is not None:
        change_audit_path.parent.mkdir(parents=True, exist_ok=True)
        # No user IDs, input contents, bank/phone details or other sensitive
        # attributes; this is an event/time audit and never HTML body content.
        change_rows.to_csv(change_audit_path, index=False)
    events["first_apply_time"] = apply
    events["followup_end"] = followup
    events["data_cutoff_ts"] = CUTOFF
    audit = {"combined_mother_events": len(mother), "orders": len(orders), "order_users": orders.user_id.nunique(),
             "scored_users_missing_from_order_history": len(missing_users),
             "rebuilt_first_apply_total_mismatch_vs_cached": int((~equals).sum()),
             "rebuilt_october_first_apply_mismatch_vs_cached": int((~equals & october_mask).sum()),
             "first_apply_change_categories": {k: int(category.eq(k).sum()) for k in [
                 "newly_observed_application", "old_application_removed_by_reconstructed_next_t0_boundary",
                 "old_application_removed_other_reason", "application_time_changed_both_observed", "other_change"]},
             "newly_observed_application": {
                 "count": int(added.sum()),
                 "at_or_after_original_row_cutoff": int(added_after_original.sum()),
                 "before_original_row_cutoff": int(added_before_original.sum()),
                 "original_row_cutoff_unknown": int((added & cached_cutoff.isna()).sum()),
                 "at_or_after_20261007": int((added & (apply >= pd.Timestamp("2026-10-07"))).sum()),
                 "before_20261007": int((added & (apply < pd.Timestamp("2026-10-07"))).sum()),
                 "first_new_application_time": str(apply.loc[added].min()) if added.any() else None,
                 "last_new_application_time": str(apply.loc[added].max()) if added.any() else None,
             },
             "removed_by_next_t0_boundary": {
                 "count": int(next_cutoff_removed.sum()),
                 "boundary_changed_from_cached": int((next_cutoff_removed & next_boundary_changed).sum()),
                 "old_hit_before_new_next_t0": int((next_cutoff_removed & (cached_apply < events.next_t0_time)).sum()),
             },
             "change_audit_csv": str(change_audit_path.resolve()) if change_audit_path is not None else None,
             "change_audit_sha256": digest(change_audit_path) if change_audit_path is not None else None,
             "matched_application_events": int(apply.notna().sum()),
             "next_t0_definition": "LEAD(as_of_time) by user from original Jan-Sep strict/dedup T0 mother plus October strict/dedup T0 mother, using unchanged original event_id",
             "first_apply_definition": "Earliest all-order apply_time >= T0 and < min(next T0, cutoff, offer date +16days), without requiring successful funding or same credit order",
             "cutoff_exclusive": str(CUTOFF), "raw_event_id_preserved": True}
    return events, audit


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--features", type=Path, default=ROOT / "features")
    parser.add_argument("--orders", type=Path, default=ROOT / "sources/orders.csv.gz")
    parser.add_argument("--out", type=Path, default=ROOT / "events_predictions.parquet")
    args = parser.parse_args()
    sep, sep_audit, mother = old_september()
    october, oct_audit = score_october(args.features)
    common = list(dict.fromkeys(["event_id", "user_id", "as_of_time", "vir_date", "first_apply_time", "next_t0_time", "followup_end", "data_cutoff_ts", "credit_serial_id", "settled_serial_id",
        "successful_loan_count", "product_count", "risk_product", "credit_direction", "risk_score_405", "risk_score_363",
        "cyc_ever_eligible", "cyc_ever_applied", "prediction_source", "prediction_time_status"] +
        [f"p_{m}_d{h}" for m in ["v3", "v4"] for h in HORIZONS]))
    assembled = pd.concat([sep.reindex(columns=common), october.reindex(columns=common)], ignore_index=True)
    id_check(assembled, "Assembled September-October scores")
    assembled = assembled.sort_values(["as_of_time", "event_id"]).reset_index(drop=True)
    assembled, label_audit = rebuild_observation(assembled, mother, october, pd.read_csv(args.orders), args.out.parent / "label_changes_audit.csv")
    # Product count must come from the original product set rather than a current
    # user snapshot. This is the original frozen model's set parsing policy.
    tokens = definitions(V4 / "product_features.py", ["tokens"], {})["tokens"]
    parsed_count = assembled.risk_product.map(lambda s: len(tokens(s)))
    existing = pd.to_numeric(assembled.product_count, errors="coerce")
    conflict = existing.notna() & existing.ne(parsed_count)
    if conflict.any():
        raise ValueError("Stored product count differs from frozen product-set parser")
    assembled["product_count"] = parsed_count
    applied = pd.to_numeric(assembled.cyc_ever_applied, errors="coerce")
    eligible = pd.to_numeric(assembled.cyc_ever_eligible, errors="coerce")
    assembled["seg_history_cycle"] = np.select([applied.gt(0), eligible.gt(0), eligible.eq(0) & applied.eq(0)],
        ["历史循环贷曾提单", "曾获循环贷资格但未提单", "无循环贷资格历史"], default="历史特征缺失")
    args.out.parent.mkdir(parents=True, exist_ok=True)
    if args.out.suffix=='.parquet':
        assembled.to_parquet(args.out, index=False)
    else:
        # The frozen numpy-2 model runtime need not include a parquet engine.
        # CSV uses full float repr; conversion elsewhere uses round_trip parsing.
        assembled.to_csv(args.out, index=False, compression='infer')
    audit = {"september": sep_audit, "october": oct_audit, "labels": label_audit,
             "total_events": len(assembled), "total_users": assembled.user_id.nunique(),
             "prediction_sources": assembled.prediction_source.value_counts().to_dict(),
             "output_path": str(args.out.resolve()), "output_sha256": digest(args.out),
             "orders_path": str(args.orders.resolve()), "orders_sha256": digest(args.orders),
             "segment_definitions": {"seg_history_cycle": "Original frozen cyc_ever_eligible/cyc_ever_applied computed using histories observable strictly before each T0, not current user cycle eligibility.",
                 "successful_loan_count": "Original cumulative successfully funded orders before each T0; grouping performed by evaluator.",
                 "product_count": "Distinct nonempty normalized tokens of current T0 risk_product, using frozen product_features.tokens()."},
             "no_database_access": True, "no_model_training": True, "no_original_artifact_writes": True}
    # pandas/numpy integer values from group counts are made portable explicitly.
    (args.out.parent / "score_audit.json").write_text(json.dumps(audit, ensure_ascii=False, indent=2, default=lambda x: int(x) if isinstance(x, np.integer) else str(x)))
    print(json.dumps({"output": str(args.out), "events": len(assembled), "users": int(assembled.user_id.nunique()), "labels": label_audit}, default=str))


if __name__ == "__main__":
    main()
