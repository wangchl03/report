"""Business examples from frozen validation / existing profit files only.

No database connection, no retraining, no financial refresh. Decile mass uses
the original evaluator's fair fractional boundary / exact-score-tie weights.
Public anonymous cases are picked by fixed category then earliest T0.
"""
from pathlib import Path
import sys,json,hashlib
import numpy as np
import pandas as pd
W=Path(__file__).resolve().parent
V=W.parent/'t0_v4_validation_20261024_20261025'
R=W.parent/'t0_risk410_lifecycle_strategy_20261025'
sys.path.insert(0,str(V))
from evaluate_validation import SortedMetrics

def clean(x):
    if isinstance(x,dict):return {str(k):clean(v) for k,v in x.items()}
    if isinstance(x,(tuple,list)):return [clean(v) for v in x]
    if isinstance(x,np.integer):return int(x)
    if isinstance(x,(float,np.floating)):return float(x) if np.isfinite(x) else None
    if x is pd.NaT:return None
    if isinstance(x,pd.Timestamp):return x.isoformat(sep=' ')
    return x
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def pp(x):return f'{x*100:.2f}%'
def row(f,**keys):
    mask=pd.Series(True,index=f.index)
    for k,v in keys.items():mask &= f[k].eq(v)
    g=f.loc[mask];assert len(g)==1,(keys,len(g))
    return g.iloc[0]

def main():
    labels=pd.read_parquet(V/'evaluation/labels_evaluated.parquet')
    scored=labels.loc[labels.as_of_time.ge(pd.Timestamp('2026-10-09'))&labels.as_of_time.lt(pd.Timestamp('2026-10-22'))&labels.p_v4_d3.notna()].copy()
    primary=scored.loc[scored.y_d3.notna()].copy()
    assert len(scored)==8866 and len(primary)==8717
    assert primary.y_d0.notna().all()
    assert primary.p_v3_d0.notna().all() and primary.p_v3_d3.notna().all()
    metrics={};deciles={}
    for h in [0,3]:
        metrics[str(h)]={};deciles[str(h)]={}
        for model in ['v4','v3']:
            s=SortedMetrics(primary[f'y_d{h}'].to_numpy(float),primary[f'p_{model}_d{h}'].to_numpy(float))
            metrics[str(h)][model]=s.compute();deciles[str(h)][model]=s.deciles()
    hi=deciles['0']['v4'][0];lo=deciles['0']['v4'][-1]
    hi3=deciles['0']['v3'][0]
    target=scored.loc[scored.p_v4_d3.lt(.5)]
    target_known=target.loc[target.y_d0.notna()]
    assert len(target)==3701 and len(target_known)==3656
    assert target_known.y_d3.notna().all()
    no0=int(target_known.y_d0.eq(0).sum());yes0=int(target_known.y_d0.eq(1).sum())
    no3=int(target_known.y_d3.eq(0).sum());yes3=int(target_known.y_d3.eq(1).sum())
    assert no0==3143 and yes0==513 and no3==2488 and yes3==1168
    weekly=[]
    for week,g in primary.groupby('offer_week'):
        vals={m:SortedMetrics(g.y_d0.to_numpy(float),g[f'p_{m}_d0'].to_numpy(float)).compute() for m in ['v4','v3']}
        weekly.append({'week_monday':week,'event_date_min':g.as_of_time.min().date().isoformat(),
          'event_date_max':g.as_of_time.max().date().isoformat(),'n_events':len(g),
          'v4_top10_actual_rate':vals['v4']['top10_precision'],'v3_top10_actual_rate':vals['v3']['top10_precision'],
          'difference_pp':100*(vals['v4']['top10_precision']-vals['v3']['top10_precision'])})
    examples=[
      {'id':'ranking_extremes','headline':'高低意愿名单能明显分开，但不是逐人保证',
       'population':'同一主样本8,717次T0获额事件，按V4当天提单概率由高到低排序',
       'top10':hi,'bottom10':lo,'bottom10_nonapply_rate':1-lo['actual_rate'],
       'business_copy':f"最高10%名单实际当天提单率{pp(hi['actual_rate'])}，最低10%为{pp(lo['actual_rate'])}；最低档仍有{lo['positive_weight']:.1f}次提单权重，并非都不提单。",
       'count_wording':'每档871.7是精确10%预算和同分边界的事件权重；不是871.7名真实用户，782.0/46.0同样是提单权重，不可四舍五入写成用户人数。',
       'supports':'可用于排序名单、优先识别自然提单意愿高低','does_not_prove':'不保证每位低分用户都不提单，也未证明优惠有效'},
      {'id':'probability_calibration','headline':'总体概率接近实际，局部仍有偏差',
       'd0':{'actual_count':int(primary.y_d0.sum()),'events':len(primary),
         'mean_predicted':metrics['0']['v4']['mean_prediction'],'actual_rate':metrics['0']['v4']['actual_rate'],
         'prediction_minus_actual_pp':100*(metrics['0']['v4']['mean_prediction']-metrics['0']['v4']['actual_rate'])},
       'd3':{'actual_count':int(primary.y_d3.sum()),'events':len(primary),
         'mean_predicted':metrics['3']['v4']['mean_prediction'],'actual_rate':metrics['3']['v4']['actual_rate'],
         'prediction_minus_actual_pp':100*(metrics['3']['v4']['mean_prediction']-metrics['3']['v4']['actual_rate'])},
       'business_copy':f"同一主样本，模型平均预测当天提单{pp(metrics['0']['v4']['mean_prediction'])}、实际{pp(metrics['0']['v4']['actual_rate'])}；D3平均预测{pp(metrics['3']['v4']['mean_prediction'])}、实际{pp(metrics['3']['v4']['actual_rate'])}。",
       'supports':'群体平均概率有参考价值','does_not_prove':'总体均值接近不代表每个分档、每一天和每位用户都校准准确'},
      {'id':'v4_vs_v3','headline':'V4有改善，但业务幅度应说清楚',
       'd0_top10':{'v3_actual_rate':hi3['actual_rate'],'v4_actual_rate':hi['actual_rate'],
         'difference_pp':100*(hi['actual_rate']-hi3['actual_rate']),
         'same_budget_event_weight':hi['event_weight'],
         'v3_positive_weight':hi3['positive_weight'],'v4_positive_weight':hi['positive_weight'],
         'extra_positive_weight_at_equal_budget':hi['positive_weight']-hi3['positive_weight']},
       'd0_auc':{'v3':metrics['0']['v3']['auc'],'v4':metrics['0']['v4']['auc'],'difference':metrics['0']['v4']['auc']-metrics['0']['v3']['auc']},
       'business_copy':f"同样取871.7次事件权重的最高10%名单，V3实际当天提单{pp(hi3['actual_rate'])}、V4为{pp(hi['actual_rate'])}，提高{100*(hi['actual_rate']-hi3['actual_rate']):.2f}个百分点，等预算约多{hi['positive_weight']-hi3['positive_weight']:.1f}次提单权重。",
       'supports':'相同样本和预算下高意愿名单略好','does_not_prove':'不是新增14.3名借款用户，不等于营销增量，也不能套用原10,695事件比较的置信区间到本8,717事件重算'},
      {'id':'negative_list','headline':'筛出低pD3名单后，当天不提单命中率约86%，仍会误选',
       'score_threshold':'p_v4_d3 < 0.5','scored_events':len(scored),'selected_events':len(target),
       'selection_coverage':len(target)/len(scored),'known_outcome_events':len(target_known),
       'unknown_outcome_events':len(target)-len(target_known),
       'actual_no_d0_events':no0,'actual_d0_events':yes0,'no_d0_precision':no0/len(target_known),
       'actual_no_d3_events':no3,'actual_d3_events':yes3,'no_d3_precision':no3/len(target_known),
       'actual_d1_d3_events':yes3-yes0,'no_d0_baseline_primary':float(primary.y_d0.eq(0).mean()),
       'business_copy':f"8,866次完整评分事件中筛出3,701次低pD3事件；其中3,656次结果已知，3,143次当天未提单（{pp(no0/len(target_known))}），513次当天仍提单，另45次结果未知。真正D3内未提单为2,488次（{pp(no3/len(target_known))}）。",
       'supports':'可减少把优惠发给自然当天就提单事件的比例','does_not_prove':'不是85.97%的全体预测准确率；不提单命中不等于会被优惠打动，45次未知不能算正确'},
      {'id':'week_variability','headline':'总体改善不等于每一批名单都更好',
       'weeks':weekly,
       'business_copy':'主样本第一段（10月9—11日）前10%名单实际当天提单率，V4为87.24%、V3为88.04%；后两段V4更高。短期分段不应写成跨月稳定性证明。',
       'supports':'上线后必须监测实际名单效果','does_not_prove':'三段含不完整周，不能证明跨月、跨策略和未来长期稳定'}]
    mapping=pd.read_parquet(R/'validation_mapping.parquet')
    g=primary.loc[primary.p_v4_d3.lt(.5)].copy()
    g=g.merge(mapping[['event_id','score_band','lifecycle_band']],on='event_id',how='left',validate='one_to_one')
    g['apply_day']=(g.first_apply_time.dt.normalize()-g.as_of_time.dt.normalize()).dt.days
    definitions=[
      ('案例A','当天仍提单的误选',g.y_d0.eq(1)),
      ('案例B','D1—D3自然返回',g.y_d0.eq(0)&g.y_d3.eq(1)&g.apply_day.between(1,3)),
      ('案例C','D7完整窗口内仍未提单',g.mature_d7.eq(True)&g.y_d7.eq(0)),
      ('案例D','D4—D7自然返回',g.mature_d7.eq(True)&g.y_d3.eq(0)&g.y_d7.eq(1)&g.apply_day.between(4,7))]
    cases=[]
    for number,name,mask in definitions:
        z=g.loc[mask].sort_values(['as_of_time','event_id'])
        assert len(z)>0
        a=z.iloc[0]
        cases.append({'case_no':number,'category':name,'qualifying_events':len(z),
          'category_observation_eligible_events':int((g.mature_d7.eq(True)&g.y_d7.notna()).sum()) if name.startswith('D7') or name.startswith('D4') else len(g),
          'selection_rule':'在预先定义类别内按T0时间、获额事件编号升序，选最早一条；不按预测或结果挑案例',
          't0_time':a.as_of_time,'p_d0':float(a.p_v4_d0),'p_d3':float(a.p_v4_d3),
          'actual_first_application_time':a.first_apply_time if pd.notna(a.first_apply_time) else None,
          'application_natural_day_offset':int(a.apply_day) if pd.notna(a.apply_day) else None,
          'd0_result':int(a.y_d0),'d3_result':int(a.y_d3),
          'd7_result':int(a.y_d7) if pd.notna(a.y_d7) else None,'d7_complete_boundary_exclusive':a.boundary_d7,
          'actual_observation_note':'截至D7完整窗口末仍未观察到提单，不等于永不提单' if name.startswith('D7') else '这是自然观察结果，没有对这条事件施加随机优惠试验',
          'score_410_band':a.score_band,'settled_loan_lifecycle_band':a.lifecycle_band})
    profiles=pd.read_csv(R/'prediction_profiles.csv')
    low=row(profiles,rule='LOWP_ALL');high=row(profiles,rule='LOWP_HIGH20');life=row(profiles,rule='LOWP_HIGH20_LIFE6PLUS')
    cells=pd.read_csv(R/'cells.csv')
    sel=cells.scope.eq('main')&cells.grain.eq('event')&cells.period.eq('ALL')
    rhi=row(cells.loc[sel],level='risk',bucket='D0',score_band='HIGH20')
    rlo=row(cells.loc[sel],level='risk',bucket='D0',score_band='LOW50')
    all0=row(cells.loc[sel],level='overall',bucket='D0')
    late=row(cells.loc[sel],level='overall',bucket='D1+')
    chain=[
      {'step':1,'question':'自然当天提单者与较晚提单者，当前账面收益有何差别？',
       'evidence':f"2026年1月1日—10月24日，首提单且成功放款的到期订单，D0盈利{pp(all0.profit_rate)}、D1+为{pp(late.profit_rate)}。",
       'supports':'有理由同时看自然提单时点和收益','does_not_prove':'较早提单导致低盈利；优惠把晚提单提前后会保持原高收益',
       'source':'cells.csv: main/event/ALL/overall/D0 versus D1+'},
      {'step':2,'question':'模型能少选自然当天就来的人吗？',
       'evidence':f"低pD3选3,701次，3,656次已知中3,143次当天不提单，命中{pp(low.ppv_no_d0)}；覆盖全部8,866评分事件的{pp(low.all_candidate_coverage)}。",
       'supports':'名单筛选有用且能量化覆盖和误选','does_not_prove':'所有未提单事件都能被优惠转化',
       'source':'prediction_profiles.csv: LOWP_ALL; frozen evaluation labels'},
      {'step':3,'question':'只看意愿够不够？',
       'evidence':f"同一历史T0事件口径，410高分档D0盈利{pp(rhi.profit_rate)}，低分档为{pp(rlo.profit_rate)}；原获额单410缺失588次。",
       'supports':'需要把风险/盈利与意愿分开看；缺分独立保留','does_not_prove':'高分候选优惠后的收益会等于该历史24.21%；评分原始时点可证',
       'source':'cells.csv: main/event/ALL/risk/D0; quality.json'},
      {'step':4,'question':'意愿与风险联合筛后，覆盖会损失多少？',
       'evidence':f"低pD3且410高档选{int(high.all_candidates):,}次（占8,866次的{pp(high.all_candidate_coverage)}）；{int(high.known_d0):,}次已知中{int(high.no_d0):,}次当天未提单（{pp(high.ppv_no_d0)}），{int(high.d0_apply):,}次仍当天提单，{int(high.unknown_d0):,}次未知。",
       'supports':'能在减少自然当天提单误选与名单覆盖之间作业务取舍','does_not_prove':'这是最优门槛或已经能全量投放',
       'source':'prediction_profiles.csv: LOWP_HIGH20'},
      {'step':5,'question':'再加高生命周期条件，会更稳吗？',
       'evidence':f"再要求刚结清第6笔及以上，低pD3且410高档剩{int(life.all_candidates):,}次，覆盖仅{pp(life.all_candidate_coverage)}；已知{int(life.known_d0):,}次中{int(life.no_d0):,}次当天未提单（{pp(life.ppv_no_d0)}）。",
       'supports':'可以另列核心客群监测，准确率与规模需一起看','does_not_prove':'不断缩小名单就得到更可盈利策略；生命周期序号等同当前总借款次数',
       'source':'prediction_profiles.csv: LOWP_HIGH20_LIFE6PLUS'},
      {'step':6,'question':'给优惠后到底赚不赚？',
       'evidence':'现有数据是自然结果回顾，没有随机分配的降息/提额试验及人均增量净收益。',
       'supports':'可设计风险限定、小规模、保留对照的试验','does_not_prove':'降低利率或提高额度能带来正增量利润',
       'source':'Existing observational design; no treatment assignment recorded'}]
    original_overall=pd.read_csv(V/'evaluation/overall.csv')
    original_deciles=pd.read_csv(V/'evaluation/deciles.csv')
    supplementary={'label':'原D0独立主检验口径，10/9—24，不能与上面8,717主样本混算',
      'overall':row(original_overall,cohort='main',horizon=0,model='v4').to_dict(),
      'deciles':original_deciles.loc[original_deciles.cohort.eq('main')&original_deciles.horizon.eq(0)&original_deciles.model.eq('v4')&original_deciles.decile.isin([1,10])].to_dict('records'),
      'caveat':'含10月24日风险字段缺失敏感性问题，仅作原报告数值追溯'}
    risk_meta=json.loads((R/'quality.json').read_text())
    result={'meta':{'offline_only':True,'database_queried':False,'model_retrained':False,'money_refreshed':False,
       'financial_snapshot_belize':risk_meta['snapshot']['snapshot_belize'],
       'primary_events':len(primary),'primary_users':primary.user_id.nunique(),'primary_dates':'2026-10-09 through 2026-10-21 America/Belize',
       'primary_rule':'V4 D3 probability available and frozen D3 outcome known; D0 outcomes also all known',
       'scored_before_unknown_exclusion':len(scored),'unknown_d3_events':len(scored)-len(primary),
       'D0_definition':'from T0 offer time through end of that Belize calendar day',
       'D3_definition':'D0 through D3 calendar-day cumulative; exclusive boundary offer date + 4 days 00:00, not rolling 72h',
       'counts_are_events':'Repeat users retained; fractional decile counts are weights, not people',
       'tie_rule':'Exact-score ties share rank-boundary inclusion weight equally; no outcome or ID breaks ties',
       'evidence_type':'retrospective replay, not prospective original scoring with proven score-availability timestamps'},
      'business_examples':examples,'primary_metrics':metrics,'primary_deciles':deciles,
      'anonymous_cases':cases,'anonymous_case_caveat':'案例按预定义类别最早T0选择，仅解释模型可能出现的结果，不代表群体比例，也不代替总体检验；不输出业务用户ID或原获额单编号。',
      'evidence_chain':chain,
      'evidence_chain_population_note':'历史盈利用1月1日—10月24日全体严格T0事件及既有10月25日回款快照，模型名单效果用10月9—21日冻结评分/反馈；两者提供不同证据，不能拼成某优惠策略的已实现金融收益。',
      'original_D0_independent_supplement':supplementary,
      'sources':{str(p.relative_to(W.parent)):sha(p) for p in [V/'evaluation/labels_evaluated.parquet',V/'evaluation/overall.csv',V/'evaluation/deciles.csv',V/'evaluation/calibration.csv',V/'evaluation/weekly.csv',V/'evaluation/pairwise.csv',R/'cells.csv',R/'prediction_profiles.csv',R/'validation_mapping.parquet']}}
    out=W/'business_examples.json';out.write_text(json.dumps(clean(result),ensure_ascii=False,indent=2,allow_nan=False))
    assert all('user_id' not in x and 'event_id' not in x and 'serial_id' not in x for x in cases)
    print(json.dumps({'output':str(out),'primary_events':len(primary),'anonymous_cases':len(cases),'top10_d0_actual':hi['actual_rate'],'bottom10_d0_actual':lo['actual_rate'],'weighted_extra_hits_v4_vs_v3':hi['positive_weight']-hi3['positive_weight']},ensure_ascii=False),flush=True)

if __name__=='__main__':main()
