"""Create publication SQL copies without embedded frozen business identifiers.

Original SQL is read-only. Target identifiers remain only in the authorized
environment; release artifacts carry scoped batch hashes/counts, not identifiers.
"""
from pathlib import Path
import hashlib,json,re,zipfile
from collections import defaultdict

ROOT=Path(__file__).resolve().parent
WORK=ROOT.parent
DEST=ROOT/'release_sql'
OUT=ROOT.parents[1]/'outputs/T0提单意愿模型V4_业务实测与上线建议_20261026'
ZIP=OUT/'T0模型V4业务实测_完整代码与统计依据.zip'


def digest_bytes(x):return hashlib.sha256(x).hexdigest()
def digest_file(p):return digest_bytes(p.read_bytes())
def write_json(path,obj):path.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')


def main():
    DEST.mkdir(parents=True,exist_ok=True)
    with zipfile.ZipFile(ZIP) as z:
        names=[n[len('code/'):] for n in z.namelist() if n.startswith('code/') and n.endswith('.sql')]
    groups={};records=[]
    in_pattern=re.compile(r'(?P<field>\b(?:\w+\.)?(?:user_id|credit_serial_id|serial_id))\s+IN\s*\((?P<numbers>[\d\s,\-]+)\)',re.I)
    values_pattern=re.compile(r"(?P<head>\bWITH\s+target_events\s*\(\s*event_id\s*,\s*user_id\s*,\s*as_of_time\s*\)\s+AS\s*\()\s*VALUES\s*(?P<rows>(?:\(\s*\d+::bigint\s*,\s*\d+::bigint\s*,\s*TIMESTAMP\s*'[^']+'\s*\)\s*,?\s*)+)\)",re.I)
    tuple_pattern=re.compile(r"\(\s*(\d+)::bigint\s*,\s*(\d+)::bigint\s*,\s*TIMESTAMP\s*'([^']+)'\s*\)",re.I)
    for relative in sorted(names):
        source=WORK/relative
        original=source.read_text()
        needed=[];replacements=[]
        def register(kind,canonical,n,unique,source_columns):
            h=digest_bytes(canonical.encode());key=kind+'_'+h[:16]
            spec={'batch_key':key,'input_kind':kind,'sha256':h,'canonical_count':n,'distinct_primary_key_count':unique,
                  'source_columns':source_columns,'files':[]}
            if key not in groups:groups[key]=spec
            assert groups[key]['sha256']==h
            groups[key]['files'].append(relative)
            if key not in needed:needed.append(key)
            return key
        def replace_in(match):
            field=match.group('field');nums=[int(x) for x in re.findall(r'-?\d+',match.group('numbers'))]
            if len(nums)<3 and not any(abs(x)>=100000 for x in nums):return match.group(0)
            vals=sorted(set(nums));kind='users' if field.lower().split('.')[-1]=='user_id' else 'offers'
            canonical=','.join(map(str,vals))
            key=register(kind,canonical,len(nums),len(vals),['user_id'] if kind=='users' else ['credit_serial_id'])
            column='user_id' if kind=='users' else 'credit_serial_id'
            replacements.append({'type':'identifier_IN_list','field':field,'batch_key':key,'original_literal_count':len(nums),'original_distinct_count':len(vals)})
            return f"{field} IN (SELECT {column} FROM validation_target_{kind} WHERE batch_key = '{key}')"
        changed=in_pattern.sub(replace_in,original)
        def replace_values(match):
            vals=[(int(a),int(b),c) for a,b,c in tuple_pattern.findall(match.group('rows'))]
            if not vals:raise ValueError('Unparsed target event VALUES')
            if len({x[0] for x in vals})!=len(vals):raise ValueError('Duplicate target event IDs in frozen SQL input')
            # Canonical timestamps are exactly the original SQL timestamp strings;
            # sorting makes the input hash independent of the VALUES row order.
            canonical=json.dumps(sorted(vals),ensure_ascii=False,separators=(',',':'))
            key=register('events',canonical,len(vals),len(vals),['event_id','user_id','as_of_time'])
            replacements.append({'type':'target_events_VALUES','batch_key':key,'original_literal_count':len(vals),'original_distinct_count':len(vals)})
            return match.group('head')+f"SELECT event_id,user_id,as_of_time FROM validation_target_events WHERE batch_key = '{key}')"
        changed=values_pattern.sub(replace_values,changed)
        if re.search(r'\bVALUES\b',changed,re.I):raise ValueError(f'Unprocessed VALUES remaining: {relative}')
        for m in in_pattern.finditer(changed):
            nums=re.findall(r'-?\d+',m.group('numbers'))
            if len(nums)>=3 or any(abs(int(x))>=100000 for x in nums):raise ValueError('Unprocessed target numeric IN list')
        header='/* 发布副本：原授权SQL保持只读；本文件不内嵌业务用户/订单ID。\n'
        header+=' * 依赖下方batch_key对应的冻结授权输入；各批次不能混用。\n'
        for key in needed:header+=' * 输入批次：'+key+'\n'
        header+=' * 输入为空时返回空结果，绝不自动移除范围限制。详见00_发布SQL输入表说明.txt。\n */\n'
        if needed:
            guards=[]
            for key in needed:
                table='validation_target_'+groups[key]['input_kind']
                guards.append(f"EXISTS (SELECT 1 FROM {table} WHERE batch_key = '{key}')")
            if re.search(r'^\s*(?:SET|DROP|CREATE|BEGIN)\b',changed,re.I):raise ValueError('Unexpected non-query source needing manual wrapping')
            # Guarded outer SELECT changes nothing when the required batch is
            # loaded; missing input cannot expose an unrelated whole cohort.
            body="SELECT release_result.*\nFROM (\n"+changed.strip().rstrip(';')+"\n) release_result\nWHERE "+'\n  AND '.join(guards)+';\n'
        else:body=changed
        target=DEST/relative;target.parent.mkdir(parents=True,exist_ok=True);target.write_text(header+body,encoding='utf-8')
        records.append({'source':str(source),'source_relative':relative,'release_path':str(target),'release_relative':str(target.relative_to(ROOT)),
          'source_sha256':digest_file(source),'release_sha256':digest_file(target),'required_batches':needed,'replacements':replacements,
          'source_unchanged_verified':digest_file(source)==digest_bytes(original.encode()),'empty_input_guard':bool(needed)})
    for g in groups.values():g['files']=sorted(set(g['files']))
    ddl="""/* 仅在原授权数据环境创建并填入；此发布包不提供实际业务ID。
   batch_key必须与发布说明/manifest一致，不能把全部用户填入替代冻结名单。
   必须检查每批distinct数量、主键唯一性与规范化SHA256；空表不运行全量。
   三表与业务查询在同一连接可见；本脚本不自动取数、不自动填数。 */
CREATE TEMP TABLE validation_target_users (
    batch_key text NOT NULL,
    user_id bigint NOT NULL
);
CREATE TEMP TABLE validation_target_offers (
    batch_key text NOT NULL,
    credit_serial_id bigint NOT NULL
);
CREATE TEMP TABLE validation_target_events (
    batch_key text NOT NULL,
    event_id bigint NOT NULL,
    user_id bigint NOT NULL,
    as_of_time timestamp NOT NULL
);
"""
    (DEST/'00_release_input_tables.sql').write_text(ddl,encoding='utf-8')
    instructions=['发布SQL输入表说明','',
      '用途：发布副本保留原查询逻辑与日期窗口，但移除实际业务用户ID、订单ID和逐事件锚点VALUES清单。原工作SQL未修改。',
      '查询不会默认扩展为全量。依赖输入的查询外层设有批次非空保护：未装载对应batch_key时返回空结果。',
      '复现前必须在原授权数据环境取得同一范围的冻结输入；本发布包不含这些清单。仅用当前全量用户或另一个批次替代，不等价于原检验。',
      '', '一、三类输入表',
      'validation_target_users(batch_key,user_id)：原user_id数字IN集合；同一用户批次按对应冻结范围装载。',
      'validation_target_offers(batch_key,credit_serial_id)：原T0/风险核验订单编号集合；serial_id过滤也读取credit_serial_id列，语义为原获额订单编号。',
      'validation_target_events(batch_key,event_id,user_id,as_of_time)：原target_events逐事件输入，保留原事件ID、用户ID和America/Belize本地锚点时间。',
      '可使用00_release_input_tables.sql创建会话临时输入表。装载方式由授权环境决定；本发布脚本不会自动查询或填充身份名单。',
      '', '二、各批次必须独立装载与验证',
      '下列仅给出数量与SHA256，不包含实际业务标识。8676、14134、18506用户集合是不同来源范围，不能混为一批。',
      'users/offers哈希规则：取原集合去重后按整数升序，十进制无前导零，用英文逗号连接，无空格或换行，UTF-8后计算SHA256。',
      'events哈希规则：按(event_id,user_id,as_of_time原SQL字符串)三元组排序，以JSON二维数组紧凑编码（separators=(逗号,冒号)，无额外空格），UTF-8后计算SHA256；时间字符串须保留原SQL精度/格式，不自行改时区。',
      '校验每批记录数与distinct主键数一致。events的event_id必须唯一；不能把同一事件重复装载或换成未来时刻。',
      '数量或哈希不一致即停止复现并核查冻结输入，不可通过删掉WHERE或扩大为全量绕过。',
      '示例原VALUES也统一输入化；其数量很小的独立批次仅为调用示例，不可与真实历史锚点混用。', '']
    for g in sorted(groups.values(),key=lambda x:(x['input_kind'],x['batch_key'])):
        instructions +=[f"批次：{g['batch_key']}",f"类型：{g['input_kind']}；原行数：{g['canonical_count']}；distinct主键数：{g['distinct_primary_key_count']}",f"SHA256：{g['sha256']}",'使用文件：'+', '.join(g['files']),'']
    instructions +=['三、执行与解释','先按文件清单装载正确批次，再核验数量/哈希，最后在同一授权环境执行对应发布SQL。',
      '无输入依赖的SQL保持原日期/业务条件；不是新增了身份筛选，也没有移除原有过滤。',
      '带输入保护的汇总查询在输入为空时也返回空，而不是输出零计数或其他无关全体汇总；正确装载时保持原业务逻辑。',
      '输入表名未附业务schema；需保证同一会话/搜索路径下可见。生产调度如改成持久输入表，必须继续携带batch_key与相同权限边界。',
      '发布副本未在数据库执行，本次只进行静态参数替换、清单数量/哈希与残留检查；不能把静态检查当数据库语法或运行性能验收。']
    (DEST/'00_发布SQL输入表说明.txt').write_text('\n'.join(instructions)+'\n',encoding='utf-8')
    manifest={'source_zip_inventory':str(ZIP),'sql_files':len(records),'input_batches':len(groups),'files':records,'batch_scopes':sorted(groups.values(),key=lambda x:x['batch_key']),
      'raw_identifiers_exported':False,'source_sql_modified':False,'database_execution_performed':False}
    write_json(ROOT/'release_sql_manifest.json',manifest)
    qa={'status':'passed_static','sql_files':len(records),'parameterized_files':sum(bool(x['replacements']) for x in records),'input_batches':len(groups),
      'batch_counts':[{'batch_key':g['batch_key'],'kind':g['input_kind'],'distinct_count':g['distinct_primary_key_count']} for g in groups.values()],
      'original_hashes_unchanged':all(x['source_unchanged_verified'] for x in records),
      'remaining_business_identifier_IN_lists':0,'remaining_target_event_VALUES_lists':0,
      'all_input_dependent_files_guarded_when_empty':all(x['empty_input_guard'] for x in records if x['required_batches']),
      'database_syntax_execution':'Not executed; static only','notes':'Original per-file SQL conditions retained except list-to-scoped-input substitution and explicit empty-input outer guard.'}
    write_json(ROOT/'release_sql_qa.json',qa)
    print(json.dumps(qa,ensure_ascii=False,indent=2))


if __name__=='__main__':main()
