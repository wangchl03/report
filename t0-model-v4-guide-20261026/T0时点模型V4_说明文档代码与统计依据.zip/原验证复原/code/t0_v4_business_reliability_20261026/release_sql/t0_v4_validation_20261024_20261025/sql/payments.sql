/* 发布副本：原授权SQL保持只读；本文件不内嵌业务用户/订单ID。
 * 依赖下方batch_key对应的冻结授权输入；各批次不能混用。
 * 输入批次：users_5bd6a6ffe75fbf2e
 * 输入为空时返回空结果，绝不自动移除范围限制。详见00_发布SQL输入表说明.txt。
 */
SELECT release_result.*
FROM (
SELECT ROW_NUMBER() OVER(ORDER BY r.user_id,r.payin_date,r.payin_time,r.serial_id) AS export_id,
 r.user_id::bigint,r.serial_id::bigint,r.payin_date::date,r.payin_time,
 SUM(r.amount)::float8 AS amount,COUNT(*) AS source_rows
FROM wangchuanliang.repayment_record_copy r
WHERE r.user_id IN (SELECT user_id FROM validation_target_users WHERE batch_key = 'users_5bd6a6ffe75fbf2e')
AND r.payin_date<DATE '2026-10-25' AND r.amount>0
GROUP BY r.user_id,r.serial_id,r.payin_date,r.payin_time
) release_result
WHERE EXISTS (SELECT 1 FROM validation_target_users WHERE batch_key = 'users_5bd6a6ffe75fbf2e');
