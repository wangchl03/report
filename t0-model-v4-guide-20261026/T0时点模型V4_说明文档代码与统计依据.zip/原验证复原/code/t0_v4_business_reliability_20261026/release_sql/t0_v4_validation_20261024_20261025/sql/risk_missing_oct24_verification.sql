/* 发布副本：原授权SQL保持只读；本文件不内嵌业务用户/订单ID。
 * 依赖下方batch_key对应的冻结授权输入；各批次不能混用。
 * 输入批次：offers_d4fdf4ccd2a65709
 * 输入为空时返回空结果，绝不自动移除范围限制。详见00_发布SQL输入表说明.txt。
 */
SELECT release_result.*
FROM (
SELECT COUNT(*) AS matched_source_rows,COUNT(DISTINCT serial_id) AS matched_distinct_event_orders,SUM(CASE WHEN kabybxgboost405apd7crecyc IS NOT NULL AND kabybxgboost405apd7crecyc<>-9999999 THEN 1 ELSE 0 END) AS valid_405,SUM(CASE WHEN kabybxgboost363dpd7cre IS NOT NULL AND kabybxgboost363dpd7cre<>-9999999 THEN 1 ELSE 0 END) AS valid_363 FROM wangchuanliang.model_result_copy WHERE serial_id IN (SELECT credit_serial_id FROM validation_target_offers WHERE batch_key = 'offers_d4fdf4ccd2a65709')
) release_result
WHERE EXISTS (SELECT 1 FROM validation_target_offers WHERE batch_key = 'offers_d4fdf4ccd2a65709');
