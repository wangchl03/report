/* 发布副本：原授权SQL保持只读；本文件不内嵌业务用户/订单ID。
 * 依赖下方batch_key对应的冻结授权输入；各批次不能混用。
 * 输入为空时返回空结果，绝不自动移除范围限制。详见00_发布SQL输入表说明.txt。
 */
WITH
tmp_t0ml_params AS (
SELECT DATE '2026-10-01' AS start_date,DATE '2026-10-25' AS end_date,TIMESTAMP '2026-10-25 00:00:00' AS data_cutoff_ts
),
tmp_t0ml_offer AS (
SELECT DISTINCT ON (v.user_id,v.serial_id)
       v.user_id,v.serial_id,v.vir_date::date AS vir_date,
       (TO_TIMESTAMP(v.vir_unix) AT TIME ZONE 'America/Belize') AS vir_time,
       v.max_credit_apply_amt::float8 AS current_credit_amt,
       v.total_term::float8 AS current_total_term,
       v.risk_product,v.vir_version
FROM wangchuanliang.order_vir_f_copy v CROSS JOIN tmp_t0ml_params p
WHERE v.is_pass1=1 AND v.loan_type_code=2
  AND v.vir_date>=p.start_date-1 AND v.vir_date<p.data_cutoff_ts::date+1
  AND EXISTS (SELECT 1 FROM wangchuanliang.side_recycle_type_copy r
              WHERE r.serial_id=v.serial_id AND r.recycle_type=3)
ORDER BY v.user_id,v.serial_id,v.vir_unix DESC
),
tmp_t0ml_dedup AS (
WITH lagged AS (
 SELECT v.*,LAG(vir_time) OVER(PARTITION BY user_id ORDER BY vir_time,serial_id) AS previous_time
 FROM tmp_t0ml_offer v
), batched AS (
 SELECT l.*,SUM(CASE WHEN previous_time IS NULL OR vir_time-previous_time>INTERVAL '20 seconds'
                    THEN 1 ELSE 0 END)
 OVER(PARTITION BY user_id ORDER BY vir_time,serial_id ROWS UNBOUNDED PRECEDING) AS batch_id
 FROM lagged l
), ranked AS (
 SELECT b.*,ROW_NUMBER() OVER(PARTITION BY user_id,batch_id ORDER BY vir_time DESC,serial_id DESC) AS rn
 FROM batched b
)
SELECT r.* FROM ranked r CROSS JOIN tmp_t0ml_params p
WHERE rn=1 AND vir_date>=p.start_date AND vir_time<p.data_cutoff_ts
),
tmp_t0ml_orders AS (
SELECT DISTINCT ON(o.user_id,o.serial_id)
 o.user_id,o.serial_id,o.apply_time,o.apply_date,o.apply_amt::float8,
 o.remit_time,o.remit_date,o.remit_amt::float8,o.is_remit,
 o.repaid_time,o.repaid_date,o.is_repaid,o.loan_status_code,
 o.due_date,o.total_term::float8,o.loan_day::float8,
 o.pre_amt::float8,o.post_amt::float8,o.remit_succ_rnb,
 o.reg_date,o.product_no,o.loan_type,o.repaid_amt::float8
FROM wangchuanliang.order_loan_f_v2_copy o
JOIN (SELECT DISTINCT user_id FROM tmp_t0ml_dedup) u ON u.user_id=o.user_id
ORDER BY o.user_id,o.serial_id,o.apply_time ASC
),
tmp_t0ml_settlement AS (
SELECT o.* FROM tmp_t0ml_orders o CROSS JOIN tmp_t0ml_params p
WHERE o.is_remit=1 AND o.remit_amt>0
 AND (o.is_repaid=1 OR o.loan_status_code=7)
 AND o.repaid_time> TIMESTAMP '2000-01-01'
 AND o.repaid_date>=p.start_date AND o.repaid_time<p.data_cutoff_ts
 AND NOT EXISTS (
  SELECT 1 FROM tmp_t0ml_orders x
  WHERE x.user_id=o.user_id AND x.serial_id<>o.serial_id
    AND x.is_remit=1 AND x.remit_amt>0 AND x.remit_time<=o.repaid_time
    AND (x.repaid_time IS NULL OR x.repaid_time<=TIMESTAMP '2000-01-01'
         OR x.repaid_time>o.repaid_time)
 )
),
tmp_t0ml_events_all AS (
WITH matched AS (
 SELECT e.*,s.serial_id AS settled_serial_id,s.repaid_time,
  ROW_NUMBER() OVER(PARTITION BY e.user_id,e.serial_id ORDER BY s.repaid_time DESC,s.serial_id DESC) AS srn
 FROM tmp_t0ml_dedup e JOIN tmp_t0ml_settlement s
 ON s.user_id=e.user_id AND s.repaid_date=e.vir_date AND s.repaid_time<=e.vir_time
)
SELECT m.*,LEAD(vir_time) OVER(PARTITION BY user_id ORDER BY vir_time,serial_id) AS next_t0_time
FROM matched m WHERE srn=1
),
tmp_t0ml_events AS (
SELECT e.*,MIN(o.apply_time) AS first_apply_time,
 LEAST(COALESCE(e.next_t0_time,p.data_cutoff_ts),p.data_cutoff_ts,
       e.vir_date+INTERVAL '16 days') AS followup_end,
 p.data_cutoff_ts
FROM tmp_t0ml_events_all e CROSS JOIN tmp_t0ml_params p
LEFT JOIN tmp_t0ml_orders o ON o.user_id=e.user_id
 AND o.apply_time>=e.vir_time AND o.apply_time<p.data_cutoff_ts
 AND o.apply_time<e.vir_date+INTERVAL '16 days'
 AND (e.next_t0_time IS NULL OR o.apply_time<e.next_t0_time)
WHERE e.vir_date<p.end_date
GROUP BY e.user_id,e.serial_id,e.vir_date,e.vir_time,e.current_credit_amt,
 e.current_total_term,e.risk_product,e.vir_version,e.previous_time,e.batch_id,
 e.rn,e.settled_serial_id,e.repaid_time,e.srn,e.next_t0_time,p.data_cutoff_ts
),
tmp_t0ml_order_credit AS (
SELECT DISTINCT ON (o.user_id,o.serial_id)
 o.user_id,o.serial_id,v.max_credit_apply_amt::float8 AS credit_amt,
 (TO_TIMESTAMP(v.vir_unix) AT TIME ZONE 'America/Belize') AS credit_time
FROM tmp_t0ml_orders o JOIN wangchuanliang.order_vir_f_copy v
 ON v.user_id=o.user_id AND v.serial_id=o.serial_id AND v.is_pass1=1
 AND (TO_TIMESTAMP(v.vir_unix) AT TIME ZONE 'America/Belize')<=o.apply_time
ORDER BY o.user_id,o.serial_id,v.vir_unix DESC
),
tmp_t0ml_order_history AS (
WITH ranked AS (
 SELECT e.serial_id AS event_id,o.*,
  v.credit_amt,v.credit_time,
  ROW_NUMBER() OVER(PARTITION BY e.serial_id ORDER BY o.apply_time DESC,o.serial_id DESC) AS arn,
  ROW_NUMBER() OVER(PARTITION BY e.serial_id
    ORDER BY CASE WHEN o.is_remit=1 AND o.remit_time<=e.vir_time THEN o.remit_time END DESC NULLS LAST,
             o.serial_id DESC) AS rrn,
  CASE WHEN o.is_remit=1 AND o.remit_amt>0 AND o.remit_time<=e.vir_time THEN 1 ELSE 0 END AS funded,
  CASE WHEN o.repaid_time>TIMESTAMP '2000-01-01' AND o.repaid_time<=e.vir_time THEN 1 ELSE 0 END AS settled
 FROM tmp_t0ml_events e JOIN tmp_t0ml_orders o ON o.user_id=e.user_id AND o.apply_time<e.vir_time
 LEFT JOIN tmp_t0ml_order_credit v ON v.user_id=o.user_id AND v.serial_id=o.serial_id
), calculated AS (
 SELECT r.*,
  CASE WHEN apply_amt>0 AND credit_amt>0 THEN apply_amt/credit_amt END AS utilization,
  CASE WHEN credit_time IS NOT NULL THEN EXTRACT(EPOCH FROM (apply_time-credit_time))/86400.0 END AS credit_apply_gap_days
 FROM ranked r
)
SELECT event_id,COUNT(*)::float8 AS historical_apply_count,
 SUM(funded)::float8 AS successful_loan_count,
 SUM(CASE WHEN funded=1 THEN remit_amt ELSE 0 END)::float8 AS total_remit_amt,
 SUM(CASE WHEN settled=1 AND repaid_date<due_date THEN 1 ELSE 0 END)::float8 AS early_settle_count,
 SUM(CASE WHEN settled=1 AND repaid_date>due_date THEN 1 ELSE 0 END)::float8 AS late_settle_count,
 MAX(CASE WHEN settled=1 THEN GREATEST(repaid_date-due_date,0) END)::float8 AS max_past_late_days,
 MIN(reg_date) AS registration_date,
 MAX(CASE WHEN arn=1 THEN apply_amt END) AS apply_amt_l1,
 MAX(CASE WHEN arn=2 THEN apply_amt END) AS apply_amt_l2,
 MAX(CASE WHEN arn=3 THEN apply_amt END) AS apply_amt_l3,
 MAX(CASE WHEN arn=1 THEN utilization END) AS apply_util_l1,
 MAX(CASE WHEN arn=2 THEN utilization END) AS apply_util_l2,
 MAX(CASE WHEN arn=3 THEN utilization END) AS apply_util_l3,
 MAX(CASE WHEN arn=1 THEN credit_apply_gap_days END) AS apply_gap_l1,
 MAX(CASE WHEN arn=2 THEN credit_apply_gap_days END) AS apply_gap_l2,
 MAX(CASE WHEN arn=3 THEN credit_apply_gap_days END) AS apply_gap_l3,
 MAX(CASE WHEN funded=1 AND rrn=1 THEN remit_amt END) AS remit_amt_l1,
 MAX(CASE WHEN funded=1 AND rrn=2 THEN remit_amt END) AS remit_amt_l2,
 MAX(CASE WHEN funded=1 AND rrn=3 THEN remit_amt END) AS remit_amt_l3,
 MAX(apply_time) AS last_apply_time,
 MAX(CASE WHEN funded=1 THEN remit_time END) AS last_remit_time
FROM calculated GROUP BY event_id
),
tmp_t0ml_credit_history AS (
WITH eligible AS (
 SELECT e.serial_id AS event_id,v.serial_id,v.vir_unix,v.is_pass1,
 v.max_credit_apply_amt::float8 AS credit_amt,
 ROW_NUMBER() OVER(PARTITION BY e.serial_id,v.serial_id ORDER BY v.vir_unix DESC) AS srn
 FROM tmp_t0ml_events e JOIN wangchuanliang.order_vir_f_copy v
 ON v.user_id=e.user_id
 AND (TO_TIMESTAMP(v.vir_unix) AT TIME ZONE 'America/Belize')<=e.vir_time
), ranked AS (
 SELECT a.*,ROW_NUMBER() OVER(PARTITION BY event_id
   ORDER BY CASE WHEN is_pass1=1 THEN vir_unix END DESC NULLS LAST,serial_id DESC) AS prn
 FROM eligible a WHERE srn=1
)
SELECT event_id,COUNT(*)::float8 AS credit_event_count,
 SUM(CASE WHEN is_pass1=1 THEN 1 ELSE 0 END)::float8 AS credit_pass_count,
 MAX(CASE WHEN is_pass1=1 AND prn=1 THEN credit_amt END) AS credit_amt_l1,
 MAX(CASE WHEN is_pass1=1 AND prn=2 THEN credit_amt END) AS credit_amt_l2,
 MAX(CASE WHEN is_pass1=1 AND prn=3 THEN credit_amt END) AS credit_amt_l3
FROM ranked GROUP BY event_id
),
tmp_t0ml_features AS (
SELECT e.serial_id AS event_id,e.user_id,e.serial_id AS credit_serial_id,e.settled_serial_id,
 e.vir_date,e.vir_time AS as_of_time,e.first_apply_time,e.followup_end,e.next_t0_time,e.data_cutoff_ts,
 e.current_credit_amt,e.current_total_term,e.risk_product,e.vir_version,
 c.credit_amt AS previous_credit_amt,
 p.apply_amt AS previous_apply_amt,p.remit_amt AS previous_remit_amt,
 p.total_term AS previous_total_term,p.loan_day AS previous_loan_day,
 CASE WHEN p.remit_amt>0 THEN (p.pre_amt+p.post_amt)/p.remit_amt END AS previous_fee_rate,
 CASE WHEN p.loan_day>0 AND p.remit_amt>0 THEN (p.pre_amt+p.post_amt)/p.remit_amt/p.loan_day END AS previous_daily_rate,
 (p.repaid_date-p.due_date)::float8 AS previous_settlement_delay,
 p.product_no AS previous_product_no,
 p.remit_succ_rnb AS original_successful_loan_rnb,
 CASE WHEN p.apply_amt>0 AND c.credit_amt>0 THEN p.apply_amt/c.credit_amt END AS previous_utilization,
 NULLIF(m.kabybxgboost405apd7crecyc,-9999999) AS risk_score_405,
 NULLIF(m.kabybxgboost363dpd7cre,-9999999) AS risk_score_363,
 h.historical_apply_count,h.successful_loan_count,h.total_remit_amt,
 h.early_settle_count,h.late_settle_count,h.max_past_late_days,
 (e.vir_date-h.registration_date)::float8 AS user_age_days,
 h.apply_amt_l1,h.apply_amt_l2,h.apply_amt_l3,
 h.apply_util_l1,h.apply_util_l2,h.apply_util_l3,
 h.apply_gap_l1,h.apply_gap_l2,h.apply_gap_l3,
 h.remit_amt_l1,h.remit_amt_l2,h.remit_amt_l3,
 EXTRACT(EPOCH FROM (e.vir_time-h.last_apply_time))/86400.0 AS days_since_last_apply,
 EXTRACT(EPOCH FROM (e.vir_time-h.last_remit_time))/86400.0 AS days_since_last_remit,
 ch.credit_event_count,ch.credit_pass_count,
 ch.credit_amt_l1,ch.credit_amt_l2,ch.credit_amt_l3
FROM tmp_t0ml_events e
JOIN tmp_t0ml_orders p ON p.user_id=e.user_id AND p.serial_id=e.settled_serial_id
LEFT JOIN tmp_t0ml_order_credit c ON c.user_id=p.user_id AND c.serial_id=p.serial_id
LEFT JOIN wangchuanliang.model_result_copy m ON m.serial_id=e.serial_id AND m.user_id=e.user_id
LEFT JOIN tmp_t0ml_order_history h ON h.event_id=e.serial_id
LEFT JOIN tmp_t0ml_credit_history ch ON ch.event_id=e.serial_id
)
SELECT * FROM tmp_t0ml_features ORDER BY event_id;
