/* 发布副本：原授权SQL保持只读；本文件不内嵌业务用户/订单ID。
 * 依赖下方batch_key对应的冻结授权输入；各批次不能混用。
 * 输入批次：users_5bd6a6ffe75fbf2e
 * 输入为空时返回空结果，绝不自动移除范围限制。详见00_发布SQL输入表说明.txt。
 */
SELECT release_result.*
FROM (
SELECT ROW_NUMBER() OVER(ORDER BY v.user_id,v.vir_unix,v.serial_id) AS export_id,
 v.user_id::bigint,v.serial_id::bigint,
 (TO_TIMESTAMP(v.vir_unix) AT TIME ZONE 'America/Belize') AS credit_time,
 v.is_pass1,v.max_credit_apply_amt::float8 AS credit_amt,v.risk_product
FROM wangchuanliang.order_vir_f_copy v
WHERE v.user_id IN (SELECT user_id FROM validation_target_users WHERE batch_key = 'users_5bd6a6ffe75fbf2e')
AND v.vir_unix>0 AND v.vir_unix<%(cutoff_unix)s
) release_result
WHERE EXISTS (SELECT 1 FROM validation_target_users WHERE batch_key = 'users_5bd6a6ffe75fbf2e');
