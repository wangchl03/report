/* 发布副本：原授权SQL保持只读；本文件不内嵌业务用户/订单ID。
 * 依赖下方batch_key对应的冻结授权输入；各批次不能混用。
 * 输入为空时返回空结果，绝不自动移除范围限制。详见00_发布SQL输入表说明.txt。
 */
SELECT remit_date::date AS profile_date,product_no::text AS product_no,
       COUNT(*) AS orders,SUM(remit_amt)::float8 AS remit_sum,
       SUM(pre_amt+post_amt)::float8 AS fee_sum,
       SUM(loan_day)::float8 AS day_sum,COUNT(loan_day) AS day_n,
       SUM(total_term)::float8 AS term_sum,COUNT(total_term) AS term_n
FROM wangchuanliang.order_loan_f_v2_copy
WHERE is_remit=1 AND remit_amt>0
  AND remit_time>TIMESTAMP '2000-01-01'
  AND remit_time<TIMESTAMP '2026-10-25 00:00:00'
  AND remit_date<DATE '2026-10-25'
  AND pre_amt IS NOT NULL AND post_amt IS NOT NULL AND loan_day>0
  AND product_no IS NOT NULL
GROUP BY remit_date::date,product_no::text
ORDER BY product_no,profile_date;
