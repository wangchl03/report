/* 发布副本：原授权SQL保持只读；本文件不内嵌业务用户/订单ID。
 * 依赖下方batch_key对应的冻结授权输入；各批次不能混用。
 * 输入批次：users_fed0257e3aa18658
 * 输入为空时返回空结果，绝不自动移除范围限制。详见00_发布SQL输入表说明.txt。
 */
SELECT release_result.*
FROM (
SELECT e.user_id,e.create_date,COUNT(e.user_id)::float8 AS events,MAX(e.create_time) AS last_active_time,
SUM(CASE WHEN e.event_type='page_view_in' AND e.props_id IN ('Loan_newpage','Loan_newpage_select') THEN 1 ELSE 0 END)::float8 AS newpage,
SUM(CASE WHEN e.props_id IN ('amount_modification','loan_form_loan_amount_selectionn_new','loan_form_loan_amount_selectionn_new_select') THEN 1 ELSE 0 END)::float8 AS amount,
SUM(CASE WHEN e.props_id IN ('Loan_contract_newdetails','Loan_contract_newdetails_select') THEN 1 ELSE 0 END)::float8 AS contract,
SUM(CASE WHEN e.props_id IN ('loan_form_term_selection_new','loan_form_term_selection_new_select') THEN 1 ELSE 0 END)::float8 AS term,
SUM(CASE WHEN e.props_id IN ('Loan_newconfirm','Loan_newconfirm_select') THEN 1 ELSE 0 END)::float8 AS confirm,
SUM(CASE WHEN e.props_id IN ('Loan_plan_newdetails','Loan_plan_newdetails_select') THEN 1 ELSE 0 END)::float8 AS plan,
SUM(CASE WHEN e.props_id IN ('Loan_purpose_newdetails','Loan_purpose_newdetails_select') THEN 1 ELSE 0 END)::float8 AS purpose,
SUM(CASE WHEN e.props_id IN ('Order_coupons_back','Order_coupons_back_select') THEN 1 ELSE 0 END)::float8 AS coupon_back,
SUM(CASE WHEN e.props_id IN ('Order_coupons_confirm','Order_coupons_confirm_select') THEN 1 ELSE 0 END)::float8 AS coupon_confirm,
SUM(CASE WHEN e.props_id IN ('Order_coupons_page','Order_coupons_page_select') THEN 1 ELSE 0 END)::float8 AS coupon_page,
SUM(CASE WHEN lower(COALESCE(e.props_id,'')||' '||COALESCE(e.page_name,'')) LIKE '%repay%' THEN 1 ELSE 0 END)::float8 AS repayment_page,
SUM(CASE WHEN e.event_type='page_view_out' AND e.event_end_time>=e.event_start_time AND e.event_end_time<=EXTRACT(EPOCH FROM((e.create_date+1)::timestamp AT TIME ZONE 'America/Belize'))*1000 THEN LEAST((e.event_end_time-e.event_start_time)/1000.0,3600.0) ELSE 0 END)::float8 AS duration,
SUM(CASE WHEN e.props_id IN ('Loan_newpage','Loan_newpage_select') THEN CASE WHEN e.event_type='page_view_out' AND e.event_end_time>=e.event_start_time AND e.event_end_time<=EXTRACT(EPOCH FROM((e.create_date+1)::timestamp AT TIME ZONE 'America/Belize'))*1000 THEN LEAST((e.event_end_time-e.event_start_time)/1000.0,3600.0) ELSE 0 END ELSE 0 END)::float8 AS apply_duration
FROM wangchuanliang.event_track_record e
WHERE e.user_id IN (SELECT user_id FROM validation_target_users WHERE batch_key = 'users_fed0257e3aa18658')
AND e.create_date>=DATE '2026-02-01' AND e.create_date<DATE '2026-03-01'
GROUP BY e.user_id,e.create_date
) release_result
WHERE EXISTS (SELECT 1 FROM validation_target_users WHERE batch_key = 'users_fed0257e3aa18658');
