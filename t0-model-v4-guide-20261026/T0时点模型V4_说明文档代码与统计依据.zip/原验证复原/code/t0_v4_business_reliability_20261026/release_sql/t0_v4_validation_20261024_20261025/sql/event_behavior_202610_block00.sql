/* 发布副本：原授权SQL保持只读；本文件不内嵌业务用户/订单ID。
 * 依赖下方batch_key对应的冻结授权输入；各批次不能混用。
 * 输入批次：events_699a8f3949ef9bb8
 * 输入为空时返回空结果，绝不自动移除范围限制。详见00_发布SQL输入表说明.txt。
 */
SELECT release_result.*
FROM (
WITH target_events(event_id,user_id,as_of_time) AS (SELECT event_id,user_id,as_of_time FROM validation_target_events WHERE batch_key = 'events_699a8f3949ef9bb8')
SELECT t.event_id,
COUNT(CASE WHEN e.create_time>=t.as_of_time-INTERVAL '7 days' THEN e.user_id END)::float8 AS beh_events_7d,
COUNT(DISTINCT CASE WHEN e.create_time>=t.as_of_time-INTERVAL '7 days' THEN e.create_date END)::float8 AS beh_active_days_7d,
SUM(CASE WHEN e.create_time>=t.as_of_time-INTERVAL '1 day' THEN 1 ELSE 0 END)::float8 AS beh_events_1d,
SUM(CASE WHEN e.create_time>=t.as_of_time-INTERVAL '3 days' THEN 1 ELSE 0 END)::float8 AS beh_events_3d,
SUM(CASE WHEN (e.create_time>=t.as_of_time-INTERVAL '7 days') AND (e.event_type='page_view_in' AND e.props_id IN ('Loan_newpage','Loan_newpage_select')) THEN 1 ELSE 0 END)::float8 AS beh_newpage_7d,
SUM(CASE WHEN (e.create_time>=t.as_of_time-INTERVAL '7 days') AND (e.props_id IN ('amount_modification','loan_form_loan_amount_selectionn_new','loan_form_loan_amount_selectionn_new_select')) THEN 1 ELSE 0 END)::float8 AS beh_amount_7d,
SUM(CASE WHEN (e.create_time>=t.as_of_time-INTERVAL '7 days') AND (e.props_id IN ('Loan_plan_newdetails','Loan_plan_newdetails_select')) THEN 1 ELSE 0 END)::float8 AS beh_plan_7d,
SUM(CASE WHEN (e.create_time>=t.as_of_time-INTERVAL '7 days') AND (e.props_id IN ('loan_form_term_selection_new','loan_form_term_selection_new_select')) THEN 1 ELSE 0 END)::float8 AS beh_term_7d,
SUM(CASE WHEN (e.create_time>=t.as_of_time-INTERVAL '7 days') AND (e.props_id IN ('Loan_newconfirm','Loan_newconfirm_select')) THEN 1 ELSE 0 END)::float8 AS beh_confirm_7d,
SUM(CASE WHEN e.create_time>=t.as_of_time-INTERVAL '7 days' THEN CASE WHEN e.event_type='page_view_out' AND e.event_end_time>=e.event_start_time AND e.event_end_time<=EXTRACT(EPOCH FROM(t.as_of_time AT TIME ZONE 'America/Belize'))*1000 THEN LEAST((e.event_end_time-e.event_start_time)/1000.0,3600.0) ELSE 0 END ELSE 0 END)::float8 AS beh_duration_7d,
EXTRACT(EPOCH FROM(t.as_of_time-MAX(CASE WHEN e.create_time>=t.as_of_time-INTERVAL '7 days' THEN e.create_time END)))/86400.0 AS days_since_active,
COUNT(CASE WHEN e.create_date=t.as_of_time::date THEN e.user_id END)::float8 AS prefix_events,
MAX(CASE WHEN e.create_date=t.as_of_time::date THEN e.create_time END) AS prefix_last_active_time,
SUM(CASE WHEN e.create_date=t.as_of_time::date AND (e.event_type='page_view_in' AND e.props_id IN ('Loan_newpage','Loan_newpage_select')) THEN 1 ELSE 0 END)::float8 AS prefix_newpage,
SUM(CASE WHEN e.create_date=t.as_of_time::date AND (e.props_id IN ('amount_modification','loan_form_loan_amount_selectionn_new','loan_form_loan_amount_selectionn_new_select')) THEN 1 ELSE 0 END)::float8 AS prefix_amount,
SUM(CASE WHEN e.create_date=t.as_of_time::date AND (e.props_id IN ('Loan_contract_newdetails','Loan_contract_newdetails_select')) THEN 1 ELSE 0 END)::float8 AS prefix_contract,
SUM(CASE WHEN e.create_date=t.as_of_time::date AND (e.props_id IN ('loan_form_term_selection_new','loan_form_term_selection_new_select')) THEN 1 ELSE 0 END)::float8 AS prefix_term,
SUM(CASE WHEN e.create_date=t.as_of_time::date AND (e.props_id IN ('Loan_newconfirm','Loan_newconfirm_select')) THEN 1 ELSE 0 END)::float8 AS prefix_confirm,
SUM(CASE WHEN e.create_date=t.as_of_time::date AND (e.props_id IN ('Loan_plan_newdetails','Loan_plan_newdetails_select')) THEN 1 ELSE 0 END)::float8 AS prefix_plan,
SUM(CASE WHEN e.create_date=t.as_of_time::date AND (e.props_id IN ('Loan_purpose_newdetails','Loan_purpose_newdetails_select')) THEN 1 ELSE 0 END)::float8 AS prefix_purpose,
SUM(CASE WHEN e.create_date=t.as_of_time::date AND (e.props_id IN ('Order_coupons_back','Order_coupons_back_select')) THEN 1 ELSE 0 END)::float8 AS prefix_coupon_back,
SUM(CASE WHEN e.create_date=t.as_of_time::date AND (e.props_id IN ('Order_coupons_confirm','Order_coupons_confirm_select')) THEN 1 ELSE 0 END)::float8 AS prefix_coupon_confirm,
SUM(CASE WHEN e.create_date=t.as_of_time::date AND (e.props_id IN ('Order_coupons_page','Order_coupons_page_select')) THEN 1 ELSE 0 END)::float8 AS prefix_coupon_page,
SUM(CASE WHEN e.create_date=t.as_of_time::date AND (lower(COALESCE(e.props_id,'')||' '||COALESCE(e.page_name,'')) LIKE '%repay%') THEN 1 ELSE 0 END)::float8 AS prefix_repayment_page,
SUM(CASE WHEN e.create_date=t.as_of_time::date THEN CASE WHEN e.event_type='page_view_out' AND e.event_end_time>=e.event_start_time AND e.event_end_time<=EXTRACT(EPOCH FROM(t.as_of_time AT TIME ZONE 'America/Belize'))*1000 THEN LEAST((e.event_end_time-e.event_start_time)/1000.0,3600.0) ELSE 0 END ELSE 0 END)::float8 AS prefix_duration,
SUM(CASE WHEN e.create_date=t.as_of_time::date AND e.props_id IN ('Loan_newpage','Loan_newpage_select') THEN CASE WHEN e.event_type='page_view_out' AND e.event_end_time>=e.event_start_time AND e.event_end_time<=EXTRACT(EPOCH FROM(t.as_of_time AT TIME ZONE 'America/Belize'))*1000 THEN LEAST((e.event_end_time-e.event_start_time)/1000.0,3600.0) ELSE 0 END ELSE 0 END)::float8 AS prefix_apply_duration
FROM target_events t LEFT JOIN wangchuanliang.event_track_record e ON e.user_id=t.user_id
AND e.create_date>=DATE '2026-09-24' AND e.create_date<DATE '2026-11-01'
AND e.create_time<t.as_of_time AND ((e.create_time>=t.as_of_time-INTERVAL '7 days') OR (e.create_date=t.as_of_time::date))
GROUP BY t.event_id,t.as_of_time
) release_result
WHERE EXISTS (SELECT 1 FROM validation_target_events WHERE batch_key = 'events_699a8f3949ef9bb8');
