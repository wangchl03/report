/* 发布副本：原授权SQL保持只读；本文件不内嵌业务用户/订单ID。
 * 依赖下方batch_key对应的冻结授权输入；各批次不能混用。
 * 输入批次：users_5bd6a6ffe75fbf2e
 * 输入为空时返回空结果，绝不自动移除范围限制。详见00_发布SQL输入表说明.txt。
 */
SELECT release_result.*
FROM (
SELECT DISTINCT ON(o.user_id,o.serial_id)
 o.serial_id::bigint AS serial_id,o.user_id::bigint AS user_id,
 o.reg_date,o.apply_time,o.apply_date,o.apply_amt::float8,
 o.remit_time,o.remit_date,o.remit_amt::float8,o.is_remit,
 o.repaid_time,o.repaid_date,o.is_repaid,o.loan_status_code,
 o.due_date,o.total_term::float8,o.loan_day::float8,
 o.pre_amt::float8,o.post_amt::float8,o.remit_succ_rnb,o.product_no,o.loan_type
FROM wangchuanliang.order_loan_f_v2_copy o
WHERE o.user_id IN (SELECT user_id FROM validation_target_users WHERE batch_key = 'users_5bd6a6ffe75fbf2e')
AND o.apply_time<TIMESTAMP '2026-10-25 00:00:00'
ORDER BY o.user_id,o.serial_id,o.apply_time
) release_result
WHERE EXISTS (SELECT 1 FROM validation_target_users WHERE batch_key = 'users_5bd6a6ffe75fbf2e');
