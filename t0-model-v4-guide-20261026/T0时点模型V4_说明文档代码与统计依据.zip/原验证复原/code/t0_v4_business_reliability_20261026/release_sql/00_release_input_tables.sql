/* 仅在原授权数据环境创建并填入；此发布包不提供实际业务ID。
   batch_key必须与发布说明/manifest一致，不能把全部用户填入替代冻结名单。
   必须检查每批distinct数量、主键唯一性与规范化SHA256；空表不运行全量。
   三表与业务查询在同一连接可见；本脚本不自动取数、不自动填数。 */
CREATE TEMP TABLE validation_target_users (
    batch_key text NOT NULL,
    user_id bigint NOT NULL
);
CREATE TEMP TABLE validation_target_offers (
    batch_key text NOT NULL,
    credit_serial_id bigint NOT NULL
);
CREATE TEMP TABLE validation_target_events (
    batch_key text NOT NULL,
    event_id bigint NOT NULL,
    user_id bigint NOT NULL,
    as_of_time timestamp NOT NULL
);
