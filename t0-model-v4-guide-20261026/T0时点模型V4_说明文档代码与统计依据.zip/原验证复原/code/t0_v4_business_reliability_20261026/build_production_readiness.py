from pathlib import Path
import json,hashlib
ROOT=Path('/Users/wangchuanliang/Documents/Codex/2026-10-18/wen')
V=ROOT/'work/t0_v4_validation_20261024_20261025'
S=ROOT/'work/t0_offer_strategy_20261025'
R=ROOT/'work/t0_risk410_lifecycle_strategy_20261025'
OUT=ROOT/'work/t0_v4_business_reliability_20261026'
read=lambda p:json.loads(p.read_text())
contract=read(V/'contract_locked.json'); final=read(V/'final_validation_audit.json'); feature=read(V/'features/feature_replay_audit.json'); score=read(V/'score_audit.json'); missing=read(V/'risk_source_missing_audit.json')
metrics=read(V/'evaluation/metrics.json'); targeting=read(S/'model_targeting.json');den=read(S/'candidate_denominator_audit.json');profiles=read(R/'prediction_profiles.json')
main=targeting['headlines_at_threshold_0_5']['main_d3_mature_20261009_20261021']
high=next(r for r in profiles['rules'] if r['rule']=='LOWP_HIGH20')
high6=next(r for r in profiles['rules'] if r['rule']=='LOWP_HIGH20_LIFE6PLUS')
def ref(p):return str(p.relative_to(ROOT))
files={
 'TECH':V/'final_validation_audit.json','SOURCE':V/'feature_source_independent_audit.json','RISK_GAP':V/'risk_source_missing_audit.json','CONTRACT':V/'contract_locked.json',
 'FEATURE':V/'features/feature_replay_audit.json','FEATURE_TEST':V/'frozen_replay_test/frozen_numerical_comparison.json','SCORE_TEST':V/'frozen_score_reproduction_audit.json','SCORE':V/'score_audit.json',
 'HISTORY_COMPLETE':V/'histories_integrity_audit.json','BEHAVIOR_COMPLETE':V/'behavior_extraction_completion.json','METRICS':V/'evaluation/metrics.json',
 'TARGETING':S/'model_targeting.json','DENOMINATOR':S/'candidate_denominator_audit.json','PROFILE':R/'prediction_profiles.json','RISK410':R/'quality.json',
}
d={
 'title':'T0 V4生产可用性：模型筛选可以走到哪一步',
 'review_date':'2026-10-26',
 'scope':'只读已有本地审计与结果；未查询数据库、未重训、未部署、未发放优惠。业务上的定向优惠方向作为待验证假设保留，本文件聚焦模型和数据能否支撑获额当日实际决策。',
 'short_answer':{
  'business_readout':'离线证据足以支持把V4接入影子运行并准备受控试验；还不足以声称已经具备生产全自动优惠条件。缺的是实时可用与执行证据，不是必须先再训练一个版本。',
  'what_pass_means':'final_validation_audit为PASS，意味着本次冻结模型、重建计算、样本标签和算术核对通过；文件本身明确不认证历史在线特征可用性或业务源完整覆盖。',
  'not_a_model_failure_claim':'没有证据证明V4完全不可用。也没有证据证明历史回放中看到的分数在当时能按同样质量、时延和成本及时生成。应把已经通过的部分与尚未实测的部分分别验收。'
 },
 'readiness_matrix':[
  {'use':'离线业务分析或人工辅助排序','decision':'可以，保留证据边界','ready_now':'已有冻结评分与标签复现证据，可用于候选规则分析和人工评估；不得把分数当真实优惠响应或已验证自动审批。','next_gate':'展示模型版本、概率、源缺失与时间口径；对当前真实用户重新使用决策时已到达的数据。'},
  {'use':'线上影子评分，不改变利率/额度、不触达优惠','decision':'可开始建设并运行，尚无已完成影子验收记录','ready_now':'可复用冻结V4，真实T0发生时生成分数并保存快照、时钟和资格，不需要先发优惠或重训。','next_gate':'必须将真实数据到达、评分生成、20秒封批及资格检查的日志同时建好；异常批次只记录、不自动动作。'},
  {'use':'小流量定向优惠试验','decision':'有条件可以；当前审计不足以直接放行自动发放','ready_now':'模型有筛选价值，支持准备小流量试验。先通过实时数据/时点/概率合同/幂等与资格门禁，再在已批准条件内按用户随机试验。','next_gate':'影子结果达到事先规定的可用覆盖、误选容忍和时延要求；记录实际成本与风险，并固定用户级对照。'},
  {'use':'生产全量、无人复核、自动降息/提额','decision':'当前不建议直接上线','ready_now':'未观察真实线上时延、实际特征到达、自动发放竞态、稳定运行及优惠后效果；存在已见风险源缺口。','next_gate':'先完成影子与小流量门槛，再按预定阶段扩大；仅靠AUC、离线命中率或技术PASS不足以通过。'}
 ],
 'facts_already_established':[
  {'fact':'模型本次没有被换掉或重训','evidence':['CONTRACT','SCORE','SCORE_TEST'],'detail':{'model_version':contract['version'],'V4_sha256':contract['artifacts']['V4']['sha256'],'before_after_model_hash_equal':score['october']['models_unchanged'],'retraining_or_recalibration':False},'can_conclude':'本次新结果来自同一冻结V4的评分实现。','cannot_conclude':'生产服务已部署相同文件，或已测过线上服务SLA。'},
  {'fact':'代码和特征复现可核查','evidence':['FEATURE_TEST','SCORE_TEST','SOURCE'],'detail':{'frozen_test_events':15,'V3_feature_columns':1759,'V4_numeric_columns':1947,'compared_feature_cells':15*(1759+1947),'mismatch_cells':0,'V4_compared_probabilities':60,'V4_max_probability_error':0.0},'can_conclude':'所测15个旧快照覆盖三日期、五借款次数组，数值和评分复现一致。','cannot_conclude':'所有生产数据边界都被覆盖；这也不是15批独立预测验证。'},
  {'fact':'本次提取完成，未将中断文件当完整输入','evidence':['TECH','HISTORY_COMPLETE','BEHAVIOR_COMPLETE'],'detail':{'completed_behavior_steps':39,'October_behavior_users':14134,'orders':76315,'credits':220783,'payments':159645,'history_offers':195339},'can_conclude':'已完成文件有行数、哈希或完整gzip校验；独立审计提到的恢复风险在本次最终输入中已有完成性核查。','cannot_conclude':'业务原始源没有漏报、延迟、后补或版本修改。'},
  {'fact':'标签成熟度和边界处理经过核验','evidence':['CONTRACT','TECH','METRICS'],'detail':{'D3_model_last_mature_date':'2026-10-21','D3_mature_events':8866,'D3_known_evaluable_events':8717,'D3_censored_events':149,'cutoff_exclusive':contract['cutoff_exclusive']},'can_conclude':'主D3结果没有把10月22—24日尚未成熟的观察填成未提单。','cannot_conclude':'被下一T0截断的未知事件会与可判事件具有相同表现。'}
 ],
 'evidence_is_replay_not_online_trial':{
  'prediction_source_counts':score['prediction_sources'],
  'fact':'16,154次10月事件使用当前副本重建过去锚点特征后再评分；6,211次9月事件复用旧保存分数。没有完整的原始在线生成时刻、当时特征到达及曝光记录来把整次检验认定为前瞻在线验证。',
  'availability_caveat':'event_time或apply/remit/repaid时间早于T0，只证明事件发生在过去，不证明对应数据/评分在当时已经到达决策系统。风险分、循环贷资格及合同字段还可能被后续更新。',
  'minimum_fix':'从现在开始，保存决策时真实可见的输入值、源版本、observed_arrival/available_at、数据水位、模型哈希和生成分数。未来结果成熟后直接评估这批不可变记录；无需为开始影子运行而先补齐全部历史available_at。',
  'evidence':['SOURCE','SCORE','FEATURE','CONTRACT']
 },
 'actual_source_gap':{
  'status':'已观察到的具体缺口，不只是理论风险',
  'freshness_qualifier':'这是原验证审计时观察到的源副本缺口。本次仅复读本地证据，未重新查库；不能声称2026年10月26日实时源仍缺588条，也不能声称已经恢复。生产前必须核对当前源并记录关闭证据。',
  'date':missing['target_event_date'],'events':missing['target_events'],'missing_events':missing['risk_missing_events'],
  'source_rows_matched':missing['raw_model_result_matches'][0]['matched_source_rows'],
  'source':'model_result_copy；原V4风险字段检查为405/363相关源。后来410分层同日也缺588条，但不能将410分层缺失单独说成V4必然错误的原因。',
  'known':'10月24日目标事件没有任何匹配模型源行；模型仍可对NaN输出概率，不代表数据源健康。',
  'unknown':'审计没有证明是ETL延迟、源未上报、同步问题还是其他原因；不能臆断原因或固定延迟。',
  'scope':'主D3筛选验证为10月9—21日，本来不含10月24日，因此85.97%的主命中率不能被说成已验证风险源整体缺失时仍可用。缺口也不等于此前所有日期评分无效。',
  'operation':'受影响且关键源未达的候选禁止自动优惠，记录缺失原因并人工核验或跳过；健康来源的其他候选可继续影子记录。上线前确定正常无历史缺失与整批源缺失两种状态，不能统一填0或继续无条件发放。',
  'evidence':['RISK_GAP','TECH','RISK410']
 },
 'selector_evidence':{
  'interpretation':'以下均为现有历史策略环境中的事件观察，可能包含既有运营；不是无优惠自然对照，不是总体accuracy，也不是降息或提额的响应率。原始概率p_D3<0.5为候选规则，不是已经优化的上线门槛。',
  'base_rule':{
   'complete_scored_mother':den['all_scored_events'],'complete_candidates':den['selected_all_events'],'complete_candidate_users':den['selected_all_users'],'complete_coverage':den['selection_coverage_all_scored'],
   'D0_known_candidates':main['selected_d0_known'],'D0_unknown_candidates':den['selected_unknown_d0'],'D0_noapply':main['selected_d0_noapply'],'D0_apply':main['selected_d0_apply'],
   'D0_noapply_precision':main['ppv_no_d0'],'D0_noapply_ci95':[main['ppv_no_d0_ci95_low'],main['ppv_no_d0_ci95_high']],
   'potential_D0_overlap_proxy':main['d0_false_offer_rate'],'D1_D3_historical_apply_share':main['d1_3_natural_apply_share'],'D3_noapply_known_only':main['npv_d3'],
   'known_mother_baseline_no_D0':main['baseline_no_d0'],'unobserved_outcome_bounds_not_CI':den['no_d0_bounds_if_unknown_all_fail_or_succeed']
  },
  'plus_HIGH410':{'complete_candidates':high['selected_all_events'],'complete_candidate_users':high['selected_all_users'],'D0_known':high['selected_d0_known_events'],'D0_unknown':high['selected_d0_unknown_events'],'D0_noapply':high['selected_d0_noapply_events'],'D0_noapply_precision':high['d0_nonapply_precision'],'D0_ci95':[high['d0_nonapply_precision_ci95_low'],high['d0_nonapply_precision_ci95_high']]},
  'plus_HIGH410_life6plus':{'complete_candidates':high6['selected_all_events'],'D0_known':high6['selected_d0_known_events'],'D0_unknown':high6['selected_d0_unknown_events'],'D0_noapply':high6['selected_d0_noapply_events'],'D0_noapply_precision':high6['d0_nonapply_precision'],'D0_ci95':[high6['d0_nonapply_precision_ci95_low'],high6['d0_nonapply_precision_ci95_high']]},
  'how_to_use':'这些结果支持选定几个透明候选层开展前瞻验收；组合越窄，覆盖和置信区间同时看。不能在这批数据中挑最高命中组后宣称已经稳定优于其他规则。',
  'business_gate_example':'若业务自行规定D0历史重叠代理必须≤10%，主规则14.03%的点估计不满足；加高410的点估计约9.31%，但其95%上界约10.74%，仍不支持“以该置信界保证≤10%”。这只是说明如何验收，不替业务规定10%门槛。',
  'evidence':['TARGETING','DENOMINATOR','PROFILE']
 },
 'blocking_vs_boundary':[
  {'item':'没有真实实时决策快照和数据到达证据','category':'自动决策上线证据缺口','blocking_for':'直接认定历史表现可原样用于生产；不阻止开始影子建设','minimum_action':'未来每次真实T0保存实际可见特征、水位、版本和分数，离线只用同快照复核。','closure_artifact':'不可变decision_snapshot、feature_availability日志和线上/离线同快照分数差异表。'},
  {'item':'10月24日588次关键风险源无匹配','category':'已见数据异常','blocking_for':'异常来源/批次的自动优惠；不等于全模型所有日期失败','minimum_action':'确认实时源覆盖、水位和根因；关键源未达时自动跳过并告警，不继续默默评分发放。','closure_artifact':'源健康检查、缺失分类、受影响event清单及已批准降级/恢复记录。'},
  {'item':'没有真实端到端时延和单位决策成本','category':'生产执行条件未实测','blocking_for':'保证在用户提单前完成评分与优惠；无法据此承诺服务吞吐和成本','minimum_action':'测量封批、取特征、推理、资格复核、曝光各段p50/p95/p99、超时与单事件成本；超过预算即跳过。','closure_artifact':'真实流量影子运行时延/资源账单和及时完成率，不以离线批处理耗时替代。'},
  {'item':'业务目标D0，而筛选概率是D3','category':'必须冻结的目标合同','blocking_for':'含糊地把三日概率当单日准确率、或把四自然日当72小时','minimum_action':'保留p_D3筛选，直接验收选中名单D0未提单；需要72小时则重新定义并验证标签，不改名字就沿用。','closure_artifact':'概率字段、窗口、阈值边界及实际曝光前资格的版本化合同。'},
  {'item':'尚未预注册覆盖/误选/成本容忍线','category':'业务放行门槛尚待明确','blocking_for':'对某个命中率直接给出可全自动放行结论','minimum_action':'按预算与经营损失设最低覆盖、最高D0重叠代理及置信下限、允许延迟和风险上限，先固定后看新样本。','closure_artifact':'签定版本的阈值与验收配置；不是本次事后最优切点。'},
  {'item':'没有优惠随机对照效果','category':'全量优惠收益尚未验证','blocking_for':'声称已能提高转化并保持利润；不阻止无优惠影子评分','minimum_action':'实时门槛通过后小流量用户级随机试验，分开评估降息与提额。','closure_artifact':'统一随访期的用户级增量收益/本金风险/成本结果。'},
  {'item':'D15主样本仅10月9日一个成熟日期，805次可评','category':'性能证据边界','blocking_for':'宣称15日跨日期稳定，不阻断以D0/D3为目标的影子试验','minimum_action':'等更多日期成熟再复核，不将未成熟填0。','closure_artifact':'追加成熟批次的冻结前瞻结果。'},
  {'item':'数值特征约20.57%缺失','category':'已解释的模型表示，不等于20.57%用户源故障','blocking_for':'不能据总缺失比例单独否定模型，也不能容忍整批关键源异常','minimum_action':'区分无历史/零分母等原公式NaN与数据源未到达，按字段/事件来源监控。','closure_artifact':'缺失原因与训练/线上分布对照；保持冻结缺失处理。'},
  {'item':'旧历史提取中断恢复风险','category':'本次已核查完成，不是遗留未完成任务','blocking_for':'不得再以此宣称当前文件不完整；未来重跑仍需核查','minimum_action':'沿用已完成的gzip CRC、行数、hash与manifest校验。','closure_artifact':'histories_integrity_audit和behavior完成清单。'}
 ],
 'shortest_executable_validation_loop':[
  {'step':1,'name':'锁定一个真实可运行的评分合同','do':'固定V4文件哈希、现有类别/特征变换、p_D3原始概率与0.5候选阈值、Belize D0/D3窗口。沿用20秒链式获额封批；在任何优惠执行前冻结锚点。关键源缺失、推理失败或已提单时不动作。','deliver':'版本化配置+最小决策日志字段清单。','pass_gate':'概率有限且0≤p_D0≤p_D3≤p_D7≤p_D15≤1，阈值不使用批内100分归一化；上游身份/时间/最新通过资格可核验。'},
  {'step':2,'name':'只接真实T0，不发优惠','do':'每次实际获额到达后，记录接收/事件/封批时刻，读取当时已到达特征并立即保存快照和分数。不要把事后补齐的源回写进原快照。对同一快照离线再算一次检查实现一致。','deliver':'decision_id、user_id、event_id、baseline_time、source_version/watermark、available_at或首次观测到达、model_hash、p_D0/p_D3、score_generated_at、源质量和状态。','pass_gate':'关键源就绪、与冻结特征含义一致、同快照分数一致；不能只提交一张分数Excel而没有生成时刻。'},
  {'step':3,'name':'量出是否来得及、成本是否允许','do':'记录资格复核和拟曝光时刻，匹配真实首次提单时刻。分别报告全部T0、模型候选、实际决策时仍可执行候选；超时、缺源、封批期间已提单者计入服务覆盖损失，不从台账消失。','deliver':'端到端及分段p50/p95/p99、完成率、提单前可用率、失败原因、资源/查询与单事件成本。','pass_gate':'达到事先规定的时延/及时覆盖与成本预算；曝光前复核无已提单、无5/8、最新获额仍有效通过。'},
  {'step':4,'name':'等自然观察窗口成熟，验收真实候选','do':'D0到下一业务午夜后才能判完整，D3到事件日期+4天00:00后才能判完整，再加实际源到达水位。用已经封存的线上分数评估，保持未知标签显式。模型监控保留原nextT0合同；经营D0目标可另列固定决策日起至午夜的用户任何提单，不以新T0提前截断，但不能悄悄替换原模型标签。','deliver':'前瞻影子候选数/覆盖/已知未知/D0未提单比例与用户聚类区间；整体模型筛选与资格过滤后的名单结果分别列。','pass_gate':'达到预注册目标及区间要求；至少有窗口成熟的实际样本，样本量按可接受精度和经营差异确定，不预设一个无依据的固定天数。'},
  {'step':5,'name':'门槛通过后才进入已批准条件的小试验','do':'按用户首次入组唯一随机至对照、仅降息、仅提额、组合；保留处理前锚点和ITT时钟。提额触发新获额记treatment_event，不重新分组、不截断用户收益。保留未曝光/未提单/未放款用户。','deliver':'固定随机台账、实际优惠/成本、同窗30/60/90天收益与风险；事先选定主要观察窗。','pass_gate':'只有收益与风险的预定门槛同时达到才逐级扩大；不以D0转化上升或命中率提高替代经济验收。'}
 ],
 'specific_clock_and_latency_notes':{
  'D0':'本次T0获额时刻起至其Belize业务日期次日00:00；晚间获额的D0剩余时长更短，应单列获额小时/剩余分钟的可用覆盖。',
  'D3':'本次获额起至业务日期+4天00:00，覆盖D0、D1、D2、D3四个自然日期；不是滚动72小时。',
  '20_second_dedup':'历史链末需要看后续事件；线上要等待20秒静默并考虑乱序水位。优惠后产生的新获额不并入处理前链，也不回写锚点。',
  'offline_runtime':'feature_replay_audit的146.4秒是16,154次离线批量特征重建耗时，不能当每用户在线时延、接口SLA或费用证明；历史多月取数更不能每次触发后全扫。可用日缓存加实时前缀等实现，但必须核对冻结特征一致性。',
  'clock_basis':'本模型复现沿用event_track_record的原有行为时钟与字段，不能因为新星途埋点采用event_time就直接替换V4输入源而继续声称同一模型检验。'
 },
 'performance_boundary_summary':{
  'model_main_metrics':[{k:r[k] for k in ['horizon','n','users','positives','auc','pr_ap','brier','mean_prediction','actual_rate']} for r in metrics['overall'] if r['cohort']=='main' and r['model']=='v4'],
  'focus':'业务门槛应看所选事件中实际D0未提单、覆盖和可及时完成，而不是只用总体AUC或V4相对V3的AUC增加量作上线判据。',
  'not_required_first':'当前没有证据要求必须先重训、再添加更多变量或重新校准才能做影子。先检验已有版本的真实数据与执行闭环；如前瞻结果不满足门槛，再定位数据、标签、阈值或模型问题。',
  'profit_context':'继续保留低意愿定向策略的业务假设；历史D0盈利较低与风险分层只用于设计候选和试验，不在本模型门槛文件中当作已实现优惠收益。'
 },
 'evidence_index':{k:{'path':ref(p),'absolute_path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for k,p in files.items()},
 'final_business_wording':'模型可以进入真实业务影子验证，并为小流量试验准备名单；目前不应把这次回顾检验写成“已经可以全量自动优惠”。先把实时输入、评分时点、源健康、资格与成本这几项闭环跑通，再用预先固定的目标验收，最后才决定扩大。'
}
OUT.mkdir(exist_ok=True)
p=OUT/'production_readiness.json';p.write_text(json.dumps(d,ensure_ascii=False,indent=2))
# Numerical and provenance checks; no source files are written.
assert d['selector_evidence']['base_rule']['D0_known_candidates']==3656
assert d['selector_evidence']['base_rule']['D0_unknown_candidates']==45
assert d['selector_evidence']['plus_HIGH410']['D0_known']==1514
assert abs(d['selector_evidence']['plus_HIGH410']['D0_noapply_precision']-1373/1514)<1e-12
assert d['actual_source_gap']['missing_events']==588
assert all(Path(v['absolute_path']).is_file() for v in d['evidence_index'].values())
print(json.dumps({'output':str(p),'bytes':p.stat().st_size,'evidence_files':len(files),'status':'read-only evidence review complete'},ensure_ascii=False))
