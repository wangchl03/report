from pathlib import Path
import json, html, csv, hashlib, zipfile, re
from bs4 import BeautifulSoup
ROOT=Path('/Users/wangchuanliang/Documents/Codex/2026-10-18/wen')
W=ROOT/'work/t0_v4_business_reliability_20261026'
O=ROOT/'outputs/T0提单意愿模型V4_业务实测与上线建议_20261026'
O.mkdir(exist_ok=True)
D=json.loads((W/'business_reliability_metrics.json').read_text())
E=json.loads((W/'business_examples.json').read_text())
P=json.loads((W/'production_readiness.json').read_text())
R=json.loads((ROOT/'work/t0_risk410_lifecycle_strategy_20261025/prediction_profiles.json').read_text())
main=next(x for x in D['rules_main'] if x['rule']=='pD3_lt_0.5')
high=next(x for x in R['rules'] if x['rule']=='LOWP_HIGH20')
report_name='T0提单意愿模型V4_实际预测效果与上线建议.html'
zip_name='T0模型V4业务实测_完整代码与统计依据.zip'
e=html.escape
def pct(v,n=2): return '—' if v is None else f'{v*100:.{n}f}%'
def num(v): return f'{v:,}'
def table(head, rows):
 return '<div class="scroll"><table><thead><tr>'+''.join('<th>'+str(x)+'</th>' for x in head)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+str(x)+'</td>' for x in r)+'</tr>' for r in rows)+'</tbody></table></div>'
def fold(title,body): return f'<details><summary>{title}</summary>{body}</details>'
def note(t): return '<p class="note">'+t+'</p>'
def call(t): return '<div class="callout">'+t+'</div>'
def section(id,title,body):return f'<section id="{id}"><h2>{title}</h2>{body}</section>'
# Independent bars avoid line/label collisions and work offline; labels reserve a fixed right column.
CHARTS=[]
def bars(id,title,rows,unit='%',maxval=100):
 # rows=(label,value,color,optional display); no shared text area with mark geometry.
 width=1060; left=310; span=510; right=width-35; top=48; step=49; height=top+step*len(rows)+28
 s=[f'<svg id="{id}" viewBox="0 0 {width} {height}" role="img" aria-label="{e(title)}"><title>{e(title)}</title>']
 for i,(label,value,color,display) in enumerate(rows):
  y=top+i*step; w=max(0,min(span,value/maxval*span))
  s+=[f'<text x="{left-18}" y="{y+5}" text-anchor="end" fill="#cbd5e1">{e(label)}</text>',f'<rect x="{left}" y="{y-13}" width="{span}" height="24" rx="4" fill="#202d43"/>',f'<rect x="{left}" y="{y-13}" width="{w:.3f}" height="24" rx="4" fill="{color}"/>',f'<text x="{right}" y="{y+5}" text-anchor="end" fill="#f8fafc" font-weight="700">{e(display or f"{value:.2f}{unit}")}</text>']
 s+=['</svg>'];CHARTS.append({'id':id,'rows':len(rows),'right_label_column':right,'bar_end_max':left+span,'height':height,'viewbox_width':width})
 return '<figure><h3>'+title+'</h3>'+''.join(s)+'</figure>'

nav=[('verdict','使用结论'),('accuracy','实测结果'),('scope','统计口径'),('dates','分批检验'),('production','执行与附录')]
body=[]
def decision(label,title,detail,color):
 return f'<div class="decision {color}"><span>{label}</span><h3>{title}</h3><p>{detail}</p></div>'
def definition(title,value,fraction,scope,meaning):
 return f'<div class="definition"><h3>{title}</h3><strong>{value}</strong><div class="formula">{fraction}</div><p><b>分母：</b>{scope}</p><p><b>含义：</b>{meaning}</p></div>'
body.append(section('verdict','一、使用结论',
 '<div class="decisions">'+
 decision('可以','筛选当天不提单候选','真实历史数据检验：候选名单的当天未提单命中率为85.97%。','yes')+
 decision('可以','开展实时评分接入测试','获额通过后立即评分，记录当时输入、分数和生成时间，业务按原策略运行。','yes')+
 decision('当前不可以','直接全量自动发放优惠','实时数据、评分时效和资格尚未验收；优惠增量收益尚未通过对照测试。','no')+
 '</div>'+call('<strong>执行结论：</strong>模型用于候选筛选；先完成实时评分验收，再开展小流量优惠对照测试。当前不直接全量自动降息或提额。')+
 note('以下均为截至2026年10月24日真实业务数据的历史回放结果。模型保持冻结，本次不重新训练、不重新取数。')))

body.append(section('accuracy','二、实测结果：名单比例、命中率、目标覆盖分别看',
 '<span id="selection" class="anchor"></span><p class="rule"><b>统一筛选规则：</b>pD3＜50%，即模型预测从获额当日起至第3日结束前，累计提单概率低于50%。</p>'+
 '<div class="flow"><div><b>全部评分</b><strong>8,866次</strong><small>8,717次可判＋149次未知</small></div><div><b>筛入候选</b><strong>3,701次</strong><small>3,656次可判＋45次未知</small></div><div><b>候选可判结果</b><strong>3,143次未提单</strong><small>513次当天提单</small></div></div>'+
 '<div class="definitions">'+
 definition('候选名单比例','41.74%','3,701 ÷ 8,866','全部完成评分的8,866次事件，包含未知结果。','每100次评分事件中，41.74次满足pD3＜50%。')+
 definition('名单内当天未提单命中率','85.97%','3,143 ÷ 3,656','候选中D0结果可判的3,656次；45次未知不计入。','候选可判事件中，85.97%当天确实未提单。')+
 definition('名单内当天实际提单比例','14.03%','513 ÷ 3,656','与85.97%相同，均为3,656次可判候选。','候选可判事件中，14.03%当天仍提单。')+
 definition('全部当天未提单事件覆盖率','59.57%','3,143 ÷ 5,276','8,717次可判事件中，实际当天未提单的5,276次。','全部当天未提单事件中，模型筛中3,143次；2,133次未筛中。')+
 '</div>'+call('<strong>85.97%回答“筛中的准不准”，59.57%回答“实际未提单的覆盖了多少”。</strong>两者分母不同。候选条件针对D0—D3，未筛入但当天未提单的事件，不据此判为D3预测错误。')+
 bars('candidate_precision','当天未提单比例：模型筛选与410分叠加',[
 ('全部可判事件',main['baseline_no_d0']*100,'#64748b',pct(main['baseline_no_d0'])),
 ('pD3＜50%候选',main['ppv_no_d0']*100,'#38bdf8',pct(main['ppv_no_d0'])),
 ('410高分客群，未加意愿筛选',high['baseline_d0_nonapply_eligible_known']*100,'#64748b',pct(high['baseline_d0_nonapply_eligible_known'])),
 ('pD3＜50%且410高分',high['ppv_no_d0']*100,'#34d399',pct(high['ppv_no_d0']))])+
 note('图中四个分母依次为8,717、3,656、2,044、1,514次D0可判事件；分子依次为5,276、3,143、1,622、1,373次D0未提单事件。')+
 '<div class="definitions compact">'+
 definition('叠加410高分后的命中率','90.69%','1,373 ÷ 1,514','同时满足pD3＜50%及410≥528的可判候选。','完整候选1,532次，其中1,514次可判、18次未知；当天提单141次。')+
 definition('叠加410高分后的名单比例','17.28%','1,532 ÷ 8,866','全部完成评分的8,866次事件。','410高分使用既定阈值≥528，不在本批候选内重新按前20%分档。')+
 '</div>'+
 fold('查看筛选与实际结果交叉表',table(['筛选结果（仅8,717次可判事件）','实际当天未提单','实际当天提单','合计'],[
 ['进入候选：pD3＜50%','3,143','513','3,656'],['未进入候选：pD3≥50%','2,133','2,928','5,061'],['合计','5,276','3,441','8,717']]))+
 fold('查看其他门槛、区间和同容量检验',
 table(['指标','实测结果','统计口径'],[
 ['基础候选命中率95%区间','84.83%—86.97%','同一用户聚类重抽样500次，保留用户内重复事件'],
 ['410高分候选命中率95%区间','89.26%—92.10%','与上行同方法，分母为1,514次可判候选'],
 ['按pD0从低到高选3,656次','当天未提单命中86.05%','与pD3＜50%在同一8,717次事件、相同名单量下比较'],
 ['同容量pD0与pD3的命中率差','0.08个百分点','配对95%差值区间−0.47至＋0.63个百分点；不能认定一方更优']])+ 
 table(['候选规则','完整候选数','名单比例（÷8,866）','可判候选数','当天未提单命中率'],[
 [('pD0' if r['score']=='p_v4_d0' else 'pD3')+f"＜{r['threshold']:.0%}",num(r['complete_all_candidates']),pct(r['complete_candidate_coverage']),num(r['known_d0']),pct(r['ppv_no_d0'])]
 for r in D['rules_main'] if r['kind']=='probability_threshold'])+
 note('此表为固定门槛的历史结果，不据此自动选择最高值作为生产门槛。pD0为当天提单概率，pD3为D0—D3累计提单概率。'))))

scope_cards=[
 ('样本与截止时间','主样本为2026年10月9—21日的8,866次评分事件。真实结果观察至10月25日00:00（不含），即截至10月24日完整业务日。'),
 ('统计单位','T0为结清续贷获额通过事件：同日存在获额前使已放款在贷订单归零的结清，匹配最近一次结清。按事件统计，不按用户去重。同用户相邻获额间隔≤20秒进行链式合并，保留链尾获额；不同事件分别计数。'),
 ('D0与D3窗口','业务时区America/Belize。D0从本次获额通过时刻到当天结束；D3从该时刻到第3日结束，包含D0、D1、D2、D3四个自然日期。'),
 ('实际提单','本次T0之后首次实际提单，不限定与获额相同订单号；不要求该次提单审核通过或成功放款。'),
 ('未知结果','被下一次严格T0截断、无法确定完整窗口结果的事件记未知。未知计入名单比例的分母，不计入命中率或实际提单比例的分母。'),
 ('预测时点与证据','使用真实历史数据按获额时点重建特征，再由冻结V4评分。它验证历史筛选效果；不等于已完成获额当时的实时供数和评分验收。')]
body.append(section('scope','三、统计口径',
 '<div class="scope-grid">'+''.join(f'<div><h3>{t}</h3><p>{s}</p></div>' for t,s in scope_cards)+'</div>'+
 '<span id="cases" class="anchor"></span>'+call('<strong>当天未提单与D0—D3未提单分别计算。</strong>基础候选中，D0—D3均未提单为2,488÷3,656＝<strong>68.05%</strong>；513次在D0提单、655次在D1—D3提单。<strong>85.97%不能解释为“D0—D3未提单准确率”，低pD3也不表示第4日后一定提单。</strong>')))

weeks=[r for r in D['consistency_weekly'] if r['rule']=='pD3_lt_0.5']
days=[r for r in D['consistency_daily'] if r['rule']=='pD3_lt_0.5']
body.append(section('dates','四、分批检验：短期有效，单日有波动',
 bars('week_accuracy','固定pD3＜50%：当天未提单命中率',[
 (r['observed_date_start'][5:]+'—'+r['observed_date_end'][5:],r['ppv_no_d0']*100,'#38bdf8',pct(r['ppv_no_d0'])+' · '+num(r['known_d0'])+'次可判') for r in weeks])+
 '<p>三个时段命中率为<strong>85.23%、85.84%、85.45%</strong>；逐日为<strong>80.74%—90.23%</strong>。这些数据证明本次短期样本有筛选效果，<strong>不能证明长期稳定，也不能保证每天达到85.97%。</strong></p>'+
 note('本节只检验D0。日期为10月9—23日，共10,298次评分事件，10,114次D0可判、184次未知；与主样本重叠。10月22—23日D3尚未成熟，不计算其D3准确率。10月24日原审计有588次风险源未匹配，未纳入本节；本次未重新检查源是否恢复。')+
 fold('查看逐周和逐日分子、分母',
 table(['日期','完整候选','可判候选','实际当天未提单','实际当天提单','未知','当天未提单命中率'],[[r['observed_date_start']+'—'+r['observed_date_end'],num(r['all_candidates']),num(r['known_d0']),num(r['no_d0']),num(r['d0_apply']),num(r['unknown_d0']),pct(r['ppv_no_d0'])] for r in weeks])+
 table(['获额日','可判候选','实际当天未提单','实际当天提单','未知','当天未提单命中率'],[[r['date'],num(r['known_d0']),num(r['no_d0']),num(r['d0_apply']),num(r['unknown_d0']),pct(r['ppv_no_d0'])] for r in days]))))

body.append(section('production','五、执行流程与代码',
 '<div class="runflow"><div><b>1　准备历史特征</b><p>预先汇总借款、还款与行为特征；数据截止点固定在本次获额时刻。</p></div><div><b>2　获额通过触发评分</b><p>补入本次额度等信息，调用冻结V4，保存pD0、pD3、输入快照和评分时间。</p></div><div><b>3　核验实时链路</b><p>核对数据是否到达、评分是否在提单前完成、用户资格是否有效；关键源缺失或用户已提单时不发优惠。</p></div><div><b>4　验证优惠效果</b><p>实时链路验收通过后，按用户固定随机分组，开展小流量优惠对照测试，核算提单增量、成本、风险和盈利。</p></div></div>'+
 call('<strong>权限与证据边界：</strong>本次没有部署评分服务、改变生产系统或发放优惠。历史验证证明筛选能力；优惠能否提高提单并保持盈利，当前没有对照试验结论，不能写成已证实。')+
 '<span id="methods" class="anchor"></span><h3>附录：复原报告代码</h3>'+
 f'<p><a class="button" href="{zip_name}">下载完整SQL / Python与统计依据</a></p>'+
 note('模型版本t0_timing_v4_20261008保持不变；本次仅精简展示，统计数据及规则均保持不变。全部SQL使用独立批次的授权输入表，不附实际用户或订单清单。')+
 fold('查看完整代码、原始汇总与扩展检验', '__CODE_APPENDIX__')))
source_paths=[
 ROOT/'work/t0_v4_validation_20261024_20261025/evaluation/labels_evaluated.parquet',
 ROOT/'work/t0_offer_strategy_20261025/model_targeting.json',
 ROOT/'work/t0_risk410_lifecycle_strategy_20261025/prediction_profiles.json',
 ROOT/'work/t0_risk410_lifecycle_strategy_20261025/cells.csv']
sourcetable=table(['依据','作用','SHA256（前16位）'],[[e(str(x.relative_to(ROOT))),['事件预测与可判标签','原候选计数与区间','410筛选及其基线','事件级利润背景'][i],hashlib.sha256(x.read_bytes()).hexdigest()[:16]] for i,x in enumerate(source_paths)])
codepaths=[W/'prepare_release_sql.py',W/'analyze_business_reliability.py',W/'make_business_examples.py',W/'build_production_readiness.py',W/'build_business_report.py',
 ROOT/'work/t0_v4_validation_20261024_20261025/build_features_replay.py',ROOT/'work/t0_v4_validation_20261024_20261025/score_and_assemble.py',ROOT/'work/t0_v4_validation_20261024_20261025/evaluate_validation.py',
 ROOT/'work/t0_offer_strategy_20261025/analyze_model_targeting.py',ROOT/'work/t0_risk410_lifecycle_strategy_20261025/analyze_prediction_profiles.py',ROOT/'work/t0_risk410_lifecycle_strategy_20261025/sql/strict_t0_risk410_lifecycle_global.sql']
# Original extraction SQL is included without rewriting its validated logic.
sqlpaths=sorted((ROOT/'work/t0_v4_validation_20261024_20261025/sql').glob('*.sql'))
release_root=W/'release_sql'
allcode=list(dict.fromkeys(codepaths+sqlpaths))
allcode=[release_root/x.relative_to(ROOT/'work') if x.suffix=='.sql' else x for x in allcode]
assert all(x.exists() for x in allcode), 'Missing parameterized release SQL'
allcode=[release_root/'00_release_input_tables.sql']+allcode
codebody=''.join(f'<details class="code"><summary>{e(str(x.relative_to(ROOT/"work")))}</summary><pre><code>{e(x.read_text())}</code></pre></details>' for x in allcode)

extra=table(['项目','本次结果'],[
 ['V4当天AUC / D3 AUC','0.8196 / 0.8028（同8,717次可判主样本）'],
 ['D7扩展样本','10月9—17日的2,739次候选，2,708次可判，31次未知'],
 ['D7可判结果','D0提单381次；D1—D3提单499次；D4—D7提单327次；到D7仍未提单1,501次'],
 ['D4—D7提单比例 / D7仍未提单比例','327÷2,708＝12.08%；1,501÷2,708＝55.43%，不能用主样本3,656作分母']])
code_appendix=fold('数据来源与扩展检验',sourcetable+extra)+fold(f'{len(allcode)}个完整代码文件',codebody)
body=[s.replace('__CODE_APPENDIX__',code_appendix) for s in body]

css='*{box-sizing:border-box}html{scroll-behavior:smooth;scroll-padding-top:110px}body{margin:0;background:#0b1220;color:#dbe5f1;font-family:-apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei",sans-serif;font-size:16px;line-height:1.85}header{padding:42px 24px 24px;text-align:center;background:linear-gradient(125deg,#111f36,#0d1729)}h1{color:#f8fafc;font-size:31px;letter-spacing:.7px;margin:0 0 12px}header p{margin:3px;color:#94a3b8}.nav{position:sticky;top:0;z-index:20;display:flex;justify-content:center;gap:4px;flex-wrap:wrap;padding:12px;background:rgba(11,18,32,.97);border-bottom:1px solid #2b3c54;backdrop-filter:blur(12px)}.nav a{padding:6px 13px;border-radius:5px;text-decoration:none;font-size:14px}.nav a:hover{background:#20314b}main{max-width:1240px;margin:auto;padding:12px 28px 60px}section{scroll-margin-top:100px;margin-top:28px;padding:26px 28px;background:#111c2e;border:1px solid #29374c;border-radius:12px}h2{font-size:23px;color:#f1f5f9;margin:0 0 18px}h3{font-size:18px;color:#f1f5f9;margin:22px 0 12px}p{margin:14px 0}strong{color:#f1f5f9}a{color:#7dd3fc}.callout{border-left:4px solid #38bdf8;padding:15px 20px;background:#14283e;border-radius:4px;margin:18px 0}.cards{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px;margin:24px 0}.card{padding:18px 16px;background:#18263b;border:1px solid #31435d;border-radius:9px;display:flex;flex-direction:column}.card span{font-size:14px;color:#a7b8ce}.card strong{font-size:32px;line-height:1.3;color:#6ee7b7;margin:5px 0}.card small{font-size:12px;color:#9aadc4}.red{color:#fb7185!important}.note{font-size:13px;color:#97abc3;line-height:1.8}figure{margin:24px 0 12px;background:#0d1728;border:1px solid #29394f;border-radius:10px;padding:10px 14px}figure h3{padding:0 8px;margin:10px 0 0}svg{width:100%;height:auto;display:block}svg text{font-size:16px;font-family:inherit}details{margin:16px 0;border:1px solid #30415a;border-radius:7px;background:#0e192b}summary{cursor:pointer;padding:12px 16px;color:#a9dff7;font-weight:600}details[open]>summary{border-bottom:1px solid #2b3c53}.scroll{overflow:auto;padding:4px 14px 12px}table{width:100%;border-collapse:collapse;font-size:14px;white-space:normal}th,td{padding:12px 13px;vertical-align:top;text-align:left;border-bottom:1px solid #29394f}th{background:#17283f;color:#d1e5f9;font-weight:600}td{color:#c5d1e0}tr:last-child td{border-bottom:0}details p{padding:0 16px}.steps{padding-left:26px}.steps li{padding:0 0 15px 5px}.button{display:inline-block;padding:9px 16px;border:1px solid #3a7597;background:#14354a;border-radius:6px;text-decoration:none}pre{max-height:540px;overflow:auto;white-space:pre;font-size:12px;line-height:1.65;padding:18px;color:#b9cde2}.code{margin:10px 14px}.code summary{font-size:12px;word-break:break-word}footer{text-align:center;color:#7e93af;font-size:12px;padding:25px}@media(max-width:800px){h1{font-size:24px}.cards{grid-template-columns:repeat(2,1fr)}main{padding:0 12px 30px}section{padding:20px 16px}h2{font-size:20px}.nav{gap:0;padding:6px}.nav a{padding:4px 7px;font-size:12px}figure{overflow:auto}figure svg{min-width:690px}.scroll table{min-width:650px}html{scroll-padding-top:120px}}.decisions{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:14px}.decision{padding:18px;background:#18283d;border-radius:9px;border-top:3px solid #34d399}.decision.no{border-color:#fb7185}.decision>span{font-weight:700;color:#6ee7b7;font-size:22px}.decision.no>span{color:#fb7185}.decision h3{margin:5px 0 10px}.decision p{font-size:14px;margin:0}.definitions{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:14px;margin:20px 0}.definition{background:#14243a;border:1px solid #2d425d;border-radius:8px;padding:17px 20px}.definition h3{font-size:16px;margin:0 0 5px}.definition>strong{font-size:29px;color:#6ee7b7;line-height:1.35}.formula{font-size:15px;color:#b8d9f3;font-variant-numeric:tabular-nums}.definition p{font-size:13px;margin:6px 0 0;line-height:1.75}.flow{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:10px;margin:18px 0}.flow>div{padding:14px;background:#102336;border:1px solid #31516b;border-radius:8px;text-align:center}.flow strong,.flow small{display:block}.flow strong{font-size:23px;margin:3px 0}.flow small{font-size:12px;color:#9bb1cb}.scope-grid,.runflow{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}.scope-grid>div,.runflow>div{padding:14px 17px;background:#142338;border-radius:7px}.scope-grid h3{font-size:16px;margin:0 0 7px}.scope-grid p,.runflow p{margin:0;font-size:14px}.runflow b{display:block;color:#b6e7fb;margin-bottom:7px}.rule{padding:12px 16px;background:#14283b;border-radius:6px}.anchor{display:block;scroll-margin-top:110px}@media(max-width:800px){.decisions,.flow,.scope-grid,.runflow{grid-template-columns:1fr}.definitions{grid-template-columns:1fr}.definition>strong{font-size:27px}.flow strong{font-size:21px}}'

report='<!DOCTYPE html><html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>T0模型V4：预测效果与使用结论</title><style>'+css+'</style></head><body><header><h1>T0提单意愿模型V4：预测效果与使用结论</h1><p>可以筛选候选；当前不可以直接全量自动发放优惠</p><p class="note">更新：2026年10月26日 · 数据截至2026年10月24日</p></header><nav class="nav" aria-label="报告目录">'+''.join(f'<a href="#{id}">{title}</a>' for id,title in nav)+'</nav><main>'+''.join(body)+'</main><footer>真实历史数据 · 事件口径 · 模型冻结 · 统计结果保持不变</footer></body></html>'
soup=BeautifulSoup(report,'html.parser')
for t in soup.select('table'):
 if not t.find_parent('details'):
  container=t.find_parent('div',class_='scroll');holder=soup.new_tag('details');summary=soup.new_tag('summary');summary.string='查看明细';holder.append(summary);container.wrap(holder)
report=str(soup)
(O/report_name).write_text(report)
# Deliver aggregate snapshots and code only. Never bundle raw event/user records or connection files.
readme='''T0模型V4业务实测与使用结论（2026-10-26）
报告图表使用截至2026-10-24既有冻结数据，本次无数据库查询、重训、部署或优惠发放。
1. 与本ZIP同目录交付的HTML可离线打开；报告内可直接下载相邻ZIP。
2. aggregates/保存完整统计结果与区间。计数按T0事件，重复用户保留；未知标签不补零。
3. code/为完整SQL/Python，不截取代码片段。发布SQL将原用户/订单/锚点清单参数化为不同batch_key的授权输入表，不改变其余计算逻辑；先查看inputs/00_发布SQL输入表说明.txt、输入DDL和清单哈希，必须填回原范围冻结输入，不同批次不能混用。原取数依赖授权数据库，连接配置不包含在包中；原模型和逐用户Parquet不打包。SQL与源统计代码可在原工作目录按依赖执行；复用汇总JSON可以直接运行报告构建脚本复原展示。脚本中默认工作区为本用户原路径，迁移时修改ROOT及上游路径。
4. 原始冻结标签和410映射的SHA256见manifest.json。无原明细/模型/环境时，不能只凭汇总JSON重新证明预测准确性；可以复核和复原此报告的展示。
5. 名单规则pD3<0.5；pD3为D0至D3四个自然日期累计提单概率，非72小时。85.97%是可判候选中D0未提单的比例。候选完整覆盖3,701/8,866；准确性3,143/3,656；45未知保留。
6. 新脚本依据固定规则和固定汇总复原，候选阈值表为描述性比较，未在测试集重训或自动优化阈值。
7. profit背景是当前回款账面收益，非优惠后的因果净利润，资金快照沿用原报告而非10月26日新取数。
'''
(W/'复现说明.txt').write_text(readme)
files={}
for x in allcode: files['code/'+str(x.relative_to(ROOT/'work'))]=x
for name in ['business_reliability_metrics.json','business_examples.json','production_readiness.json','business_reliability_qa.json']:
 x=W/name
 if x.exists():files['aggregates/'+x.name]=x
for x in W.glob('*.csv'): files['aggregates/'+x.name]=x
for name in ['prediction_profiles.json','prediction_profiles.csv','prediction_profiles_qa.json','cells.csv','quality.json']:
 x=ROOT/'work/t0_risk410_lifecycle_strategy_20261025'/name
 if x.exists():files['aggregates/context/'+name]=x
files['README.txt']=W/'复现说明.txt'
for name in ['release_sql_manifest.json','release_sql_qa.json']:
 x=W/name
 if x.exists():files['inputs/'+name]=x
for x in release_root.glob('*.txt'):files['inputs/'+x.name]=x
manifest={'generated_date':'2026-10-26','model':'t0_timing_v4_20261008','source_cutoff_exclusive':'2026-10-25 00:00:00 America/Belize','files':{k:{'bytes':v.stat().st_size,'sha256':hashlib.sha256(v.read_bytes()).hexdigest()} for k,v in files.items()},'private_sources_not_in_zip':{str(x.relative_to(ROOT)):hashlib.sha256(x.read_bytes()).hexdigest() for x in source_paths}}
with zipfile.ZipFile(O/zip_name,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for k,v in files.items():z.write(v,k)
 z.writestr('manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2))
(W/'report_manifest.json').write_text(json.dumps({'html':str(O/report_name),'zip':str(O/zip_name),'charts':CHARTS,'code_files':len(allcode),'main_counts':{k:main[k] for k in ['known_d0','no_d0','d0_apply','ppv_no_d0','complete_all_candidates']},'report_revised_in_place':True,'previous_version_backed_up':True},ensure_ascii=False,indent=2))
print(json.dumps({'html':str(O/report_name),'bytes':(O/report_name).stat().st_size,'zip':str(O/zip_name),'zip_bytes':(O/zip_name).stat().st_size,'charts':len(CHARTS),'code_files':len(allcode)},ensure_ascii=False))
