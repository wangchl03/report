"""Business-facing reliability replay of frozen T0 V4, no DB and no training.

Prespecified thresholds and fixed same-volume ranking are descriptive diagnostics.
Actual applications are observed under historical policy, not untreated potential
outcomes. Unknown labels stay unknown; candidate counts never require outcomes.
"""
from __future__ import annotations
import os
os.environ.setdefault('OPENBLAS_NUM_THREADS','2')
os.environ.setdefault('OMP_NUM_THREADS','2')
from pathlib import Path
import hashlib,json
import numpy as np
import pandas as pd

ROOT=Path(__file__).resolve().parent
V=ROOT.parent/'t0_v4_validation_20261024_20261025'
SEED=20261025
B=500


def clean(x):
    if isinstance(x,dict):return {str(k):clean(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [clean(v) for v in x]
    if isinstance(x,np.integer):return int(x)
    if isinstance(x,(float,np.floating)):return float(x) if np.isfinite(x) else None
    if isinstance(x,(pd.Timestamp,np.datetime64)):return str(x)
    return x


def ratio(a,b):
    a,b=np.asarray(a,float),np.asarray(b,float)
    return np.divide(a,b,out=np.full_like(b,np.nan),where=b>0)


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def ncount(x):
    f=float(x)
    return int(round(f)) if abs(f-round(f))<1e-8 else f


def make_rules(common):
    rules=[{'rule':f'pD0_lt_{i/10:.1f}','score':'p_v4_d0','threshold':i/10,'kind':'probability_threshold'} for i in range(1,6)]
    rules +=[{'rule':f'pD3_lt_{i/10:.1f}','score':'p_v4_d3','threshold':i/10,'kind':'probability_threshold'} for i in range(2,6)]
    n=int((common.p_v4_d3<.5).sum());p=common.p_v4_d0.to_numpy()
    boundary=float(np.partition(p,n-1)[n-1]);less=int((p<boundary).sum());ties=int((p==boundary).sum())
    rules.append({'rule':'low_pD0_same_volume_as_pD3_lt_0.5','score':'p_v4_d0','threshold':boundary,
       'kind':'same_volume_fixed_boundary','boundary_tie_fraction':float((n-less)/ties),
       'same_volume_events_common_cohort':n,'boundary_tie_events_common':ties,
       'definition':'Boundary fitted only to equal pD3<0.5 event count in common8717; equal score ties get equal expected quota. Same boundary/fraction then applied unchanged to full8866 and supplemental dates.'})
    return rules


def selection(d,r):
    p=d[r['score']].to_numpy(float);t=r['threshold']
    s=(p<t).astype(float)
    if r['kind']=='same_volume_fixed_boundary':s[p==t]=r['boundary_tie_fraction']
    return s


def vectors(d,s):
    y0=d.y_d0.to_numpy(float);y3=d.y_d3.to_numpy(float)
    k0=np.isfinite(y0);k3=np.isfinite(y3)
    return {
      'full_scored_events':np.ones(len(d)),
      'cohort_d0_known':k0,'cohort_d0_unknown':~k0,'cohort_no_d0':y0==0,'cohort_d0_apply':y0==1,
      'cohort_d3_known':k3,'cohort_d3_unknown':~k3,'cohort_no_d3':y3==0,'cohort_d3_apply':y3==1,
      'all_candidates':s,'known_d0':s*k0,'unknown_d0':s*~k0,
      'no_d0':s*(y0==0),'d0_apply':s*(y0==1),
      'd3_known':s*k3,'d3_unknown':s*~k3,'d3_noapply':s*(y3==0),'d3_apply':s*(y3==1),
      'd1_d3_apply':s*(y0==0)*(y3==1),
      'd0_classifier_tn':s*(y0==0),'d0_classifier_fn':s*(y0==1),
      'd0_classifier_fp':(1-s)*(y0==0),'d0_classifier_tp':(1-s)*(y0==1),
      'd3_classifier_tn':s*(y3==0),'d3_classifier_fn':s*(y3==1),
      'd3_classifier_fp':(1-s)*(y3==0),'d3_classifier_tp':(1-s)*(y3==1),
    }


def metrics(c):
    pairs={
      'full_candidate_coverage':('all_candidates','full_scored_events'),
      'evaluable_candidate_coverage':('known_d0','cohort_d0_known'),
      'ppv_no_d0':('no_d0','known_d0'),
      'd0_apply_fraction_known_candidates':('d0_apply','known_d0'),
      'npv_d3':('d3_noapply','d3_known'),
      'd1_d3_apply_fraction_known_d3_candidates':('d1_d3_apply','d3_known'),
      'd0_nonapply_capture':('no_d0','cohort_no_d0'),
      'baseline_no_d0':('cohort_no_d0','cohort_d0_known'),
      'baseline_no_d3':('cohort_no_d3','cohort_d3_known'),
    }
    m={k:ratio(c[a],c[b]) for k,(a,b) in pairs.items()}
    m['observed_d0_apply_per_100_known_candidates']=100*m['d0_apply_fraction_known_candidates']
    m['ppv_no_d0_lift_vs_baseline_pp']=100*(m['ppv_no_d0']-m['baseline_no_d0'])
    m['d0_classification_accuracy']=ratio(c['d0_classifier_tn']+c['d0_classifier_tp'],c['cohort_d0_known'])
    m['d3_classification_accuracy']=ratio(c['d3_classifier_tn']+c['d3_classifier_tp'],c['cohort_d3_known'])
    m['d0_majority_class_accuracy_baseline']=np.maximum(m['baseline_no_d0'],1-m['baseline_no_d0'])
    m['d3_majority_class_accuracy_baseline']=np.maximum(m['baseline_no_d3'],1-m['baseline_no_d3'])
    # Worst/best-case identification bounds, distinct from statistical CIs.
    m['all_candidate_no_d0_identification_lower']=ratio(c['no_d0'],c['all_candidates'])
    m['all_candidate_no_d0_identification_upper']=ratio(c['no_d0']+c['unknown_d0'],c['all_candidates'])
    m['all_candidate_d0_apply_per_100_identification_lower']=100*ratio(c['d0_apply'],c['all_candidates'])
    m['all_candidate_d0_apply_per_100_identification_upper']=100*ratio(c['d0_apply']+c['unknown_d0'],c['all_candidates'])
    return m


def evaluate(d,rules,cohort_name):
    codes,users=pd.factorize(d.user_id,sort=True);u=len(users)
    rng=np.random.default_rng(SEED);boot=rng.multinomial(u,np.full(u,1/u),size=B)
    result=[];resampled={}
    for r in rules:
        s=selection(d,r);vs=vectors(d,s);keys=list(vs)
        point_counts={k:float(np.sum(vs[k])) for k in keys};point=metrics(point_counts)
        user_matrix=np.column_stack([np.bincount(codes,weights=vs[k],minlength=u) for k in keys])
        z=boot@user_matrix;bs=metrics({k:z[:,i] for i,k in enumerate(keys)})
        row={'cohort':cohort_name,**r,**{k:ncount(v) for k,v in point_counts.items()},
          'full_scored_users':u,'all_candidate_users':int(d.loc[s>0,'user_id'].nunique()),
          'known_candidate_users':int(d.loc[(s>0)&d.y_d0.notna().to_numpy(),'user_id'].nunique()),
          'candidate_users_count_status':'Exact' if set(np.unique(s)).issubset({0,1}) else 'Users with positive tie quota; event counts use expected allocation',
          **{k:float(v) for k,v in point.items()}}
        for k,v in bs.items():
            finite=np.asarray(v)[np.isfinite(v)]
            row[k+'_ci95_low']=float(np.quantile(finite,.025)) if len(finite) else None
            row[k+'_ci95_high']=float(np.quantile(finite,.975)) if len(finite) else None
            row[k+'_bootstrap_valid']=len(finite)
        row['sparse_zero_observed_d0_error_warning']=bool(point_counts['known_d0']>0 and point_counts['d0_apply']==0)
        result.append(row);resampled[r['rule']]=bs
    return result,resampled


def flows(d,name):
    return {'cohort':name,'events':len(d),'users':int(d.user_id.nunique()),
      **{f'{h}_mature':int(d[f'mature_{h}'].sum()) for h in ['d0','d3','d7']},
      **{f'{h}_known':int(d[f'y_{h}'].notna().sum()) for h in ['d0','d3','d7']},
      **{f'{h}_unknown':int(d[f'y_{h}'].isna().sum()) for h in ['d0','d3','d7']},
      'date_start':str(d.offer_date.min()),'date_end':str(d.offer_date.max())}


def d7_composition(d):
    z=d[d.p_v4_d3<.5].copy()
    y0=z.y_d0.to_numpy(float);y3=z.y_d3.to_numpy(float);y7=z.y_d7.to_numpy(float)
    categories={
      'D0':y0==1,
      'D1_D3':(y0==0)&(y3==1),
      'D4_D7':(y3==0)&(y7==1),
      'NO_APPLY_THROUGH_D7':y7==0,
      'UNKNOWN':~np.isfinite(y7),
    }
    assert np.array(list(categories.values())).sum(axis=0).min()==1
    assert np.array(list(categories.values())).sum(axis=0).max()==1
    codes,users=pd.factorize(z.user_id,sort=True);u=len(users);rng=np.random.default_rng(SEED)
    boots=rng.multinomial(u,np.full(u,1/u),size=B)
    total_bs=boots@np.bincount(codes,minlength=u)
    known_bs=boots@np.bincount(codes,weights=np.isfinite(y7),minlength=u)
    rows=[]
    for key,mask in categories.items():
        n=int(mask.sum());num_bs=boots@np.bincount(codes,weights=mask,minlength=u)
        allshares=ratio(num_bs,total_bs);knownshares=ratio(num_bs,known_bs)
        row={'bucket':key,'events':n,'users':int(z.loc[mask,'user_id'].nunique()),
          'all_candidates':len(z),'known_d7_candidates':int(np.isfinite(y7).sum()),
          'share_all_candidates':n/len(z),'share_all_candidates_ci95_low':float(np.nanquantile(allshares,.025)),
          'share_all_candidates_ci95_high':float(np.nanquantile(allshares,.975)),
          'share_known_d7_candidates':n/np.isfinite(y7).sum() if key!='UNKNOWN' else None,
          'share_known_d7_candidates_ci95_low':float(np.nanquantile(knownshares,.025)) if key!='UNKNOWN' else None,
          'share_known_d7_candidates_ci95_high':float(np.nanquantile(knownshares,.975)) if key!='UNKNOWN' else None}
        rows.append(row)
    nlate=int(categories['D4_D7'].sum());n3zero=int((y3==0).sum());unknownafter3=int(((y3==0)&~np.isfinite(y7)).sum())
    return {'cohort_flow':flows(d,'D7_mature_20261009_20261017'),'selected_candidates':len(z),
      'selected_users':u,'known_d7_candidates':int(np.isfinite(y7).sum()),'unknown_d7_candidates':int((~np.isfinite(y7)).sum()),
      'rows':rows,'actual_d3_nonapply_candidates':n3zero,'actual_d3_nonapply_then_d4_7_apply':nlate,
      'actual_d3_nonapply_d7_unknown':unknownafter3,
      'd4_7_apply_share_of_actual_d3_nonapply_known_d7':nlate/(n3zero-unknownafter3) if n3zero>unknownafter3 else None,
      'interpretation':'Low predicted D3 application selects non-application propensity through D3; it does not predict that these people will apply after D3. D4-D7 actual application, D7 non-application and unknown remain separate.'}


def main():
    input_pred=V/'events_predictions.parquet';input_labels=V/'evaluation/labels_evaluated.parquet'
    p=pd.read_parquet(input_pred);d=pd.read_parquet(input_labels)
    a=p.set_index('event_id').sort_index();b=d.set_index('event_id').sort_index()
    for k in ['user_id','as_of_time','p_v4_d0','p_v4_d3']:np.testing.assert_equal(a[k].to_numpy(),b[k].to_numpy())
    full=d[(d.offer_date>='2026-10-09')&(d.offer_date<='2026-10-21')].copy()
    common=full[full.mature_d3&full.y_d3.notna()].copy()
    quality=d[(d.offer_date>='2026-10-09')&(d.offer_date<='2026-10-23')].copy()
    d7=d[(d.offer_date>='2026-10-09')&(d.offer_date<='2026-10-17')].copy()
    assert len(full)==8866 and len(common)==8717
    assert quality.mature_d0.all() and d7.mature_d7.all()
    rules=make_rules(common)
    rows_main,bs=evaluate(common,rules,'common_D3_mature_known_8717')
    rows_full,_=evaluate(full,rules,'full_D3_mature_scored_8866')
    rows_quality,_=evaluate(quality,rules,'D0_mature_exclude_oct24_20261009_20261023')
    # Main fairness and complete-candidate disclosure side by side, never swap denominators.
    full_lookup={x['rule']:x for x in rows_full}
    for r in rows_main:
        r['complete_scored_event_count']=len(full)
        r['complete_all_candidates']=full_lookup[r['rule']]['all_candidates']
        r['complete_all_candidate_users']=full_lookup[r['rule']]['all_candidate_users']
        r['complete_unknown_d0']=full_lookup[r['rule']]['unknown_d0']
        r['complete_candidate_coverage']=full_lookup[r['rule']]['full_candidate_coverage']
        assert abs(r['known_d0']-full_lookup[r['rule']]['known_d0'])<1e-8
    primary=next(x for x in rows_main if x['rule']=='pD3_lt_0.5')
    assert primary['all_candidates']==3656 and primary['no_d0']==3143 and primary['d0_apply']==513
    pairs=[];anchor='pD3_lt_0.5';lookup={x['rule']:x for x in rows_main}
    for rule in ['pD0_lt_0.5','low_pD0_same_volume_as_pD3_lt_0.5']:
        for metric in ['ppv_no_d0','observed_d0_apply_per_100_known_candidates','d0_classification_accuracy','npv_d3']:
            delta=bs[rule][metric]-bs[anchor][metric]
            multiplier=1 if metric.startswith('observed_') else 100
            pairs.append({'rule':rule,'reference':anchor,'metric':metric,
              'difference_rule_minus_reference_pp_or_per100':multiplier*(lookup[rule][metric]-lookup[anchor][metric]),
              'paired_ci95_low':float(np.nanquantile(multiplier*delta,.025)),
              'paired_ci95_high':float(np.nanquantile(multiplier*delta,.975)),
              'unit':'per100_known_candidates' if multiplier==1 else 'percentage_points'})
    daily=[];weekly=[]
    consistency_rules=[r for r in rules if r['kind']=='probability_threshold']
    for date,z in quality.groupby('offer_date',sort=True):
        result,_=evaluate(z,consistency_rules,'daily_D0_mature_quality')
        for r in result:r['date']=str(date.date());r['D3_mature_date']=bool(z.mature_d3.all())
        daily.extend(result)
    for week,z in quality.groupby('offer_week',sort=True):
        result,_=evaluate(z,consistency_rules,'weekly_D0_mature_quality')
        for r in result:r['week_start']=str(week);r['observed_date_start']=str(z.offer_date.min().date());r['observed_date_end']=str(z.offer_date.max().date());r['D3_fully_mature_week']=bool(z.mature_d3.all())
        weekly.extend(result)
    comp=d7_composition(d7)
    old=json.loads((ROOT.parent/'t0_offer_strategy_20261025/model_targeting.json').read_text())['headlines_at_threshold_0_5']['main_d3_mature_20261009_20261021']
    assert abs(primary['ppv_no_d0']-old['ppv_no_d0'])<1e-12
    assert abs(primary['ppv_no_d0_ci95_low']-old['ppv_no_d0_ci95_low'])<1e-12
    assert abs(primary['ppv_no_d0_ci95_high']-old['ppv_no_d0_ci95_high'])<1e-12
    result={
      'meta':{
        'model':'Frozen T0 application timing V4; no retraining/calibration/database query',
        'source_outcome_cutoff':'2026-10-25 00:00:00 America/Belize exclusive; outcomes through October24',
        'main':'Same8,717 D3-mature, label-known events dated October9-21 for all fair comparisons; complete8,866 scored events including149 unknown outcomes shown separately.',
        'supplement':'October9-23 D0-mature events, excluding all October24 scores because that day lacked risk source matches in prior audit. This exclusion does not prove every other historical feature was contemporaneously available.',
        'D0':'After passed T0 offer timestamp until next Belize midnight, not rolling24hours',
        'D3':'D0 through day3 end, event_date+4days exclusive; four natural dates, not rolling72hours',
        'D7':'D0 through day7 end, event_date+8days exclusive; main D7 cohort October9-17 only',
        'outcome':'First actual user application before next strict T0; not successful disbursement',
        'negative_prediction_rule':'p<cutoff; equality predicts application. Fixed probability grids are descriptive, not selected from these results for rollout.',
        'same_volume':'Exact3,656 expected event quota on common8,717 by ascending pD0. Equal-score boundary allocated equally; fixed boundary/fraction applied elsewhere. Not necessarily the same complete-candidate volume or supplemental coverage.',
        'main_accuracy':'ppv_no_d0 is actual D0 non-application among known selected candidates (NPV for application label). It is not full-population classification accuracy or incentive uplift.',
        'per100':'observed_d0_apply_per_100_known_candidates is100*(actual D0 applications / known candidates). These observed historical applications are a potential offer-leakage proxy, not a measured causal wasted-incentive rate.',
        'unknown':'Unknown/censored and administratively immature windows remain unknown. Full-candidate identification bounds are distinct from95% bootstrap confidence intervals.',
        'bootstrap':f'{B} percentile user-cluster replicates, seed{SEED}; repeated user events resampled together, paired rules share the same draws. Daily/weekly CIs are descriptive with no multiplicity-adjusted stability guarantee.',
        'daily_weekly':'Fixed gates on all D0-mature October9-23 dates; D3 metrics on later dates only use mature/known subsets and can be unavailable. Partial boundary weeks explicitly dated.',
        'classification':'Classification accuracy assumes selected candidates predict no application and all others predict application, separately measured for D0 and D3 known labels. Always-majority accuracy supplied; pD3 rule judged against D0 is a decision proxy, not a trained D0 classifier.',
        'evidence':'Retrospective replay, not verified contemporaneous online scoring, randomized incentive response, profitability proof, or production approval.',
      },
      'source_files':{str(input_pred):sha(input_pred),str(input_labels):sha(input_labels)},
      'rule_definitions':rules,
      'cohort_flow':[flows(full,'full8866'),flows(common,'common8717'),flows(quality,'D0_quality_supplement'),flows(d7,'D7_mature')],
      'rules_main':rows_main,'rules_complete_scored':rows_full,'rules_d0_quality_supplement':rows_quality,
      'paired_comparison':pairs,'consistency_daily':daily,'consistency_weekly':weekly,
      'd7_outcome_composition':comp,
      'reproduced_prior_main_85_97_and_interval':True,
    }
    for fname,rows in [('business_reliability_rules_main.csv',rows_main),('business_reliability_rules_full.csv',rows_full),('business_reliability_rules_d0_quality.csv',rows_quality),('business_reliability_daily.csv',daily),('business_reliability_weekly.csv',weekly),('business_reliability_pairs.csv',pairs),('business_reliability_d7_composition.csv',comp['rows'])]:
        pd.DataFrame(rows).to_csv(ROOT/fname,index=False)
    (ROOT/'business_reliability_metrics.json').write_text(json.dumps(clean(result),ensure_ascii=False,indent=2))
    print(json.dumps(clean({'rules_main':len(rows_main),'daily':len(daily),'weekly':len(weekly),'primary_pD3_0_5':primary,'D7_composition':comp}),ensure_ascii=False),flush=True)


if __name__=='__main__':main()
