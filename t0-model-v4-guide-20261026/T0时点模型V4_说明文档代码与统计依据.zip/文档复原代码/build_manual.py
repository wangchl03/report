"""Build the public, standalone T0 timing V4 model manual from frozen evidence."""
from pathlib import Path
from collections import Counter
import json,ast,html,hashlib,zipfile,csv,re,shutil
ROOT=Path('/Users/wangchuanliang/Documents/Codex/2026-10-18/wen')
W=ROOT/'work/t0_v4_model_manual_20261026'
OLD=ROOT/'work/t0_v4_business_reliability_20261026'
MODEL=Path('/Users/wangchuanliang/Documents/Codex/2026-09-21/ji-x/outputs/T0提单时点预测模型_V4')
OUT=ROOT/'outputs/T0提单时点模型V4_模型说明与实测效果_20261026'
OUT.mkdir(exist_ok=True)
HNAME='T0提单时点模型V4_完整说明与实测效果.html'
ZNAME='T0时点模型V4_说明文档代码与统计依据.zip'
FNAME='T0模型V4_完整特征字典.json'
A=json.loads((OLD/'model_architecture_intro.json').read_text())
F=json.loads((OLD/'model_features_intro.json').read_text())
Q=json.loads((W/'features_public.json').read_text())
D=json.loads((OLD/'business_reliability_metrics.json').read_text())
E=json.loads((OLD/'business_examples.json').read_text())
R=json.loads((ROOT/'work/t0_risk410_lifecycle_strategy_20261025/prediction_profiles.json').read_text())
main=next(r for r in D['rules_main'] if r['rule']=='pD3_lt_0.5')
high=next(r for r in R['rules'] if r['rule']=='LOWP_HIGH20')
assert Q['feature_count']==1930==sum(Q['family_counts'].values())
assert len(Q['features'])==len({r['name'] for r in Q['features']})==1930
assert dict(Counter(r['family'] for r in Q['features']))==Q['family_counts']
esc=html.escape
pct=lambda x:f'{x*100:.2f}%'
num=lambda x:f'{x:,}'
def table(headers,rows):
 return '<div class="scroll"><table><thead><tr>'+''.join('<th>'+str(h)+'</th>' for h in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+str(c)+'</td>' for c in row)+'</tr>' for row in rows)+'</tbody></table></div>'
def fold(label,body):return f'<details><summary>{label}</summary>{body}</details>'
def note(s):return '<p class="note">'+s+'</p>'
def box(s):return '<div class="callout">'+s+'</div>'
def section(id,title,body):return f'<section id="{id}"><h2>{title}</h2>{body}</section>'
def card(label,value,detail,cls=''):return f'<div class="card {cls}"><span>{label}</span><strong>{value}</strong><small>{detail}</small></div>'
CHARTS=[]
def bars(id,title,rows):
 left,span,right,width=310,510,1025,1060;top,step=45,48;height=top+step*len(rows)+24
 s=[f'<svg id="{id}" viewBox="0 0 {width} {height}" role="img" aria-label="{esc(title)}"><title>{esc(title)}</title>']
 for i,(label,value,color,display) in enumerate(rows):
  y=top+i*step
  s.extend([f'<text x="{left-18}" y="{y+5}" text-anchor="end" fill="#c9d7e7">{esc(label)}</text>',f'<rect x="{left}" y="{y-13}" width="{span}" height="24" rx="4" fill="#233249"/>',f'<rect x="{left}" y="{y-13}" width="{span*value:.4f}" height="24" rx="4" fill="{color}"/>',f'<text x="{right}" y="{y+5}" text-anchor="end" fill="#f8fafc" font-weight="700">{esc(display)}</text>'])
 s.append('</svg>');CHARTS.append({'id':id,'values':[v for _,v,_,_ in rows],'data_label_column':right,'bar_end_max':left+span})
 return '<figure><h3>'+title+'</h3>'+''.join(s)+'</figure>'
B=[]
# Business identity and limits are explicit; retrospective results are not projected guarantees.
B.append(section('overview','一、模型解决什么问题',
 box('<strong>在用户T0获额通过时，预测其首次提单发生的时间。</strong>模型使用获额前的借还款、产品和行为信息，输出D0、D3、D7、D15累计提单概率，用于低意愿候选筛选。')+
 '<div class="cards">'+card('实际输入列','1,930','多窗口、统计量、交互和编码展开后的字段')+card('共享LightGBM模型','838棵树','一个二分类器，四个预测区间共享')+card('基础候选当天未提单命中','85.97%','3,143 / 3,656次可判候选')+card('叠加410高分后的命中','90.69%','1,373 / 1,514次可判候选')+'</div>'+
 '<div class="tri"><div><b class="good">可以</b><strong>筛选低意愿候选</strong><p>历史实测有区分度，可以开展实时评分接入测试。</p></div><div><b class="bad">当前不可以</b><strong>直接全量自动发优惠</strong><p>实时供数、评分时效和资格尚未验收。</p></div><div><b class="bad">不能认定</b><strong>优惠已提高提单和利润</strong><p>本次检验没有随机优惠对照结果。</p></div></div>'+
 note('<b>T0纳入：</b>结清续贷获额通过；同日存在获额前使已放款在贷订单归零的结清，匹配最近一次结清。同用户相邻获额间隔≤20秒链式合并，保留链尾；不同T0事件分别计数。目标是用户后续首次实际提单，不限定同一订单号，不要求审核通过或放款。')))

intervals=[('D0','获额时刻—当天结束','当天首次提单'),('D1—D3','次日—第3日结束','此前未提单者在本段首次提单'),('D4—D7','第4日—第7日结束','此前未提单者在本段首次提单'),('D8—D15','第8日—第15日结束','此前未提单者在本段首次提单')]
outputrows=[['p_apply_d0 / pD0','当天累计','获额时刻到当天结束'],['p_apply_d3 / pD3','截至第3日累计','包含D0—D3，共4个自然日期'],['p_apply_d7 / pD7','截至第7日累计','包含D0—D7，共8个自然日期'],['p_apply_d15 / pD15','截至第15日累计','包含D0—D15，共16个自然日期']]
B.append(section('mechanism','二、模型如何计算',
 '<p>用一个LightGBM模型学习四个区间的<strong>条件首次提单概率</strong>，逐区间做sigmoid概率校准，再转换为累计概率。</p>'+
 '<div class="intervals">'+''.join(f'<div><b>{x}</b><strong>{y}</strong><p>{z}</p></div>' for x,y,z in intervals)+'</div>'+
 '<div class="formula">累计提单概率＝1－截至该阶段各区间“未提单概率”的连乘</div>'+
 box('<strong>计算示例（非真实个体）：</strong>当天提单概率20%；当天未提单者在D1—D3提单的概率30%。因此pD3＝20%＋80%×30%＝<strong>44%</strong>。')+
 '<p class="monotone">输出关系：<strong>pD0 ≤ pD3 ≤ pD7 ≤ pD15</strong>。所有窗口使用America/Belize业务时区。</p>'+
 fold('查看四个输出字段及概率定义',table(['输出字段 / 文中简称','预测目标','观察窗口'],outputrows)+note('pD3＜50%是短期低意愿候选规则，不等于预测第4日后一定提单。概率取0—1；0.35表示预测累计提单概率35%。'))+
 fold('查看技术结构与参数',table(['项目','冻结事实'],[
 ['算法','一个全局LightGBM LGBMClassifier，binary目标；838棵树'],['阶段输入','interval_id、interval_length、interval_start_day，共3列'],['校准','4个逐区间sigmoid校准器，基于历史样本外预测拟合'],['当前参数','num_leaves=63；max_depth=8；learning_rate=0.025；min_child_samples=200；reg_lambda=10；reg_alpha=0.1'],['产品表达','独立产品编码、未知产品/新组合和缺失标记；编码词表只用训练期拟合'],['实际模型','global共享模型；未采用借款2—3次独立专家']])+
 note('算法术语参见<a href="https://lightgbm.readthedocs.io/en/stable/">LightGBM官方说明</a>；校准概念参见<a href="https://scikit-learn.org/stable/modules/calibration.html">scikit-learn官方概率校准文档</a>。本模型的树数、字段与校准配置均由本地冻结文件核对。'))))

examples={
 '借还款、额度及历史交互':'借款次数、额度使用率、借还间隔、结清后再借、提前还款和额度变化。',
 '历史T0提单习惯':'过去获额后多久提单、历史各阶段提单率及近期变化。',
 '历史循环贷经历':'循环贷资格与提单经历、最近一次结果、连续未提单情况。',
 '产品条件与选择':'本次产品费用、利率、期限及相对上笔变化，历史产品选择。',
 'App行为':'活跃、进入提单页、金额操作、计划详情、确认等；含非还款日支路。',
 '风控分及缺失标记':'405、363模型分及缺失标记；不包含410分。',
 '预测阶段编码':'模型当前预测的区间编号、区间长度、区间起点。'}
search='''<details id="feature-browser"><summary>查询1,930个实际模型输入字段</summary><div class="feature-controls"><input id="feature-query" type="search" placeholder="搜索字段、释义或时间口径" aria-label="搜索特征"><select id="feature-family" aria-label="筛选特征类别"><option value="">全部类别</option>'''+''.join(f'<option>{esc(f)}</option>' for f in Q['family_counts'])+'''</select></div><p id="feature-status" class="note"></p><div id="feature-result" class="scroll"></div></details>'''
B.append(section('features','三、使用哪些特征',
 '<div class="feature-grid">'+''.join(f'<div><h3>{family}<span>{count}列</span></h3><p>{examples[family]}</p></div>' for family,count in Q['family_counts'].items())+'</div>'+
 note('合计1,930个实际输入列；同一个业务概念可展开成多个窗口、统计量或编码。字段保留不代表每列都有独立增量价值。')+
 '<div class="two"><div><h3>行为数据来源</h3><p><code>wangchuanliang.event_track_record</code>明细。冻结模型沿用其<code>create_time / create_date</code>口径，未使用<code>event_track</code>汇总表或新星途埋点表。</p></div><div><h3>区分还款与借款行为</h3><p>另建剔除实际还款日的行为支路。还款日按有效还款流水时间识别，降低还款进提单页对意愿判断的干扰。</p></div></div>'+
 fold('查看行为窗口和信息截止规则',table(['特征系列','准确时间口径'],[
 ['基础beh_events_1d / 3d / 7d','T0前滚动24 / 72 / 168小时，严格排除T0及之后'],['app_all_* / app_nonpay_*','含T0当日的1 / 3 / 7 / 14 / 30 / 60 / 90个Belize自然日；当日只取T0之前记录'],['app_*_1d','获额业务日零点至T0之前，不是过去滚动24小时'],['App可观察历史','从max(2024-01-01，注册日)起的可观察历史，不代表注册前或源表缺失期间行为'],['历史提单率','只用T0之前已成熟的历史获额观察窗口'],['字段可用性','发生时间截止T0是代码约束；部分迟报、后补与风控分历史可得时间尚未完成线上核验']]))+
 box('<strong>405、363是模型输入；410是评分后的外部筛选条件。</strong>410≥528来自此前全量T0有效分的第80百分位；基准中占20.17%，同分不拆。它是统计分组线，未被证明是最优投放门槛。')+
 search+note('查询仅展示字段定义，不含用户值。全部1,930列均匹配冻结开发字典；其中76列原释义较简略，本页保留原文。完整公式、时间约束见下载字典。')+
 f'<a class="button" href="{FNAME}">下载完整特征字典 JSON</a>'))

folds=A['training']['folds']
B.append(section('training','四、训练与检验如何进行',
 '<div class="cards three">'+card('训练期母样本','170,832次','2026年1月1日—8月15日T0事件')+card('实际参与拟合的事件','167,292次','另3,540次无可用观察区间，不参与拟合')+card('区间训练记录','358,661条','每个事件按仍未提单的区间展开')+'</div>'+
 '<div class="process"><div><b>时间滚动验证</b><p>6月、7月、8月滚动验证；训练与验证保留15天以上间隔。</p></div><div><b>选型与校准</b><p>累计Brier优先、AUC辅助；使用样本外预测拟合分段sigmoid校准。</p></div><div><b>冻结后再检验</b><p>版本t0_timing_v4_20261008保持冻结；本次10月检验不重训、不重校准。</p></div></div>'+
 box('<strong>标签处理：</strong>发生首次提单后，不再产生后续区间训练记录；下一次严格T0截断原观察窗口，无法判断的结果记未知，不填成未提单。')+
 fold('查看训练切分、版本和来源证据',table(['训练截止（不含）','验证日期'],[[r['train_end_exclusive'],r['validation']] for r in folds])+table(['项目','事实'],[
 ['训练事件日期','2026-01-01≤event_date＜2026-08-16'],['原训练结果观察','训练期事件的完整D15窗口最迟到8月31日'],['9月检验','9月1—9日为冻结后单独回顾留出；9月10—21日为旧版已多次查看的参考留出'],['模型冻结版本','t0_timing_v4_20261008；不能把模拟的9月1日可用条件写成9月实际已经上线'],['模型SHA256',A['model_identity']['sha256']]])+note('本页引用真实历史数据回放。它证明离线筛选效果；模型在获额当时的真实供数、时延和曝光仍需实时验收。'))))

# Original full-window metrics are supplementary; D0/D3 use the same 8,717 events here.
overall=list(csv.DictReader((ROOT/'work/t0_v4_validation_20261024_20261025/evaluation/overall.csv').open()))
rows4=[]
for h in [0,3,7,15]:
 if h in [0,3]:
  m=E['primary_metrics'][str(h)]['v4'];n=8717;pos=3441 if h==0 else 5055;date='10月9—21日'
 else:
  r=next(x for x in overall if x['cohort']=='main' and x['model']=='v4' and x['horizon']==str(h));m={k:float(r[k]) for k in ['auc','pr_ap','mean_prediction','actual_rate','brier']};n=int(r['n']);pos=int(r['positives']);date='10月9—17日' if h==7 else '仅10月9日'
 rows4.append({'horizon':h,'dates':date,'n':n,'positives':pos,**{k:m[k] for k in ['auc','pr_ap','mean_prediction','actual_rate','brier']}})
rank=E['primary_deciles']['0']['v4']
rankchart=bars('rank-chart','按当天提单概率排序：实际当天提单率',[
 ('预测最高10%档',rank[0]['actual_rate'],'#38bdf8',pct(rank[0]['actual_rate'])),('同一主样本整体',E['primary_metrics']['0']['v4']['actual_rate'],'#64748b',pct(E['primary_metrics']['0']['v4']['actual_rate'])),('预测最低10%档',rank[-1]['actual_rate'],'#34d399',pct(rank[-1]['actual_rate']))])
selectchart=bars('selection-chart','不同筛选条件下：实际当天未提单比例',[
 ('全部可判事件',main['baseline_no_d0'],'#64748b',pct(main['baseline_no_d0'])),('pD3＜50%候选',main['ppv_no_d0'],'#38bdf8',pct(main['ppv_no_d0'])),('410≥528，未加意愿筛选',high['baseline_d0_nonapply_eligible_known'],'#64748b',pct(high['baseline_d0_nonapply_eligible_known'])),('pD3＜50%且410≥528',high['ppv_no_d0'],'#34d399',pct(high['ppv_no_d0']))])
weeks=[r for r in D['consistency_weekly'] if r['rule']=='pD3_lt_0.5']
B.append(section('performance','五、真实预测效果',
 '<p><strong>主检验：</strong>10月9—21日8,866次评分事件，8,717次结果可判、149次未知。实际结果截至10月24日完整业务日；D0与D3主指标采用同一8,717次可判事件。</p>'+
 '<div class="cards">'+card('当天排序AUC','0.8196','同8,717次事件；不是81.96%准确率')+card('截至D3排序AUC','0.8028','同8,717次事件')+card('模型平均预测当天提单','38.84%','实际：3,441 / 8,717＝39.47%')+card('模型平均预测D3累计提单','56.44%','实际：5,055 / 8,717＝57.99%')+'</div>'+
 rankchart+note('同一8,717次事件按pD0排序，最高与最低各取精确10%预算，同分边界按权重分摊。每档871.7是事件权重，不是人数。均值接近实际不等于每个分档都完全准确。')+
 selectchart+note('上图分子/分母依次为5,276/8,717、3,143/3,656、1,622/2,044、1,373/1,514。四组重叠，不能相加。')+
 '<div class="metrics"><div><b>85.97%：名单准不准</b><p>3,143÷3,656；候选中当天确实未提单的比例。513次当天仍提单，占14.03%；45次未知不计入此分母。</p></div><div><b>41.74%：名单有多大</b><p>3,701÷8,866；完整候选占全部评分事件的比例，未知结果仍计入。</p></div><div><b>90.69%：叠加风险分后的命中</b><p>1,373÷1,514；完整候选1,532次，其中18次未知。完整名单比例1,532÷8,866＝17.28%。</p></div><div><b>59.57%：目标覆盖多少</b><p>3,143÷5,276；全部当天未提单事件中，模型覆盖3,143次，未覆盖2,133次。</p></div></div>'+
 box('<strong>可以确认：</strong>模型将当天未提单事件集中到候选名单。<strong>不能认定：</strong>85.97%是全体准确率或优惠转化率。基础候选D0—D3均未提单为2,488÷3,656＝<strong>68.05%</strong>，与当天未提单85.97%分别计算。')+
 '<div class="weekchips">'+''.join(f'<div><span>{r["observed_date_start"][5:]}—{r["observed_date_end"][5:]}</span><strong>{pct(r["ppv_no_d0"])}</strong><small>{num(r["known_d0"])}次可判候选</small></div>' for r in weeks)+'</div>'+
 note('分批补充采用10月9—23日D0成熟数据，与主样本重叠。固定pD3＜50%门槛，单日命中80.74%—90.23%；短期有效不能证明长期稳定。')+
 fold('查看四个窗口的效果、样本与统计口径',table(['窗口','获额日期','可判事件','实际提单次数','平均预测','实际提单率','AUC','PR-AP'],[[f'D{x["horizon"]}',x['dates'],num(x['n']),num(x['positives']),pct(x['mean_prediction']),pct(x['actual_rate']),f'{x["auc"]:.4f}',f'{x["pr_ap"]:.4f}'] for x in rows4])+note('D0/D3统一使用主样本；D7/D15展示成熟子集。D15只有10月9日805次可判事件，不能证明跨批稳定。各窗口只用可判结果计算；不将未成熟窗口填为未提单。AUC衡量排序区分度；PR-AP衡量提单正例排序，均不是普通分类准确率。')+
 table(['名单','完整候选','可判','D0未提单','D0提单','未知','命中率95%区间'],[['pD3＜50%','3,701','3,656','3,143','513','45','84.83%—86.97%'],['再要求410≥528','1,532','1,514','1,373','141','18','89.26%—92.10%']])+note('区间按用户聚类bootstrap 500次，保留同用户多事件关系，不能视为下一批保证。完整规则：候选pD3＜0.5；高分固定410≥528。未知由下一T0截断等原因导致可判不足，不补零。')+
 table(['同容量比较','可判候选数','当天未提单命中'],[['pD3＜50%','3,656','85.97%'],['pD0从低到高同样选3,656次','3,656','86.05%']])+note('相差0.08个百分点，配对95%差值区间−0.47至＋0.63个百分点，不能认定一方更优。'))))

B.append(section('use','六、如何使用与验收',
 '<div class="process four"><div><b>1　准备特征</b><p>按冻结字典汇总获额前数据；严格保留时间口径与缺失标记。</p></div><div><b>2　获额触发评分</b><p>补入本次条件，调用冻结模型，保存四个累计概率和生成时刻。</p></div><div><b>3　先验收实时链路</b><p>记录当时实际可得输入、源水位、评分时延及资格；已提单或关键源缺失不发优惠。</p></div><div><b>4　再做优惠对照</b><p>通过验收后按用户固定随机分组，分别核算提单增量、优惠成本、风险与成熟收益。</p></div></div>'+
 box('<strong>当前执行边界：</strong>可以做候选筛选与实时接入测试。实时数据、评分时效、资格验收前，不直接全量自动发优惠；本次没有部署生产服务或发放优惠。')+
 fold('查看评分输入输出与上线记录要求',table(['内容','要求'],[
 ['输入身份与锚点','业务用户ID、20秒去重后的T0事件ID、America/Belize获额通过时点'],['模型输入','按冻结工程生成的数值矩阵及产品/类别信息；保持字段、顺序、编码与缺失处理一致'],['实际概率输出','p_apply_d0、p_apply_d3、p_apply_d7、p_apply_d15；范围0—1且单调不减'],['生产记录','输入快照、源到达水位、模型版本/哈希、评分开始结束时间、用户是否已提单、资格与拟曝光时间'],['候选规则','使用原始累计概率pD3＜0.5；410≥528是额外条件，不替代风控审批'],['策略评估','固定优惠前的原T0锚点；同一用户固定组别，政策引发下一T0不重置实验起点']]))))

faq=[
 ('业务介绍时怎么说？','本模型在T0获额时，利用用户既有借还款与行为信息，预测首次提单时间；历史检验证实它能筛出当天不提单候选，实时链路通过验收后用于小流量优惠对照测试。'),
 ('1,930列是否代表1,930种信息？','不是。它包含同一业务概念的多个时间窗、统计量、交互、产品编码和三个阶段输入。字段数量不等于独立信息量。'),
 ('可以把410说成模型内部特征吗？','不可以。内部风控分是405和363，410用于评分后的外部分组。410≥528定义此前基准中的最高约20%分组，不是已证最优收益阈值。'),
 ('能把数据换成新星途埋点直接评分吗？','不能直接替换。冻结模型使用event_track_record及原窗口；换源须重新验证字段含义、分布、可得时点和评分效果。'),
 ('85.97%能保证以后每批都达到吗？','不能。它是本批真实历史候选的命中率；逐日有波动，线上数据可得性与时延尚未完成验收。'),
 ('模型能证明降息提额提高利润吗？','不能。当前是提单时点预测模型，不是优惠增量收益模型；必须通过真实随机对照核算。')]
# The existing public release is reused only as reviewed source code and aggregates.
oldzip=ROOT/'outputs/T0提单意愿模型V4_业务实测与上线建议_20261026/T0模型V4业务实测_完整代码与统计依据.zip'
entries={}
with zipfile.ZipFile(oldzip) as z:
 for n in z.namelist():
  if n=='manifest.json':continue
  entries['原验证复原/'+n]=z.read(n)
core_names=['model_v4.py','train_v4.py','train_parallel.py','product_features.py','build_product_features.py','common.py','run_pipeline.py','analyze_v4.py','audit_calibration.py']
for n in core_names:entries['模型V4原始代码/'+n]=(MODEL/n).read_bytes()
for n in ['build_manual.py','build_features_public.py']:
 entries['文档复原代码/'+n]=(W/n).read_bytes()
for p,n in [(OLD/'model_architecture_intro.json','模型技术摘要.json'),(OLD/'model_features_intro.json','模型特征摘要.json'),(W/'features_public.json',FNAME),(W/'features_public_audit.json','特征字典核验.json')]:entries['说明与证据/'+n]=p.read_bytes()
entries['说明与证据/四窗口效果.json']=json.dumps(rows4,ensure_ascii=False,indent=2).encode()
public_summary={'version':A['model_identity']['version'],'model_sha256':A['model_identity']['sha256'],'input_features':1930,'trees':838,'training':A['training'],'family_counts':Q['family_counts'],'main_sample':{'dates':'2026-10-09 through 2026-10-21','scored':8866,'evaluable':8717,'unknown':149},'four_horizons':rows4,'statistics_snapshot':'As of 2026-10-24 Belize complete calendar day; no new extraction or model fitting.'}
entries['说明与证据/文档事实摘要.json']=json.dumps(public_summary,ensure_ascii=False,indent=2).encode()
readme='''T0提单时点V4：模型说明与实测效果
本资料包含模型说明事实、1,930字段字典、V4核心算法/训练源码和此前已公开的验证复原代码/汇总结果。
不含模型二进制、数据库连接凭证、逐用户数据、特征矩阵或个体分数。原始训练与验证重算依赖授权数据、原模型运行库及历代特征工程环境；只有汇总JSON不能重新训练，也不能独立重新证明准确性。
文档复原：在原工作区运行build_manual.py（依赖现有冻结摘要、公开特征字典和先前验证资料包）；特征字典复原见build_features_public.py。
旧验证SQL中的实际用户/订单清单已参数化，空批次不会自动扩大到全量，使用时按其输入说明填回相同冻结范围。
当前版本t0_timing_v4_20261008。模型与数据均保持冻结，本次仅整理说明和网页；没有新查库、训练或投放。
所有指标在HTML就近标明窗口与分母。D0/D3主指标共同使用8,717次可判事件；D7/D15是窗口成熟样本，不能混用分母。
模型可用于候选筛选和实时接入测试；当前不直接全量自动发优惠。真实优惠增量与利润未由本次预测检验证明。
'''
entries['README_本说明文档.txt']=readme.encode()
source_codes=[(n,b.decode()) for n,b in entries.items() if n.endswith(('.py','.sql'))]
codebody=''.join(f'<details class="code"><summary>{esc(n)}</summary><pre><code>{esc(t)}</code></pre></details>' for n,t in source_codes)
B.append(section('appendix','七、常见问题与复原依据',
 ''.join(fold(q,'<p>'+a+'</p>') for q,a in faq)+
 f'<p><a class="button" href="{ZNAME}">下载代码与统计依据 ZIP</a> <a class="button" href="https://wangchl03.github.io/report/t0-model-v4-business-validation-20261026/?v=8026564">打开原业务检验报告</a></p>'+
 note('本说明独立生成；原验证报告保留。没有改变模型、统计样本或筛选规则。模型文件SHA256：<code class="hash">'+A['model_identity']['sha256']+'</code>。')+
 fold(f'附录：复原报告代码（{len(source_codes)}个完整SQL / Python文件）',codebody)))
# Reuse the established dark theme, centered title and fixed navigation.
tree=ast.parse((OLD/'build_business_report.py').read_text())
css=next(ast.literal_eval(n.value) for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='css' for t in n.targets))
css+='''.tri{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}.tri>div{background:#142338;padding:16px;border-radius:8px}.tri b,.tri strong{display:block}.tri p{font-size:13px;margin:6px 0}.good{color:#6ee7b7}.bad{color:#fb7185}.intervals{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:12px}.intervals>div{border:1px solid #355174;background:#13283e;padding:15px;border-radius:8px}.intervals b{font-size:21px;color:#7dd3fc}.intervals strong{display:block;font-size:14px;margin-top:5px}.intervals p{font-size:13px;margin:5px 0}.formula{padding:14px;background:#1a2b42;text-align:center;color:#a8ddf6;font-weight:600}.monotone{text-align:center}.feature-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:12px}.feature-grid>div{padding:16px;background:#142338;border-radius:7px}.feature-grid h3{font-size:16px;margin:0 0 7px}.feature-grid h3 span{float:right;color:#7dd3fc}.feature-grid p{font-size:13px;margin:0}.feature-grid>div:last-child{grid-column:1/-1}.two{display:grid;grid-template-columns:1fr 1fr;gap:14px}.two>div{padding:15px;background:#142338;border-radius:8px}.two h3{font-size:16px;margin:0 0 6px}.two p{font-size:13px;margin:0}.process{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px}.process>div{background:#142338;padding:15px;border-radius:7px}.process b{color:#a1d7ef}.process p{font-size:13px;margin:5px 0}.process.four{grid-template-columns:repeat(4,minmax(0,1fr))}.cards.three{grid-template-columns:repeat(3,minmax(0,1fr))}.metrics{display:grid;grid-template-columns:1fr 1fr;gap:12px}.metrics>div{padding:15px;border:1px solid #31425b;border-radius:8px;background:#142338}.metrics b{color:#b1dffc}.metrics p{font-size:13px;margin:5px 0}.weekchips{display:grid;grid-template-columns:repeat(3,1fr);gap:12px;margin-top:20px}.weekchips>div{padding:12px;text-align:center;background:#142338;border-radius:7px}.weekchips strong,.weekchips small{display:block}.weekchips strong{font-size:24px;color:#7dd3fc}.weekchips small{color:#9aadc4}.feature-controls{display:flex;gap:12px;padding:16px}.feature-controls input,.feature-controls select{background:#162b42;border:1px solid #3e5878;border-radius:6px;color:#deebf9;padding:10px;min-width:0}.feature-controls input{flex:1}.feature-controls select{max-width:40%}.feature-name{font-family:monospace;word-break:break-word}code.hash{word-break:break-all}#feature-status{padding:0 16px}section>p code,.two code{font-size:12px;word-break:break-word}@media(max-width:850px){.tri,.two,.process,.process.four,.cards.three{grid-template-columns:1fr}.intervals{grid-template-columns:1fr 1fr}.feature-grid,.metrics{grid-template-columns:1fr}.feature-grid>div:last-child{grid-column:auto}.weekchips{grid-template-columns:1fr}.feature-controls{flex-direction:column}.feature-controls select{max-width:none}}'''
nav=[('overview','认识模型'),('mechanism','如何预测'),('features','使用特征'),('training','训练验证'),('performance','实测效果'),('use','使用流程'),('appendix','问题与依据')]
# Lazy render 50 matching rows, keeping the full 1,930 definitions searchable without a huge table DOM.
compact=[{k:r[k] for k in ['index','name','family','description','window_hint']} for r in Q['features']]
jsdata=json.dumps(compact,ensure_ascii=False,separators=(',',':')).replace('<','\\u003c').replace('>','\\u003e')
js='''(()=>{const rows=JSON.parse(document.getElementById('feature-data').textContent);const box=document.getElementById('feature-browser'),q=document.getElementById('feature-query'),f=document.getElementById('feature-family'),out=document.getElementById('feature-result'),status=document.getElementById('feature-status');function draw(){const key=q.value.trim().toLowerCase();const found=rows.filter(r=>(!f.value||r.family===f.value)&&(!key||[r.name,r.family,r.description,r.window_hint].join(' ').toLowerCase().includes(key)));status.textContent='匹配 '+found.length+' / 1930 个字段；显示前 '+Math.min(found.length,50)+' 个，继续输入可缩小范围。';out.replaceChildren();const t=document.createElement('table'),head=document.createElement('thead'),tr=document.createElement('tr');['序号','字段','类别','冻结字典释义','窗口'].forEach(x=>{const c=document.createElement('th');c.textContent=x;tr.appendChild(c)});head.appendChild(tr);t.appendChild(head);const body=document.createElement('tbody');found.slice(0,50).forEach(r=>{const tr=document.createElement('tr');[r.index,r.name,r.family,r.description,r.window_hint].forEach((x,i)=>{const c=document.createElement('td');c.textContent=String(x);if(i===1)c.className='feature-name';tr.appendChild(c)});body.appendChild(tr)});t.appendChild(body);out.appendChild(t)}box.addEventListener('toggle',()=>{if(box.open)draw()});q.addEventListener('input',draw);f.addEventListener('change',draw)})();'''
report='<!DOCTYPE html><html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>T0提单时点模型V4｜模型说明与实测效果</title><style>'+css+'</style></head><body><header><h1>T0提单时点模型V4｜模型说明与实测效果</h1><p>面向业务介绍与技术沟通的完整说明</p><p class="note">版本 t0_timing_v4_20261008 · 文档2026年10月26日 · 实测数据截至2026年10月24日</p></header><nav class="nav" aria-label="文档目录">'+''.join(f'<a href="#{x}">{y}</a>' for x,y in nav)+'</nav><main>'+''.join(B)+'</main><footer>冻结模型 · 真实历史数据 · 事件口径 · 原报告保留</footer><script id="feature-data" type="application/json">'+jsdata+'</script><script>'+js+'</script></body></html>'
(OUT/HNAME).write_text(report)
shutil.copy2(W/'features_public.json',OUT/FNAME)
manifest={'model_version':A['model_identity']['version'],'model_sha256':A['model_identity']['sha256'],'event_results_cutoff':'2026-10-25 00:00:00 America/Belize exclusive','files':{n:{'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()} for n,b in entries.items()}}
with zipfile.ZipFile(OUT/ZNAME,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for n,b in entries.items():z.writestr(n,b)
 z.writestr('manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2))
(W/'four_horizon_metrics.json').write_text(json.dumps(rows4,ensure_ascii=False,indent=2))
(W/'manual_manifest.json').write_text(json.dumps({'html':str(OUT/HNAME),'zip':str(OUT/ZNAME),'dictionary':str(OUT/FNAME),'model_sha256':A['model_identity']['sha256'],'features':1930,'code_files':len(source_codes),'charts':CHARTS,'files':{p.name:{'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in [OUT/HNAME,OUT/ZNAME,OUT/FNAME]}},ensure_ascii=False,indent=2))
print(json.dumps({'html':str(OUT/HNAME),'html_bytes':(OUT/HNAME).stat().st_size,'zip_bytes':(OUT/ZNAME).stat().st_size,'dictionary_bytes':(OUT/FNAME).stat().st_size,'code_files':len(source_codes),'charts':len(CHARTS)},ensure_ascii=False))
