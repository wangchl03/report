"""Export feature-name/schema metadata only; never reads user feature matrices or predictions."""
from pathlib import Path
from collections import Counter
import csv, hashlib, json

ROOT = Path('/Users/wangchuanliang/Documents/Codex/2026-10-18/wen')
MODEL = Path('/Users/wangchuanliang/Documents/Codex/2026-09-21/ji-x/outputs/T0提单时点预测模型_V4')
OUT = ROOT / 'work/t0_v4_model_manual_20261026'
SOURCES = {
    'frozen_model_feature_names': MODEL / 'datasets/model_feature_names.json',
    'development_dictionary_json': MODEL / '生命周期特征开发规格字典.json',
    'development_dictionary_csv': MODEL / '生命周期特征开发规格字典.csv',
    'verified_model_introduction': ROOT / 'work/t0_v4_business_reliability_20261026/model_features_intro.json',
    'frozen_family_classifier': MODEL / 'analyze_v4.py',
    'frozen_model_artifact_hash_only': MODEL / 'models/t0_application_timing_v4.joblib',
}

def sha256(path):
    h = hashlib.sha256()
    with path.open('rb') as f:
        while block := f.read(1024 * 1024):
            h.update(block)
    return h.hexdigest()

def exact_family(n):
    # Copied verbatim in meaning from frozen analyze_v4.py; no model/user values used.
    if n.startswith(('prod_', 'product_')): return '产品条件与选择生命周期'
    if n.startswith('app_nonpay'): return '非还款日App行为'
    if n.startswith('app_'): return '实际App行为'
    if n.startswith(('beh_', 'days_since_active')): return 'V1基础App行为'
    if n.startswith('risk_score_'): return '两项风控模型分'
    if n.startswith('cyc_'): return '历史循环贷经历'
    if n.startswith('t0hist_'): return '历史T0时点习惯'
    if n.startswith('history_cross_'): return '历史交互'
    if n.startswith('interval_'): return '条件风险区间'
    return '其他借还与额度生命周期'

GROUPS = {
    '借还款、额度及历史交互': ['其他借还与额度生命周期', '历史交互'],
    '历史T0提单习惯': ['历史T0时点习惯'],
    '历史循环贷经历': ['历史循环贷经历'],
    '产品条件与选择': ['产品条件与选择生命周期'],
    'App行为': ['V1基础App行为', '实际App行为', '非还款日App行为'],
    '风控分及缺失标记': ['两项风控模型分'],
    '预测阶段编码': ['条件风险区间'],
}
EXPECTED = dict(zip(GROUPS, [716, 315, 216, 218, 457, 5, 3]))
MERGE = {sub: group for group, subs in GROUPS.items() for sub in subs}

names = json.loads(SOURCES['frozen_model_feature_names'].read_text())
specs = json.loads(SOURCES['development_dictionary_json'].read_text())
intro = json.loads(SOURCES['verified_model_introduction'].read_text())
assert len(names) == len(set(names)) == 1930
by = {s['feature']: s for s in specs}
assert len(by) == len(specs)
assert all(n in by for n in names)
with SOURCES['development_dictionary_csv'].open(encoding='utf-8-sig', newline='') as f:
    csv_by = {s['feature']: s for s in csv.DictReader(f)}
assert all(n in csv_by for n in names)

items = []
for index, name in enumerate(names, 1):
    s = by[name]
    definition = s.get('definition') or s.get('definition_cn')
    csv_description = csv_by[name].get('definition') or csv_by[name].get('definition_cn')
    assert definition == csv_description, (name, definition, csv_description)
    fine = exact_family(name)
    item = {
        'index': index,
        'name': name,
        'family': MERGE[fine],
        'description': definition or '字段释义待补（原始开发字典未提供释义）',
        'family_detail': fine,
        'dictionary_family': s.get('family'),
        'description_source': '冻结V4生命周期特征开发规格字典，原文摘录',
        'spec_id': s.get('spec_id'),
    }
    if s.get('window'): item['window_hint'] = s['window']
    if s.get('source'): item['source_hint'] = s['source']
    if s.get('formula'): item['formula'] = s['formula']
    if s.get('time_policy'): item['time_policy'] = s['time_policy']
    # Base V1 window has a separate, verified frozen implementation. Keep raw dictionary
    # description untouched while replacing only its generic window/source hints.
    if name in intro['behavior']['base_v1_windows']['fields']:
        item['window_hint'] = intro['behavior']['base_v1_windows']['fields'][name]
        item['window_hint_evidence'] = '已核验model_features_intro.json：behavior.base_v1_windows.fields'
        item['source_hint'] = 'wangchuanliang.event_track_record（冻结版本按create_time/create_date统计）'
    if name in intro['risk_sources'] and name.startswith('risk_score_'):
        item['source_hint'] = intro['risk_sources'][name]
        item['source_hint_evidence'] = '已核验model_features_intro.json：risk_sources'
    items.append(item)

fine_counts = Counter(x['family_detail'] for x in items)
counts = Counter(x['family'] for x in items)
assert dict(counts) == EXPECTED, (dict(counts), EXPECTED)
assert dict(fine_counts) == intro['families_exact']
assert len(items) == 1930 and [x['name'] for x in items] == names

sources = [{'id': key, 'file_name': path.name,
            'sha256': sha256(path)} for key, path in SOURCES.items()]
public = {
    'model': intro['version'],
    'model_scope': 'T0提单时点预测模型V4；不是召回提单意愿模型V4',
    'feature_count': len(items),
    'order': '严格按冻结模型datasets/model_feature_names.json的实际输入列顺序；index从1开始',
    'privacy': '仅字段定义与开发元数据；不含用户标识、用户特征值、个体分数、预测样本或原始输入文本。',
    'family_counts': EXPECTED,
    'feature_count_note': '1,930为窗口、统计量、交互、类别编码与3项区间输入展开后的列数，不是1,930种独立业务信息。',
    'description_note': 'description逐字沿用冻结开发字典；部分基础字段原释义较简略，未据字段名补造定义。window_hint的11项基础行为窗口由已核验实现补充。',
    'model_notes': [
        '405与363为模型输入；410不属于冻结模型输入，410≥528为评分后的外部分组条件。',
        'App行为源为event_track_record；没有使用event_track或新星途行为表。',
        '滚动小时与自然日窗口并存；beh_events_1d为T0前24小时，app_*_1d为获额业务日内且严格早于T0的记录。',
        '输入列保留不等于每列有独立增量价值；训练增益不能解释为因果贡献。',
    ],
    'sources': sources,
    'features': items,
}
OUT.mkdir(parents=True, exist_ok=True)
output = OUT / 'features_public.json'
output.write_text(json.dumps(public, ensure_ascii=False, indent=2) + '\n')
audit = {
    'model': intro['version'],
    'feature_order_matches_frozen_model': [x['name'] for x in items] == names,
    'feature_count': len(items),
    'selected_features_covered_by_json_dictionary': sum(n in by for n in names),
    'selected_features_covered_by_csv_dictionary': sum(n in csv_by for n in names),
    'json_csv_selected_descriptions_equal': True,
    'description_missing_count': sum(not(by[n].get('definition') or by[n].get('definition_cn')) for n in names),
    'base_description_simplified_count': sum(x['description'].startswith('基础输入；') for x in items),
    'counts_exact': dict(fine_counts),
    'counts_merged': dict(counts),
    'expected_counts_merged': EXPECTED,
    'counts_match_intro_and_expected': True,
    'merge_rules': GROUPS,
    'feature_names_unique': len(names) == len(set(names)),
    'reads_user_values': False,
    'source_files': sources,
    'output': {'file_name': output.name, 'sha256': sha256(output)},
}
(OUT / 'features_public_audit.json').write_text(json.dumps(audit, ensure_ascii=False, indent=2) + '\n')
print(json.dumps({'output': str(output), 'feature_count': len(items), 'family_counts': dict(counts), 'descriptions_missing': audit['description_missing_count'], 'base_descriptions_simplified': audit['base_description_simplified_count']}, ensure_ascii=False))
