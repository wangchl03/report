"""Checkpointed product features, no edits to V1-V3."""
from common import ROOT,V1,V2,V3,base_frame,np,pd,digest,save_json
from product_features import Profiles,tokens,snapshot,SPECS
import json,time

def load_history():
    credits=pd.read_csv(V2/'sources/credits.csv.gz',dtype={'risk_product':str})
    credits.credit_time=pd.to_datetime(credits.credit_time,format='mixed')
    credits=credits.loc[credits.is_pass1.eq(1)].sort_values(['user_id','credit_time','serial_id'])
    assert not credits.duplicated(['user_id','serial_id']).any(),'Repeated serial snapshots must be latest-before-T0; do not keep a future latest row'
    credits=credits.drop_duplicates(['user_id','serial_id'],keep='last')
    # Restrict rate denominators to known reloan eligible offers, whose 15-day validity is defined.
    elig=pd.read_csv(V3/'sources/history_offers.csv.gz',usecols=['user_id','serial_id','loan_type_code','has_type2','has_type3'])
    elig=elig.loc[elig.loan_type_code.eq(2)&(elig.has_type2.eq(1)|elig.has_type3.eq(1)),['user_id','serial_id']].drop_duplicates()
    credits=credits.merge(elig,on=['user_id','serial_id'],how='inner',validate='one_to_one')
    orders=pd.read_csv(V2/'sources/orders.csv.gz',usecols=['user_id','serial_id','apply_time','product_no'],dtype={'product_no':str})
    orders.apply_time=pd.to_datetime(orders.apply_time,format='mixed',errors='coerce')
    credits=credits.merge(orders,on=['user_id','serial_id'],how='left',validate='one_to_one')
    groups={}
    for uid,g in credits.groupby('user_id',sort=False):
        g=g.sort_values(['credit_time','serial_id'])
        batch=(g.credit_time.diff().gt(pd.Timedelta(seconds=20))|g.credit_time.diff().isna()).cumsum()
        starts=g.groupby(batch).credit_time.min()
        final=g.loc[~batch.duplicated(keep='last')].copy()
        final['batch_start']=batch.loc[final.index].map(starts)
        recs=[(r.credit_time,tokens(r.risk_product),int(r.serial_id),r.apply_time,str(r.product_no) if pd.notna(r.product_no) else '') for r in final.itertuples()]
        groups[int(uid)]=(final.batch_start.to_numpy('datetime64[ns]'),final.credit_time.to_numpy('datetime64[ns]'),recs)
    return groups,len(credits)

def main():
    at=time.time();df=base_frame();profiles=Profiles(pd.read_csv(ROOT/'sources/product_profiles_daily.csv',dtype={'product_no':str}))
    groups,source_n=load_history();example,_=snapshot([],pd.Timestamp('2026-01-01'),'',profiles,[np.nan]*4,1)
    names=list(example);path=ROOT/'datasets/product_features.npy'
    checkpoint=ROOT/'datasets/product_checkpoint.json'
    contract=digest(ROOT/'product_features.py')+digest(ROOT/'sources/product_profiles_daily.csv')+digest(V3/'datasets/base_with_labels.pkl.gz')
    if checkpoint.exists():
        ck=json.loads(checkpoint.read_text());assert ck['contract']==contract
        done=ck['done'];matrix=np.load(path,mmap_mode='r+')
    else:
        done=0;matrix=np.lib.format.open_memmap(path,mode='w+',dtype='float32',shape=(len(df),len(names)))
    records=df.to_dict('records');missing=[]
    for start in range(done,len(df),2000):
        stop=min(start+2000,len(df))
        for i in range(start,stop):
            e=records[i];t=e['as_of_time'];g=groups.get(int(e['user_id']))
            if g:
                starts,times,recs=g
                k=np.searchsorted(times,t.to_datetime64(),side='right')
                # Remove the current automatic batch, even when it contains earlier product rows.
                current_start=starts[k-1] if k and times[k-1]==t.to_datetime64() else t.to_datetime64()
                h=np.searchsorted(times,current_start,side='left');hist=recs[:h]
            else:hist=[]
            previous=[e['previous_fee_rate'],e['previous_daily_rate'],e['previous_loan_day'],e['previous_total_term']]
            vals,audit=snapshot(hist,t,e['risk_product'],profiles,previous,e['successful_loan_count'])
            assert list(vals)==names and not audit['future_history_used']
            matrix[i]=[vals[n] for n in names]
        matrix.flush();save_json(checkpoint,{'done':stop,'total':len(df),'contract':contract})
        if stop%10000==0 or stop==len(df):print('PRODUCT_FEATURES',stop,len(df),'seconds',round(time.time()-at),flush=True)
    save_json(ROOT/'datasets/product_feature_names.json',names)
    save_json(ROOT/'datasets/product_feature_specs.json',SPECS)
    df.to_pickle(ROOT/'datasets/base_with_labels.pkl.gz',compression='gzip')
    # Product_info association is explicitly audit-only for historical events.
    current=pd.read_csv(ROOT/'sources/product_info_snapshot.csv',dtype={'product_no':str}).set_index('product_no')
    joins=[]
    for r in df[['event_id','risk_product','vir_date']].itertuples():
        ps=tokens(r.risk_product);g=current.reindex(list(ps))
        joins.append({'event_id':r.event_id,'product_n':len(ps),'current_table_match_n':int(g.interest_fees.notna().sum()),
            'product_info_min_fee':g.interest_fees.min(),'product_info_min_daily':g.daily_interest.min(),
            'product_info_max_days':g.loan_day.max(),'product_info_max_terms':g.total_term.max(),
            'historical_model_input':False})
    pd.DataFrame(joins).to_csv(ROOT/'datasets/product_info关联核对_不回填历史.csv.gz',index=False,compression='gzip')
    pos={n:i for i,n in enumerate(names)}
    audit={'events':len(df),'users':int(df.user_id.nunique()),'product_features':len(names),'seconds':round(time.time()-at,1),
        'product_info_rows':len(current),'historical_source_offer_n':source_n,'profile_partial_missing_n':int(matrix[:,pos['prod_profile_partial_missing']].sum()),
        'profile_all_missing_n':int(matrix[:,pos['prod_profile_all_missing']].sum()),'missing_events_dropped':0,
        'mother_sha256':digest(V3/'datasets/base_with_labels.pkl.gz'),'history_policy':'exclude current 20-second batch, offers strictly before T0',
        'current_info_not_in_historical_matrix':True,'source_contract_mutability':'offline/shadow; historical effective timestamps not available'}
    save_json(ROOT/'analysis/product_feature_build_audit.json',audit)
    rows=[]
    inherited=pd.read_csv(V3/'生命周期特征开发规格字典.csv')
    inherited.to_csv(ROOT/'继承V3生命周期特征字典.csv',index=False,encoding='utf-8-sig')
    for j,n in enumerate(names):rows.append({**SPECS[n],'missing_rate':float(np.isnan(matrix[:,j]).mean())})
    pd.DataFrame(rows).to_csv(ROOT/'产品生命周期特征字典.csv',index=False,encoding='utf-8-sig')
    print('DONE',audit,flush=True)

if __name__=='__main__':main()
