"""Same frozen experiments; isolated fits, sequential by default on a 16GB host."""
import os,multiprocessing as mp
import train_v4 as train
from common import ROOT,np,save_json
import json,joblib

SHARED={}

def worker(task):
    fold,strategy,params,tag,variant=task
    df,base,names=SHARED['df'],SHARED['base'],SHARED['names']
    # DEFAULT tuning is identical to the selected sample-strategy experiment.
    # Reuse its exact frozen fit, rather than fit identical data/params twice.
    if tag=='tune_00':
        source=ROOT/'models'/f'sample_{strategy}__{fold["name"]}.joblib'
        target=ROOT/'models'/f'{tag}__{fold["name"]}.joblib'
        if source.exists() and not target.exists():
            bundle=joblib.load(source);bundle['tag']=tag
            bundle['reused_identical_fit_from']=source.name
            joblib.dump(bundle,target)
    bundle,rows=train.fit_candidate(df,base,names,fold,strategy,params,tag,variant)
    p,h=train.predict(bundle,base,df,rows,calibrated=False)
    np.savez_compressed(ROOT/'analysis'/f'{tag}__{fold["name"]}_oof.npz',rows=rows,hazard=h,prediction=p)
    return dict(fold=fold['name'],best_iteration=bundle['best_iteration'],train_events=bundle['train_events'],features=len(bundle['features']),**train.score_result(df,rows,p))

def parallel_compare(df,base,names,strategy,params,tag,variant='global',folds=None):
    SHARED.update(df=df,base=base,names=names)
    tasks=[(f,strategy,params,tag,variant) for f in folds or train.CONTRACT['folds'][1:]]
    # Forked children only run local LightGBM: no database connection or App automation.
    workers=max(1,min(2,int(os.environ.get('V4_FOLD_WORKERS','1'))))
    with mp.get_context('fork').Pool(min(workers,len(tasks))) as pool:results=pool.map(worker,tasks)
    out=dict(tag=tag,strategy=strategy,variant=variant,params=params,folds=results,
        mean_brier=float(np.mean([r['mean_brier'] for r in results])),mean_auc=float(np.mean([r['mean_auc'] for r in results])),
        weak_mean_brier=float(np.mean([r['weak_mean_brier'] for r in results])),weak_mean_auc=float(np.mean([r['weak_mean_auc'] for r in results])))
    print('RESULT',tag,round(out['mean_brier'],6),round(out['mean_auc'],6),flush=True)
    return out

if __name__=='__main__':
    os.environ['OBJC_DISABLE_INITIALIZE_FORK_SAFETY']='YES'
    from input_contract import check
    check(freeze_if_missing=True)
    train.compare_candidate=parallel_compare
    train.main()
