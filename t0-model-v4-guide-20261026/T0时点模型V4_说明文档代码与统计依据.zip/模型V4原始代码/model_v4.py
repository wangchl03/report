"""Train-only product-set encoding and monotone cumulative hazard scoring."""
from common import ROOT,V1,V3,np,pd,HORIZONS,END_DAYS,START_DAYS,inherited_inputs
from product_features import tokens
import json

CATS=['vir_version','previous_product_no','risk_product']

def numeric_inputs():
    names,old=inherited_inputs()
    prodnames=json.loads((ROOT/'datasets/product_feature_names.json').read_text())
    prod=np.load(ROOT/'datasets/product_features.npy',mmap_mode='r')
    keep=[i for i,n in enumerate(names) if n not in ['risk_product']+CATS]
    outnames=[names[i] for i in keep]+prodnames
    matrix=np.empty((len(old),len(outnames)),dtype='float32')
    matrix[:,:len(keep)]=old[:,keep];matrix[:,len(keep):]=prod
    matrix[np.isinf(matrix)]=np.nan
    return outnames,matrix

def fit_encoder(frame):
    counts={}
    for s in frame.risk_product:
        for p in tokens(s):counts[p]=counts.get(p,0)+1
    known=sorted(counts)
    combos=sorted({','.join(tokens(s)) for s in frame.risk_product})
    mapping={c:{v:i+1 for i,v in enumerate(sorted((frame[c].map(lambda s:','.join(tokens(s))) if c=='risk_product' else frame[c].fillna('SOURCE_MISSING').astype(str)).unique()))} for c in CATS}
    return {'product_codes':known,'product_counts':counts,'product_combos':combos,'categories':mapping,
        'unknown_category_code':0,'note':'0 reserved for unseen; flags distinguish source absence; no future-category fit'}

def encode(frame,encoder):
    codepos={p:j for j,p in enumerate(encoder['product_codes'])};known=set(codepos);combos=set(encoder['product_combos'])
    names=['product_present_'+p for p in encoder['product_codes']]+['product_unknown_count','product_unknown_share','product_combo_unseen']
    names += [x for c in CATS for x in [c+'_encoded',c+'_unseen',c+'_source_missing']]
    x=np.zeros((len(frame),len(names)),dtype='float32');offset=len(codepos)
    for i,s in enumerate(frame.risk_product):
        ps=tokens(s)
        for p in ps:
            if p in codepos:x[i,codepos[p]]=1
        unseen=sum(p not in known for p in ps)
        x[i,offset:offset+3]=[unseen,unseen/len(ps) if ps else np.nan,int(','.join(ps) not in combos)]
    for j,c in enumerate(CATS):
        source=frame[c];vals=source.map(lambda s:','.join(tokens(s))) if c=='risk_product' else source.fillna('SOURCE_MISSING').astype(str);mp=encoder['categories'][c]
        at=offset+3+3*j
        x[:,at]=vals.map(mp).fillna(0).to_numpy(float)
        x[:,at+1]=(~vals.isin(mp)).to_numpy(int)
        x[:,at+2]=(source.isna()|vals.isin(['','SOURCE_MISSING','MISSING'])).to_numpy(int)
    return names,x

def train_columns(names,x,rows):
    """Fit-only constant pruning. Keep both App families, risk flags and explicit missing flags."""
    keep=[];dropped=[]
    for j,n in enumerate(names):
        v=x[rows,j];ok=np.isfinite(v)
        protected=(n.startswith(('risk_score_','interval_','product_')) or
            n.endswith(('_source_missing','_unseen')) or n.startswith('prod_profile_'))
        if protected or (ok.any() and (ok.sum()!=len(v) or np.nanmin(v)!=np.nanmax(v))):keep.append(j)
        else:dropped.append({'feature':n,'reason':'training-only empty or constant'})
    for family in ['app_','app_nonpay']:
        assert any(names[j].startswith(family) for j in keep),'Required App family removed'
    for n in ['risk_score_405','risk_score_363']:assert n in [names[j] for j in keep]
    return keep,dropped

def block(base,encoded,names,encoder_names,rows,columns,interval=None):
    z=np.column_stack([base[rows],encoded[rows]])[:,columns].astype('float32')
    selected=[(names+encoder_names)[j] for j in columns]
    if interval is not None:
        ii=np.asarray(interval,int)
        for c,value in [('interval_id',ii),('interval_length',np.asarray(END_DAYS)[ii]-np.asarray(START_DAYS)[ii]),('interval_start_day',np.asarray(START_DAYS)[ii])]:
            z[:,selected.index(c)]=value
    return z

def apply_calibration(hazards,calibrators):
    z=hazards.copy()
    for j,model in calibrators.items():
        if model is None:continue
        p=np.clip(z[:,int(j)],1e-7,1-1e-7);logit=np.log(p/(1-p))
        z[:,int(j)]=model.predict_proba(logit[:,None])[:,1]
    return np.clip(z,1e-7,1-1e-7)

def predict(bundle,base,frame,rows=None,calibrated=True):
    rows=np.arange(len(frame)) if rows is None else np.asarray(rows,int)
    enames,encoded=encode(frame.iloc[rows],bundle['encoder'])
    assert enames==bundle['encoder_names']
    hazard=np.empty((len(rows),4))
    pos={n:i for i,n in enumerate(bundle['features'])}
    for at in range(0,len(rows),12000):
        part=rows[at:at+12000]
        x=np.column_stack([base[part],encoded[at:at+len(part)]])[:,bundle['columns']].astype('float32')
        for j in range(4):
            x[:,pos['interval_id']]=j;x[:,pos['interval_length']]=END_DAYS[j]-START_DAYS[j];x[:,pos['interval_start_day']]=START_DAYS[j]
            p=bundle['model'].booster_.predict(x,num_threads=4)
            if bundle.get('expert') is not None:
                weak=frame.iloc[part].successful_loan_count.isin([2,3]).to_numpy()
                if weak.any():p[weak]=bundle['expert'].booster_.predict(x[weak],num_threads=4)
            hazard[at:at+len(part),j]=p
    if calibrated:hazard=apply_calibration(hazard,bundle.get('calibrators',{}))
    hazard=np.clip(hazard,1e-7,1-1e-7)
    p=1-np.cumprod(1-hazard,axis=1)
    assert np.isfinite(p).all() and not (np.diff(p,axis=1)<-1e-12).any()
    return p,hazard

def predict_snapshot(bundle,snapshot):
    # Only saved predictor names are read; labels and future outcomes are ignored.
    data=snapshot.copy()
    for c in ['risk_product']+CATS:
        if c not in data:data[c]=None
    if 'successful_loan_count' not in data:data['successful_loan_count']=np.nan
    numeric=data.reindex(columns=bundle['numeric_names']).apply(pd.to_numeric,errors='coerce').to_numpy('float32')
    numeric[np.isinf(numeric)]=np.nan
    return predict(bundle,numeric,data)
