"""Only after freeze: same-event prior-model comparisons, cohort metrics and product associations."""
from common import ROOT,V1,V2,V3,np,pd,HORIZONS,END_DAYS,base_frame,save_json,day_mask
from model_v4 import numeric_inputs,predict,encode
from train import metric
from sklearn.metrics import roc_auc_score
from product_features import tokens
import json,joblib

def family(n):
    if n.startswith(('prod_','product_')):return '产品条件与选择生命周期'
    if n.startswith('app_nonpay'):return '非还款日App行为'
    if n.startswith('app_'):return '实际App行为'
    if n.startswith(('beh_','days_since_active')):return 'V1基础App行为'
    if n.startswith('risk_score_'):return '两项风控模型分'
    if n.startswith('cyc_'):return '历史循环贷经历'
    if n.startswith('t0hist_'):return '历史T0时点习惯'
    if n.startswith('history_cross_'):return '历史交互'
    if n.startswith('interval_'):return '条件风险区间'
    return '其他借还与额度生命周期'

def comparisons(df,p):
    """Predictions are frozen original artifacts, not re-trained to match V4."""
    paths={'V1':V1/'全部T0事件_预测分数.csv.gz','V2':V2/'T0提单时点预测模型_V2_全量预测结果.csv.gz','V3':V3/'T0提单时点预测模型_V3_全量预测结果.csv.gz'}
    old={}
    for v,path in paths.items():
        z=pd.read_csv(path,usecols=['event_id']+[f'p_apply_d{h}' for h in HORIZONS]).set_index('event_id')
        assert df.event_id.isin(z.index).all()
        old[v]=z.loc[df.event_id,[f'p_apply_d{h}' for h in HORIZONS]].to_numpy(float)
    old['V4']=p
    return old

def labels_and_monthly(df,prod,pn):
    at={n:i for i,n in enumerate(pn)}
    choice=prod[:,at['prod_current_count']]
    def band(values,edges,labels):
        z=pd.Series(pd.cut(values,edges,right=False,labels=labels)).astype(object)
        return z.where(z.notna(),'产品条件缺失').to_numpy()
    series={
      '可选产品数量':np.select([choice==1,choice==2,choice>=3],['1个产品','2个产品','≥3个产品'],default='原字段缺失'),
      '借款次数':df.successful_loan_count.clip(upper=6).astype('Int64').astype(str).replace({'6':'≥6','<NA>':'缺失'}).to_numpy(),
      '额度方向':df.credit_direction.map({-1:'降额',0:'不变',1:'提额'}).fillna('缺失').to_numpy(),
      '产品息费率':band(prod[:,at['prod_current_fee_best']],[-np.inf,.3,.4,.5,.6,.7,np.inf],['<30%','30–40%','40–50%','50–60%','60–70%','≥70%']),
      '产品日息':band(prod[:,at['prod_current_daily_best']],[-np.inf,.02,.025,.03,.035,.04,np.inf],['<2%','2–2.5%','2.5–3%','3–3.5%','3.5–4%','≥4%']),
      '产品账期':band(prod[:,at['prod_current_days_best']],[-np.inf,7.01,14.01,21.01,28.01,np.inf],['≤7天','7–14天','14–21天','21–28天','>28天']),
      '产品期次':band(prod[:,at['prod_current_terms_best']],[-np.inf,1.01,2.01,3.01,4.01,np.inf],['≤1期','1–2期','2–3期','3–4期','>4期']),
      '产品特征覆盖':np.select([prod[:,at['prod_profile_all_missing']]>0,prod[:,at['prod_profile_partial_missing']]>0],['全部产品画像缺失','部分产品画像缺失'],default='产品画像齐全')}
    series['借款次数×可选产品数']=np.asarray([str(a)+'次 / '+str(b) for a,b in zip(series['借款次数'],series['可选产品数量'])])
    monthly=[]
    for group,values in series.items():
        z=df[['vir_date']].copy();z['group']=values;z['month']=z.vir_date.dt.strftime('%Y-%m')
        for h,end in zip(HORIZONS,END_DAYS):
            mature=(df.vir_date+pd.Timedelta(days=end)<=df.data_cutoff_ts)&df[f'y_d{h}'].notna()
            z[f'mature_n_d{h}']=mature.astype(int)
            z[f'positive_n_d{h}']=np.where(mature,df[f'y_d{h}'].fillna(0),0)
        agg=z.groupby(['month','group'],dropna=False).agg(events=('group','size'),**{c:(c,'sum') for c in z if c.startswith(('mature_n_','positive_n_'))}).reset_index()
        for h in HORIZONS:agg[f'actual_rate_d{h}']=agg[f'positive_n_d{h}']/agg[f'mature_n_d{h}'].where(agg[f'mature_n_d{h}']>0)
        agg['grouping']=group;monthly.append(agg)
    pd.concat(monthly,ignore_index=True).to_csv(ROOT/'analysis/月度产品条件与实际提单率.csv',index=False,encoding='utf-8-sig')
    return series

def main():
    from audit_calibration import main as audit_calibration
    audit_calibration()
    df=base_frame();pn=json.loads((ROOT/'datasets/product_feature_names.json').read_text());prod=np.load(ROOT/'datasets/product_features.npy',mmap_mode='r')
    p=np.load(ROOT/'datasets/event_predictions.npy');bundle=joblib.load(ROOT/'models/t0_application_timing_v4.joblib')
    assert (ROOT/'analysis/frozen_model_contract.json').exists()
    numeric=np.load(ROOT/'datasets/numeric_features.npy',mmap_mode='r')
    nn=json.loads((ROOT/'datasets/numeric_feature_names.json').read_text());positions=[j for j,n in enumerate(nn) if not n.startswith('interval_')]
    missing=np.empty(len(df),int)
    for start in range(0,len(df),10000):missing[start:start+10000]=np.isnan(numeric[start:start+10000,positions]).sum(axis=1)
    predpath=ROOT/'T0提单时点预测模型_V4_全量预测结果.csv.gz';export=pd.read_csv(predpath)
    assert export.event_id.eq(df.event_id).all()
    assert np.max(np.abs(export[[f'p_apply_d{h}' for h in HORIZONS]].to_numpy()-p))<1e-10
    export['missing_numeric_feature_n']=missing;export['partial_feature_missing']=(missing>0).astype(int)
    export.to_csv(predpath,index=False,compression='gzip',encoding='utf-8-sig')
    export.loc[export.split.str.endswith('holdout')].to_csv(ROOT/'T0提单时点预测模型_V4_复核集预测.csv',index=False,encoding='utf-8-sig')
    export.head(2000).to_csv(ROOT/'预测结果样例_本地.csv',index=False,encoding='utf-8-sig')
    del export,numeric
    predictions=comparisons(df,p);series=labels_and_monthly(df,prod,pn)
    contract=json.loads((ROOT/'experiment_contract.json').read_text());metrics=[];sub=[];ci=[];calibration=[];coverage=[]
    rng=np.random.default_rng(20261008)
    oldmap=json.loads((V3/'datasets/categorical_mappings.json').read_text())['risk_product']
    en,encoded=encode(df,bundle['encoder']);ep={n:i for i,n in enumerate(en)}
    for kind in ['fresh_retrospective_holdout','legacy_retrospective_holdout']:
        spec=contract[kind];rows=np.flatnonzero(day_mask(df,spec['start'],spec['end']));test=df.iloc[rows]
        users,inverse=np.unique(test.user_id.to_numpy(),return_inverse=True)
        draws=[np.bincount(rng.integers(0,len(users),len(users)),minlength=len(users))[inverse] for _ in range(300)]
        for model,allp in predictions.items():
            for j,h in enumerate(HORIZONS):
                y=test[f'y_d{h}'].to_numpy(float);prob=allp[rows,j]
                metrics.append(dict(split=kind,model=model,horizon=h,**metric(y,prob)))
                metrics.append(dict(split=kind+'_no_apply',model=model,horizon=h,**metric(1-y,1-prob)))
                for grouping,allvalues in series.items():
                    vals=np.asarray(allvalues)[rows]
                    for value in np.unique(vals):
                        ix=vals==value
                        if np.isfinite(y[ix]).sum()<50:continue
                        sub.append(dict(split=kind,model=model,horizon=h,grouping=grouping,group=str(value),**metric(y[ix],prob[ix])))
                if model=='V4':
                    ok=np.isfinite(y);yy=y[ok];new=prob[ok];old=predictions['V3'][rows,j][ok]
                    delta=[]
                    for w in draws:
                        w=w[ok]
                        if w[yy==0].sum()==0 or w[yy==1].sum()==0:continue
                        delta.append((roc_auc_score(yy,new,sample_weight=w)-roc_auc_score(yy,old,sample_weight=w),np.average((new-yy)**2-(old-yy)**2,weights=w)))
                    a=np.array(delta)
                    ci.append(dict(split=kind,horizon=h,replicates=len(a),user_n=len(users),
                        auc_delta=roc_auc_score(yy,new)-roc_auc_score(yy,old),auc_delta_low=np.quantile(a[:,0],.025),auc_delta_high=np.quantile(a[:,0],.975),
                        brier_delta=np.mean((new-yy)**2-(old-yy)**2),brier_delta_low=np.quantile(a[:,1],.025),brier_delta_high=np.quantile(a[:,1],.975)))
                if model in ['V3','V4']:
                    valid=np.isfinite(y);yy=y[valid];prob=prob[valid]
                    q=pd.qcut(pd.Series(prob).rank(method='first'),10,labels=False).to_numpy()
                    for dec in range(10):
                        ix=q==dec;calibration.append(dict(split=kind,model=model,horizon=h,decile=dec+1,n=int(ix.sum()),mean_prediction=float(prob[ix].mean()),actual_rate=float(yy[ix].mean())))
        unknown=~test.risk_product.isin(oldmap)
        coverage.append(dict(split=kind,events=len(test),v3_unknown_combo_n=int(unknown.sum()),v3_unknown_combo_share=float(unknown.mean()),
            v4_unseen_combo_n=int(encoded[rows,ep['product_combo_unseen']].sum()),v4_unseen_individual_event_n=int((encoded[rows,ep['product_unknown_count']]>0).sum()),
            v4_unseen_individual_product_n=int(encoded[rows,ep['product_unknown_count']].sum()),
            source_missing_n=int(test.risk_product.fillna('').eq('').sum()),
            product_partial_missing_n=int(prod[rows,pn.index('prod_profile_partial_missing')].sum()),
            product_all_missing_n=int(prod[rows,pn.index('prod_profile_all_missing')].sum()),predicted_events=len(rows)))
    pd.DataFrame(metrics).to_csv(ROOT/'analysis/模型同期复核指标.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(sub).to_csv(ROOT/'analysis/客群复核指标.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(ci).to_csv(ROOT/'analysis/V3_V4用户聚类置信区间.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(calibration).to_csv(ROOT/'analysis/概率十分位校准.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame(coverage).to_csv(ROOT/'analysis/产品编码与特征覆盖.csv',index=False,encoding='utf-8-sig')
    imp=pd.read_csv(ROOT/'analysis/feature_importance.csv');imp['family']=imp.feature.map(family)
    if bundle.get('expert') is not None:pd.DataFrame({'feature':bundle['features'],'gain':bundle['expert'].feature_importances_}).sort_values('gain',ascending=False).to_csv(ROOT/'analysis/expert_feature_importance.csv',index=False,encoding='utf-8-sig')
    imp.to_csv(ROOT/'analysis/feature_importance.csv',index=False,encoding='utf-8-sig')
    families=imp.groupby('family').agg(input_features=('feature','size'),positive_gain_features=('gain',lambda a:int((a>0).sum())),gain=('gain','sum')).reset_index()
    families['gain_share']=families.gain/families.gain.sum();families.to_csv(ROOT/'analysis/特征族实际参与情况.csv',index=False,encoding='utf-8-sig')
    save_json(ROOT/'analysis/model_diagnostics.json',dict(metrics=metrics,product_coverage=coverage,bootstrap=ci,bootstrap_replicates=300,used_for_model_selection=False))
    print('ANALYSIS_COMPLETE',flush=True)
    for r in metrics:
        if r['model'] in ['V3','V4'] and not r['split'].endswith('no_apply'):print(r['split'],r['model'],'D'+str(r['horizon']),round(r.get('auc',0),5),round(r.get('brier',0),5),flush=True)

if __name__=='__main__':main()
