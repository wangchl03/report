"""V4 isolated artifacts; original mothers, labels and prior models are immutable."""
from pathlib import Path
import sys, json, hashlib
ROOT=Path(__file__).resolve().parent
V1=ROOT.parent/'T0提单时点预测模型_V1'
V2=ROOT.parent/'T0提单时点预测模型_V2'
V3=ROOT.parent/'T0提单时点预测模型_V3'
sys.path[:0]=[str(V1),str(V1/'runtime')]
import numpy as np
import pandas as pd
from model import HORIZONS,END_DAYS,START_DAYS,expand
for name in ['sources','datasets','models','analysis']:
    (ROOT/name).mkdir(exist_ok=True)

def base_frame():
    return pd.read_pickle(V3/'datasets/base_with_labels.pkl.gz',compression='gzip')

def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest()

def save_json(path,obj):
    Path(path).write_text(json.dumps(obj,ensure_ascii=False,indent=2,default=str))

def day_mask(df,start,end):
    return (df.vir_date>=pd.Timestamp(start))&(df.vir_date<pd.Timestamp(end))

def inherited_inputs():
    names=json.loads((V3/'datasets/model_feature_names.json').read_text())
    matrix=np.load(V3/'datasets/model_features.npy',mmap_mode='r')
    return names,matrix

