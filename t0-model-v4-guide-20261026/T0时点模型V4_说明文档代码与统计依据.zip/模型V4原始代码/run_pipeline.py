"""Run sequential stages with resumable local checkpoints; no automatic business actions."""
from pathlib import Path
import subprocess,sys,json,time
ROOT=Path(__file__).resolve().parent
STAGES=['extract_products.py','test_products.py','build_product_features.py','train_v4.py','analyze_v4.py','validate_v4.py','build_documents.py','validate_v4.py']

def main():
    if (ROOT/'analysis/training_input_fingerprints.json').exists():
        subprocess.run([sys.executable,str(ROOT/'input_contract.py')],cwd=ROOT,check=True)
    for name in STAGES:
        (ROOT/'pipeline_status.json').write_text(json.dumps({'stage':name,'status':'running','started_at':time.strftime('%Y-%m-%d %H:%M:%S')},indent=2))
        if name=='train_v4.py':subprocess.run([sys.executable,str(ROOT/'input_contract.py'),'--freeze'],cwd=ROOT,check=True)
        subprocess.run([sys.executable,str(ROOT/name)],cwd=ROOT,check=True)
    (ROOT/'pipeline_status.json').write_text(json.dumps({'status':'complete','finished_at':time.strftime('%Y-%m-%d %H:%M:%S')},indent=2))

if __name__=='__main__':main()
