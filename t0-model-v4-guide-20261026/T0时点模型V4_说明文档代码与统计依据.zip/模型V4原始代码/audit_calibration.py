"""Check saved sigmoid fits against a scalar stable objective before reading holdouts."""
from common import ROOT,np,pd,expand,base_frame,digest,save_json
from scipy.special import expit
from scipy.optimize import minimize
import json,joblib

def main():
    path=ROOT/'models/t0_application_timing_v4.joblib'
    bundle=joblib.load(path);calibrators=bundle.get('calibrators',{})
    tag=bundle['selected_experiment']['tag'];df=base_frame();ys=[];ps=[];intervals=[]
    for name in ['fold1','fold2']:
        z=np.load(ROOT/'analysis'/f'{tag}__{name}_oof.npz')
        r=expand(df.iloc[z['rows']].assign(local_row=np.arange(len(z['rows']))))
        ps.append(z['hazard'][r.local_row.to_numpy(int),r.interval_id.to_numpy(int)])
        ys.append(r.hazard_label.to_numpy(float));intervals.append(r.interval_id.to_numpy(int))
    ph=np.concatenate(ps);target=np.concatenate(ys);iv=np.concatenate(intervals)
    assert np.isfinite(ph).all() and np.isfinite(target).all()
    checks=[]
    for j,model in calibrators.items():
        mask=iv==int(j);p=np.clip(ph[mask],1e-7,1-1e-7);x=np.log(p/(1-p));y=target[mask]
        theta=np.r_[model.coef_.ravel(),model.intercept_.ravel()]
        assert theta.shape==(2,) and np.isfinite(theta).all() and theta[0]>0
        # Same sklearn C=1 L2 objective; scalar reductions avoid the warning's matrix multiply.
        def objective(t):
            linear=t[0]*x+t[1]
            return float(np.logaddexp(0,linear).sum()-np.sum(y*linear)+.5*t[0]**2/model.C)
        def gradient(t):
            residual=expit(t[0]*x+t[1])-y
            return np.array([np.sum(residual*x)+t[0]/model.C,np.sum(residual)])
        reference=minimize(objective,np.array([1.,0.]),jac=gradient,method='L-BFGS-B',
            options={'maxiter':500,'ftol':1e-14,'gtol':1e-8})
        assert np.isfinite(reference.x).all()
        saved=expit(theta[0]*x+theta[1]);ref=expit(reference.x[0]*x+reference.x[1])
        error=float(np.max(np.abs(saved-ref)))
        loss_gap=float((objective(theta)-objective(reference.x))/len(y))
        assert error<1e-3 and loss_gap<1e-7,(j,error,loss_gap)
        direct=model.predict_proba(x[:,None])[:,1]
        assert np.isfinite(direct).all() and np.max(np.abs(direct-saved))<1e-10
        checks.append(dict(interval=int(j),n=len(y),coefficients_finite=True,slope_positive=True,
            max_probability_difference_from_independent_fit=error,mean_objective_gap=loss_gap,
            stable_mean_gradient_max=float(np.max(np.abs(gradient(theta)))/len(y))))
    audit=dict(status='PASS',calibration='sigmoid' if calibrators else 'identity',
        model_sha256=digest(path),only_oof_folds_used=['fold1','fold2'],holdout_used=False,
        checks=checks,numerical_warning_checked=True)
    save_json(ROOT/'analysis/calibration_numerical_audit.json',audit)
    print('CALIBRATION_NUMERICAL_AUDIT_PASS',checks,flush=True)
    return audit

if __name__=='__main__':main()
