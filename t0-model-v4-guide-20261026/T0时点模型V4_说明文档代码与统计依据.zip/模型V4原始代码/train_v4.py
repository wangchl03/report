"""Bounded rolling experiments, train-only encoding, no holdout-driven tuning."""
from common import ROOT,V1,V2,V3,np,pd,HORIZONS,END_DAYS,START_DAYS,expand,base_frame,save_json,digest,day_mask
from model_v4 import numeric_inputs,fit_encoder,encode,train_columns,block,predict,apply_calibration
from train import metric
from lightgbm import LGBMClassifier,early_stopping,log_evaluation
from sklearn.linear_model import LogisticRegression
import json,joblib,time,gc,hashlib

SEED=20261008
CONTRACT=json.loads((ROOT/'experiment_contract.json').read_text())
DEFAULT=dict(num_leaves=31,min_child_samples=150,learning_rate=.035,max_depth=-1,reg_lambda=10,reg_alpha=.1,colsample_bytree=.85,subsample=.85,max_bin=127)
CONFIGS=[
    DEFAULT,
    dict(DEFAULT,num_leaves=15,min_child_samples=300,reg_lambda=20),
    dict(DEFAULT,num_leaves=31,min_child_samples=300,reg_lambda=20,colsample_bytree=.7),
    dict(DEFAULT,num_leaves=63,min_child_samples=300,max_depth=8,reg_lambda=20),
    dict(DEFAULT,num_leaves=31,min_child_samples=500,max_depth=6,colsample_bytree=1.0),
    dict(DEFAULT,num_leaves=63,min_child_samples=500,reg_lambda=30,colsample_bytree=.7),
    dict(DEFAULT,num_leaves=15,min_child_samples=150,learning_rate=.05,reg_lambda=5),
    dict(DEFAULT,num_leaves=31,min_child_samples=150,learning_rate=.05,reg_lambda=5,subsample=1.0),
    dict(DEFAULT,num_leaves=31,min_child_samples=300,learning_rate=.025,reg_alpha=1),
    dict(DEFAULT,num_leaves=63,min_child_samples=200,max_depth=8,learning_rate=.025,colsample_bytree=.7),
    dict(DEFAULT,num_leaves=31,min_child_samples=250,reg_lambda=30,max_bin=63,colsample_bytree=.65),
    dict(DEFAULT,num_leaves=47,min_child_samples=250,max_depth=7,learning_rate=.04,reg_alpha=1)
]

def sample_mask(df,end,strategy):
    end=pd.Timestamp(end)
    start=pd.Timestamp('2026-01-01')
    if strategy=='recent6m':start=max(start,end-pd.DateOffset(months=6))
    if strategy=='recent3m':start=max(start,end-pd.DateOffset(months=3))
    return (df.vir_date>=start)&(df.vir_date<end)

def eval_rows(df,rows,p):
    return [dict(horizon=h,**metric(df.iloc[rows][f'y_d{h}'].to_numpy(float),p[:,j])) for j,h in enumerate(HORIZONS)]

def score_result(df,rows,p):
    mets=eval_rows(df,rows,p)
    weak=df.iloc[rows].successful_loan_count.isin([2,3]).to_numpy()
    wk=[dict(horizon=h,**metric(df.iloc[rows][f'y_d{h}'].to_numpy(float)[weak],p[weak,j])) for j,h in enumerate(HORIZONS)]
    return dict(mean_brier=float(np.mean([m['brier'] for m in mets])),mean_auc=float(np.mean([m['auc'] for m in mets])),
        weak_mean_brier=float(np.mean([m['brier'] for m in wk])),weak_mean_auc=float(np.mean([m['auc'] for m in wk])),metrics=mets,weak_metrics=wk)

def fit_candidate(df,base,names,fold,strategy,params,tag,variant='global',iterations=None):
    path=ROOT/'models'/f'{tag}__{fold["name"]}.joblib'
    signature=hashlib.sha256((json.dumps([fold,strategy,params,variant,iterations],sort_keys=True)+digest(ROOT/'model_v4.py')+digest(ROOT/'train_v4.py')+digest(ROOT/'experiment_contract.json')).encode()).hexdigest()
    valid=np.flatnonzero(day_mask(df,fold['valid_start'],fold['valid_end'])) if fold.get('valid_start') else np.asarray([],int)
    if path.exists():
        b=joblib.load(path);assert b['signature']==signature,'Changed experiment contract; preserve cached models and use a new tag'
        print('REUSE',tag,fold['name'],flush=True)
        return b,valid
    trainmask=sample_mask(df,fold['train_end'],strategy);trainrows=np.flatnonzero(trainmask)
    assert pd.Timestamp(fold['train_end'])+pd.Timedelta(days=15)<=pd.Timestamp(fold.get('valid_start','2026-09-01'))
    encoder=fit_encoder(df.loc[trainmask]);enames,enc=encode(df,encoder);allnames=names+enames
    columns,dropped=train_columns(allnames,np.column_stack([base,enc]),trainrows)
    if variant=='legacy_products':
        columns=[j for j in columns if not allnames[j].startswith(('prod_','product_'))]
    else:
        columns=[j for j in columns if not allnames[j].startswith('risk_product_')]
        if variant=='without_product_lifecycle':columns=[j for j in columns if not allnames[j].startswith('prod_')]
    selected=[allnames[j] for j in columns]
    risk=expand(df.loc[trainmask].assign(matrix_row=trainrows))
    x=block(base,enc,names,enames,risk.matrix_row.to_numpy(int),columns,risk.interval_id.to_numpy(int))
    weight=np.ones(len(risk))
    if strategy=='expanding_decay60':weight*=np.power(.5,(pd.Timestamp(fold['train_end'])-risk.vir_date).dt.days.to_numpy()/60)
    if variant=='weighted23':weight*=np.where(risk.successful_loan_count.isin([2,3]),1.5,1.0)
    weight/=weight.mean()
    validx=validy=None
    if len(valid):
        vr=expand(df.iloc[valid].assign(matrix_row=valid))
        validx=block(base,enc,names,enames,vr.matrix_row.to_numpy(int),columns,vr.interval_id.to_numpy(int));validy=vr.hazard_label.to_numpy(int)
    at=time.time();print('TRAIN',tag,fold['name'],'events',len(trainrows),'risk',len(risk),'features',len(selected),flush=True)
    mod=LGBMClassifier(**params,n_estimators=iterations or 1000,subsample_freq=1,n_jobs=4,verbosity=-1,random_state=SEED,importance_type='gain',force_col_wise=True)
    kwargs=dict(feature_name=selected,categorical_feature=[selected.index(c+'_encoded') for c in ['vir_version','previous_product_no','risk_product'] if c+'_encoded' in selected],sample_weight=weight)
    if len(valid):kwargs.update(eval_set=[(validx,validy)],eval_metric='binary_logloss',callbacks=[early_stopping(70,verbose=False),log_evaluation(0)])
    mod.fit(x,risk.hazard_label.to_numpy(int),**kwargs)
    b=dict(model=mod,expert=None,columns=columns,features=selected,numeric_names=names,encoder_names=enames,encoder=encoder,
        calibrators={},version=CONTRACT['version'],tag=tag,strategy=strategy,params=params,variant=variant,signature=signature,
        train_events=len(trainrows),risk_rows=len(risk),train_end=fold['train_end'],dropped=dropped,
        best_iteration=int(mod.best_iteration_ or mod.n_estimators),fit_seconds=round(time.time()-at,1),
        label_definition=CONTRACT['label_definition'],as_of='T0 approval time',timezone='America/Belize',deployment_status='offline/shadow')
    if variant=='expert23':
        weak=risk.successful_loan_count.isin([2,3]).to_numpy()
        expert=LGBMClassifier(**dict(params,min_child_samples=max(200,params['min_child_samples'])),n_estimators=iterations or b['best_iteration'],subsample_freq=1,n_jobs=4,verbosity=-1,random_state=SEED,importance_type='gain',force_col_wise=True)
        expert.fit(x[weak],risk.hazard_label.to_numpy(int)[weak],feature_name=selected,categorical_feature=kwargs['categorical_feature'],sample_weight=weight[weak])
        b['expert']=expert
    joblib.dump(b,path)
    print('FIT_DONE',tag,fold['name'],'seconds',b['fit_seconds'],'iterations',b['best_iteration'],flush=True)
    del x,enc,risk,validx;gc.collect()
    return b,valid

def compare_candidate(df,base,names,strategy,params,tag,variant='global',folds=None):
    results=[]
    for fold in folds or CONTRACT['folds'][1:]:
        b,rows=fit_candidate(df,base,names,fold,strategy,params,tag,variant)
        p,h=predict(b,base,df,rows,calibrated=False)
        np.savez_compressed(ROOT/'analysis'/f'{tag}__{fold["name"]}_oof.npz',rows=rows,hazard=h,prediction=p)
        results.append(dict(fold=fold['name'],best_iteration=b['best_iteration'],train_events=b['train_events'],features=len(b['features']),**score_result(df,rows,p)))
    out=dict(tag=tag,strategy=strategy,variant=variant,params=params,folds=results,
        mean_brier=float(np.mean([r['mean_brier'] for r in results])),mean_auc=float(np.mean([r['mean_auc'] for r in results])),
        weak_mean_brier=float(np.mean([r['weak_mean_brier'] for r in results])),weak_mean_auc=float(np.mean([r['weak_mean_auc'] for r in results])))
    print('RESULT',tag,round(out['mean_brier'],6),round(out['mean_auc'],6),flush=True)
    return out

def main():
    at=time.time();df=base_frame();names,base=numeric_inputs()
    np.save(ROOT/'datasets/numeric_features.npy',base)
    save_json(ROOT/'datasets/numeric_feature_names.json',names)
    save_json(ROOT/'analysis/environment.json',{'python':__import__('sys').version,'lightgbm':__import__('lightgbm').__version__,'numpy':np.__version__,'pandas':pd.__version__,'seed':SEED})
    history=[]
    for strategy in CONTRACT['sample_strategies']:
        r=compare_candidate(df,base,names,strategy,DEFAULT,'sample_'+strategy);history.append(r)
        save_json(ROOT/'analysis/experiment_results.json',history)
    samplebest=min(history,key=lambda x:(x['mean_brier'],-x['mean_auc']))
    strategy=samplebest['strategy'];search=[]
    for variant in ['legacy_products','without_product_lifecycle']:
        history.append(compare_candidate(df,base,names,strategy,DEFAULT,'ablation_'+variant,variant))
        save_json(ROOT/'analysis/experiment_results.json',history)
    for j,params in enumerate(CONFIGS):
        r=compare_candidate(df,base,names,strategy,params,f'tune_{j:02}');search.append(r);history.append(r)
        save_json(ROOT/'analysis/experiment_results.json',history)
    best=min(search,key=lambda x:(x['mean_brier'],-x['mean_auc']))
    weak=[]
    for variant in ['weighted23','expert23']:
        r=compare_candidate(df,base,names,strategy,best['params'],'weak_'+variant,variant);weak.append(r);history.append(r)
        save_json(ROOT/'analysis/experiment_results.json',history)
    eligible=[best]+[r for r in weak if r['mean_brier']<=best['mean_brier']+.0003 and r['mean_auc']>=best['mean_auc']-.001 and r['weak_mean_brier']<best['weak_mean_brier']]
    selected=min(eligible,key=lambda x:(x['mean_brier'],-x['mean_auc']))
    save_json(ROOT/'analysis/selection_before_holdout.json',dict(selected=selected,selection_rule=CONTRACT['selection'],test_labels_used=False))
    # Complete the third OOF fold for calibration; labels are all available before September.
    first=compare_candidate(df,base,names,strategy,selected['params'],selected['tag'],selected['variant'],folds=CONTRACT['folds'][:1])
    calmodels={};fit_targets=[];fit_hazards=[]
    for fold in CONTRACT['folds'][:2]:
        z=np.load(ROOT/'analysis'/f'{selected["tag"]}__{fold["name"]}_oof.npz');rows=z['rows'];h=z['hazard']
        risk=expand(df.iloc[rows].assign(local_row=np.arange(len(rows))))
        fit_targets.append(risk[['interval_id','hazard_label']].reset_index(drop=True))
        fit_hazards.append(h[risk.local_row.to_numpy(int),risk.interval_id.to_numpy(int)])
    targets=pd.concat(fit_targets,ignore_index=True);ph=np.concatenate(fit_hazards)
    for j in range(4):
        mask=targets.interval_id.eq(j).to_numpy();p=np.clip(ph[mask],1e-7,1-1e-7);y=targets.loc[mask,'hazard_label'].to_numpy(int)
        calmodels[j]=LogisticRegression(C=1,max_iter=300).fit(np.log(p/(1-p))[:,None],y)
    z=np.load(ROOT/'analysis'/f'{selected["tag"]}__fold3_oof.npz');checkrows=z['rows'];haz=z['hazard']
    raw=1-np.cumprod(1-haz,axis=1);cal=1-np.cumprod(1-apply_calibration(haz,calmodels),axis=1)
    rawresult=score_result(df,checkrows,raw);calresult=score_result(df,checkrows,cal)
    chosen=calmodels if calresult['mean_brier']<rawresult['mean_brier'] else {}
    save_json(ROOT/'analysis/calibration_selection.json',dict(selected='sigmoid' if chosen else 'identity',raw=rawresult,calibrated=calresult,fit_folds=['fold1','fold2'],check_fold='fold3',holdout_used=False))
    iterations=int(np.median([r['best_iteration'] for r in selected['folds']]))
    fold={'name':'final','train_end':CONTRACT['final_train_end_exclusive']}
    bundle,_=fit_candidate(df,base,names,fold,strategy,selected['params'],'final_selected',selected['variant'],iterations)
    bundle['calibrators']=chosen;bundle['selected_experiment']=selected;bundle['experiment_contract']=CONTRACT
    joblib.dump(bundle,ROOT/'models/t0_application_timing_v4.joblib')
    bundle['model'].booster_.save_model(str(ROOT/'models/t0_application_timing_v4_lightgbm.txt'))
    # Freeze artifact before the only evaluation of the September holdouts.
    save_json(ROOT/'analysis/frozen_model_contract.json',{'model_sha256':digest(ROOT/'models/t0_application_timing_v4.joblib'),'selected':selected['tag'],'test_labels_used_in_selection':False,'frozen_at':str(pd.Timestamp.now())})
    print('FROZEN',selected['tag'],flush=True)
    p,hazard=predict(bundle,base,df)
    marginal=np.column_stack([p[:,0],np.diff(p,axis=1),1-p[:,-1]])
    assert np.max(np.abs(marginal.sum(axis=1)-1))<1e-9
    pred=df[['event_id','user_id','credit_serial_id','settled_serial_id','as_of_time','vir_date','successful_loan_count','credit_direction','risk_product']].copy()
    prodnames=json.loads((ROOT/'datasets/product_feature_names.json').read_text());prod=np.load(ROOT/'datasets/product_features.npy',mmap_mode='r');pp={n:i for i,n in enumerate(prodnames)}
    pred['product_count']=prod[:,pp['prod_current_count']].astype(int)
    pred['product_feature_partial_missing']=prod[:,pp['prod_profile_partial_missing']].astype(int)
    pred['product_feature_all_missing']=prod[:,pp['prod_profile_all_missing']].astype(int)
    enames,encoded=encode(df,bundle['encoder']);ep={n:i for i,n in enumerate(enames)}
    pred['unseen_product_count']=encoded[:,ep['product_unknown_count']].astype(int)
    pred['unseen_product_combo']=encoded[:,ep['product_combo_unseen']].astype(int)
    for j,h in enumerate(HORIZONS):pred[f'p_apply_d{h}']=p[:,j];pred[f'actual_d{h}']=df[f'y_d{h}'].to_numpy()
    for j,c in enumerate(['p_d0','p_d1_3','p_d4_7','p_d8_15','p_no_apply_d15']):pred[c]=marginal[:,j]
    pred['split']=np.where(sample_mask(df,CONTRACT['final_train_end_exclusive'],strategy),'final_training','scoring_only')
    for key,label in [('fresh_retrospective_holdout','fresh_holdout'),('legacy_retrospective_holdout','legacy_holdout')]:
        spec=CONTRACT[key];pred.loc[day_mask(df,spec['start'],spec['end']),'split']=label
    pred['model_version']=CONTRACT['version'];pred['prediction_use']='历史快照离线复核，不是当前可触达名单'
    pred.to_csv(ROOT/'T0提单时点预测模型_V4_全量预测结果.csv.gz',index=False,compression='gzip')
    pred.loc[pred.split.str.endswith('holdout')].to_csv(ROOT/'T0提单时点预测模型_V4_复核集预测.csv',index=False,encoding='utf-8-sig')
    pred.head(2000).to_csv(ROOT/'预测结果样例_本地.csv',index=False,encoding='utf-8-sig')
    np.save(ROOT/'datasets/event_predictions.npy',p)
    # Save final encoder input and actual expanded training matrix for full reproducibility.
    full=np.lib.format.open_memmap(ROOT/'datasets/model_features.npy',mode='w+',dtype='float32',shape=(len(df),len(bundle['features'])))
    for st in range(0,len(df),10000):full[st:st+10000]=np.column_stack([base[st:st+10000],encoded[st:st+10000]])[:,bundle['columns']]
    full.flush();save_json(ROOT/'datasets/model_feature_names.json',bundle['features']);save_json(ROOT/'datasets/categorical_mappings.json',bundle['encoder'])
    trainrows=np.flatnonzero(sample_mask(df,fold['train_end'],strategy));risk=expand(df.iloc[trainrows].assign(matrix_row=trainrows))
    risk[['event_id','matrix_row','interval_id','interval_length','interval_start_day','hazard_label']].to_csv(ROOT/'datasets/training_risk_rows.csv.gz',index=False,compression='gzip')
    trainmatrix=np.lib.format.open_memmap(ROOT/'datasets/training_features.npy',mode='w+',dtype='float32',shape=(len(risk),len(bundle['features'])))
    for st in range(0,len(risk),10000):
        z=risk.iloc[st:st+10000];trainmatrix[st:st+len(z)]=block(base,encoded,names,enames,z.matrix_row.to_numpy(int),bundle['columns'],z.interval_id.to_numpy(int))
    trainmatrix.flush()
    pd.DataFrame(bundle['dropped']).to_csv(ROOT/'analysis/训练期常量特征排除.csv',index=False,encoding='utf-8-sig')
    pd.DataFrame({'feature':bundle['features'],'gain':bundle['model'].feature_importances_}).sort_values('gain',ascending=False).to_csv(ROOT/'analysis/feature_importance.csv',index=False,encoding='utf-8-sig')
    summary=dict(selected=selected,train_events=len(trainrows),training_risk_rows=len(risk),selected_features=len(bundle['features']),
        scored_events=len(df),calibration='sigmoid' if chosen else 'identity',experiments=history,
        product_code_vocab=len(bundle['encoder']['product_codes']),known_product_combos=len(bundle['encoder']['product_combos']),
        monotonic_violations=int((np.diff(p,axis=1)<-1e-12).any(axis=1).sum()),partial_missing_scored=int(pred.product_feature_partial_missing.sum()),
        all_missing_scored=int(pred.product_feature_all_missing.sum()),seconds=round(time.time()-at,1),model_frozen_before_holdout=True,
        original_mother_unchanged=True,labels_unchanged=True,old_versions_preserved=True,contract=CONTRACT)
    save_json(ROOT/'training_summary.json',summary);print('TRAINING_COMPLETE',summary['selected']['tag'],'events',len(pred),flush=True)

if __name__=='__main__':main()
