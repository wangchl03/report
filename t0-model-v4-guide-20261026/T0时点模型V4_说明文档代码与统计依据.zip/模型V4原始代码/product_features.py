"""Product sets and user offer-choice lifecycle, strictly available before T0.

Current product_info values are not used here: the source has no effective dates.
Profiles are weighted aggregates of known contracts before each offer's calendar day.
Historical same-serial conversions are observed only before the current prediction.
"""
from common import np,pd
from functools import lru_cache

ATTRS=['fee','daily','days','terms']
ATTR_CN={'fee':'息费率','daily':'日息','days':'账期天数','terms':'期次'}
SPECS={}

def tokens(value):
    if value is None or pd.isna(value):return ()
    return tuple(sorted({p.strip() for p in str(value).split(',') if p.strip() and p.strip().lower() not in ['nan','none','missing']}))

def put(out,name,value,definition,formula='',unit='数值'):
    out[name]=float(value) if value is not None and np.isfinite(value) else np.nan
    SPECS.setdefault(name,dict(feature=name,family='产品条件与选择生命周期',definition_cn=definition,
        formula=formula or definition,unit=unit,
        missing_policy='数值不匹配/历史不足/零分母为NaN；无该行为为0；部分缺失单独标记，不删事件',
        time_policy='当前产品在T0已获额；历史获额/提单严格早于T0；画像合同日期严格早于对应获额日期'))

def ratio(a,b):return a/b if b>0 and np.isfinite(b) else np.nan

def describe(out,prefix,values,label,lags=True):
    a=np.asarray(values,dtype=float);ix=np.flatnonzero(np.isfinite(a));v=a[ix]
    put(out,prefix+'_valid_n',len(v),label+'有效值数量',unit='次')
    for op in ['mean','std','min','max']:
        put(out,prefix+'_'+op,getattr(np,op)(v) if len(v) else np.nan,label+'全生命周期'+op)
    center=ix-ix.mean() if len(ix) else ix
    slope=np.sum(center*(v-v.mean()))/np.sum(center**2) if len(v)>1 else np.nan
    put(out,prefix+'_slope',slope,label+'随历史获额序列的线性变化斜率')
    for n in [3,5]:
        z=a[-n:];z=z[np.isfinite(z)]
        put(out,prefix+f'_last{n}_mean',z.mean() if len(z) else np.nan,label+f'最近{n}次均值')
    put(out,prefix+'_recent_lifetime_delta',out[prefix+'_last3_mean']-out[prefix+'_mean'],label+'最近3次均值减生命周期均值')
    if lags:
        for n in [1,2,3]:put(out,prefix+f'_l{n}',a[-n] if len(a)>=n else np.nan,label+f'最近第{n}次值（不跳过缺失）')
        put(out,prefix+'_delta12',a[-1]-a[-2] if len(a)>=2 else np.nan,label+'最近一次减上一次')

def streak(flag):
    best=current=run=0
    for b in flag:
        run=run+1 if b else 0;best=max(best,run)
    current=run
    return current,best

class Profiles:
    def __init__(self,frame):
        frame=frame.copy();frame.profile_date=pd.to_datetime(frame.profile_date)
        self.data={}
        for code,g in frame.groupby('product_no',sort=False):
            g=g.sort_values('profile_date')
            numeric=['orders','remit_sum','fee_sum','day_sum','day_n','term_sum','term_n']
            self.data[str(code)]=(g.profile_date.to_numpy('datetime64[D]'),g[numeric].to_numpy(float).cumsum(axis=0))

    @lru_cache(maxsize=100000)
    def get(self,code,day):
        if code not in self.data:return (np.nan,np.nan,np.nan,np.nan,0)
        dates,agg=self.data[code];i=np.searchsorted(dates,np.datetime64(day,'D'),side='left')-1
        if i<0:return (np.nan,np.nan,np.nan,np.nan,0)
        n,remit,fee,days,dn,terms,tn=agg[i]
        fr=ratio(fee,remit);dy=ratio(days,dn);tm=ratio(terms,tn)
        return fr,ratio(fr,dy),dy,tm,n

    def choice(self,ps,day):
        vals=np.array([self.get(p,day)[:4] for p in ps],dtype=float).reshape(-1,4)
        best=[]
        for j,a in enumerate(ATTRS):
            v=vals[:,j];v=v[np.isfinite(v)]
            best.append((v.min() if a in ['fee','daily'] else v.max()) if len(v) else np.nan)
        return vals,np.asarray(best)

def snapshot(hist,t,current_products,profiles,previous,loan_count):
    """hist: ordered records (offer_time, tokens, serial, apply_time, selected_product)."""
    hist=[z for z in hist if z[0]<t]
    out={};ps=tokens(current_products);day=str(pd.Timestamp(t).date())
    values,current=profiles.choice(ps,day)
    n=len(ps)
    put(out,'prod_current_count',n,'本次risk_product去重后的产品数量',unit='个')
    put(out,'prod_source_missing',int(n==0),'原始risk_product为空标记',unit='标记')
    put(out,'prod_current_single',int(n==1),'本次只有一个可选产品',unit='标记')
    put(out,'prod_current_multi',int(n>=2),'本次有两个及以上可选产品',unit='标记')
    matched=np.isfinite(values).all(axis=1).sum() if n else 0
    put(out,'prod_profile_match_count',matched,'预测日前历史画像四项齐全的产品数量',unit='个')
    put(out,'prod_profile_missing_count',n-matched,'缺少预测日前画像的产品数量',unit='个')
    put(out,'prod_profile_partial_missing',int(0<matched<n),'部分可选产品画像缺失',unit='标记')
    put(out,'prod_profile_all_missing',int(matched==0),'全部可选产品画像缺失（含risk_product为空）',unit='标记')
    put(out,'prod_profile_match_share',ratio(matched,n),'可选产品画像完整覆盖比例',unit='比例')
    for j,a in enumerate(ATTRS):
        v=values[:,j];v=v[np.isfinite(v)]
        for op in ['min','max','mean']:
            put(out,'prod_current_'+a+'_'+op,getattr(np,op)(v) if len(v) else np.nan,'本次可选产品'+ATTR_CN[a]+op)
        put(out,'prod_current_'+a+'_range',v.max()-v.min() if len(v)>=2 else (0 if len(v)==1 and n==1 else np.nan),'本次可选产品'+ATTR_CN[a]+'差距')
        put(out,'prod_current_'+a+'_best',current[j],'本次'+ATTR_CN[a]+'最优值（费率最低、期限最长，分别选择）')
        put(out,'prod_current_'+a+'_missing_n',n-len(v),'本次产品'+ATTR_CN[a]+'缺失数量',unit='个')
        prev=previous[j]
        put(out,'prod_'+a+'_change_vs_previous',current[j]-prev,'本次最优'+ATTR_CN[a]+'减触发T0已结清订单实际值')
        put(out,'prod_'+a+'_ratio_vs_previous',ratio(current[j],prev),'本次最优'+ATTR_CN[a]+'除以上一笔实际值')
        tol=.01 if a=='fee' else (.0005 if a=='daily' else 0)
        delta=current[j]-prev
        direction=(0 if abs(delta)<tol or delta==0 else np.sign(delta)) if np.isfinite(delta) else np.nan
        put(out,'prod_'+a+'_change_direction',direction,'产品条件变化方向；息费差绝对值<1pp、日息差<0.05pp视为不变；等号不归不变')
        for k in [0,1]:
            put(out,f'prod_slot{k+1}_{a}',values[k,j] if n>k else np.nan,f'按产品编号排序的第{k+1}个产品'+ATTR_CN[a])
    # Do not synthesize a nonexistent product by multiplying independent best conditions.
    complete=np.isfinite(values).all(axis=1) if n else np.asarray([],bool)
    low_fee=np.nanargmin(values[:,0]) if n and np.isfinite(values[:,0]).any() else None
    long_days=np.nanargmax(values[:,2]) if n and np.isfinite(values[:,2]).any() else None
    put(out,'prod_best_fee_and_days_same_product',int(low_fee==long_days) if low_fee is not None and long_days is not None else np.nan,'最低息费与最长账期是否来自同一个实际产品',unit='标记')
    put(out,'prod_low_fee_product_days',values[low_fee,2] if low_fee is not None else np.nan,'最低息费产品自身的账期，保持实际方案完整性')
    put(out,'prod_long_days_product_fee',values[long_days,0] if long_days is not None else np.nan,'最长账期产品自身的息费率，保持实际方案完整性')

    count=np.asarray([len(h[1]) for h in hist],float);hn=len(hist)
    put(out,'prod_hist_offer_n',hn,'本次自动获额批次之前的20秒去重通过获额次数',unit='次')
    seen={p for h in hist for p in h[1]}
    put(out,'prod_hist_distinct_product_n',len(seen),'生命周期曾获额的不同产品数量',unit='个')
    put(out,'prod_current_never_offered_count',sum(p not in seen for p in ps),'本次产品中用户此前从未获额的产品数',unit='个')
    put(out,'prod_current_seen_share',ratio(sum(p in seen for p in ps),n),'本次产品在用户既往获额中出现过的比例')
    last=set(hist[-1][1]) if hn else set()
    put(out,'prod_overlap_previous_offer',ratio(len(set(ps)&last),len(set(ps)|last)) if hn else np.nan,'本次与上一批获额产品集合的Jaccard相似度')
    switches=[hist[i][1]!=hist[i-1][1] for i in range(1,hn)]
    put(out,'prod_hist_combo_switch_n',sum(switches),'历史相邻获额产品组合切换次数',unit='次')
    put(out,'prod_hist_combo_switch_share',ratio(sum(switches),len(switches)),'历史产品组合切换率')
    for label,flag in [('single',count==1),('multi',count>=2)]:
        put(out,'prod_hist_'+label+'_n',flag.sum(),'历史'+label+'产品获额次数',unit='次')
        put(out,'prod_hist_'+label+'_share',ratio(flag.sum(),hn),'历史'+label+'产品获额占比')
        cs,ms=streak(flag)
        put(out,'prod_hist_'+label+'_current_streak',cs,'最近连续'+label+'产品获额次数',unit='次')
        put(out,'prod_hist_'+label+'_max_streak',ms,'生命周期最长连续'+label+'产品获额次数',unit='次')
        for w in [30,90]:
            ix=np.asarray([h[0]>=pd.Timestamp(t)-pd.Timedelta(days=w) for h in hist],bool)
            put(out,f'prod_hist_{label}_share_{w}d',ratio((flag&ix).sum(),ix.sum()),f'最近{w}天'+label+'产品获额占比')
    put(out,'prod_hist_single_to_multi_n',int(((count[:-1]==1)&(count[1:]>=2)).sum()),'历史单产品切换为多产品的次数',unit='次')
    put(out,'prod_hist_multi_to_single_n',int(((count[:-1]>=2)&(count[1:]==1)).sum()),'历史多产品切换为单产品的次数',unit='次')
    for k in [1,2,3]:put(out,f'prod_hist_choice_n_l{k}',count[-k] if hn>=k else np.nan,f'历史最近第{k}次可选产品数量',unit='个')
    history_best=np.array([profiles.choice(h[1],str(h[0].date()))[1] for h in hist],float).reshape(-1,4)
    for j,a in enumerate(ATTRS):
        describe(out,'prod_hist_best_'+a,history_best[:,j],'生命周期每次获额最优'+ATTR_CN[a])
        put(out,'prod_'+a+'_change_vs_last_offer',current[j]-history_best[-1,j] if hn else np.nan,'当前最优'+ATTR_CN[a]+'减上一批获额条件')
        delta=np.diff(history_best[:,j]);valid=np.isfinite(delta)
        threshold=.01 if a=='fee' else (.0005 if a=='daily' else 0)
        for label,mask in [('up',delta>=threshold if threshold else delta>0),('down',delta<=-threshold if threshold else delta<0)]:
            mask=mask&valid
            put(out,f'prod_hist_{a}_{label}_n',mask.sum(),'历史'+ATTR_CN[a]+label+'次数',unit='次')
            put(out,f'prod_hist_{a}_{label}_share',ratio(mask.sum(),valid.sum()),'历史'+ATTR_CN[a]+label+'占比')
            cs,ms=streak(mask)
            put(out,f'prod_hist_{a}_{label}_current_streak',cs,'最近连续'+ATTR_CN[a]+label+'次数',unit='次')
    # Order-level historical offer conversion. Nonapplication only after window maturity.
    for label,flag in [('single',count==1),('multi',count>=2),('all',np.ones(hn,bool))]:
        for h,end in zip([0,3,7,15],[1,4,8,16]):
            denom=hit=0
            for z,is_choice in zip(hist,flag):
                right=min(z[0].normalize()+pd.Timedelta(days=end),z[0]+pd.Timedelta(days=15))
                if is_choice and right<=t:
                    denom+=1
                    hit+=int(pd.notna(z[3]) and z[0]<=z[3]<right and z[3]<t)
            put(out,f'prod_hist_{label}_mature_n_d{h}',denom,f'历史{label}产品获额D{h}已成熟分母（原订单15天有效期）',unit='次')
            put(out,f'prod_hist_{label}_apply_rate_d{h}',ratio(hit,denom),f'历史{label}产品获额D{h}同serial提单率（仅预测前已成熟）',unit='比例')
    pending=sum(z[0]+pd.Timedelta(days=15)>t and (pd.isna(z[3]) or z[3]>=t) for z in hist)
    put(out,'prod_hist_pending_unapplied_n',pending,'尚未满15天且截至当前未提单的历史获额数；不当成最终未提单',unit='次')
    sel_n=fee_n=daily_n=days_n=0
    for z in hist:
        if len(z[1])<2 or pd.isna(z[3]) or not(z[0]<=z[3]<min(t,z[0]+pd.Timedelta(days=15))) or z[4] not in z[1]:continue
        vv,_=profiles.choice(z[1],str(z[0].date()))
        if not np.isfinite(vv).all():continue
        selected=z[1].index(z[4]);sel_n+=1
        fee_n+=int(vv[selected,0]<=vv[:,0].min()+1e-10)
        daily_n+=int(vv[selected,1]<=vv[:,1].min()+1e-10)
        days_n+=int(vv[selected,2]>=vv[:,2].max()-1e-10)
    put(out,'prod_hist_multi_selected_known_n',sel_n,'历史多产品且已提单、可核验选择偏好的次数',unit='次')
    for label,number in [('low_fee',fee_n),('low_daily',daily_n),('long_days',days_n)]:
        put(out,'prod_hist_selected_'+label+'_share',ratio(number,sel_n),'历史多产品选择'+label+'方案的占比')
    put(out,'prod_fee_change_x_loan_count',out['prod_fee_change_vs_previous']*loan_count,'息费变化×已成功放款次数')
    put(out,'prod_days_change_x_loan_count',out['prod_days_change_vs_previous']*loan_count,'账期变化×已成功放款次数')
    audit={'history_n':hn,'latest_history_time':str(hist[-1][0]) if hn else None,
        'future_history_used':any(z[0]>=t for z in hist),'profile_policy':'contracts before offer day',
        'partial_missing':int(0<matched<n),'all_missing':int(matched==0)}
    return out,audit
