from pathlib import Path
import json,html,re,zipfile,shutil,hashlib
W=Path(__file__).resolve().parent;ROOT=W.parents[1]
OUT=ROOT/'outputs/T7两类流失用户_产品选择与盈利风险分析_20261110';OUT.mkdir(exist_ok=True)
D=json.loads((W/'analysis.json').read_text());S=json.loads((W/'source_workbooks.json').read_text());POPS=list(D)
C={'bg':'#06192b','surface':'#0c2944','ink':'#eff8ff','muted':'#aac5da','body':'#c7dceb','line':'#2a5c7e','single':'#43c7e7','dual':'#b4a2f3','long':'#64dcae','short':'#ffc26b','risk':'#f68ab0'}
def esc(s):return html.escape(str(s),quote=True)
def n(v):return f'{v:,.0f}'
def p(v,d=2):return '—' if v is None else f'{v*100:.{d}f}%'
def pp(v):return '—' if v is None else f'{v*100:+.2f}pp'
def money(v):return f'{v:,.2f}'
def diff(r,k):return r['long'][k]-r['short'][k] if r['long'][k] is not None and r['short'][k] is not None else None
def txt(x,y,s,size=12,c='body',weight=400,anchor='start'):
 size=13 if size<=11 else 14 if size<=13 else 16 if size<=15 else size
 return f'<text x="{x:.2f}" y="{y:.2f}" font-size="{size}" fill="{C.get(c,c)}" font-weight="{weight}" text-anchor="{anchor}">{esc(s)}</text>'
def tip(s):return f'data-tip="{esc(s)}" tabindex="0"'
def rect(x,y,w,h,c,extra='',rx=4):return f'<rect x="{x:.2f}" y="{y:.2f}" width="{max(0,w):.2f}" height="{max(0,h):.2f}" rx="{rx}" fill="{C.get(c,c)}" {extra}/>'
def line(x,y,x2,y2,c='line',width=1,extra=''):return f'<line x1="{x:.2f}" y1="{y:.2f}" x2="{x2:.2f}" y2="{y2:.2f}" stroke="{C.get(c,c)}" stroke-width="{width}" {extra}/>'
def circle(x,y,r,c,extra=''):return f'<circle cx="{x:.2f}" cy="{y:.2f}" r="{r}" fill="{C.get(c,c)}" {extra}/>'
def svg(s,w,h,label):return f'<div class="chart-frame" style="--chart-min:{w}px"><svg viewBox="0 0 {w} {h}" role="img" aria-label="{esc(label)}"><title>{esc(label)}</title>{s}</svg></div>'
def table(headers,rows):
 return '<div class="table-scroll"><table><thead><tr>'+''.join('<th>'+esc(x)+'</th>' for x in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+str(x)+'</td>' for x in row)+'</tr>' for row in rows)+'</tbody></table></div>'
def detail(label,body):return '<details class="table-fold"><summary>'+label+'</summary>'+body+'</details>'
def insight(s,cls=''):return '<div class="insight-strip '+cls+'"><i class="dot"></i><div>'+s+'</div></div>'
def finding(title,items,cls=''):
 return '<aside class="finding-block '+cls+'"><h3>'+title+'</h3><ul>'+''.join('<li><b>'+label+'</b><span>'+value+'</span></li>' for label,value in items)+'</ul></aside>'
def panel(title,caption,body):return '<article class="panel"><div class="panel-head"><div><h3>'+title+'</h3>'+('<p class="caption">'+caption+'</p>' if caption else '')+'</div></div><div class="panel-body">'+body+'</div></article>'
def section(i,id,title,sub,body):return f'<section class="section" id="{id}"><div class="section-head"><div class="section-num">{i:02}</div><div><h2>{title}</h2>'+('<p class="section-sub">'+sub+'</p>' if sub else '')+f'</div></div>{body}</section>'
def legend(items):return '<div class="legend">'+''.join(f'<span><i class="swatch" style="background:{C[k]}"></i>{v}</span>' for k,v in items)+'</div>'
def population_tabs(tag):return '<div class="population-tabs segmented" role="group" aria-label="选择'+tag+'客群">'+''.join(f'<button type="button" data-pop="{name}" aria-pressed="{str(i==0).lower()}">{name}</button>' for i,name in enumerate(POPS))+'</div>'
def population_panels(fn):return ''.join('<div class="population-panel" data-population="'+name+'"'+(' hidden' if i else '')+'>'+fn(name,D[name])+'</div>' for i,name in enumerate(POPS))

# Main source ratios, always separately by population.
body='<section id="overview" class="summary-block">'
body+='<div class="decision"><span class="decision-kicker">核心结论</span><h2>推进较长账期，优先扩大21/28天主力组合</h2><ol class="executive-findings">'
for title,items in [
 ('选择偏好明确',[('新增流失','87.70%选择较长账期'),('活跃流失','88.34%选择较长账期')]),
 ('总体盈利更高',[('新增流失','长账期高3.92pp'),('活跃流失','长账期高9.47pp')]),
 ('当前逾期也更高',[('新增流失','长账期高2.91pp'),('活跃流失','长账期高1.93pp')]),
 ('按产品分层推进',[('21/28天','优先扩大主力供给'),('60天','持续跟踪成熟表现')])]:
 body+='<li><h3>'+title+'</h3><dl>'+''.join('<div><dt>'+k+'</dt><dd>'+v+'</dd></div>' for k,v in items)+'</dl></li>'
body+='</ol><p class="decision-footnote">选择比例分母：双产品首单。盈利差、逾期差：较长账期减较短账期。</p></div>'
body+='</section>'

# Supply mix and actual choices.
s=''
for i,name in enumerate(POPS):
 r=D[name];y=38+i*88;L=125;bw=850;s+=txt(0,y+22,name,14,'ink',650);x=L
 for key in ['single','dual']:
  count=r[key]['first'];width=bw*count/r['first'];s+=rect(x,y,width,35,key,tip(f'{name} · {"单产品" if key=="single" else "双产品"}首单\n{n(count)} / {n(r["first"])} · {p(count/r["first"])}'))
  s+=txt(x+width/2,y+23,p(count/r['first']),15,'bg',750,'middle');x+=width
 s+=txt(L,y+58,f'单产品 {n(r["single"]["first"])}笔；双产品 {n(r["dual"]["first"])}笔；异常 {n(r["anomalies"])}笔',12,'muted')
 s+=txt(1105,y+23,n(r['first'])+'笔',12,'body',600,'end')
composition=panel('已提单人群中，单产品仍占多数','按每批每位用户召回后的首笔提单统计。',legend([('single','单产品获额首单'),('dual','双产品获额首单')])+svg(s,1120,218,'两类流失用户首次提单的产品供给结构'))
rows=[]
for name,r in D.items():rows.append([name,n(r['recall']),n(r['first']),n(r['single']['first']),p(r['single']['first']/r['first']),n(r['dual']['first']),p(r['dual']['first']/r['first']),n(r['anomalies'])])
composition+=detail('查看首单分类与分母',table(['客群','召回人次','有首单人次','单产品首单','占全部首单','双产品首单','占全部首单','异常首单'],rows))
composition+=finding('双产品覆盖：活跃流失更高',[('双产品占首单','新增35.85%；活跃43.05%'),('客群差值','活跃流失高7.20pp'),('经营方向','扩大符合准入条件用户的双产品供给')])

def preference(name,r):
 Wd=1080;L=140;R=940;X=lambda v:L+(v-.75)/.25*(R-L);h=60+len(r['batches'])*41;s=''
 for v in [.75,.8,.85,.9,.95,1]:s+=line(X(v),28,X(v),h-25)+txt(X(v),17,p(v,0),11,'muted',anchor='middle')
 for i,b in enumerate(r['batches']):
  y=49+i*41;v=b['long']['first']/b['dual'];s+=txt(0,y+4,b['batch'],13,'ink',650)+line(X(.75),y,X(v),y,'#3a6381',3)+circle(X(v),y,5,'long',tip(f'{name} {b["batch"]}\n较长账期 {n(b["long"]["first"])} / {n(b["dual"])}笔\n占比 {p(v)}'))+txt(X(v)+11,y+4,p(v),12,'long',650)+txt(1075,y+4,f'{n(b["long"]["first"])} / {n(b["dual"])}',11,'body',anchor='end')
 return '<div class="chart-scroll">'+svg(s,Wd,h,name+'各批次双产品长账期选择率')+'</div>'
composition+=panel('各批次均偏好较长账期','横轴从75%开始，便于比较批次差异。长账期按同一次获额组合中的较长选项识别。',population_tabs('偏好')+population_panels(preference))
composition+=finding('长账期偏好：各批次一致',[('新增各批','85.77%—90.29%'),('活跃各批','87.57%—88.81%'),('偏好结论','两类客群、各召回批次均集中选择较长账期')])
body+=section(1,'choice','产品供给与长账期选择','来源：两表《批次汇总》及《获额组合与提单产品》。合计保留跨批重复。',composition)

# Financial overview, full table + paired charts.
rows=[]
for name,r in D.items():
 for key,label in [('single','单产品'),('dual','双产品合计'),('long','双产品中较长账期'),('short','双产品中较短账期')]:
  z=r[key];rows.append([name,'<b style="color:'+C[key]+'">'+label+'</b>',n(z['first']),n(z['mature']),p(z['profit']),f'{n(z["overdue_n"])} / {n(z["mature"])}',p(z['overdue'])])
financial=panel('单双产品与长短账期的盈利、风险总览','按各产品分组的到期放款订单统计。',table(['客群','获额及选择分组','首单数','到期放款订单','到期盈利率','当前逾期 / 到期','当前订单逾期率'],rows))
financial+='<div class="grid-equal space-top">'
for metric,title,xmax,ticks in [('profit','长账期盈利率更高',.30,[0,.1,.2,.3]),('overdue','长账期当前逾期率也更高',.4,[0,.1,.2,.3,.4])]:
 L=130;R=510;X=lambda v:L+v/xmax*(R-L);s=''
 for t in ticks:s+=line(X(t),30,X(t),165)+txt(X(t),191,p(t,0),10,'muted',anchor='middle')
 for i,(name,r) in enumerate(D.items()):
  y=65+i*76;a=r['short'][metric];b=r['long'][metric];s+=txt(0,y+5,name,13,'ink',650)+line(X(a),y,X(b),y,'#466f8e',5)
  for v,c,dy in [(a,'short',22),(b,'long',-14)]:s+=circle(X(v),y,5,c,tip(name+' · '+('较长账期' if c=='long' else '较短账期')+'\n'+p(v)))+txt(X(v),y+dy,p(v),12,c,650,'middle')
 financial+=panel(title,'每个点为同组到期订单的汇总表现。',legend([('long','较长账期'),('short','较短账期')])+svg(s,560,210,title))
financial+='</div>'+finding('双产品与单产品的总体差异',[('新增流失','双产品盈利率高3.80pp；逾期率高0.66pp'),('活跃流失','双产品盈利率高0.52pp；逾期率低0.98pp'),('经营判断','双产品整体盈利水平更高，优先拓展长账期选择空间')])
financial+=detail('查看双产品长短账期的金额核算',table(['客群','组别','到期单量','到期放款本金','截至快照已还金额','已还减本金','盈利率'],[[name,'较长' if key=='long' else '较短',n(r[key]['mature']),money(r[key]['remit']),money(r[key]['repaid']),money(r[key]['profit_amount']),p(r[key]['profit'])] for name,r in D.items() for key in ['long','short']]))
body+=section(2,'financial','总体盈利与当前逾期','',financial)

# Within-batch outcomes and sensitivity.
def batch_financial(name,r):
 rows=[]
 for b in r['batches']:
  rows.append([b['batch'],str(b['days'])+'天',n(b['long']['mature']),n(b['short']['mature']),p(b['long']['profit']),p(b['short']['profit']),pp(diff(b,'profit')),p(b['long']['overdue']),p(b['short']['overdue']),pp(diff(b,'overdue'))])
 return table(['批次','跟访天数','较长到期','较短到期','较长盈利率','较短盈利率','盈利差','较长逾期率','较短逾期率','逾期差'],rows)
batch=panel('各批次长短账期盈利与逾期表现','差值均为较长账期减较短账期。',population_tabs('批次')+population_panels(batch_financial))
batch+=finding('各批次盈利表现分布',[('新增较长更高','0818、0902'),('新增较短更高','0910、0917、0930'),('活跃较长更高','0903、0910'),('活跃较短更高','0918')])
batch+=panel('不同批次范围的汇总表现','','<div class="segmented scope-tabs" role="group" aria-label="选择批次汇总范围"><button type="button" data-scope="all" aria-pressed="true">全部批次</button><button type="button" data-scope="early" aria-pressed="false">仅9月底前</button></div><div id="sensitivitySummary" class="scope-results"></div><div id="sensitivityTable"></div>')
body+=section(3,'batches','批次差异与汇总敏感性','各批次统一统计至业务日2026年11月5日。',batch)

# Specific products and identical-composition reweighting.
def combo_table(name,r):
 rows=[]
 for z in r['term_combos']:
  rows.append([f'{z["period"][0]}天 / {z["period"][1]}天',n(z['first']),p(z['first']/r['dual']['first']),p(z['long_share']),n(z['long']['mature'])+' / '+n(z['short']['mature']),p(z['long']['profit'])+' / '+p(z['short']['profit']),p(z['long']['overdue'])+' / '+p(z['short']['overdue'])])
 return table(['本次获额账期组合','双产品首单','占双产品首单','选择较长占比','较长 / 较短到期','较长 / 较短盈利率','较长 / 较短逾期率'],rows)
products=panel('选择较长账期，主要发生在21天与28天之间','按本次获额组合区分较长与较短账期。',population_tabs('产品组合')+population_panels(combo_table))
products+=finding('推进对象：具体组合优先',[('21/28天占双产品','新增85.17%；活跃84.61%'),('14/21天较长侧盈利','新增−19.48%；活跃−49.90%'),('经营含义','扩大21/28天主力供给，专项治理14/21天负盈利组合')],'risk-note')
rows=[]
for name,r in D.items():
 z=r['pairs'][0];assert z['pair']=='40285 + 302125'
 rows.append([name,n(z['first']),p(z['first']/r['dual']['first']),p(z['long_share']),n(z['long']['mature'])+' / '+n(z['short']['mature']),p(z['long']['profit'])+' / '+p(z['short']['profit']),p(z['long']['overdue'])+' / '+p(z['short']['overdue'])])
products+=panel('优先组合：40285（28天）与302125（21天）','主力产品组合的选择、盈利与逾期表现。',table(['客群','组合首单','占双产品首单','选择28天占比','28天 / 21天到期','28天 / 21天盈利率','28天 / 21天逾期率'],rows))
stdrows=[]
for name,r in D.items():
 z=r['standardized']['10'];stdrows.append([name,str(z['cells']),n(z['long_mature'])+' / '+n(z['short_mature']),p(z['long_profit']),p(z['short_profit']),pp(z['long_profit']-z['short_profit']),p(z['long_overdue']),p(z['short_overdue']),pp(z['long_overdue']-z['short_overdue'])])
products+=detail('查看同批次、同产品组合的统一构成复核', '<div class="appendix-content method-copy"><p>保留同一“批次×产品编号组合”中较长、较短两侧各至少10笔到期的格子。盈利率统一按每格两侧合计到期本金赋权，逾期率统一按每格两侧合计到期订单数赋权。同一项指标的长短两侧使用相同权重。</p><p>标准化结果统一批次与产品组合权重；活跃流失的3个保留格子均为主力产品组合。</p></div>'+table(['客群','保留格子','较长 / 较短到期','较长标准化盈利率','较短标准化盈利率','差值','较长标准化逾期率','较短标准化逾期率','差值'],stdrows))
products+=detail('查看全部产品编号组合与选择结果',population_panels(lambda name,r:table(['获额组合','首单','较长选择率','较长 / 较短到期','较长 / 较短盈利率','较长 / 较短逾期率'],[[esc(z['label']),n(z['first']),p(z['long_share']),n(z['long']['mature'])+' / '+n(z['short']['mature']),p(z['long']['profit'])+' / '+p(z['short']['profit']),p(z['long']['overdue'])+' / '+p(z['short']['overdue'])] for z in r['pairs']])))
body+=section(4,'products','产品组合与优先推进对象','按产品编号组合及实际提单选择汇总。',products)

# Maturity, actual term distributions.
s=''
for i,(name,r) in enumerate(D.items()):
 t=next(z for z in r['terms'] if z['days']==60);y=40+i*91;L=145;bw=830;s+=txt(0,y+18,name,14,'ink',650)+rect(L,y,bw,25,'#173e58')+rect(L,y,bw*t['mature']/t['funded'],25,'long',tip(f'{name} 60天产品\n放款{n(t["funded"])}笔，整笔到期{n(t["mature"])}笔\n到期覆盖{p(t["mature"]/t["funded"])}'))+txt(L,y+49,f'60天首单 {n(t["first"])}笔；成功放款 {n(t["funded"])}笔；整笔到期仅 {n(t["mature"])}笔',12,'muted')+txt(1100,y+18,p(t['mature']/t['funded']),14,'long',750,'end')
maturity=panel('60天到期样本：新增11笔，活跃2笔','背景条为各客群60天成功放款首单；绿色为截至原快照已经整笔到期的部分。',legend([('long','已经整笔到期')])+svg(s,1120,214,'60天产品放款与到期覆盖'))
maturity+=finding('60天产品的到期表现与跟踪重点',[('已到期盈利率','新增62.07%；活跃63.17%'),('对应到期样本','新增11笔；活跃2笔'),('最大60天组合','4028（28天）+40602（60天）'),('该组合60天侧','两类客群均为0笔整笔到期'),('经营安排','持续跟踪60天产品新增到期批次')],'risk-note')
rows=[]
for name,r in D.items():
 for key,label in [('long','相对较长'),('short','相对较短')]:
  z=r[key];rows.append([name,label,n(z['funded']),n(z['mature']),p(z['maturity'])])
maturity+=detail('查看长短两组的到期覆盖差异',table(['客群','组别','成功放款首单','整笔到期','到期覆盖率'],rows))
maturity+=finding('长短账期到期覆盖情况',[('新增到期覆盖','较长46.60%；较短57.93%'),('活跃到期覆盖','较长28.34%；较短37.84%'),('还款与状态','均取原表11月5日快照'),('跟踪安排','分账期更新到期订单与回款表现')])
body+=section(5,'maturity','60天产品的到期成熟度','数据时点：北京时间2026年11月6日。',maturity)

# Actions grounded in evidence, no fabricated rollout thresholds.
actions='<div class="evidence-grid">'
for tag,title,facts,steps in [
 ('优先推进','21/28天主力组合',[
  ('产品','40285（28天）与302125（21天）'),
  ('选择','两类客群均集中选择28天产品'),
  ('收益','两类客群28天盈利率均高于21天')],
  ['优先扩大符合准入用户的较长账期供给','强化28天产品展示，保留21天选择','分组评估转化、盈利和逾期变化']),
 ('供给拓展','符合准入的单产品用户',[
  ('供给结构','单产品占首单56.88%—64.13%'),
  ('用户偏好','双产品用户约88%选择较长账期'),
  ('经营方向','提升符合准入用户的产品可选性')],
  ['识别具备双产品资格的单产品用户','增加较长账期选项','跟踪供给覆盖与提单转化']),
 ('重点治理','14/21天负盈利组合',[
  ('新增流失','较长侧盈利率−19.48%'),
  ('活跃流失','较长侧盈利率−49.90%'),
  ('经营方向','按产品编号治理负盈利组合')],
  ['复核客群资质、产品定价与回款','识别负盈利的主要来源','调整供给结构与运营策略']),
 ('专项跟踪','60天产品',[
  ('选择','新增291笔；活跃462笔首单'),
  ('到期','新增11笔；活跃2笔'),
  ('经营重点','新增到期批次与回款表现')],
  ['按批次跟踪放款与到期进度','更新成熟订单盈利和逾期表现','结合成熟表现分批评估供给规模'])]:
 actions+='<article class="evidence-card"><span class="tag">'+tag+'</span><h3>'+title+'</h3><dl class="action-facts">'+''.join('<div><dt>'+label+'</dt><dd>'+value+'</dd></div>' for label,value in facts)+'</dl><div class="next-step"><b>推进动作</b><ul>'+''.join('<li>'+step+'</li>' for step in steps)+'</ul></div></article>'
actions+='</div>'
actions+=finding('建议的推进顺序',[('优先','扩大21/28天主力组合的较长账期供给'),('效果评估','分组跟踪提单转化、到期盈利率和逾期率'),('先排查','14/21天负盈利组合'),('专项跟踪','60天产品到期进度与回款表现')])
body+=section(6,'actions','分层推进与经营评估','扩大主力长账期供给，提升提单转化，持续跟踪盈利与风险。',actions)

# Methodology and reproducibility, transparent source locations.
methods=[
('输入与快照','新增流失：九批，2026-11-06 11:52:12北京时间（Belize 11-05 21:52:12）；活跃流失：七批，2026-11-06 12:02:54（Belize 11-05 22:02:54）。两表分别沿用各自查询快照。'),
('首单选取','沿用原表：每批每位用户从召回日00:00:00到截止，按apply_time、serial_id选首笔提单，再判断其获额产品。首笔不合格时，不以之后的订单替代。'),
('单双产品','单产品为一项有效产品；双产品恰有两项不同产品编号、有效且不同账期，实际提单产品属于本次获额组合。原表所有合格异账期多产品首单均为双产品，同账期多产品均为0。'),
('相对长短','本笔获额两种产品中天数更长者为较长，另一个为较短。同一个28天产品可在21/28组合中为长，在28/60组合中为短。'),
('重复与样本单位','每批内用户去重，跨批用户及相同实际订单均按原表保留。新增9,797个有首单的批次×用户，对应9,694笔实际订单；活跃10,657个对应5,039笔实际订单。实际订单数引用原表统计口径页，两类客群分别汇总。'),
('到期与放款','成功放款为is_remit=1且remit_amt>0；整笔到期为due_date有效且due_date < 2026-11-05，使用整笔最后到期日。尚未到期订单不纳入盈利、逾期分母。'),
('盈利公式','(本组到期订单SUM(repaid_amt) − SUM(remit_amt)) / SUM(remit_amt)。长短及产品组合的合计由本金、已还金额重算；单产品总体直接引用原表合计，不按订单数平均盈利率。货币单位沿用源表。'),
('逾期公式','本组到期订单中当前loan_status_code=8的订单数 / 本组整笔到期放款订单数。回款和订单状态取各自查询快照。'),
('异常与核对','新增2笔异常首单、活跃7笔，保留在全部首单分母，排除单双产品正常分类。两类客群各有1笔异常已到期首单，单产品指标直接引用原表分组结果。未使用新增表重复展示的Sheet1再次加总。'),
('黑名单与数据范围','沿用源表已排除5101518的规则与获额匹配口径。数据范围为两份首次提单产品与长账期选择工作簿。'),
('分组方式','按实际获额产品组合及用户首次提单选择分组，用于产品选择与经营表现对比。')]
appendix='<details class="appendix"><summary>统计口径与核对结果</summary><div class="appendix-content"><div class="scope-grid">'+''.join('<div class="scope-row"><b>'+a+'</b>'+b+'</div>' for a,b in methods)+'</div></div></details>'
source_rows=[]
for name,r in D.items():
 end=15 if name=='新增流失' else 13;ce=206 if name=='新增流失' else 183
 source_rows.append([name,esc(Path(r['source']).name),f'批次汇总!A5:AC{end}',f'获额组合与提单产品!A5:P{ce}',r['sha256'][:16]+'…'])
appendix+='<details class="appendix" id="sources"><summary>两份来源与可追溯位置</summary><div class="appendix-content"><p class="caption">本报告只分析用户提供的两份Excel。源表保持不变，所有金额与订单数按各自人群核对。完整SHA256、源表标准化数据及核对代码见复核附件。</p></div>'+table(['客群','来源文件','单双产品总览来源','选择、金额与产品组合来源','文件SHA256前16位'],source_rows)+'</details>'
code=(W/'analyze.py').read_text()
appendix+='<details class="appendix"><summary>完整汇总分析代码与复核附件</summary><div class="appendix-content"><div class="code-toolbar"><p>附件含两份Excel的标准化汇总内容、计算代码、分析结果及核对记录；无订单级用户明细。金额与比率重算可在离线环境完成。</p><a class="action" href="分析复核附件.zip" download>下载分析复核附件</a><a class="action" href="完整分析代码.py" download>下载完整分析代码</a></div><pre>'+esc(code)+'</pre></div></details>'
body+=section(7,'method','统计口径与复核附件','原始数据、统计口径及完整复核代码。',appendix)

reference=(ROOT/'work/report_template_dark.html').read_text();css=re.search(r'<style>(.*?)</style>',reference,re.S)[1]
css+='''
.chart-frame{overflow-x:auto}.chart-frame svg{display:block;width:100%;height:auto}.summary-block{scroll-margin-top:85px}.decision{padding:25px 30px;background:#10324f;border:1px solid #32627f;border-radius:18px}.decision-kicker{font-size:12px;color:var(--teal);font-weight:700}.decision h2{font-size:25px;line-height:1.55;color:var(--ink);margin:7px 0 12px}.decision p{font-size:15px;line-height:1.95}.risk-note{background:#2e2b3c;border-color:#67455d}.risk-note .dot{background:var(--rose)}.kpi .number{font-size:31px;letter-spacing:-.02em}.table-scroll{border-top:0}table{font-size:12px}th,td{padding:12px 13px;line-height:1.65}th{position:relative}.space-top{margin-top:18px}.population-tabs{margin:4px 0 20px}.population-panel[hidden]{display:none!important}.chart-scroll{overflow:auto}.chart-scroll svg{display:block;min-width:760px;width:100%;height:auto}.panel-body>svg{display:block;width:100%;height:auto}.legend{margin-bottom:10px}.scope-results{display:grid;grid-template-columns:1fr 1fr;gap:16px;margin:20px 0}.scope-result{background:#0a2239;border:1px solid #234761;border-radius:11px;padding:16px}.scope-result h4{margin:0 0 8px;color:var(--ink)}.scope-result b{font-size:25px;color:var(--teal)}.scope-result p{font-size:12px;margin-top:6px;color:var(--muted)}.evidence-grid{display:grid;grid-template-columns:1fr 1fr;gap:18px}.evidence-card{padding:24px;background:var(--surface);border:1px solid var(--line);border-radius:18px}.evidence-card h3{margin:12px 0;color:#c5e9fa;font-size:18px}.evidence-card p{font-size:14px;line-height:1.9}.next-step{padding:13px 15px;background:#10324f;border-radius:9px;margin-top:16px;font-size:13px;line-height:1.9}.method-copy p{margin-top:12px;line-height:1.9;font-size:12px}.scope-row{font-size:12px;line-height:1.95}.caption{font-size:12px}.section-sub{font-size:12px}.insight-strip{font-size:13px}.code-toolbar p{font-size:12px}.footer{font-size:11px}nav{gap:22px}.top-meta{font-size:11px}.hero .lead{font-size:16px}.content{padding-top:24px}section>.panel+details,section>details+.panel,section>.insight-strip+.panel,section>.panel+.panel{margin-top:18px}
@media(max-width:720px){.chart-frame svg{min-width:var(--chart-min)}.decision{padding:20px 18px}.decision h2{font-size:21px}.decision p{font-size:14px}.kpi .number{font-size:26px}.scope-results,.evidence-grid{grid-template-columns:1fr}.hero h1{font-size:25px}.hero .lead{font-size:14px}.top-meta{font-size:9px;max-width:145px;text-align:right}.section h2{font-size:20px}.section-num{flex:none}.panel-head{padding-bottom:0}.scope-result b{font-size:23px}.table-scroll{max-width:100%}.kpi-label{font-size:11px}.kpi p{font-size:10px}.shell{width:calc(100% - 28px)}.footer{font-size:10px}}
'''
css+='''
/* Typography follows the supplied 60-day analysis reference. */
body{font:16px/1.75 -apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei",sans-serif;font-variant-numeric:tabular-nums}
.hero h1{font-size:clamp(28px,3.2vw,42px);line-height:1.35;letter-spacing:-.025em;font-weight:700}
.hero .lead{font-size:16px;line-height:1.75}.section h2{font-size:24px;line-height:1.45;font-weight:700}
.panel-head h3,.evidence-card h3{font-size:18px;line-height:1.55;font-weight:700}.section-num{font:800 19px/42px -apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei",sans-serif;width:44px;height:42px}
.caption,.section-sub{font-size:13px;line-height:1.75}.legend{font-size:14px;line-height:1.75;gap:10px 22px}.tag{font-size:12px}
table{font-size:14px;line-height:1.75}th{font-size:13px}th,td{padding:11px 13px;line-height:1.75}.table-fold summary{font-size:14px;line-height:1.75}.appendix summary{font-size:15px}.code-toolbar p,.scope-row{font-size:13px}.footer{font-size:13px}
nav a{font-size:14px}.segmented button{font-size:14px;padding:8px 15px}.tooltip{font-size:14px;line-height:1.65;padding:12px 15px}.action{font-size:14px}
.decision{padding:27px 30px}.decision-kicker{font-size:14px}.decision h2{font-size:26px;line-height:1.45;margin:9px 0 23px}
.executive-findings{counter-reset:conclusion;list-style:none;margin:0;padding:0;display:grid;grid-template-columns:1fr 1fr;gap:15px}
.executive-findings>li{counter-increment:conclusion;position:relative;padding:19px 20px 19px 55px;border-radius:10px;background:#172f47;min-width:0}
.executive-findings>li:before{content:counter(conclusion);position:absolute;left:20px;top:19px;font-size:18px;color:#fbbf24;font-weight:800}
.executive-findings h3{font-size:18px;line-height:1.5;color:#f6d679;margin:0 0 11px}
.executive-findings dl,.action-facts{margin:0;display:grid;gap:6px}.executive-findings dl>div,.action-facts>div{display:grid;grid-template-columns:82px minmax(0,1fr);gap:12px}
.executive-findings dt,.action-facts dt{color:var(--muted);font-size:14px}.executive-findings dd,.action-facts dd{margin:0;font-size:16px;color:var(--ink);line-height:1.75;overflow-wrap:anywhere}
.decision .decision-footnote{font-size:13px;line-height:1.75;margin:17px 0 0;color:var(--muted)}
.finding-block{margin-top:18px;padding:20px 24px;border:1px solid #335c7a;border-left:3px solid #fbbf24;border-radius:10px;background:#102b43}
.finding-block h3{margin:0 0 13px;font-size:18px;line-height:1.5;color:#f6d679}.finding-block ul{padding:0;margin:0;list-style:none;display:grid;grid-template-columns:1fr 1fr;gap:9px 28px}
.finding-block li{display:grid;grid-template-columns:125px minmax(0,1fr);gap:12px;font-size:16px;line-height:1.75;align-items:start}
.finding-block li>b{font-size:14px;font-weight:600;color:var(--muted)}.finding-block li>span{color:var(--ink);overflow-wrap:anywhere}
.finding-block.risk-note{background:#2e2b3c;border-color:#67455d;border-left-color:var(--rose)}.finding-block.risk-note h3{color:#ffd0db}
.evidence-card{padding:24px}.evidence-card h3{margin:12px 0 18px}.action-facts{gap:9px}.action-facts>div{grid-template-columns:76px minmax(0,1fr)}
.next-step{margin-top:20px;padding:16px 17px;font-size:16px;line-height:1.75}.next-step>b{font-size:14px;color:var(--teal)}.next-step ul{margin:9px 0 0;padding-left:20px}.next-step li{margin:5px 0;padding-left:2px}
.scope-result h4{font-size:16px}.scope-result p{font-size:14px;line-height:1.75}.scope-result b{font-size:28px}.method-copy p{font-size:14px;line-height:1.75}
section>.finding-block+.panel,section>.finding-block+.table-fold{margin-top:18px}.evidence-grid+.panel{margin-top:18px}
@media(max-width:760px){.hero h1{font-size:28px}.hero .lead{font-size:15px}.section h2{font-size:22px}.decision{padding:22px 18px}.decision h2{font-size:23px}.executive-findings{grid-template-columns:1fr}.executive-findings>li{padding:17px 17px 17px 49px}.executive-findings>li:before{left:17px;top:17px}.finding-block{padding:18px 17px}.finding-block ul{grid-template-columns:1fr}.finding-block li{grid-template-columns:105px minmax(0,1fr);gap:10px}.finding-block li>span{font-size:15px}.finding-block li>b{font-size:13px}.section-num{font-size:18px;width:38px;height:38px;line-height:38px}table{font-size:13px}th,td{padding:10px}nav a{font-size:12px}.segmented button{font-size:14px;padding:8px 13px}.caption,.section-sub{font-size:13px}.evidence-grid{grid-template-columns:1fr}.evidence-card{padding:21px 18px}.next-step{padding:14px;font-size:15px}.footer{font-size:12px}.top-meta{font-size:10px;line-height:1.6}.scope-results{grid-template-columns:1fr}}
'''
nav=[('overview','核心判断'),('choice','供给与选择'),('financial','盈利与风险'),('batches','批次复核'),('products','产品组合'),('maturity','到期成熟度'),('actions','推进方案'),('method','口径附件')]
navhtml=''.join(f'<a href="#{id}"><span>{i:02}</span>{title}</a>' for i,(id,title) in enumerate(nav))
js='''
const D=JSON.parse(document.getElementById('analysis-data').textContent);const e=s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));const p=v=>v===null?'—':(100*v).toFixed(2)+'%',pp=v=>(v>=0?'+':'')+(100*v).toFixed(2)+'pp',n=v=>v.toLocaleString('en-US');
function population(name){document.querySelectorAll('[data-population]').forEach(el=>el.hidden=el.dataset.population!==name);document.querySelectorAll('[data-pop]').forEach(el=>el.setAttribute('aria-pressed',String(el.dataset.pop===name)))}document.querySelectorAll('[data-pop]').forEach(el=>el.addEventListener('click',()=>population(el.dataset.pop)));
function scope(key){const rows=[];let cards='';Object.entries(D).forEach(([name,r])=>{const a=r.sensitivity[key],L=a.long,S=a.short;cards+='<div class="scope-result"><h4>'+name+'</h4><b>'+pp(L.profit-S.profit)+'</b><span> 盈利率差</span><p>较长 '+p(L.profit)+'，较短 '+p(S.profit)+'</p><p>当前逾期差 '+pp(L.overdue-S.overdue)+'；到期 '+n(L.mature)+' / '+n(S.mature)+'笔</p></div>';rows.push([name,n(L.mature),n(S.mature),p(L.profit),p(S.profit),pp(L.profit-S.profit),p(L.overdue),p(S.overdue),pp(L.overdue-S.overdue)])});document.getElementById('sensitivitySummary').innerHTML=cards;document.getElementById('sensitivityTable').innerHTML='<div class="table-scroll"><table><thead><tr>'+['客群','较长到期','较短到期','较长盈利率','较短盈利率','盈利差','较长逾期率','较短逾期率','逾期差'].map(v=>'<th>'+v+'</th>').join('')+'</tr></thead><tbody>'+rows.map(r=>'<tr>'+r.map(v=>'<td>'+e(v)+'</td>').join('')+'</tr>').join('')+'</tbody></table></div>';document.querySelectorAll('[data-scope]').forEach(el=>el.setAttribute('aria-pressed',String(el.dataset.scope===key)))}document.querySelectorAll('[data-scope]').forEach(el=>el.addEventListener('click',()=>scope(el.dataset.scope)));scope('all');
const tip=document.getElementById('tooltip');function show(el,x,y){tip.textContent=el.dataset.tip;tip.style.display='block';tip.style.left=Math.max(8,Math.min(x+14,innerWidth-tip.offsetWidth-8))+'px';tip.style.top=Math.max(8,Math.min(y+14,innerHeight-tip.offsetHeight-8))+'px'}document.addEventListener('pointermove',ev=>{const el=ev.target.closest('[data-tip]');if(el)show(el,ev.clientX,ev.clientY);else tip.style.display='none'});document.addEventListener('focusin',ev=>{if(ev.target.matches('[data-tip]')){let r=ev.target.getBoundingClientRect();show(ev.target,r.x,r.y)}});document.addEventListener('focusout',()=>tip.style.display='none');window.addEventListener('scroll',()=>tip.style.display='none',{passive:true});if('IntersectionObserver' in window){const io=new IntersectionObserver(es=>{es.forEach(el=>{if(el.isIntersecting)document.querySelectorAll('nav a').forEach(a=>a.classList.toggle('active',a.hash==='#'+el.target.id))})},{rootMargin:'-15% 0px -65% 0px'});document.querySelectorAll('section[id]').forEach(s=>io.observe(s))}window.__reportReady=true;
'''
page='<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="color-scheme" content="dark"><meta name="theme-color" content="#06192b"><title>T7两类流失用户产品选择与盈利风险分析</title><style>'+css+'</style></head><body><div class="topbar"><div class="shell"><div class="brand"><span class="brand-mark">T7</span>召回用户 · 产品经营分析</div><div class="top-meta">原始快照 2026.11.06 · 报告 2026.11.10</div></div></div><header class="hero"><div class="shell"><div class="eyebrow">PRODUCT CHOICE AND RETURN</div><h1>两类流失用户的产品选择<br>与长短账期盈利风险分析</h1><p class="lead">新增流失九批与活跃流失七批：产品供给、选择偏好、盈利风险及推进方案。</p><div class="chips"><span class="chip">双产品首单中约88%选择较长账期</span><span class="chip">优先扩大21/28天主力供给</span><span class="chip">新增流失九批、活跃流失七批</span></div></div></header><div class="nav-wrap"><nav class="shell" aria-label="报告章节">'+navhtml+'</nav></div><main class="shell content">'+body+'<footer class="footer"><span>来源：用户指定的两份首次提单产品与长账期选择Excel，原快照业务日2026-11-05</span><span>生成：北京时间2026-11-10</span></footer></main><div id="tooltip" class="tooltip" role="tooltip"></div><script id="analysis-data" type="application/json">'+json.dumps(D,ensure_ascii=False).replace('</','<\\/')+'</script><script>'+js+'</script></body></html>'
filename='T7两类流失用户_产品选择与盈利风险分析报告.html';(OUT/filename).write_text(page)
shutil.copy2(W/'analyze.py',OUT/'完整分析代码.py');(W/'report_runtime.js').write_text(js)
readme='''分析复核附件\n\n输入为用户提供的两份Excel的汇总内容，原始Excel保持不变。\nsource_workbooks.json为逐单元格值的标准化快照，analysis.json为计算结果，checks.json为汇总核对。\n在本目录执行 python3 analyze.py 即可从标准化快照重算；分析脚本只使用Python标准库。\ninspect_workbooks.py用于从原始Excel读取快照，需要openpyxl，并在原本地路径或调整路径后执行。\n统计口径与数据局限以网页附录及原表“统计口径”为准。跨批重复保留，不将两类人群合并。\n'''
with zipfile.ZipFile(OUT/'分析复核附件.zip','w',zipfile.ZIP_DEFLATED) as z:
 for name in ['source_workbooks.json','analysis.json','checks.json','analyze.py','inspect_workbooks.py','build_report.py']:
  z.write(W/name,name)
 z.writestr('README.txt',readme)
(W/'output_manifest.json').write_text(json.dumps({'report':str(OUT/filename),'sha256':hashlib.sha256(page.encode()).hexdigest(),'source_unchanged':True,'standalone':True},ensure_ascii=False,indent=2))
print(json.dumps({'report':str(OUT/filename),'bytes':len(page.encode()),'charts':len(re.findall(r'<svg\b',page)),'source_workbooks_unchanged':True},ensure_ascii=False))
