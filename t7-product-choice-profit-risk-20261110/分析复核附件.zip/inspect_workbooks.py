from pathlib import Path
import openpyxl,json,hashlib
root=Path('/Users/wangchuanliang/Documents/Codex/2026-10-18/wen/outputs')
paths={
'新增流失':root/'T7九批召回_首次提单长账期选择与到期表现_20261106/T7九批召回_首次提单产品与长账期选择_20261106.xlsx',
'活跃流失':root/'T7七批活跃召回_首次提单长账期选择与到期表现_20261106/T7七批活跃召回_首次提单产品与长账期选择_20261106.xlsx'}
result={}
for kind,path in paths.items():
 wb=openpyxl.load_workbook(path,data_only=True,read_only=True)
 print('\nWORKBOOK:',kind)
 item={'path':str(path),'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'sheets':{}}
 for ws in wb:
  rows=[list(r) for r in ws.iter_rows(values_only=True)]
  item['sheets'][ws.title]={'dimensions':[ws.max_row,ws.max_column],'rows':rows}
  print('SHEET:',ws.title,'shape',ws.max_row,ws.max_column)
  for i,row in enumerate(rows[:9],1):print(i,json.dumps(row,ensure_ascii=False,default=str))
 wb.close();result[kind]=item
Path('work/t7_product_preference/source_workbooks.json').write_text(json.dumps(result,ensure_ascii=False,indent=2,default=str))
