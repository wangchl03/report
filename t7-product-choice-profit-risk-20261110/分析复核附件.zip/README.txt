分析复核附件

输入为用户提供的两份Excel的汇总内容，原始Excel保持不变。
source_workbooks.json为逐单元格值的标准化快照，analysis.json为计算结果，checks.json为汇总核对。
在本目录执行 python3 analyze.py 即可从标准化快照重算；分析脚本只使用Python标准库。
inspect_workbooks.py用于从原始Excel读取快照，需要openpyxl，并在原本地路径或调整路径后执行。
统计口径与数据局限以网页附录及原表“统计口径”为准。跨批重复保留，不将两类人群合并。
