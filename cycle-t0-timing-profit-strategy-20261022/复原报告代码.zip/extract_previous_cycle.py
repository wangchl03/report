"""Read-only enrichment of frozen T0 anchors with their triggering settlement order.

Labels and finances remain at the original report snapshot for direct comparison.
No database table is created or changed. Raw identifiers stay in the local work folder.
"""
from pathlib import Path
from collections import defaultdict
import gzip,json,time,sys
import psycopg2
from extract import packed,enc,connection_kwargs
W=Path(__file__).resolve().parent
SQL="""WITH anchor_input AS (
    -- Equal-length arrays enumerate distinct (user, frozen clean-settlement timestamp) pairs.
    SELECT UNNEST(%(users)s::bigint[]) AS user_id,
           UNNEST(%(times)s::bigint[]) AS settle_epoch
), funded_orders AS (
    -- Same funded-order deduplication and eligibility as the original T0 template.
    SELECT DISTINCT ON (o.user_id,o.serial_id)
           o.user_id,o.serial_id,o.repaid_time,o.repaid_date,
           o.remit_time,o.is_repaid,o.loan_status_code
    FROM wangchuanliang.order_loan_f_v2_copy o
    WHERE o.user_id IN (SELECT user_id FROM anchor_input)
      AND o.is_remit=1 AND o.remit_amt>0
    ORDER BY o.user_id,o.serial_id,o.apply_time ASC NULLS LAST
), matched AS (
    SELECT f.*,a.settle_epoch
    FROM funded_orders f JOIN anchor_input a
      ON a.user_id=f.user_id
     AND EXTRACT(EPOCH FROM f.repaid_time AT TIME ZONE 'America/Belize')::bigint=a.settle_epoch
    WHERE (f.is_repaid=1 OR f.loan_status_code=7)
      AND f.repaid_time>=TIMESTAMP '2026-01-01'
      AND f.repaid_time<TIMESTAMP '2026-10-01'
)
SELECT m.user_id,m.serial_id,m.settle_epoch,m.repaid_time,m.repaid_date,
       m.remit_time,r.recycle_type
FROM matched m LEFT JOIN wangchuanliang.side_recycle_type_copy r
  ON r.serial_id=m.serial_id
"""
def write_queries():
 native=(W/'T0_template.sql').read_text()
 old="WHERE e.vir_date >= p.output_start_date AND e.vir_date < p.output_end_date"
 new=old+"\n      -- Filter only after the complete T0 sequence and its next-offer cutoff were built.\n      -- settled_serial_id is the order that triggered zero outstanding loans, not any historical loan.\n      AND EXISTS (SELECT 1 FROM wangchuanliang.side_recycle_type_copy r\n                  WHERE r.serial_id=e.settled_serial_id AND r.recycle_type=2)"
 assert native.count(old)==1
 full=native.replace(old,new)
 end=full.index('SELECT s.*,100.0*book_profit')
 full=full[:end]+'''-- Include the non-application bucket in each month's event denominator.
SELECT s.*,SUM(events) OVER(PARTITION BY month) AS eligible_offer_events,
       events::numeric/NULLIF(SUM(events) OVER(PARTITION BY month),0) AS first_apply_rate,
       book_profit/NULLIF(matured_principal,0) AS profit_rate,
       a.* FROM summary s CROSS JOIN audit a ORDER BY month,first_apply_bucket;
'''
 (W/'T0_previous_cycle_six_stages.sql').write_text('-- Complete read-only rerun; current repaid_amt is read at rerun time.\n-- Compare with frozen report values only when using the same data snapshot.\n'+full)
 (W/'previous_cycle_settlement_query.sql').write_text('-- Read-only parameterized enrichment of frozen T0 settlement anchors.\n'+SQL+';\n')
def main():
 start=time.monotonic();write_queries()
 with gzip.open(W/'t0_events.json.gz','rt') as f:events=json.load(f)
 pairs=sorted({(int(e['user_id']),int(e['clean_settle_epoch'])) for e in events})
 allrows=[]
 with psycopg2.connect(**dict(connection_kwargs(),connect_timeout=20,application_name='t0_previous_cycle_readonly')) as c:
  c.set_session(readonly=True,isolation_level='REPEATABLE READ')
  with c.cursor() as q:
   for sql in ["SET TIME ZONE 'America/Belize'",'SET query_dop=1',"SET work_mem='32MB'",'SET statement_timeout=120000','SET enable_nestloop=off']:q.execute(sql)
   q.execute("SELECT CURRENT_TIMESTAMP,CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Shanghai',current_setting('transaction_read_only')")
   tm,bj,ro=q.fetchone();assert ro=='on'
   print(json.dumps({'phase':'started','settlement_anchors':len(pairs),'read_only':ro}),flush=True)
   for shard in range(4):
    pp=[p for p in pairs if p[0]%4==shard];t=time.monotonic()
    rr=packed(q,SQL,{'users':[u for u,ep in pp],'times':[ep for u,ep in pp]})
    requested=set(pp)
    assert all((int(r['user_id']),int(r['settle_epoch'])) in requested for r in rr)
    with gzip.open(W/f'previous_settlement_shard_{shard}.json.gz','wt') as f:json.dump(rr,f,default=enc)
    allrows.extend(rr)
    print(json.dumps({'phase':'shard_complete','shard':shard,'anchors':len(pp),'source_rows':len(rr),'seconds':round(time.monotonic()-t,1)}),flush=True)
  c.rollback()
 # Source duplicates of the same immutable type do not multiply the cohort.
 bypair=defaultdict(dict);types=defaultdict(set);repeated=0
 for r in allrows:
  key=(int(r['user_id']),int(r['settle_epoch']));sid=int(r['serial_id'])
  types[sid].add(None if r['recycle_type'] is None else int(r['recycle_type']))
  if sid in bypair[key]:repeated+=1
  bypair[key][sid]=r
 assert set(bypair)==set(pairs),f'Frozen settlement anchors missing: {len(set(pairs)-set(bypair))}'
 assert all(len(t)==1 for t in types.values()),'Conflicting recycle types require investigation.'
 selected=[];mixed_ties=0;multi=0
 for key,orders in sorted(bypair.items()):
  # Original settlement_rn uses latest settlement time, then largest order ID.
  latest=max(r['repaid_time'] for r in orders.values())
  exact=[r for r in orders.values() if r['repaid_time']==latest]
  if len(exact)>1:
   multi+=1;mixed_ties+=int(len({r['recycle_type'] for r in exact})>1)
  chosen=max(exact,key=lambda r:int(r['serial_id'])).copy()
  chosen['same_timestamp_orders']=len(exact);chosen['same_timestamp_mixed_type']=int(len({r['recycle_type'] for r in exact})>1)
  selected.append(chosen)
 with gzip.open(W/'previous_settlement_map.json.gz','wt') as f:json.dump(selected,f,default=enc)
 meta={'passed':True,'classification_snapshot':tm,'classification_beijing_time':bj,'read_only':ro,
       'frozen_t0_events':len(events),'settlement_anchors':len(pairs),'matched_anchors':len(selected),
       'same_timestamp_multiple_order_anchors':multi,'same_timestamp_mixed_type_anchors':mixed_ties,
       'duplicate_join_rows_collapsed':repeated,'missing_selected_type_anchors':sum(r['recycle_type'] is None for r in selected),
       'type_distribution_anchors':{str(t):sum(r['recycle_type']==t for r in selected) for t in sorted({r['recycle_type'] for r in selected},key=str)},
       'seconds':round(time.monotonic()-start,1)}
 (W/'previous_cycle_extraction.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2,default=enc))
 print(json.dumps(meta,ensure_ascii=False,default=enc),flush=True)
if __name__=='__main__':main()
