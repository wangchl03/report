"""Self-contained dark report. Only aggregate data is embedded or published."""
from pathlib import Path
import os,json,html,zipfile,shutil,re
from previous_cycle_report import render_previous_cycle
W=Path(__file__).resolve().parent
OUT=Path(os.environ.get('REPORT_OUTPUT_DIR',str(W.parents[1]/'outputs/循环贷与T0_提单时点盈利与召回策略_20261022')))
H=lambda v:html.escape(str(v))
N=lambda v:f'{v:,.0f}'
P=lambda v:'—' if v is None else f'{v*100:.2f}%'
def table(headers,rows):
 return '<div class="scroll"><table><thead><tr>'+''.join('<th>'+H(v)+'</th>' for v in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+H(v)+'</td>' for v in r)+'</tr>' for r in rows)+'</tbody></table></div>'
def fold(label,text):return '<details><summary>'+H(label)+'</summary>'+text+'</details>'
def main():
 d=json.loads((W/'analysis.json').read_text());assert d['quality']['passed'];OUT.mkdir(parents=True,exist_ok=True)
 rows=d['rows'];q=d['quality'];meta=d['meta'];ST=d['stages']
 def get(p,s,m='合计'):return next(r for r in rows+d['combined'] if r['product']==p and r['stage']==s and r['month']==m)
 c0,t0=get('循环贷','D0'),get('T0','D0');cl,tl=get('循环贷','D1-D15'),get('T0','D1-D15')
 overlap=[r for r in d['overlap'] if r['month']=='合计'];order_ov=next(r for r in overlap if r['kind']=='同一首次提单订单')
 fm={p:next((r for r in d['fully_mature_control'] if r['product']==p and r['stage']=='D0'),None) for p in ['循环贷','T0']}
 css='''*{box-sizing:border-box}:root{color-scheme:dark;--bg:#061b2a;--paper:#082235;--panel:#0b2a40;--line:#21465a;--text:#d9e7ef;--muted:#9bb5c7;--cyan:#43c7e7;--amber:#ffc26b;--green:#64dcae;--red:#ff7a83}body{margin:0;background:var(--bg);color:var(--text);font:16px/1.8 -apple-system,BlinkMacSystemFont,"PingFang SC",Arial,sans-serif}main{max-width:1360px;margin:auto;padding:32px 24px 70px}h1{text-align:center;font-size:32px;margin:8px 0;color:#f3faff}h2{color:var(--cyan);font-size:23px;margin:0 0 12px}h3{font-size:17px;color:var(--amber);margin:12px 0}p{margin:10px 0}header p{text-align:center}nav{display:flex;gap:24px;flex-wrap:wrap;justify-content:center;text-align:center;margin:22px 0}a,summary{color:var(--cyan);text-decoration:none}a:hover{text-decoration:underline}section{background:var(--paper);border:1px solid var(--line);border-radius:12px;padding:25px;margin:22px 0;scroll-margin-top:16px}.note,.muted{font-size:14px;color:var(--muted)}.conclusion{padding:12px 16px;border-left:3px solid var(--cyan);background:#123146}.cards,.two{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px}.two{grid-template-columns:repeat(2,minmax(0,1fr))}.card{background:var(--panel);border:1px solid var(--line);border-top:3px solid var(--cyan);padding:15px;border-radius:8px}.card h3{font-size:14px;margin:0 0 3px;color:var(--text)}.card strong{display:block;font-size:23px;line-height:1.5;font-variant-numeric:tabular-nums;color:var(--cyan)}.card small{display:block;font-size:12px;color:var(--muted)}.good{color:var(--green)}.bad{color:var(--red)}.scroll{overflow:auto}table{width:100%;border-collapse:collapse;font-size:13px;margin:14px 0;font-variant-numeric:tabular-nums}th,td{text-align:right;vertical-align:top;padding:10px 12px;border-bottom:1px solid var(--line)}th{background:#123b51;white-space:nowrap;color:var(--cyan)}td:first-child,th:first-child{text-align:left}tr:nth-child(even){background:var(--panel)}details{border-top:1px solid var(--line);padding:12px 0;margin-top:12px}summary{cursor:pointer}pre{overflow:auto;max-height:500px;background:#041725;padding:18px;border:1px solid var(--line);border-radius:8px;font:12px/1.65 Menlo,monospace}select{font:inherit;background:var(--panel);color:var(--text);padding:6px 10px;border:1px solid var(--line);border-radius:6px}.figure svg{display:block;width:100%;height:auto}.controls{display:flex;align-items:center;gap:12px;margin:12px 0}.definition{border-left:2px solid var(--line);padding-left:12px}a:focus-visible,summary:focus-visible,select:focus-visible{outline:2px solid var(--cyan);outline-offset:4px}@media(max-width:1000px){.cards{grid-template-columns:repeat(2,minmax(0,1fr))}.two{grid-template-columns:1fr}}@media(max-width:620px){main{padding:18px 12px}section{padding:18px 14px}h1{font-size:25px}.cards{grid-template-columns:1fr}.figure{overflow:auto}.figure svg{min-width:520px}}'''
 a=[f'<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>循环贷与T0提单时点、盈利及召回策略</title><style>{css}</style></head><body><main><header><h1>循环贷与T0提单时点、盈利及召回策略</h1><p class="muted">生成时间 · 2026年10月22日</p></header>']
 nav=[('core','核心判断'),('stages','六阶段对比'),('monthly','月度变化'),('overlap','事件重叠'),('strategy','召回策略'),('definitions','指标口径'),('appendix','复原报告代码')]
 if 'previous_cycle_t0' in d:nav.insert(3,('previous-cycle-t0','刚结清循环贷T0'))
 a.append('<nav>'+''.join(f'<a href="#{k}">{v}</a>' for k,v in nav)+'</nav>')
 a.append('<section id="core"><h2>核心判断</h2>')
 a.append(f'<p class="conclusion">循环贷和T0的当天首次提单订单账面盈利率分别为{P(c0["profit_rate"])}、{P(t0["profit_rate"])}；D1—D15合并后分别为{P(cl["profit_rate"])}、{P(tl["profit_rate"])}。当天用户仍是主要转化来源，召回应同时评估新增提单、放款及账面利润，不能只考核D0提单率。</p>')
 cards=[('当天首次提单率',P(c0['apply_rate'])+' / '+P(t0['apply_rate']),'循环贷 / T0，分母为各自入样获额事件'),('当天订单账面盈利率',P(c0['profit_rate'])+' / '+P(t0['profit_rate']),'循环贷 / T0，仅已到期放款订单'),('D1—D15订单账面盈利率',P(cl['profit_rate'])+' / '+P(tl['profit_rate']),'循环贷 / T0，区间内订单重新去重'),('共享的首次提单订单',N(q['shared_first_orders'])+'笔','分别对应循环贷'+N(order_ov['cycle_events'])+'次、T0 '+N(order_ov['t0_events'])+'次提单事件')]
 a.append('<div class="cards">'+''.join(f'<div class="card"><h3>{x}</h3><strong>{y}</strong><small>{z}</small></div>' for x,y,z in cards)+'</div>')
 a.append(f'<p>入样循环贷获额{N(c0["offer_events"])}次，T0获额{N(t0["offer_events"])}次。两类产品分别保留同用户20秒链式获额去重。利润为当前回款减放款本金，回款读取同一数据库快照。</p>')
 a.append('<p class="note">观察到的时点差异包含用户需求、风险、额度、利率和到期结构的共同影响。历史晚提单订单盈利率更高，不能直接推出把当天用户延后召回即可提高盈利，也不能据此认定新增当天提单必然降低总利润。</p></section>')
 a.append('<section id="stages"><h2>六阶段提单率与盈利率对比</h2><div class="controls"><label for="month">获额月份</label><select id="month">'+''.join(f'<option value="{m}">{m}</option>' for m in ['合计']+d['months'])+'</select></div><div class="two"><div><h3>首次提单率</h3><div class="figure" id="rate-chart"></div></div><div><h3>已到期订单账面盈利率</h3><div class="figure" id="profit-chart"></div></div></div><p class="note" id="scope"></p>')
 a.append(fold('展开六阶段人数、事件数与金额明细','<div id="stage-table"></div>'))
 combined=[get(p,s) for s in ['D0','D1-D15','D0-D15'] for p in ['循环贷','T0']]
 a.append(fold('展开D0与D1—D15合并对比',table(['类型','阶段','首次提单事件数','提单率','到期订单数','盈利率','到期覆盖率'],[[r['product'],r['stage'],N(r['apply_events']),P(r['apply_rate']),N(r['matured_orders']),P(r['profit_rate']),P(r['mature_coverage'])] for r in combined])))
 a.append(f'<p>合计T0的D0提单率比循环贷高{(t0["apply_rate"]-c0["apply_rate"])*100:.2f}个百分点，但D0订单盈利率低{(c0["profit_rate"]-t0["profit_rate"])*100:.2f}个百分点。D1—D7各阶段T0盈利率均高于循环贷；D8—D15循环贷为{P(get("循环贷","D8-D15")["profit_rate"])}，T0为{P(get("T0","D8-D15")["profit_rate"])}。</p>')
 a.append('<p class="note">各阶段为互斥的首次提单事件分段。未最终放款的提单也计入提单率；盈利率仅计算已放款、已到期订单。两者分母不同。阶段与合并区间的金额都按订单去重。</p></section>')
 a.append('<section id="monthly"><h2>当天提单率与盈利率的月度变化</h2><h3>D0首次提单率</h3><div class="figure" id="monthly-rate"></div><h3>D0已到期订单账面盈利率</h3><div class="figure" id="monthly-profit"></div>')
 for p in ['循环贷','T0']:
  jan=get(p,'D0','2026-01');sep=get(p,'D0','2026-09')
  delta=(sep['apply_rate']-jan['apply_rate'])*100
  a.append(f'<p>{p}D0提单率从1月{P(jan["apply_rate"])}变为9月{P(sep["apply_rate"])}，变化<span class="'+('bad' if delta<0 else 'good')+f'">{delta:+.2f}个百分点</span>。同期D0已到期订单盈利率由{P(jan["profit_rate"])}变为{P(sep["profit_rate"])}。</p>')
 a.append(f'<p class="note">全部放款订单均已到期的共同月份：{"、".join(q["fully_mature_months"])}。9月晚提单覆盖不完整，尤其D8—D15，不与完整月份等同解释。</p>')
 a.append(f'<p>在共同完整到期月份内，循环贷D0盈利率为{P(fm["循环贷"]["profit_rate"])}，T0为{P(fm["T0"]["profit_rate"])}，两类D1—D15各阶段的盈利率仍均高于本类D0。晚提单组较高的历史盈利率并非仅由9月未到期订单形成。</p>')
 a.append(fold('展开共同完整到期月份的六阶段核对',table(['类型','阶段','提单率','到期订单数','盈利率','到期覆盖率'],[[r['product'],r['stage'],P(r['apply_rate']),N(r['matured_orders']),P(r['profit_rate']),P(r['mature_coverage'])] for r in d['fully_mature_control']])))
 a.append(fold('展开全部月度明细','<div id="monthly-table"></div>')+'</section>')
 if 'previous_cycle_t0' in d:a.append(render_previous_cycle(d,table,fold))
 a.append('<section id="overlap"><h2>获额事件、提单事件和用户重叠</h2>')
 a.append(f'<p class="conclusion">两类获额订单的精确交集为{N(q["same_offer_order_events"])}次。同一首次提单订单交集为{N(q["shared_first_orders"])}笔，循环贷侧命中{N(order_ov["cycle_events"])}次，占本类D0—D15首次提单事件{P(order_ov["cycle_share"])}；T0侧命中{N(order_ov["t0_events"])}次，占{P(order_ov["t0_share"])}。</p>')
 a.append(fold('展开获额及提单事件重叠统计',table(['重叠口径','循环贷侧事件数','占对应事件','T0侧事件数','占对应事件'],[[r['kind'],N(r['cycle_events']),P(r['cycle_share']),N(r['t0_events']),P(r['t0_share'])] for r in overlap])))
 a.append(f'<p>期内同时发生两类获额的用户{N(q["common_offer_users"])}人，占循环贷获额用户{P(q["common_offer_users"]/q["cycle_offer_users"])}，占T0获额用户{P(q["common_offer_users"]/q["t0_offer_users"])}。同一用户可以先后处于两种借款状态，用户交叉不等于事件重复。</p>')
 a.append('<p>用户交叉可能来自循环贷资格开通、循环贷获额后未提单直至全部结清，或逾期后循环贷资格被取消等不同路径。重叠人数本身不表示转化方向；刚结清循环贷的T0分组也不能单独识别资格取消原因。</p>')
 a.append('<p class="note">同一获额事件按用户ID与获额订单号识别；相差≤20秒只表示两个保留事件的时点相近。同一首次提单订单按用户ID与提单订单号识别。获额重叠比例分母为本类全部入样获额事件；提单重叠比例分母为本类D0—D15首次提单事件。月度明细各自按本侧获额月份归组。</p>')
 a.append('<p>循环贷与T0使用固定且不同的获额类型，因此同一获额订单没有交集。同一用户的两次不同获额仍可能对应同一笔后续提单，且因锚点不同落入不同提单阶段。27笔共享订单占比很低，无法解释两类产品的整体盈利差异。</p>')
 a.append(fold('展开六阶段提单重叠',table(['类型','阶段','首次提单事件','命中共享订单事件','占本阶段','共享订单数'],[[r['product'],r['stage'],N(r['apply_events']),N(r['shared_first_order_events']),P(r['shared_share']),N(r['shared_orders'])] for r in d['overlap_stages']])))
 a.append('</section><section id="strategy"><h2>召回策略：从单一D0提单率转向新增利润</h2>')
 a.append('<p class="conclusion">保留当天高意愿、高预期利润用户的转化，分阶段经营尚未提单用户。不要为了提高当天指标广泛加补贴，也不要因为晚提单组历史盈利率较高就主动压后全部用户。</p>')
 a.append(table(['阶段','循环贷','结清续贷T0','共同考核'],[
  ['D0','确认仍有在途、当前无逾期且获额有效。区分还款带来的进页与主动提单意愿。','确认干净结清后的最新获额仍通过，优先承接主动选择金额、查看计划等明确意愿。','新增有效提单及放款。同步看金额、预测利润、补贴成本。'],
  ['D1—D3','对仍具循环贷资格且未提单者分层召回，避免已结清后继续套用循环贷标签。','对获额仍通过的未提单用户分层触达，核对额度、日息和页面转化问题。','分别统计累计提单和新增利润，检查是否仅将D4—D15需求提前。'],
  ['D4—D7','先复核在途与逾期资格，再考虑触达，不以历史事件标签代替实时资格。','区分被拒、可提单但未活跃、有互动未提交三类状态。','以用户为单位去重触达，跨循环贷和T0合并管理。'],
  ['D8—D15','只在资格有效及预期利润为正的人群测试较低频触达。','按历史价值、产品条件与需求分层，不把阶段性未提单当作永久流失。','使用完整到期结果复核收益，避免9月晚提单样本的到期选择偏差。']]))
 a.append('<h3>下一步验证方式</h3><p>按用户随机分配“现有策略”“加强D0触达”“D0加D1—D7分阶段触达”三组，跨产品保持同一分组。主指标采用15日累计新增放款及扣除触达、优惠成本后的新增利润，D0提单率作为过程指标；在相同到期成熟度下复核风险和盈利。</p><p class="note">本次为历史描述性比较，不包含新增召回成本、实验对照或可识别的增量效果，不能给出可信的最优补贴金额与确定收益提升。</p></section>')
 definitions=[
 ('事件范围','2026年1月1日至9月30日获额通过事件，按获额通过日期分月。America/Belize自然日。'),
 ('T0事件','recycle_type=3、loan_type_code=2且获额通过。同用户在该获额当日、获额之前曾干净结清，结清后当时已放款未结清订单数为0。不是只结清任意一单。'),
 ('循环贷事件','recycle_type=2、loan_type_code=2且获额通过。获额时有在途，后续首次提单时仍有在途。获额至首次提单前出现分期逾期，或在途全部结束，记未有效提单。'),
 ('去重与归因','两类各自先按同一订单最新获额，再按同用户相邻间隔≤20秒链式归批，取最新获额，同秒取最大订单号。提单可为其他订单。同秒多笔提单取最小订单号。'),
 ('观察差异','T0沿用既有下一次T0获额截断，保证首次提单归属唯一。循环贷每次获额独立观察。下表给出T0同样独立观察的对照。'),
 ('提单率','该阶段首次有效提单获额事件数÷本类入样获额事件数。分子不要求最终放款或到期。同一事件最多归入一个阶段，用户可贡献多次事件。'),
 ('盈利率','首次提单已放款且到期的订单，(SUM(repaid_amt)−SUM(remit_amt))÷SUM(remit_amt)。只用该次首次提单，不跳过失败提单改取后续放款。回款不限制日期。'),
 ('已到期','is_remit=1、remit_amt>0、is_due=1、有效due_date且due_date严格早于业务统计日。当前状态8订单仍保留。未扣资金、获客与运营成本。'),
 ('汇总与重复','月度和阶段内订单去重；合计跨月重新去重；D1—D15及D0—D15合并时再次订单去重。各阶段金额不能直接加总，盈利率不是各月或各阶段百分比的算术平均。'),
 ('数据时点',f'两类金额来自同一只读可重复读快照，北京时间{meta["beijing_time"][:19].replace("T"," ")}。业务统计日{meta["business_stat_date"]}。循环贷历史资格复用2026-10-19已审计标签，T0历史资格本次读取；未宣称两类历史标签在同一时点重建。'),
 ('完整性','所有D0—D15提单观察窗口均已成熟，不把未成熟观察记为未提单。订单到期成熟是另一概念，9月部分订单仍未到期。'),
 ('数据来源','order_vir_f_copy、side_recycle_type_copy、order_loan_f_v2_copy、repayment_plan_v2_copy，均位于wangchuanliang。实际行为埋点未参与本次取数。')]
 a.append('<section id="definitions"><h2>指标口径与可比性核对</h2>'+''.join(f'<p class="definition"><b>{H(k)}：</b>{H(v)}</p>' for k,v in definitions[:4]))
 a.append(fold('展开完整指标定义',''.join(f'<p class="definition"><b>{H(k)}：</b>{H(v)}</p>' for k,v in definitions[4:])))
 native=get('T0','D0');ii=d['independent_t0_control'];a.append(f'<p>T0若采用与循环贷相同的独立观察方式，额外计入{N(q["t0_cutoff_affected_events"])}次提单归因。主表仍沿用原T0口径。该对照仅改变归因，不表示新增真实提单。</p>')
 a.append(fold('展开T0独立观察与原口径对照',table(['阶段','原口径事件数','独立观察事件数','原口径提单率','独立观察提单率','原口径盈利率','独立观察盈利率'],[[r['stage'],N(get('T0',r['stage'])['apply_events']),N(r['apply_events']),P(get('T0',r['stage'])['apply_rate']),P(r['apply_rate']),P(get('T0',r['stage'])['profit_rate']),P(r['profit_rate'])] for r in ii])))
 a.append('</section><section id="appendix"><h2>附录：复原报告代码</h2>')
 files=['extract.py','t0_event_details.sql','T0_template.sql','cycle_cash_query.sql','cycle_event_details.sql','refresh_cycle_labels.py','analyze.py','build_report.py','report_ui.js','build_workbook.mjs','common.py']
 if 'previous_cycle_t0' in d:files+=['extract_previous_cycle.py','previous_cycle_settlement_query.sql','T0_previous_cycle_six_stages.sql','previous_cycle_report.py']
 code=[]
 for name in files:
  p=W/name
  if p.exists():code.append((name,p.read_text()))
 a.append(fold('展开完整SQL、Python与导出代码',f'<p class="note">{len(code)}个完整代码文件，默认折叠。汇总数据可离线复原网页；重查数据库需配置只读连接。历史源副本后补可能使复跑结果变化。公开内容仅含汇总数据及代码。</p><p><a href="复原报告代码.zip">下载复原代码</a> · <a href="analysis.json">下载汇总数据</a></p>'+''.join(fold(name,'<pre><code>'+H(text)+'</code></pre>') for name,text in code)))
 payload=json.dumps(d,ensure_ascii=False,separators=(',',':')).replace('</','<\\/')
 script=(W/'report_ui.js').read_text()
 a.append('</section></main><script id="data" type="application/json">'+payload+'</script><script>'+script+'</script></body></html>')
 report=''.join(a);assert not re.search(r'<details[^>]*\bopen\b',report)
 target=OUT/'循环贷与T0_提单时点盈利及召回策略分析报告.html';target.write_text(report)
 (OUT/'analysis.json').write_text(json.dumps(d,ensure_ascii=False,indent=2))
 with zipfile.ZipFile(OUT/'复原报告代码.zip','w',zipfile.ZIP_DEFLATED) as z:
  for name,text in code:z.writestr(name,text)
  z.writestr('analysis.json',json.dumps(d,ensure_ascii=False,indent=2))
  for name,source in [('cycle_previous_controls.json',W.parent/'cycle_first_apply_profit_6stages_20261022/result.json'),('t0_previous_controls.json',W.parent/'t0_first_apply_profit_202601_202609_20261021/result.json')]:
   if source.exists():z.write(source,name)
  z.writestr('README.txt','网页复原：python build_report.py（与analysis.json、report_ui.js、previous_cycle_report.py同目录），可设置REPORT_OUTPUT_DIR。\n重新取数：配置DB_HOST、DB_PORT、DB_NAME、DB_USER、DB_PASSWORD，运行refresh_cycle_labels.py，再依次运行extract.py、extract_previous_cycle.py、analyze.py。重查会使用新快照，不能保证与历史冻结标签完全相同。\n刚结清循环贷T0：先生成完整T0序列和下一次T0截断，再按触发干净结清的订单自身recycle_type=2筛选。独立PGSQL见T0_previous_cycle_six_stages.sql。\nExcel导出：通过@oai/artifact-tool及配套Node运行build_workbook.mjs。\n主表T0采用下一次获额截断，独立观察对照仅用于可比性检查。\n')
 print(json.dumps({'file':str(target),'bytes':target.stat().st_size,'code_files':len(code),'expandable_sections_default_closed':True},ensure_ascii=False))
if __name__=='__main__':main()
