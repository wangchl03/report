-- Read-only; strict T0, 20-second deduplication, unique first-order attribution.
SET TIME ZONE 'America/Belize';
SET query_dop=1;
WITH params AS (
    SELECT DATE '2026-01-01' AS base_start_date,
           DATE '2026-01-01' AS output_start_date,
           DATE '2026-10-01' AS output_end_date,
           CURRENT_TIMESTAMP AT TIME ZONE 'America/Belize' AS data_cutoff_ts
), raw_pass_offer AS (
    SELECT v.user_id, v.serial_id, v.vir_date::date AS vir_date,
           v.vir_unix,
           TO_TIMESTAMP(v.vir_unix) AT TIME ZONE 'America/Belize' AS vir_time
    FROM wangchuanliang.order_vir_f_copy v CROSS JOIN params p
    WHERE v.is_pass1 = 1 AND v.loan_type_code = 2 AND v.vir_unix > 0
      AND v.vir_date >= p.base_start_date - 1
      AND v.vir_date < p.data_cutoff_ts::date + 1
      AND TO_TIMESTAMP(v.vir_unix) AT TIME ZONE 'America/Belize' < p.data_cutoff_ts
), qualified_offer AS (
    SELECT v.* FROM raw_pass_offer v
    WHERE EXISTS (
        SELECT 1 FROM wangchuanliang.side_recycle_type_copy r
        WHERE r.serial_id = v.serial_id AND r.recycle_type = 3
    )
), serial_latest AS (
    SELECT DISTINCT ON (user_id, serial_id) * FROM qualified_offer
    ORDER BY user_id, serial_id, vir_unix DESC
), lagged AS (
    SELECT v.*, LAG(vir_time) OVER (
        PARTITION BY user_id ORDER BY vir_time, serial_id
    ) AS previous_time
    FROM serial_latest v
), batched AS (
    SELECT v.*, SUM(CASE WHEN previous_time IS NULL
                              OR vir_time - previous_time > INTERVAL '20 seconds'
                        THEN 1 ELSE 0 END) OVER (
        PARTITION BY user_id ORDER BY vir_time, serial_id ROWS UNBOUNDED PRECEDING
    ) AS batch_id
    FROM lagged v
), batch_ranked AS (
    SELECT v.*, ROW_NUMBER() OVER (
        PARTITION BY user_id, batch_id ORDER BY vir_time DESC, serial_id DESC
    ) AS batch_rn
    FROM batched v
), dedup_offer AS (
    SELECT v.* FROM batch_ranked v CROSS JOIN params p
    WHERE batch_rn = 1 AND vir_date >= p.base_start_date
), candidate_users AS (
    SELECT DISTINCT user_id FROM dedup_offer
), funded_orders AS (
    SELECT DISTINCT ON (o.user_id, o.serial_id)
           o.user_id, o.serial_id, o.apply_time, o.remit_time,
           o.remit_amt, o.is_remit, o.repaid_time, o.repaid_date,
           o.is_repaid, o.loan_status_code
    FROM wangchuanliang.order_loan_f_v2_copy o
    JOIN candidate_users u ON u.user_id = o.user_id
    WHERE o.is_remit = 1 AND o.remit_amt > 0
    ORDER BY o.user_id, o.serial_id, o.apply_time ASC NULLS LAST
), clean_settlement AS (
    SELECT o.* FROM funded_orders o CROSS JOIN params p
    WHERE (o.is_repaid = 1 OR o.loan_status_code = 7)
      AND o.repaid_time > TIMESTAMP '2000-01-01'
      AND o.repaid_date >= p.base_start_date
      AND o.repaid_time < p.data_cutoff_ts
      AND NOT EXISTS (
          SELECT 1 FROM funded_orders x
          WHERE x.user_id = o.user_id AND x.serial_id <> o.serial_id
            AND x.remit_time <= o.repaid_time
            AND (x.repaid_time IS NULL
                 OR x.repaid_time <= TIMESTAMP '2000-01-01'
                 OR x.repaid_time > o.repaid_time)
      )
), settlement_matched AS (
    SELECT e.*, s.serial_id AS settled_serial_id, s.repaid_time,
           ROW_NUMBER() OVER (
               PARTITION BY e.user_id, e.serial_id
               ORDER BY s.repaid_time DESC, s.serial_id DESC
           ) AS settlement_rn
    FROM dedup_offer e JOIN clean_settlement s
      ON s.user_id = e.user_id AND s.repaid_date = e.vir_date
     AND s.repaid_time <= e.vir_time
), strict_t0_all AS (
    SELECT e.*, LEAD(vir_time) OVER (
        PARTITION BY user_id ORDER BY vir_time, serial_id
    ) AS next_t0_time
    FROM settlement_matched e WHERE settlement_rn = 1
), cohort AS (
    SELECT e.*, p.data_cutoff_ts FROM strict_t0_all e CROSS JOIN params p
    WHERE e.vir_date >= p.output_start_date AND e.vir_date < p.output_end_date
), raw_applications AS (
    SELECT o.user_id,o.serial_id,o.apply_time,o.apply_date,
           o.is_remit,o.remit_time,o.remit_amt,o.repaid_amt,o.due_date,o.is_due,
           o.loan_status_code,
           COUNT(*) OVER(PARTITION BY o.user_id,o.serial_id) AS source_order_rows
    FROM wangchuanliang.order_loan_f_v2_copy o
    JOIN candidate_users u ON u.user_id=o.user_id CROSS JOIN params p
    WHERE o.apply_date>=p.base_start_date-1
      AND o.apply_date<p.data_cutoff_ts::date+1
      AND o.apply_time>=p.base_start_date::timestamp AND o.apply_time<p.data_cutoff_ts
), applications AS (
    SELECT DISTINCT ON (user_id,serial_id) * FROM raw_applications
    ORDER BY user_id,serial_id,apply_time
), application_ranked AS (
    SELECT e.user_id,e.serial_id AS credit_serial_id,e.vir_date,e.vir_time,e.repaid_time,
           e.next_t0_time,e.data_cutoff_ts,
           o.serial_id AS apply_serial_id,o.apply_time,o.is_remit,o.remit_time,
           o.remit_amt,o.repaid_amt,o.due_date,o.is_due,o.loan_status_code,o.source_order_rows,
           ROW_NUMBER() OVER(PARTITION BY e.user_id,e.serial_id ORDER BY o.apply_time,o.serial_id) AS apply_rn
    FROM cohort e LEFT JOIN applications o
      ON o.user_id=e.user_id AND o.apply_time>=e.vir_time
     AND o.apply_time<e.vir_date+INTERVAL '16 days'
     AND (e.next_t0_time IS NULL OR o.apply_time<e.next_t0_time)
), labels AS (
    SELECT *,DATE_TRUNC('month',vir_date)::date AS t0_month,
           CASE WHEN apply_time IS NULL THEN '未在15日内提单'
                WHEN apply_time::date-vir_date=0 THEN 'D0'
                WHEN apply_time::date-vir_date=1 THEN 'D1'
                WHEN apply_time::date-vir_date=2 THEN 'D2'
                WHEN apply_time::date-vir_date=3 THEN 'D3'
                WHEN apply_time::date-vir_date BETWEEN 4 AND 7 THEN 'D4-D7'
                WHEN apply_time::date-vir_date BETWEEN 8 AND 15 THEN 'D8-D15'
                ELSE '时间异常' END AS first_apply_bucket,
           CASE WHEN is_remit=1 AND remit_amt>0 THEN 1 ELSE 0 END AS funded,
           CASE WHEN is_remit=1 AND remit_amt>0 AND is_due=1
                     AND due_date>=DATE '2000-01-01' AND due_date<data_cutoff_ts::date
                THEN 1 ELSE 0 END AS matured
    FROM application_ranked WHERE apply_rn=1
), audit AS (
    SELECT COUNT(*) AS all_t0_events,COUNT(*)-COUNT(DISTINCT credit_serial_id) AS duplicate_t0_ids,
      COUNT(apply_serial_id)-COUNT(DISTINCT apply_serial_id) AS duplicate_first_order_assignments,
      SUM(CASE WHEN repaid_time>vir_time OR vir_time::date<>vir_date
                    OR apply_time<vir_time OR apply_time>=next_t0_time THEN 1 ELSE 0 END) AS invalid_time_events,
      SUM(CASE WHEN source_order_rows>1 THEN 1 ELSE 0 END) AS repeated_financial_source_orders,
      SUM(CASE WHEN matured=1 AND repaid_amt IS NULL THEN 1 ELSE 0 END) AS missing_mature_repaid_amount,
      SUM(CASE WHEN funded=1 AND (due_date IS NULL OR due_date<DATE '2000-01-01') THEN 1 ELSE 0 END) AS missing_funded_due_date,
      SUM(CASE WHEN first_apply_bucket='时间异常' THEN 1 ELSE 0 END) AS unexpected_timing_bucket,
      MIN(vir_date) AS first_event_date,MAX(vir_date) AS last_event_date
    FROM labels
), summary AS (
    SELECT CASE WHEN GROUPING(t0_month)=1 THEN '合计' ELSE TO_CHAR(t0_month,'YYYY-MM') END AS month,
      first_apply_bucket,COUNT(*) AS events,COUNT(DISTINCT user_id) AS users,
      COUNT(apply_serial_id) AS first_application_orders,
      SUM(funded) AS funded_orders,SUM(matured) AS matured_orders,
      COUNT(DISTINCT CASE WHEN matured=1 THEN user_id ELSE NULL END) AS matured_users,
      SUM(CASE WHEN funded=1 AND matured=0 THEN 1 ELSE 0 END) AS not_matured_funded_orders,
      SUM(CASE WHEN matured=1 THEN remit_amt ELSE 0 END) AS matured_principal,
      SUM(CASE WHEN matured=1 THEN COALESCE(repaid_amt,0) ELSE 0 END) AS matured_repaid,
      SUM(CASE WHEN matured=1 THEN COALESCE(repaid_amt,0)-remit_amt ELSE 0 END) AS book_profit,
      SUM(CASE WHEN matured=1 AND loan_status_code=8 THEN 1 ELSE 0 END) AS current_overdue_matured_orders
    FROM labels GROUP BY GROUPING SETS ((t0_month,first_apply_bucket),(first_apply_bucket))
)
SELECT s.*,100.0*book_profit/NULLIF(matured_principal,0) AS profit_pct,
       a.* FROM summary s CROSS JOIN audit a ORDER BY month,first_apply_bucket