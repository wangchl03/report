import fs from 'node:fs/promises';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import assert from 'node:assert/strict';
import {Workbook,SpreadsheetFile} from '@oai/artifact-tool';
const W=path.dirname(fileURLToPath(import.meta.url));
const d=JSON.parse(await fs.readFile(path.join(W,'analysis.json'),'utf8'));
assert(d.quality.passed);
const out=path.resolve(W,'../../outputs/循环贷与T0_提单时点盈利与召回策略_20261022');
await fs.mkdir(out,{recursive:true});
const wb=Workbook.create();
let tableSequence=0;
const amount='#,##0.00;[Red](#,##0.00);0.00',pct='0.00%;[Red](0.00%);0.00%',count='#,##0;[Red](#,##0);0';
function c(n){let s='';for(;n;n=Math.floor((n-1)/26))s=String.fromCharCode(65+(n-1)%26)+s;return s;}
function make(name,title,headers,rows,widths={},formats={}){
 const sh=wb.worksheets.add(name),last=c(headers.length),end=rows.length+5;
 sh.showGridLines=false;sh.tabColor='#213F59';
 sh.getRange(`A1:${last}${end}`).format={font:{name:'Arial',size:11,color:'#183046'},rowHeight:25,columnWidth:20,verticalAlignment:'center'};
 sh.getRange('A2').values=[[title]];sh.getRange('A2').format.font={name:'Arial',size:15,bold:true,color:'#183046'};
 sh.getRange('A3').values=[['获额期间：2026-01-01至2026-09-30。回款快照（北京时间）：'+d.meta.beijing_time.slice(0,19).replace('T',' ')+'。业务统计日：'+d.meta.business_stat_date+'。']];
 sh.getRange('A3').format.font={name:'Arial',size:10,color:'#526575'};
 sh.getRange(`A5:${last}5`).values=[headers];sh.getRange(`A6:${last}${end}`).values=rows;
 sh.getRange(`A6:${last}${end}`).setNumberFormat(count);
 const t=sh.tables.add(`A5:${last}${end}`,true,'Data'+(++tableSequence));t.showFilterButton=true;
 sh.getRange(`A5:${last}5`).format={fill:'#213F59',font:{name:'Arial',size:11,bold:true,color:'#FFFFFF'},wrapText:true,rowHeight:48,horizontalAlignment:'center',verticalAlignment:'center',borders:{insideVertical:{style:'thin',color:'#FFFFFF'}}};
 for(const [col,w] of Object.entries(widths))sh.getRange(`${col}5:${col}${end}`).format.columnWidth=w;
 for(const [col,f] of Object.entries(formats))sh.getRange(`${col}6:${col}${end}`).setNumberFormat(f);
 sh.freezePanes.freezeRows(5);sh.freezePanes.freezeColumns(2);
 return {sh,end,last};
}
const fields=[['product','类型'],['month','获额月份'],['stage','首次提单阶段'],['offer_events','入样获额\n事件数'],['offer_users','获额用户数'],['apply_events','首次提单\n事件数'],['apply_users','首次提单\n用户数'],['apply_rate','阶段提单率'],['unique_orders','首次提单\n独立订单数'],['funded_orders','放款订单数'],['matured_orders','已到期\n放款订单数'],['mature_coverage','到期覆盖率'],['principal','已到期放款本金'],['repaid','已到期订单\n当前回款'],['profit','账面利润'],['profit_rate','账面盈利率'],['avg_mature_principal','已到期订单\n平均本金'],['current_status8_mature_orders','已到期中\n当前状态8订单数'],['funded_order_rate','首次提单订单\n放款成功率']];
const values=rr=>rr.map(r=>fields.map(([k])=>['principal','repaid','profit'].includes(k)?Number(r[k]):r[k]));
const formats={H:pct,L:pct,M:amount,N:amount,O:amount,P:pct,Q:amount,S:pct};
const widths={A:14,B:16,C:18,M:24,N:24,O:24,Q:24};
const pooled=[...d.rows.filter(r=>r.month==='合计'),...d.combined.filter(r=>r.month==='合计')];
const first=make('阶段对比','循环贷与T0六阶段提单率及盈利率',fields.map(x=>x[1]),values(pooled),widths,formats);
first.sh.getRange('A4').values=[['D1—D15及D0—D15按订单重新去重汇总。阶段之间可能重复对应同一笔提单订单，金额不可直接相加。']];
first.sh.getRange('A4').format.font={name:'Arial',size:10,color:'#526575'};
const dr=first.end+4;
first.sh.getRange(`A${dr}:G${dr}`).values=[['阶段','循环贷提单率','T0提单率','提单率差\nT0−循环贷（百分点）','循环贷盈利率','T0盈利率','盈利率差\nT0−循环贷（百分点）']];
first.sh.getRange(`A${dr}:G${dr}`).format={fill:'#213F59',font:{name:'Arial',size:11,bold:true,color:'#FFFFFF'},rowHeight:48,wrapText:true,horizontalAlignment:'center'};
first.sh.getRange(`A${dr+1}:G${dr+6}`).values=d.stages.map(s=>{const cc=d.rows.find(r=>r.product==='循环贷'&&r.stage===s&&r.month==='合计'),tt=d.rows.find(r=>r.product==='T0'&&r.stage===s&&r.month==='合计');return [s,cc.apply_rate,tt.apply_rate,100*(tt.apply_rate-cc.apply_rate),cc.profit_rate,tt.profit_rate,100*(tt.profit_rate-cc.profit_rate)];});
for(const col of ['B','C','E','F'])first.sh.getRange(`${col}${dr+1}:${col}${dr+6}`).setNumberFormat(pct);
for(const col of ['D','G'])first.sh.getRange(`${col}${dr+1}:${col}${dr+6}`).setNumberFormat('+0.00;[Red]-0.00;0.00');
const monthly=make('月度明细','月度六阶段及累计区间统计',fields.map(x=>x[1]),values([...d.rows,...d.combined]),widths,formats);
for(const [idx,r] of [...d.rows,...d.combined].entries())if(r.month==='合计'){
 const rr=monthly.sh.getRange(`A${idx+6}:S${idx+6}`);rr.format.fill='#DFEAF2';rr.format.font={name:'Arial',size:11,bold:true,color:'#183046'};
}
const overlapFields=[['month','月份'],['kind','重叠口径'],['cycle_events','循环贷侧\n命中事件数'],['cycle_denominator','循环贷\n对应分母'],['cycle_share','占循环贷\n对应事件数'],['t0_events','T0侧\n命中事件数'],['t0_denominator','T0\n对应分母'],['t0_share','占T0\n对应事件数'],['cycle_all_offer_share','占循环贷\n全部获额事件数'],['t0_all_offer_share','占T0\n全部获额事件数']];
const ov=make('重叠分析','获额事件与首次提单订单重叠',overlapFields.map(x=>x[1]),d.overlap.map(r=>overlapFields.map(([k])=>r[k])),{A:15,B:34},{E:pct,H:pct,I:pct,J:pct});
ov.sh.getRange('A4').values=[['同一首次提单订单的对应分母为各自D0—D15首次提单事件数。两类获额均发生的用户仅描述用户交叉，不代表同一次事件。']];
let r=ov.end+3;ov.sh.getRange(`A${r}`).values=[['六阶段首次提单订单重叠']];r+=2;
const oh=['类型','阶段','首次提单事件数','对应共享订单事件数','占该阶段提单事件','共享独立订单数'];
ov.sh.getRange(`A${r}:F${r}`).values=[oh];ov.sh.getRange(`A${r}:F${r}`).format={fill:'#213F59',font:{color:'#FFFFFF',bold:true},rowHeight:44,wrapText:true};
ov.sh.getRange(`A${r+1}:F${r+d.overlap_stages.length}`).values=d.overlap_stages.map(x=>[x.product,x.stage,x.apply_events,x.shared_first_order_events,x.shared_share,x.shared_orders]);ov.sh.getRange(`E${r+1}:E${r+d.overlap_stages.length}`).setNumberFormat(pct);
const controls=[...d.independent_t0_control.map(r=>({...r,control:'T0不按下一次获额截断'})),...d.fully_mature_control.map(r=>({...r,control:'两类均全部到期月份'})),...d.nonshared_application_control.map(r=>({...r,control:'剔除跨类型共享提单订单'}))];
const cf=[['control','核对口径'],...fields];
const ctl=make('口径与核对','观察规则及到期成熟度核对',cf.map(x=>x[1]),controls.map(r=>cf.map(([k])=>['principal','repaid','profit'].includes(k)?Number(r[k]):r[k])),{A:32,B:14,C:45,D:18,N:24,O:24,P:24,R:24},{I:pct,M:pct,N:amount,O:amount,P:amount,Q:pct,R:amount,T:pct});
const notes=[
 ['业务时区','America/Belize。D0为获额时刻至当天结束，D1为次日，以此类推。D4—D7、D8—D15均含首尾日。'],
 ['20秒去重','两类分别按同用户相邻获额间隔≤20秒链式去重，保留最新获额，同秒取最大订单编号。'],
 ['T0事件','结清续贷类型recycle_type=3且获额通过。当日此前须曾整笔干净结清全部已放款订单。'],
 ['T0提单归因','主表沿用既有规则，观察在下一次T0获额出现时截断。不截断结果在本页单列。'],
 ['循环贷事件','recycle_type=2且获额通过。获额时须有在途订单；获额至首次提单前在途全部结束或出现分期逾期，记未有效提单。'],
 ['提单分母','阶段提单事件数÷该类入样获额事件数，不限定最终是否放款、到期。各阶段为首次提单分段，并非累计。'],
 ['盈利订单','首次提单且成功放款、remit_amt>0、is_due=1、到期日有效且严格早于业务统计日。'],
 ['回款与盈利','回款取当前repaid_amt，不限制回款日期。盈利率=(回款合计−本金合计)÷本金合计。不是月度百分比均值。'],
 ['金额单位','金额保留源表单位，不额外换算币种。未另扣资金、获客和运营成本。'],
 ['去重','月内、阶段内按提单订单去重。合计跨月份重新去重。D1—D15、D0—D15重新按订单去重，不能简单累加阶段金额。'],
 ['事件重叠','同一用户且同一获额订单号才是同一获额事件。相差≤20秒只表示时点接近，不将其强行合为同一业务事件。'],
 ['提单重叠','两类事件的首次提单命中同一用户同一提单订单，分别统计各侧归因事件数及所占比例。'],
 ['相近事件月度','各侧按本类获额事件月份归月，另一侧允许命中1—9月任一事件，不要求同月。'],
 ['完整到期核对','本次两类六阶段全部放款均到期的月份为：'+d.quality.fully_mature_months.join('、')+'。'],
 ['标签时点','循环贷标签复用2026-10-19已审计数据；T0标签本次读取。两类回款均取同一数据库快照。'],
 ['统计边界','已到期订单当前状态8仍保留。历史不同提单时点的差异不等于召回、提前或推迟提单的因果效果。'],
 ['数据来源','wangchuanliang.order_vir_f_copy、side_recycle_type_copy、order_loan_f_v2_copy、repayment_plan_v2_copy。']
];
r=ctl.end+4;ctl.sh.getRange(`A${r}:B${r+notes.length-1}`).values=notes;ctl.sh.getRange(`A${r}:A${r+notes.length-1}`).format.font={name:'Arial',size:11,bold:true,color:'#526575'};
ctl.sh.getRange(`B${r}:B${r+notes.length-1}`).format.wrapText=false;
if(d.previous_cycle_t0){
 const p=d.previous_cycle_t0;
 const subtitle='按触发本次在贷归零的结清订单自身类型=循环贷筛选；提单、回款沿用原报告快照。';
 const allTotals=[...p.rows,...p.combined,...d.rows,...d.combined,...p.remainder_rows,...p.remainder_combined].filter(x=>x.month==='合计');
 const newWidths={...widths,A:30};
 const summary=make('循环贷结清后T0对比','刚结清循环贷订单的T0事件：六阶段对比',fields.map(x=>x[1]),values(allTotals),newWidths,formats);
 summary.sh.getRange('A4').values=[[subtitle+' 本组是全部T0子集，不能相加。']];
 summary.sh.getRange('A4').format.font={name:'Arial',size:10,color:'#526575'};
 const monthlyRows=[...p.rows,...p.combined,...p.remainder_rows,...p.remainder_combined];
 const sub=make('循环贷结清后T0月度','刚结清循环贷T0及其余T0：月度六阶段明细',fields.map(x=>x[1]),values(monthlyRows),newWidths,formats);
 sub.sh.getRange('A4').values=[[subtitle]];sub.sh.getRange('A4').format.font={name:'Arial',size:10,color:'#526575'};
 for(const [idx,row] of monthlyRows.entries())if(row.month==='合计'){
  const rr=sub.sh.getRange(`A${idx+6}:S${idx+6}`);rr.format.fill='#DFEAF2';rr.format.font={name:'Arial',size:11,bold:true,color:'#183046'};
 }
 assert.deepEqual(summary.sh.getRange(`A6:S${summary.end}`).values,values(allTotals));
 assert.deepEqual(sub.sh.getRange(`A6:S${sub.end}`).values,values(monthlyRows));
}
wb.recalculate();assert.deepEqual(first.sh.getRange(`A6:S${first.end}`).values,values(pooled));assert.equal(monthly.end-5,160);
const file=path.join(out,'循环贷与T0_六阶段提单率与盈利率对比_20260101-20260930.xlsx');
await(await SpreadsheetFile.exportXlsx(wb)).save(file);
await fs.writeFile(path.join(W,'excel_verification.json'),JSON.stringify({passed:true,file,summary_rows:pooled.length,monthly_rows:160,overlap_rows:d.overlap.length,controls:controls.length,previous_cycle_summary_rows:d.previous_cycle_t0?32:0,previous_cycle_monthly_rows:d.previous_cycle_t0?160:0},null,2));
console.log(JSON.stringify({file,bytes:(await fs.stat(file)).size}));
