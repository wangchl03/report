网页复原：python build_report.py（与analysis.json、report_ui.js同目录），可设置REPORT_OUTPUT_DIR。
重新取数：配置DB_HOST、DB_PORT、DB_NAME、DB_USER、DB_PASSWORD，运行refresh_cycle_labels.py，再运行extract.py、analyze.py。重查会使用新快照，不能保证与历史冻结标签完全相同。
Excel导出：通过@oai/artifact-tool及配套Node运行build_workbook.mjs。
主表T0采用下一次获额截断，独立观察对照仅用于可比性检查。
