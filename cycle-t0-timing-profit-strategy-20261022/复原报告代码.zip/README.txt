网页复原：python build_report.py（与analysis.json、report_ui.js、previous_cycle_report.py同目录），可设置REPORT_OUTPUT_DIR。
重新取数：配置DB_HOST、DB_PORT、DB_NAME、DB_USER、DB_PASSWORD，运行refresh_cycle_labels.py，再依次运行extract.py、extract_previous_cycle.py、analyze.py。重查会使用新快照，不能保证与历史冻结标签完全相同。
刚结清循环贷T0：先生成完整T0序列和下一次T0截断，再按触发干净结清的订单自身recycle_type=2筛选。独立PGSQL见T0_previous_cycle_six_stages.sql。
Excel导出：通过@oai/artifact-tool及配套Node运行build_workbook.mjs。
主表T0采用下一次获额截断，独立观察对照仅用于可比性检查。
