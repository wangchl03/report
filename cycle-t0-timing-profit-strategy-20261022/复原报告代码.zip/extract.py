"""Read-only T0 labels and both cohorts' finances in one database snapshot."""
from pathlib import Path
from datetime import date,datetime
from decimal import Decimal as D
import sys,json,time,gzip,base64,secrets,re
import pandas as pd
import psycopg2
W=Path(__file__).resolve().parent
sys.path.insert(0,str(W.parent/'t0_raise3000_behavior_20261020'))
from common import connection_kwargs,PGPMessage

def enc(x):
 if isinstance(x,D):return str(x)
 if isinstance(x,(date,datetime)):return x.isoformat()
 raise TypeError(type(x).__name__)
def parse(s):
 pattern=r'("(?:[^"\\]|\\.)*")|(?P<lead>[:\[,]\s*)(?P<sign>-?)\.(?P<digit>\d)'
 return json.loads(re.sub(pattern,lambda m:m.group(0) if m.group(1) else m.group('lead')+m.group('sign')+'0.'+m.group('digit'),s),parse_float=D)
def packed(q,sql,args=None):
 key=secrets.token_urlsafe(32);args=dict(args or {},transport_key=key)
 query="SELECT COUNT(*),encode(pgp_sym_encrypt(string_agg(row_to_json(z)::text,E'\\n'),%(transport_key)s,'compress-algo=1,compress-level=6,cipher-algo=aes256'),'base64') FROM ("+sql+") z"
 q.execute(query,args);expected,blob=q.fetchone()
 if expected==0:return []
 decrypted=PGPMessage.from_blob(base64.b64decode(blob)).decrypt(key);raw=decrypted.message
 if isinstance(raw,(bytes,bytearray)):raw=bytes(raw).decode('utf-8')
 elif decrypted._message.format=='t':raw=raw.encode('latin-1').decode('utf-8')
 rows=[parse(s) for s in str(raw).splitlines()];assert len(rows)==expected
 return rows
def save(name,rows):
 with gzip.open(W/name,'wt',encoding='utf-8') as f:json.dump(rows,f,ensure_ascii=False,default=enc)

template=W/'T0_template.sql'
source=(template if template.exists() else W.parent/'t0_first_apply_profit_202601_202609_20261021/query.sql').read_text()
T0=source[source.index('WITH params AS ('):source.index('), raw_applications AS (')]+''')
SELECT user_id,serial_id AS offer_serial_id,
 EXTRACT(EPOCH FROM vir_time AT TIME ZONE 'America/Belize')::bigint AS offer_epoch,
 EXTRACT(EPOCH FROM repaid_time AT TIME ZONE 'America/Belize')::bigint AS clean_settle_epoch,
 EXTRACT(EPOCH FROM next_t0_time AT TIME ZONE 'America/Belize')::bigint AS next_t0_epoch,
 EXTRACT(EPOCH FROM (vir_date+16)::timestamp AT TIME ZONE 'America/Belize')::bigint AS window_end_epoch
FROM cohort'''
(W/'t0_event_details.sql').write_text('-- Read-only. Compare native next-T0 cutoff with independent D0-D15 attribution.\n'+T0+';')
CASH='''SELECT o.user_id,o.serial_id,
 CASE WHEN o.apply_time>=TIMESTAMP '2000-01-01'
 THEN EXTRACT(EPOCH FROM o.apply_time AT TIME ZONE 'America/Belize')::bigint
 WHEN o.apply_unix>0 THEN o.apply_unix::bigint END AS app_epoch,
 o.is_remit,o.remit_amt,o.repaid_amt,o.due_date,o.is_due,o.loan_status_code
 FROM wangchuanliang.order_loan_f_v2_copy o
 WHERE o.user_id IN (SELECT UNNEST(%(users)s::bigint[]))
 AND ((o.apply_time>=TIMESTAMP '2026-01-01' AND o.apply_time<TIMESTAMP '2026-10-16')
 OR ((o.apply_time IS NULL OR o.apply_time<TIMESTAMP '2000-01-01')
 AND o.apply_unix>=1767247200 AND o.apply_unix<1792130400))'''
(W/'cycle_cash_query.sql').write_text('-- Read-only. users parameter comes from audited cycle event labels.\n'+CASH+';')

def main():
 start=time.monotonic()
 ev=pd.read_pickle(W/'cycle_events.pkl') if (W/'cycle_events.pkl').exists() else pd.read_csv(W.parent/'cycle_inflight_conversion_20s_20261020/event_audit.csv.gz')
 ev=ev.loc[ev.offer_time.between(1767247200,1790834399)].copy()
 ev['month']=pd.to_datetime(ev.offer_time,unit='s',utc=True).dt.tz_convert('America/Belize').dt.strftime('%Y-%m')
 qualified=ev.loc[ev.included.eq(1)&ev.valid_first_app.eq(1)&ev.day.between(0,15)]
 wanted={(int(r.user_id),int(r.first_app_time)) for r in qualified.itertuples()}
 users=sorted({u for u,t in wanted});financial=[]
 with psycopg2.connect(**dict(connection_kwargs(),connect_timeout=20,application_name='t0_cycle_comparison_readonly')) as c:
  c.set_session(readonly=True,isolation_level='REPEATABLE READ')
  with c.cursor() as q:
   for sql in ["SET TIME ZONE 'America/Belize'",'SET query_dop=1',"SET work_mem='32MB'",'SET statement_timeout=180000']:q.execute(sql)
   q.execute("SELECT CURRENT_TIMESTAMP,CURRENT_DATE,CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Shanghai',current_setting('transaction_read_only')")
   meta=dict(zip(['snapshot','business_stat_date','beijing_time','read_only'],q.fetchone()));assert meta['read_only']=='on'
   (W/'snapshot.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2,default=enc))
   print(json.dumps({'phase':'started','meta':meta,'cycle_events':len(ev),'cycle_valid_app_events':len(qualified)},default=enc),flush=True)
   t0=[]
   for ts in range(4):
    t=time.monotonic();sql=T0.replace('WHERE v.is_pass1 = 1 AND v.loan_type_code = 2 AND v.vir_unix > 0',f'WHERE v.is_pass1 = 1 AND v.loan_type_code = 2 AND v.vir_unix > 0 AND MOD(v.user_id,4)={ts}')
    part=packed(q,sql);save(f't0_event_shard_{ts}.json.gz',part);t0.extend(part)
    print(json.dumps({'phase':'T0_details_shard_complete','shard':ts,'events':len(part),'seconds':round(time.monotonic()-t,1)}),flush=True)
   save('t0_events.json.gz',t0)
   t0users={int(r['user_id']) for r in t0};users=sorted(set(users)|t0users)
   q.execute('SET enable_nestloop=off')
   for shard in range(8):
    t=time.monotonic();rows=packed(q,CASH,{'users':'{'+','.join(str(u) for u in users if u%8==shard)+'}'})
    keep=[r for r in rows if int(r['user_id']) in t0users or (int(r['user_id']),int(r['app_epoch'])) in wanted]
    financial.extend(keep);save(f'cycle_finances_{shard}.json.gz',keep)
    print(json.dumps({'phase':'cycle_finances_complete','shard':shard,'source_rows':len(rows),'needed_rows':len(keep),'seconds':round(time.monotonic()-t,1)}),flush=True)
   # Global source-type quality is checked without choosing MIN/MAX recycle_type.
   types=packed(q,"""SELECT COUNT(*) AS multi_type_order_ids FROM (
    SELECT serial_id FROM wangchuanliang.side_recycle_type_copy
    WHERE recycle_type IN (2,3) GROUP BY serial_id HAVING COUNT(DISTINCT recycle_type)>1) x""")
   (W/'type_quality.json').write_text(json.dumps(types,ensure_ascii=False,default=enc,indent=2))
  c.rollback()
 ev.to_pickle(W/'cycle_events.pkl')
 assert wanted.issubset(set((int(r['user_id']),int(r['app_epoch'])) for r in financial))
 (W/'extraction_complete.json').write_text(json.dumps({'passed':True,'meta':meta,'t0_events':len(t0),'cycle_events':len(ev),'cycle_first_app_keys':len(wanted),'financial_rows':len(financial),'seconds':round(time.monotonic()-start,1)},ensure_ascii=False,default=enc,indent=2))
 print(json.dumps({'phase':'complete','seconds':round(time.monotonic()-start,1)},ensure_ascii=False),flush=True)

if __name__=='__main__':main()
