-- Read-only parameterized enrichment of frozen T0 settlement anchors.
WITH anchor_input AS (
    -- Equal-length arrays enumerate distinct (user, frozen clean-settlement timestamp) pairs.
    SELECT UNNEST(%(users)s::bigint[]) AS user_id,
           UNNEST(%(times)s::bigint[]) AS settle_epoch
), funded_orders AS (
    -- Same funded-order deduplication and eligibility as the original T0 template.
    SELECT DISTINCT ON (o.user_id,o.serial_id)
           o.user_id,o.serial_id,o.repaid_time,o.repaid_date,
           o.remit_time,o.is_repaid,o.loan_status_code
    FROM wangchuanliang.order_loan_f_v2_copy o
    WHERE o.user_id IN (SELECT user_id FROM anchor_input)
      AND o.is_remit=1 AND o.remit_amt>0
    ORDER BY o.user_id,o.serial_id,o.apply_time ASC NULLS LAST
), matched AS (
    SELECT f.*,a.settle_epoch
    FROM funded_orders f JOIN anchor_input a
      ON a.user_id=f.user_id
     AND EXTRACT(EPOCH FROM f.repaid_time AT TIME ZONE 'America/Belize')::bigint=a.settle_epoch
    WHERE (f.is_repaid=1 OR f.loan_status_code=7)
      AND f.repaid_time>=TIMESTAMP '2026-01-01'
      AND f.repaid_time<TIMESTAMP '2026-10-01'
)
SELECT m.user_id,m.serial_id,m.settle_epoch,m.repaid_time,m.repaid_date,
       m.remit_time,r.recycle_type
FROM matched m LEFT JOIN wangchuanliang.side_recycle_type_copy r
  ON r.serial_id=m.serial_id
;
