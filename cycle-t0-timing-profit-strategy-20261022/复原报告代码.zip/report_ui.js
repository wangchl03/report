const D=JSON.parse(document.getElementById('data').textContent);
const colors=['#43c7e7','#ffc26b'];
const names=['循环贷','T0'];
const stageNames=['当天D0','第1日','第2日','第3日','第4—7日','第8—15日'];
const pct=x=>x==null?'—':(100*x).toFixed(2)+'%';
const num=x=>x==null?'—':Number(x).toLocaleString('en-US');
const amt=x=>Number(x).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});
function bars(title,series){
 const multi=series.length>2,w=600,h=multi?550:420,left=107,right=100,top=55,stride=multi?78:56,bar=16;
 const max=Math.max(.01,...series.flatMap(s=>s.values.filter(v=>v!=null)))*1.16,scale=(w-left-right)/max;
 let z=`<svg role="img" aria-label="${title}" viewBox="0 0 ${w} ${h}" xmlns="http://www.w3.org/2000/svg"><title>${title}</title>`;
 series.forEach((s,j)=>z+=`<rect x="${left+j*160}" y="12" width="12" height="12" fill="${s.color||colors[j]}"/><text x="${left+18+j*160}" y="23" fill="${s.color||colors[j]}" font-size="13">${s.name}</text>`);
 stageNames.forEach((s,i)=>{const y=top+stride*i;z+=`<text x="${left-10}" y="${y+22}" text-anchor="end" fill="#d9e7ef" font-size="14">${s}</text>`;series.forEach((s,j)=>{const v=s.values[i],ww=Math.max(0,v||0)*scale,yy=y+j*21,color=s.color||colors[j];z+=`<rect x="${left}" y="${yy}" width="${ww.toFixed(2)}" height="${bar}" rx="3" fill="${color}"/><text x="${left+ww+7}" y="${yy+13}" fill="${color}" font-size="13">${pct(v)}</text>`})});return z+'</svg>';
}
function rectsMeet(a,b,gap=0){
 return a.x<b.x+b.width+gap&&a.x+a.width+gap>b.x&&a.y<b.y+b.height+gap&&a.y+a.height+gap>b.y;
}
function segmentMeetsBox(a,b,box,pad=0){
 const r={x:box.x-pad,y:box.y-pad,width:box.width+pad*2,height:box.height+pad*2};
 let lo=0,hi=1;
 for(const [start,delta,min,max] of [[a.x,b.x-a.x,r.x,r.x+r.width],[a.y,b.y-a.y,r.y,r.y+r.height]]){
  if(Math.abs(delta)<1e-9){if(start<min||start>max)return false;continue}
  let u=(min-start)/delta,v=(max-start)/delta;if(u>v)[u,v]=[v,u];lo=Math.max(lo,u);hi=Math.min(hi,v);if(lo>hi)return false;
 }
 return true;
}
function lineChartLayout(field,desiredWidth=1160,extraHeight=0){
 const w=Math.max(620,Math.min(1160,desiredWidth)),h=430+(w<900?110:0)+extraHeight,left=76,right=54,top=64,bottom=56;
 const series=names.map(name=>({name,values:D.months.map(m=>D.rows.find(r=>r.product===name&&r.month===m&&r.stage==='D0')[field])}));
 const vals=series.flatMap(s=>s.values).filter(x=>x!=null),min=Math.max(0,Math.min(...vals)-.04),max=Math.max(...vals)+.04;
 const xx=i=>left+38+(w-left-right-76)*i/(D.months.length-1),yy=v=>h-bottom-(v-min)/(max-min)*(h-top-bottom);
 series.forEach((s,j)=>s.points=s.values.map((v,i)=>({x:xx(i),y:yy(v),series:j,month:i,value:v,text:pct(v)})));
 const points=series.flatMap(s=>s.points),segments=series.flatMap(s=>s.points.slice(1).map((p,i)=>[s.points[i],p]));
 let labels=[];
 // Prefer the nearest collision-free position, with close series on opposite sides.
 // Bounds include padding for the real text, point marker and 3px line stroke.
 const ordered=[...points].sort((a,b)=>a.month-b.month||a.y-b.y||a.series-b.series),choices=[];
 for(const point of ordered){
  const other=series[1-point.series].points[point.month],preferred=point.y<=other.y?-1:1;
  const width=Math.ceil([...point.text].reduce((n,c)=>n+(c==='%'?12.5:c==='.'?4.5:8),0)+10),height=24,candidates=[];
  for(const sign of [preferred,-preferred])for(const distance of [0,6,12,18,22,26,30,34,38,42,48,56,64,74,86,100,116])for(const shift of [0,-10,10,-20,20,-30,30,-42,42]){
   const cx=point.x+shift,cy=point.y+sign*distance;
   const box={x:cx-width/2,y:cy-height/2,width,height};
   if(box.x<left+3||box.x+width>w-right-3||box.y<35||box.y+height>h-39)continue;
   if(segments.some(([a,b])=>segmentMeetsBox(a,b,box,6)))continue;
   if(points.some(p=>Math.hypot(p.x-Math.max(box.x,Math.min(p.x,box.x+width)),p.y-Math.max(box.y,Math.min(p.y,box.y+height)))<10))continue;
   candidates.push({...point,cx,cy,box,score:(distance*distance+shift*shift)/30+Math.abs(shift)*.1+(sign===preferred?0:3)});
  }
  candidates.sort((a,b)=>a.score-b.score);
  choices.push(candidates);
 }
 const conflict=(a,b)=>rectsMeet(a.box,b.box,8);
 let visits=0;
 function place(remaining){
  if(!remaining.length)return true;
  if(++visits>20000)return false;
  let selected=-1,available=null;
  for(const k of remaining){const free=choices[k].filter(c=>!labels.some(l=>conflict(c,l)));if(!free.length)return false;if(available===null||free.length<available.length){selected=k;available=free}}
  const rest=remaining.filter(k=>k!==selected);
  for(const candidate of available){labels.push(candidate);if(place(rest))return true;labels.pop()}
  return false;
 }
 if(!place(choices.map((_,i)=>i))){
  if(extraHeight<200)return lineChartLayout(field,w,extraHeight+100);
  throw new Error('Unable to place all monthly labels without collisions: '+field);
 }
 // Tighten the feasible layout without moving any label onto a line or another label.
 for(let pass=0;pass<4;pass++){
  let changed=false;
  for(let i=0;i<labels.length;i++){
   const current=labels[i],k=ordered.findIndex(p=>p.series===current.series&&p.month===current.month);
   const closer=choices[k].find(c=>c.score<current.score-.01&&!labels.some((l,j)=>j!==i&&conflict(c,l)));
   if(closer){labels[i]=closer;changed=true}
  }
  if(!changed)break;
 }
 // Jointly move neighboring labels so one displaced label does not keep its neighbor far away.
 for(let pass=0;pass<2;pass++)for(let i=0;i<labels.length;i++)for(let j=i+1;j<labels.length;j++){
  const a=labels[i],b=labels[j];
  if(Math.abs(a.month-b.month)>1||Math.max(Math.hypot(a.cx-a.x,a.cy-a.y),Math.hypot(b.cx-b.x,b.cy-b.y))<34)continue;
  const freeFor=l=>choices[ordered.findIndex(p=>p.series===l.series&&p.month===l.month)]
   .filter(c=>!labels.some((other,k)=>k!==i&&k!==j&&conflict(c,other))).slice(0,24);
  const aa=freeFor(a),bb=freeFor(b);let bestScore=a.score+b.score,best=null;
  for(const x of aa)for(const y of bb){
   const score=x.score+y.score;
   if(score<bestScore-.01&&!conflict(x,y)){bestScore=score;best=[x,y]}
  }
  if(best){labels[i]=best[0];labels[j]=best[1]}
 }
 labels.sort((a,b)=>a.month-b.month||a.series-b.series);
 return {w,h,left,right,top,bottom,min,max,series,labels,segments,xx,yy};
}
function lines(title,field,width=1160){
 const {w,h,left,right,bottom,min,max,series,labels,xx,yy}=lineChartLayout(field,width);
 let z=`<svg role="img" aria-label="${title}" viewBox="0 0 ${w} ${h}" xmlns="http://www.w3.org/2000/svg"><title>${title}</title>`;
 for(let i=0;i<5;i++){const v=min+(max-min)*i/4,y=yy(v);z+=`<path d="M${left} ${y}H${w-right}" stroke="#21465a"/><text x="${left-12}" y="${y+5}" text-anchor="end" fill="#9bb5c7" font-size="12">${pct(v)}</text>`}
 series.forEach((s,j)=>{
  z+=`<text x="${left+j*150}" y="20" fill="${colors[j]}" font-size="14">${s.name}</text><polyline class="data-series-line" data-series="${j}" points="${s.points.map(p=>p.x+','+p.y).join(' ')}" stroke="${colors[j]}" fill="none" stroke-width="3"/>`;
  s.points.forEach(p=>z+=`<circle cx="${p.x}" cy="${p.y}" r="4" fill="${colors[j]}"/>`);
 });
 labels.forEach(l=>{
  const color=colors[l.series];
  z+=`<g class="data-label" data-series="${l.series}" data-month="${D.months[l.month]}"><rect class="data-label-box" x="${l.box.x}" y="${l.box.y}" width="${l.box.width}" height="${l.box.height}" rx="4" fill="#082235"/><text x="${l.cx}" y="${l.cy+4.5}" text-anchor="middle" fill="${color}" font-family="Arial,sans-serif" font-size="14" font-variant-numeric="tabular-nums">${l.text}</text></g>`;
 });
 z+=`<text x="${w-right}" y="20" text-anchor="end" fill="#9bb5c7" font-size="12">${D.months[0].slice(0,4)}年</text>`;
 D.months.forEach((m,i)=>z+=`<text x="${xx(i)}" y="${h-18}" text-anchor="middle" fill="#9bb5c7" font-size="13">${Number(m.slice(-2))}月</text>`);return z+'</svg>';
}
const headers=['类型','月份','阶段','获额事件','首次提单事件','提单率','到期订单','到期覆盖率','已到期放款本金','当前回款','账面利润','盈利率'];
function table(rr){return '<div class="scroll"><table><thead><tr>'+headers.map(x=>'<th>'+x+'</th>').join('')+'</tr></thead><tbody>'+rr.map(r=>'<tr>'+[r.product,r.month,r.stage,num(r.offer_events),num(r.apply_events),pct(r.apply_rate),num(r.matured_orders),pct(r.mature_coverage),amt(r.principal),amt(r.repaid),amt(r.profit),pct(r.profit_rate)].map(x=>'<td>'+x+'</td>').join('')+'</tr>').join('')+'</tbody></table></div>'}
function update(){
 const m=document.getElementById('month').value,rr=D.rows.filter(r=>r.month===m);
 for(const [id,field,title] of [['rate-chart','apply_rate','各阶段首次提单率'],['profit-chart','profit_rate','各阶段已到期订单盈利率']])document.getElementById(id).innerHTML=bars(title,names.map(name=>({name,values:D.stages.map(s=>rr.find(r=>r.product===name&&r.stage===s)[field])})));
 const diffHeaders=['阶段','循环贷提单率','T0提单率','差值（百分点）','循环贷盈利率','T0盈利率','差值（百分点）'];
 const delta=x=>`<span class="${x<0?'bad':'good'}">${x>=0?'+':''}${(x*100).toFixed(2)}</span>`;
 const diff='<div class="scroll"><table><thead><tr>'+diffHeaders.map(v=>'<th>'+v+'</th>').join('')+'</tr></thead><tbody>'+D.stages.map(s=>{const c=rr.find(r=>r.product==='循环贷'&&r.stage===s),t=rr.find(r=>r.product==='T0'&&r.stage===s);return '<tr><td>'+s+'</td><td>'+pct(c.apply_rate)+'</td><td>'+pct(t.apply_rate)+'</td><td>'+delta(t.apply_rate-c.apply_rate)+'</td><td>'+pct(c.profit_rate)+'</td><td>'+pct(t.profit_rate)+'</td><td>'+delta(t.profit_rate-c.profit_rate)+'</td></tr>'}).join('')+'</tbody></table></div>';
 document.getElementById('stage-table').innerHTML='<p class="note">以下差值均为T0减循环贷。</p>'+diff+table(rr);
 const c=rr.find(r=>r.product==='循环贷'),t=rr.find(r=>r.product==='T0');
 document.getElementById('scope').textContent=`${m}：循环贷分母${num(c.offer_events)}次，T0分母${num(t.offer_events)}次获额事件。盈利率按已到期本金加权。`;
}
document.getElementById('month').addEventListener('change',update);update();
function renderMonthly(){
 const width=Math.floor(document.getElementById('monthly-rate').clientWidth||1160);
 document.getElementById('monthly-rate').innerHTML=lines('D0首次提单率月度变化','apply_rate',width);
 document.getElementById('monthly-profit').innerHTML=lines('D0账面盈利率月度变化','profit_rate',width);
}
renderMonthly();
if(typeof window!=='undefined'){
 let chartResizeTimer;
 window.addEventListener('resize',()=>{clearTimeout(chartResizeTimer);chartResizeTimer=setTimeout(renderMonthly,120)});
}
document.getElementById('monthly-table').innerHTML=table(D.rows.filter(r=>r.month!=='合计'));
if(D.previous_cycle_t0){
 function updatePreviousCycle(){
  const p=D.previous_cycle_t0,m=document.getElementById('previous-cycle-month').value;
  const target=p.rows.filter(r=>r.month===m),native=D.rows.filter(r=>r.month===m),rest=p.remainder_rows.filter(r=>r.month===m);
  const groups=[{name:'刚结清循环贷T0',color:'#b798ff',rows:target},{name:'全部T0',color:colors[1],rows:native.filter(r=>r.product==='T0')},{name:'循环贷',color:colors[0],rows:native.filter(r=>r.product==='循环贷')}];
  for(const [id,field,title] of [['previous-cycle-rate','apply_rate','刚结清循环贷T0六阶段首次提单率'],['previous-cycle-profit','profit_rate','刚结清循环贷T0六阶段已到期订单盈利率']]){
   document.getElementById(id).innerHTML=bars(title,groups.map(g=>({name:g.name,color:g.color,values:D.stages.map(s=>g.rows.find(r=>r.stage===s)[field])})));
  }
  document.getElementById('previous-cycle-scope').textContent=`${m}：本组分母${num(target[0].offer_events)}次，全部T0 ${num(groups[1].rows[0].offer_events)}次，循环贷${num(groups[2].rows[0].offer_events)}次获额事件。本组为全部T0的子集。`;
  document.getElementById('previous-cycle-table').innerHTML=table([...target,...groups[1].rows,...groups[2].rows,...rest]);
 }
 document.getElementById('previous-cycle-month').addEventListener('change',updatePreviousCycle);updatePreviousCycle();
}
