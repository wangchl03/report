const D=JSON.parse(document.getElementById('data').textContent);
const colors=['#43c7e7','#ffc26b'];
const names=['循环贷','T0'];
const stageNames=['当天D0','第1日','第2日','第3日','第4—7日','第8—15日'];
const pct=x=>x==null?'—':(100*x).toFixed(2)+'%';
const num=x=>x==null?'—':Number(x).toLocaleString('en-US');
const amt=x=>Number(x).toLocaleString('en-US',{minimumFractionDigits:2,maximumFractionDigits:2});
function bars(title,series){
 const w=600,h=420,left=107,right=100,top=55,stride=56,bar=16;
 const max=Math.max(.01,...series.flatMap(s=>s.values.filter(v=>v!=null)))*1.16,scale=(w-left-right)/max;
 let z=`<svg role="img" aria-label="${title}" viewBox="0 0 ${w} ${h}" xmlns="http://www.w3.org/2000/svg"><title>${title}</title>`;
 series.forEach((s,j)=>z+=`<rect x="${left+j*160}" y="12" width="12" height="12" fill="${colors[j]}"/><text x="${left+18+j*160}" y="23" fill="${colors[j]}" font-size="13">${s.name}</text>`);
 stageNames.forEach((s,i)=>{const y=top+stride*i;z+=`<text x="${left-10}" y="${y+22}" text-anchor="end" fill="#d9e7ef" font-size="14">${s}</text>`;series.forEach((s,j)=>{const v=s.values[i],ww=Math.max(0,v||0)*scale,yy=y+j*21;z+=`<rect x="${left}" y="${yy}" width="${ww.toFixed(2)}" height="${bar}" rx="3" fill="${colors[j]}"/><text x="${left+ww+7}" y="${yy+13}" fill="${colors[j]}" font-size="13">${pct(v)}</text>`})});return z+'</svg>';
}
function lines(title,field){
 const w=1160,h=340,left=66,right=70,top=58,bottom=50;
 const series=names.map(p=>D.months.map(m=>D.rows.find(r=>r.product===p&&r.month===m&&r.stage==='D0')[field]));
 const vals=series.flat().filter(x=>x!=null),min=Math.max(0,Math.min(...vals)-.04),max=Math.max(...vals)+.04;
 const xx=i=>left+(w-left-right)*i/8,yy=v=>h-bottom-(v-min)/(max-min)*(h-top-bottom);
 let z=`<svg role="img" aria-label="${title}" viewBox="0 0 ${w} ${h}" xmlns="http://www.w3.org/2000/svg"><title>${title}</title>`;
 for(let i=0;i<5;i++){const v=min+(max-min)*i/4,y=yy(v);z+=`<path d="M${left} ${y}H${w-right}" stroke="#21465a"/><text x="${left-10}" y="${y+5}" text-anchor="end" fill="#9bb5c7" font-size="12">${pct(v)}</text>`}
 names.forEach((name,j)=>{z+=`<text x="${left+j*150}" y="20" fill="${colors[j]}" font-size="14">${name}</text><polyline points="${series[j].map((v,i)=>xx(i)+','+yy(v)).join(' ')}" stroke="${colors[j]}" fill="none" stroke-width="3"/>`;series[j].forEach((v,i)=>z+=`<circle cx="${xx(i)}" cy="${yy(v)}" r="4" fill="${colors[j]}"/><text x="${xx(i)}" y="${yy(v)+(j?22:-13)}" text-anchor="middle" fill="${colors[j]}" font-size="13">${pct(v)}</text>`)});
 D.months.forEach((m,i)=>z+=`<text x="${xx(i)}" y="${h-18}" text-anchor="middle" fill="#9bb5c7" font-size="13">${m}</text>`);return z+'</svg>';
}
const headers=['类型','月份','阶段','获额事件','首次提单事件','提单率','到期订单','到期覆盖率','已到期放款本金','当前回款','账面利润','盈利率'];
function table(rr){return '<div class="scroll"><table><thead><tr>'+headers.map(x=>'<th>'+x+'</th>').join('')+'</tr></thead><tbody>'+rr.map(r=>'<tr>'+[r.product,r.month,r.stage,num(r.offer_events),num(r.apply_events),pct(r.apply_rate),num(r.matured_orders),pct(r.mature_coverage),amt(r.principal),amt(r.repaid),amt(r.profit),pct(r.profit_rate)].map(x=>'<td>'+x+'</td>').join('')+'</tr>').join('')+'</tbody></table></div>'}
function update(){
 const m=document.getElementById('month').value,rr=D.rows.filter(r=>r.month===m);
 for(const [id,field,title] of [['rate-chart','apply_rate','各阶段首次提单率'],['profit-chart','profit_rate','各阶段已到期订单盈利率']])document.getElementById(id).innerHTML=bars(title,names.map(name=>({name,values:D.stages.map(s=>rr.find(r=>r.product===name&&r.stage===s)[field])})));
 const diffHeaders=['阶段','循环贷提单率','T0提单率','差值（百分点）','循环贷盈利率','T0盈利率','差值（百分点）'];
 const delta=x=>`<span class="${x<0?'bad':'good'}">${x>=0?'+':''}${(x*100).toFixed(2)}</span>`;
 const diff='<div class="scroll"><table><thead><tr>'+diffHeaders.map(v=>'<th>'+v+'</th>').join('')+'</tr></thead><tbody>'+D.stages.map(s=>{const c=rr.find(r=>r.product==='循环贷'&&r.stage===s),t=rr.find(r=>r.product==='T0'&&r.stage===s);return '<tr><td>'+s+'</td><td>'+pct(c.apply_rate)+'</td><td>'+pct(t.apply_rate)+'</td><td>'+delta(t.apply_rate-c.apply_rate)+'</td><td>'+pct(c.profit_rate)+'</td><td>'+pct(t.profit_rate)+'</td><td>'+delta(t.profit_rate-c.profit_rate)+'</td></tr>'}).join('')+'</tbody></table></div>';
 document.getElementById('stage-table').innerHTML='<p class="note">以下差值均为T0减循环贷。</p>'+diff+table(rr);
 const c=rr.find(r=>r.product==='循环贷'),t=rr.find(r=>r.product==='T0');
 document.getElementById('scope').textContent=`${m}：循环贷分母${num(c.offer_events)}次，T0分母${num(t.offer_events)}次获额事件。盈利率按已到期本金加权。`;
}
document.getElementById('month').addEventListener('change',update);update();
document.getElementById('monthly-rate').innerHTML=lines('D0首次提单率月度变化','apply_rate');
document.getElementById('monthly-profit').innerHTML=lines('D0账面盈利率月度变化','profit_rate');
document.getElementById('monthly-table').innerHTML=table(D.rows.filter(r=>r.month!=='合计'));
