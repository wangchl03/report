"""Aggregate-only report section for T0 triggered by settlement of a cycle loan."""
import html
N=lambda v:f'{v:,.0f}'
P=lambda v:'—' if v is None else f'{v*100:.2f}%'
H=lambda v:html.escape(str(v))
def render_previous_cycle(d,table,fold):
 p=d['previous_cycle_t0'];q=p['quality'];st=d['stages'];a=[]
 def get(rows,s,m='合计'):return next(r for r in rows if r['stage']==s and r['month']==m)
 x=get(p['rows'],'D0');t=next(r for r in d['rows'] if r['product']=='T0' and r['month']=='合计' and r['stage']=='D0')
 c=next(r for r in d['rows'] if r['product']=='循环贷' and r['month']=='合计' and r['stage']=='D0')
 rest=get(p['remainder_rows'],'D0');late=get(p['combined'],'D1-D15')
 def diff(v,base):
  if v is None or base is None:return '不可计算'
  delta=(v-base)*100
  return f'{"高" if delta>=0 else "低"}{abs(delta):.2f}个百分点'
 a.append('<section id="previous-cycle-t0"><h2>刚结清循环贷订单的T0事件</h2>')
 a.append('<p>本次T0获额通过之前，刚结清的那笔订单本身属于循环贷；结清后，用户名下全部已放款订单结清、在贷归零，并在同一业务自然日重新获额通过。按触发本次干净结清的订单判断，不按用户历史上是否借过循环贷判断。</p>')
 a.append(f'<p class="conclusion">共{N(x["offer_events"])}次T0事件、{N(x["offer_users"])}名用户，占全部T0事件的{P(q["target_event_share_of_all_t0"])}。当天首次提单率{P(x["apply_rate"])}，对应已到期订单账面盈利率{P(x["profit_rate"])}；分别比全部T0{diff(x["apply_rate"],t["apply_rate"])}、{diff(x["profit_rate"],t["profit_rate"])}。</p>')
 cards=[('入样T0事件',N(x['offer_events'])+'次',N(x['offer_users'])+'名去重用户'),('占全部T0事件',P(q['target_event_share_of_all_t0']),'全部T0 '+N(t['offer_events'])+'次'),('当天首次提单率',P(x['apply_rate']),'全部T0 '+P(t['apply_rate'])),('当天账面盈利率',P(x['profit_rate']),'全部T0 '+P(t['profit_rate']))]
 a.append('<div class="cards">'+''.join(f'<div class="card"><h3>{H(k)}</h3><strong>{H(v)}</strong><small>{H(n)}</small></div>' for k,v,n in cards)+'</div>')
 a.append('<div class="controls"><label for="previous-cycle-month">获额月份</label><select id="previous-cycle-month">'+''.join(f'<option value="{m}">{m}</option>' for m in ['合计']+d['months'])+'</select></div>')
 a.append('<div class="two"><div><h3>六阶段首次提单率</h3><div class="figure" id="previous-cycle-rate"></div></div><div><h3>六阶段已到期订单账面盈利率</h3><div class="figure" id="previous-cycle-profit"></div></div></div><p class="note" id="previous-cycle-scope"></p>')
 a.append(fold('展开所选月份的事件、订单及金额明细','<div id="previous-cycle-table"></div>'))
 a.append(f'<p>与原循环贷获额事件相比，这类T0的当天首次提单率{diff(x["apply_rate"],c["apply_rate"])}，当天订单盈利率{diff(x["profit_rate"],c["profit_rate"])}。其第1—15日合计首次提单率为{P(late["apply_rate"])}，对应已到期订单盈利率为{P(late["profit_rate"])}，比自身当天{diff(late["profit_rate"],x["profit_rate"])}。</p>')
 a.append(f'<p class="note">当天订单到期覆盖率为{P(x["mature_coverage"])}，第1—15日合计为{P(late["mature_coverage"])}。晚提单组仍有部分订单尚未到期；盈利差异也受用户、产品条件和到期结构影响，不能直接推断延后提单会提高利润。</p>')
 a.append(f'<p>将这部分事件与其余T0拆开看：其余T0的当天提单率为{P(rest["apply_rate"])}、盈利率为{P(rest["profit_rate"])}；本组分别{diff(x["apply_rate"],rest["apply_rate"])}、{diff(x["profit_rate"],rest["profit_rate"])}。召回评估应同时观察提单率、放款与利润，不把两个群体的历史盈利差异直接当作召回效果。</p>')
 monthly=[]
 for m in d['months']:
  xx=get(p['rows'],'D0',m);tt=next(r for r in d['rows'] if r['product']=='T0' and r['month']==m and r['stage']=='D0')
  monthly.append([m,N(xx['offer_events']),P(xx['offer_events']/tt['offer_events']),P(xx['apply_rate']),P(tt['apply_rate']),P(xx['profit_rate']),P(tt['profit_rate']),N(xx['matured_orders']),P(xx['mature_coverage'])])
 a.append(fold('展开各月当天提单率与盈利率对比',table(['月份','本组获额事件','占当月全部T0','本组D0提单率','全部T0 D0提单率','本组D0盈利率','全部T0 D0盈利率','本组已到期订单','本组到期覆盖率'],monthly)))
 rr=p['rows']+p['combined']+p['remainder_rows']+p['remainder_combined']
 a.append(fold('展开本组及其余T0全部月度明细',table(['类型','月份','阶段','获额事件','首次提单事件','提单率','已到期订单','已到期本金','当前回款','账面利润','盈利率','到期覆盖率'],[[r['product'],r['month'],r['stage'],N(r['offer_events']),N(r['apply_events']),P(r['apply_rate']),N(r['matured_orders']),f'{float(r["principal"]):,.2f}',f'{float(r["repaid"]):,.2f}',f'{float(r["profit"]):,.2f}',P(r['profit_rate']),P(r['mature_coverage'])] for r in rr])))
 a.append('<p class="note">本组是全部T0的子集，不能与全部T0相加。各阶段均为互斥的首次提单分段；分母为所选月份本组全部入样获额事件。先保留原T0去重与下一次T0获额截断，再筛选结清订单类型，不能仅用本组的下一次获额延长观察窗口。盈利只计已放款、已到期订单，使用原报告同一快照的repaid_amt；各汇总区间按提单订单重新去重。</p>')
 a.append('<p class="note">本组不要求此前存在一次“获额但未提单”的循环贷事件，也不据此认定循环贷资格被取消。它描述触发结清订单的类型与后续T0表现。</p>')
 if q['same_timestamp_multiple_order_events']:
  a.append(f'<p class="note">有{N(q["same_timestamp_multiple_order_events"])}次T0事件在同一结清时刻对应多笔订单，沿用原T0规则取订单编号最大的一笔；其中{N(q["same_timestamp_mixed_type_events"])}次涉及不同订单类型。订单类型缺失{N(q["unknown_trigger_type_events"])}次。</p>')
 a.append(f'<p class="note">结清订单类型补查时间：北京时间{H(q["classification_beijing_time"][:19].replace("T"," "))}。提单结果与回款仍沿用原报告北京时间{H(d["meta"]["beijing_time"][:19].replace("T"," "))}的冻结数据，保持比较时点一致。</p></section>')
 return ''.join(a)
