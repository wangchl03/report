"""Optional full refresh of cycle historical labels from read-only SQL.

The delivered report used already audited 2026-10-19 cycle labels. This script
does not silently replace the historical snapshot with later backfilled data.
Run explicitly before extract.py when a new label snapshot is intended.
"""
from pathlib import Path
import json,time
import pandas as pd
import psycopg2
from common import connection_kwargs
W=Path(__file__).resolve().parent
def main():
 sql=(W/'cycle_event_details.sql').read_text();allrows=[]
 with psycopg2.connect(**dict(connection_kwargs(),connect_timeout=20,application_name='cycle_label_refresh_readonly')) as c:
  c.set_session(readonly=True,isolation_level='REPEATABLE READ')
  with c.cursor() as q:
   for s in ["SET TIME ZONE 'America/Belize'",'SET query_dop=1','SET statement_timeout=300000']:q.execute(s)
   for i in range(8):
    query=sql.replace('0::int AS shard_id,4::int AS shard_count',f'{i}::int AS shard_id,8::int AS shard_count')
    q.execute(query);cols=[d.name for d in q.description]
    while True:
     part=q.fetchmany(5000)
     if not part:break
     allrows.extend(dict(zip(cols,r)) for r in part)
    print(json.dumps({'shard':i,'cumulative_events':len(allrows)}),flush=True)
  c.rollback()
 pd.DataFrame(allrows).to_pickle(W/'cycle_events.pkl')
if __name__=='__main__':main()
