-- Read-only. Compare native next-T0 cutoff with independent D0-D15 attribution.
WITH params AS (
    SELECT DATE '2026-01-01' AS base_start_date,
           DATE '2026-01-01' AS output_start_date,
           DATE '2026-10-01' AS output_end_date,
           CURRENT_TIMESTAMP AT TIME ZONE 'America/Belize' AS data_cutoff_ts
), raw_pass_offer AS (
    SELECT v.user_id, v.serial_id, v.vir_date::date AS vir_date,
           v.vir_unix,
           TO_TIMESTAMP(v.vir_unix) AT TIME ZONE 'America/Belize' AS vir_time
    FROM wangchuanliang.order_vir_f_copy v CROSS JOIN params p
    WHERE v.is_pass1 = 1 AND v.loan_type_code = 2 AND v.vir_unix > 0
      AND v.vir_date >= p.base_start_date - 1
      AND v.vir_date < p.data_cutoff_ts::date + 1
      AND TO_TIMESTAMP(v.vir_unix) AT TIME ZONE 'America/Belize' < p.data_cutoff_ts
), qualified_offer AS (
    SELECT v.* FROM raw_pass_offer v
    WHERE EXISTS (
        SELECT 1 FROM wangchuanliang.side_recycle_type_copy r
        WHERE r.serial_id = v.serial_id AND r.recycle_type = 3
    )
), serial_latest AS (
    SELECT DISTINCT ON (user_id, serial_id) * FROM qualified_offer
    ORDER BY user_id, serial_id, vir_unix DESC
), lagged AS (
    SELECT v.*, LAG(vir_time) OVER (
        PARTITION BY user_id ORDER BY vir_time, serial_id
    ) AS previous_time
    FROM serial_latest v
), batched AS (
    SELECT v.*, SUM(CASE WHEN previous_time IS NULL
                              OR vir_time - previous_time > INTERVAL '20 seconds'
                        THEN 1 ELSE 0 END) OVER (
        PARTITION BY user_id ORDER BY vir_time, serial_id ROWS UNBOUNDED PRECEDING
    ) AS batch_id
    FROM lagged v
), batch_ranked AS (
    SELECT v.*, ROW_NUMBER() OVER (
        PARTITION BY user_id, batch_id ORDER BY vir_time DESC, serial_id DESC
    ) AS batch_rn
    FROM batched v
), dedup_offer AS (
    SELECT v.* FROM batch_ranked v CROSS JOIN params p
    WHERE batch_rn = 1 AND vir_date >= p.base_start_date
), candidate_users AS (
    SELECT DISTINCT user_id FROM dedup_offer
), funded_orders AS (
    SELECT DISTINCT ON (o.user_id, o.serial_id)
           o.user_id, o.serial_id, o.apply_time, o.remit_time,
           o.remit_amt, o.is_remit, o.repaid_time, o.repaid_date,
           o.is_repaid, o.loan_status_code
    FROM wangchuanliang.order_loan_f_v2_copy o
    JOIN candidate_users u ON u.user_id = o.user_id
    WHERE o.is_remit = 1 AND o.remit_amt > 0
    ORDER BY o.user_id, o.serial_id, o.apply_time ASC NULLS LAST
), clean_settlement AS (
    SELECT o.* FROM funded_orders o CROSS JOIN params p
    WHERE (o.is_repaid = 1 OR o.loan_status_code = 7)
      AND o.repaid_time > TIMESTAMP '2000-01-01'
      AND o.repaid_date >= p.base_start_date
      AND o.repaid_time < p.data_cutoff_ts
      AND NOT EXISTS (
          SELECT 1 FROM funded_orders x
          WHERE x.user_id = o.user_id AND x.serial_id <> o.serial_id
            AND x.remit_time <= o.repaid_time
            AND (x.repaid_time IS NULL
                 OR x.repaid_time <= TIMESTAMP '2000-01-01'
                 OR x.repaid_time > o.repaid_time)
      )
), settlement_matched AS (
    SELECT e.*, s.serial_id AS settled_serial_id, s.repaid_time,
           ROW_NUMBER() OVER (
               PARTITION BY e.user_id, e.serial_id
               ORDER BY s.repaid_time DESC, s.serial_id DESC
           ) AS settlement_rn
    FROM dedup_offer e JOIN clean_settlement s
      ON s.user_id = e.user_id AND s.repaid_date = e.vir_date
     AND s.repaid_time <= e.vir_time
), strict_t0_all AS (
    SELECT e.*, LEAD(vir_time) OVER (
        PARTITION BY user_id ORDER BY vir_time, serial_id
    ) AS next_t0_time
    FROM settlement_matched e WHERE settlement_rn = 1
), cohort AS (
    SELECT e.*, p.data_cutoff_ts FROM strict_t0_all e CROSS JOIN params p
    WHERE e.vir_date >= p.output_start_date AND e.vir_date < p.output_end_date
)
SELECT user_id,serial_id AS offer_serial_id,
 EXTRACT(EPOCH FROM vir_time AT TIME ZONE 'America/Belize')::bigint AS offer_epoch,
 EXTRACT(EPOCH FROM repaid_time AT TIME ZONE 'America/Belize')::bigint AS clean_settle_epoch,
 EXTRACT(EPOCH FROM next_t0_time AT TIME ZONE 'America/Belize')::bigint AS next_t0_epoch,
 EXTRACT(EPOCH FROM (vir_date+16)::timestamp AT TIME ZONE 'America/Belize')::bigint AS window_end_epoch
FROM cohort;