-- Read-only, full cycle eligibility. Run user shards separately.
WITH
/* 一、统一日期、秒数和观察时点。无穷大只用于尚未整笔结清的区间右端。 */
params AS (
 SELECT DATE '2026-01-01' AS start_date, DATE '2026-10-01' AS end_date_exclusive,
  0::int AS shard_id,4::int AS shard_count,
  CURRENT_TIMESTAMP AT TIME ZONE 'America/Belize' AS asof_local,
  EXTRACT(EPOCH FROM TIMESTAMPTZ '2026-01-01 00:00:00-06:00')::double precision AS start_epoch,
  EXTRACT(EPOCH FROM TIMESTAMPTZ '2026-10-01 00:00:00-06:00')::double precision AS end_epoch,
  EXTRACT(EPOCH FROM CURRENT_TIMESTAMP)::double precision AS asof_epoch,
  EXTRACT(EPOCH FROM (CURRENT_DATE::timestamp AT TIME ZONE 'America/Belize'))::double precision AS complete_before_epoch,
  9000000000000000000::double precision AS open_end_epoch
),
/* 二、通过的循环贷获额；同用户同订单保留统计期内最新通过时间。
   vir_date筛选沿用原提取脚本，仅作分区裁剪，最终范围由vir_unix决定。
   EXISTS防止类型表关联放大，不与结清续贷流失用户表关联。 */
raw_offer AS (
    SELECT
        v.user_id::bigint AS user_id,
        v.serial_id::bigint AS serial_id,
        MAX(v.vir_unix)::double precision AS offer_epoch
    FROM wangchuanliang.order_vir_f_copy v
    CROSS JOIN params p
    WHERE v.is_pass1=1 AND v.loan_type_code=2 AND MOD(v.user_id,p.shard_count)=p.shard_id
      AND v.user_id IS NOT NULL AND v.serial_id IS NOT NULL
      AND v.vir_unix>=p.start_epoch-86400 AND v.vir_unix<p.end_epoch+86400
      AND v.vir_date>=DATE '2025-12-30' AND v.vir_date<DATE '2026-10-03'
      AND EXISTS (
          SELECT 1 FROM wangchuanliang.side_recycle_type_copy r
          WHERE r.serial_id=v.serial_id AND r.recycle_type=2
      )
    GROUP BY v.user_id,v.serial_id
),
/* 三、20秒链式归批。必须先LAG再累加，不能使用FLOOR(时间/20)。 */
offer_lag AS (
    SELECT g.*,
           LAG(offer_epoch) OVER (
               PARTITION BY user_id ORDER BY offer_epoch,serial_id
           ) AS previous_epoch
    FROM raw_offer g
),
offer_batch AS (
    SELECT g.*,
           SUM(CASE WHEN previous_epoch IS NULL OR offer_epoch-previous_epoch>20
                    THEN 1 ELSE 0 END) OVER (
               PARTITION BY user_id ORDER BY offer_epoch,serial_id
               ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
           ) AS batch_id
    FROM offer_lag g
),
offer_rank AS (
    SELECT g.*,
           ROW_NUMBER() OVER (
               PARTITION BY user_id,batch_id ORDER BY offer_epoch DESC,serial_id DESC
           ) AS batch_rn,
           COUNT(*) OVER (PARTITION BY user_id,batch_id) AS batch_record_count,
           MIN(offer_epoch) OVER (PARTITION BY user_id,batch_id) AS batch_first_epoch,
           MAX(offer_epoch) OVER (PARTITION BY user_id,batch_id) AS batch_last_epoch
    FROM offer_batch g
),
offer_dated AS (
    SELECT g.*,
           (TO_TIMESTAMP(offer_epoch) AT TIME ZONE 'America/Belize')::date AS offer_date,
           (TO_TIMESTAMP(batch_first_epoch) AT TIME ZONE 'America/Belize')::date AS batch_first_date,
           (TO_TIMESTAMP(batch_last_epoch) AT TIME ZONE 'America/Belize')::date AS batch_last_date
    FROM offer_rank g CROSS JOIN params p
    WHERE g.batch_rn=1 AND g.offer_epoch>=p.start_epoch AND g.offer_epoch<p.end_epoch
),
/* 仅上述范围原始获额用户的历史订单参与；保留未20秒去重范围用于前后对账。 */
candidate_users AS (SELECT DISTINCT user_id FROM raw_offer),
/* 四、提单/放款/结清原始时间。有效timestamp优先，提单/放款才允许unix回退。
   与原提取一致：这层从2026年起提单记录及年初仍可能在途订单取数。
   观察期末是原取数时点，不是10月10日，否则D7结果会被截断。 */
loan_source AS (
    SELECT o.user_id::bigint AS user_id,o.serial_id::bigint AS serial_id,
           CASE WHEN o.apply_time>=TIMESTAMP '2000-01-01'
                THEN EXTRACT(EPOCH FROM o.apply_time AT TIME ZONE 'America/Belize')::bigint
                WHEN o.apply_unix>0 THEN o.apply_unix::bigint END AS app_epoch,
           CASE WHEN o.remit_time>=TIMESTAMP '2000-01-01'
                THEN EXTRACT(EPOCH FROM o.remit_time AT TIME ZONE 'America/Belize')::bigint
                WHEN o.remit_unix>0 THEN o.remit_unix::bigint END AS fund_epoch,
           CASE WHEN o.repaid_time>=TIMESTAMP '2000-01-01'
                THEN EXTRACT(EPOCH FROM o.repaid_time AT TIME ZONE 'America/Belize')::bigint END AS settle_epoch,
           o.is_remit,o.is_repaid,o.loan_status_code,o.remit_amt,o.repaid_amt,o.due_date,o.is_due
    FROM wangchuanliang.order_loan_f_v2_copy o
    JOIN candidate_users u ON u.user_id=o.user_id
    CROSS JOIN params p
    WHERE (o.apply_time>=p.start_date::timestamp AND o.apply_time<=p.asof_local)
       OR (o.is_remit=1 AND (
              o.repaid_time>=p.start_date::timestamp
              OR o.repaid_time<TIMESTAMP '2000-01-01' OR o.repaid_time IS NULL
          ))
),
/* 完全重复行不放大数据；同用户同订单的生命周期字段冲突则整用户排除。 */
loan_distinct AS (SELECT DISTINCT * FROM loan_source),
loan_conflict_users AS (
    SELECT user_id FROM loan_distinct
    GROUP BY user_id,serial_id HAVING COUNT(*)>1
),
loan_quality AS (
    SELECT l.*,
           CASE WHEN is_remit=1 AND (
               fund_epoch IS NULL
               OR ((COALESCE(is_repaid,0)=1 OR COALESCE(loan_status_code,0)=7)
                   AND settle_epoch IS NULL)
               OR (settle_epoch IS NOT NULL AND settle_epoch<fund_epoch)
           ) THEN 1 ELSE 0 END AS bad_lifecycle
    FROM loan_distinct l
),
/* 当前状态7仅用于发现“标记结清却无结清时间”的异常，不用于套用历史状态。 */
loan_bad_users AS (SELECT DISTINCT user_id FROM loan_quality WHERE bad_lifecycle=1),
funded AS (
    SELECT l.user_id,l.serial_id,l.fund_epoch::double precision AS fund_epoch,
           COALESCE(l.settle_epoch::double precision,p.open_end_epoch) AS end_epoch
    FROM loan_quality l CROSS JOIN params p
    WHERE l.is_remit=1 AND l.bad_lifecycle=0 AND l.fund_epoch<=p.asof_epoch
      AND (l.settle_epoch IS NULL OR l.settle_epoch>p.start_epoch)
),
/* 五、分期逾期：包括已还分期，绝不能额外加is_repaid_period=0。 */
period_source AS (
    SELECT q.user_id::bigint AS user_id,q.serial_id::bigint AS serial_id,
           COUNT(*) AS rows_n,COUNT(DISTINCT q.current_term) AS terms_n,
           MIN(CASE WHEN q.overdue_days_period>0 THEN q.due_date_period::date END) AS first_positive_due,
           SUM(CASE WHEN q.overdue_days_period>0 AND (
               q.due_date_period IS NULL OR q.due_date_period<DATE '2000-01-01'
           ) THEN 1 ELSE 0 END) AS bad_positive_due,
           SUM(CASE WHEN q.overdue_days_period IS NULL THEN 1 ELSE 0 END) AS null_overdue,
           SUM(CASE WHEN q.current_term IS NULL THEN 1 ELSE 0 END) AS null_terms
    FROM wangchuanliang.repayment_plan_v2_copy q
    JOIN candidate_users u ON u.user_id=q.user_id
    CROSS JOIN params p
    WHERE q.is_remit=1 AND (
        q.repaid_time>=p.start_date::timestamp
        OR q.repaid_time<TIMESTAMP '2000-01-01' OR q.repaid_time IS NULL
    )
    GROUP BY q.user_id,q.serial_id
),
funded_period AS (
    SELECT f.*,q.serial_id AS period_serial_id,q.rows_n,q.terms_n,
           q.bad_positive_due,q.null_overdue,q.null_terms,q.first_positive_due,
           CASE WHEN q.first_positive_due IS NOT NULL THEN
               EXTRACT(EPOCH FROM ((q.first_positive_due+1)::timestamp
                         AT TIME ZONE 'America/Belize'))::double precision
           END AS overdue_start_epoch
    FROM funded f LEFT JOIN period_source q
      ON q.user_id=f.user_id AND q.serial_id=f.serial_id
),
period_bad_users AS (
    SELECT DISTINCT user_id FROM funded_period
    WHERE period_serial_id IS NULL OR bad_positive_due>0 OR null_overdue>0 OR null_terms>0
       OR (overdue_start_epoch IS NOT NULL AND (
              overdue_start_epoch<fund_epoch OR overdue_start_epoch>=end_epoch
          ))
),
invalid_users AS (
    SELECT user_id FROM loan_conflict_users
    UNION SELECT user_id FROM loan_bad_users
    UNION SELECT user_id FROM period_bad_users
),
usable_funded AS (
    SELECT f.* FROM funded_period f
    WHERE NOT EXISTS (SELECT 1 FROM invalid_users x WHERE x.user_id=f.user_id)
),
/* 六、把多笔在途区间合并成连续在途段。
   必须与“此前所有区间最大结束时间”比较，不能只LAG上一行结束时间，
   否则被长订单覆盖的短订单会把连续在途误拆。首尾相接也合并。
   但首次提单的既有在途条件另用fund_epoch<app_epoch严格检查。 */
funded_running AS (
    SELECT f.*,
           MAX(end_epoch) OVER (
               PARTITION BY user_id ORDER BY fund_epoch,end_epoch,serial_id
               ROWS BETWEEN UNBOUNDED PRECEDING AND 1 PRECEDING
           ) AS prior_max_end
    FROM usable_funded f
),
funded_episode_id AS (
    SELECT f.*,
           SUM(CASE WHEN prior_max_end IS NULL OR fund_epoch>prior_max_end
                    THEN 1 ELSE 0 END) OVER (
               PARTITION BY user_id ORDER BY fund_epoch,end_epoch,serial_id
               ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW
           ) AS episode_id
    FROM funded_running f
),
episodes AS (
    SELECT user_id,episode_id,MIN(fund_epoch) AS episode_start,MAX(end_epoch) AS episode_end
    FROM funded_episode_id GROUP BY user_id,episode_id
),
/* 同用户同秒多笔提单只需一个时点；分子按获额事件计数，不按提单订单数。 */
applications AS (
    SELECT l.user_id,l.serial_id,l.app_epoch::double precision AS app_epoch
    FROM loan_distinct l CROSS JOIN params p
    WHERE l.app_epoch>=p.start_epoch AND l.app_epoch<p.end_epoch+15*86400
),
application_min AS (
 SELECT g.user_id,g.serial_id,MIN(a.app_epoch) AS first_app_epoch
 FROM offer_dated g LEFT JOIN applications a ON a.user_id=g.user_id
   AND a.app_epoch>=g.offer_epoch
   AND a.app_epoch<EXTRACT(EPOCH FROM ((g.offer_date+16)::timestamp AT TIME ZONE 'America/Belize'))
 GROUP BY g.user_id,g.serial_id
),
first_application AS (
 SELECT m.user_id,m.serial_id,m.first_app_epoch,MIN(a.serial_id) AS first_app_serial_id
 FROM application_min m LEFT JOIN applications a
   ON a.user_id=m.user_id AND a.app_epoch=m.first_app_epoch
 GROUP BY m.user_id,m.serial_id,m.first_app_epoch
),
anchor AS (
    SELECT g.*,a.first_app_epoch,a.first_app_serial_id,e.episode_end,
           CASE WHEN x.user_id IS NULL THEN 0 ELSE 1 END AS invalid_user
    FROM offer_dated g
    LEFT JOIN first_application a ON a.user_id=g.user_id AND a.serial_id=g.serial_id
    LEFT JOIN episodes e ON e.user_id=g.user_id
      AND e.episode_start<=g.offer_epoch AND e.episode_end>g.offer_epoch
    LEFT JOIN invalid_users x ON x.user_id=g.user_id
),
/* 取从获额起至该连续在途段结束前，首次命中的分期逾期时刻。
   单笔逾期到整笔结清即退出；另一笔逾期订单也可使本事件失效。
   逾期在首次提单后发生不影响valid，交给后续严格先后比较处理。 */
first_bad AS (
    SELECT a.user_id,a.serial_id,
           MIN(GREATEST(a.offer_epoch,f.overdue_start_epoch)) AS first_bad_epoch
    FROM anchor a JOIN usable_funded f ON f.user_id=a.user_id
    CROSS JOIN params p
    WHERE f.overdue_start_epoch IS NOT NULL AND f.overdue_start_epoch<=p.asof_epoch
      AND f.end_epoch>a.offer_epoch AND f.overdue_start_epoch<a.episode_end
    GROUP BY a.user_id,a.serial_id
),
/* 必须有放款时刻严格早于首次提单且彼时尚未结清的订单。
   不能仅靠本次提单在同一秒产生的新放款满足在途条件。 */
prior_inflight_at_app AS (
    SELECT a.user_id,a.serial_id,1 AS has_prior_inflight
    FROM anchor a JOIN usable_funded f ON f.user_id=a.user_id
      AND f.fund_epoch<a.first_app_epoch AND f.end_epoch>a.first_app_epoch
    GROUP BY a.user_id,a.serial_id
),
event_flags AS (
    SELECT a.*,b.first_bad_epoch,COALESCE(i.has_prior_inflight,0) AS has_prior_inflight,
           CASE WHEN a.invalid_user=0 AND a.episode_end IS NOT NULL THEN 1 ELSE 0 END AS included,
           CASE WHEN a.invalid_user=0 AND a.episode_end IS NOT NULL
                     AND a.first_app_epoch IS NOT NULL AND a.first_app_epoch<a.episode_end
                     AND COALESCE(i.has_prior_inflight,0)=1
                     AND (b.first_bad_epoch IS NULL OR a.first_app_epoch<b.first_bad_epoch)
                THEN 1 ELSE 0 END AS valid_first_app
    FROM anchor a
    LEFT JOIN first_bad b ON b.user_id=a.user_id AND b.serial_id=a.serial_id
    LEFT JOIN prior_inflight_at_app i ON i.user_id=a.user_id AND i.serial_id=a.serial_id
),
/* 七、原因按与原Python一致的优先级归属，保持互斥且覆盖全部入样事件。 */
event_detail AS (
    SELECT e.*,
           TO_CHAR(e.offer_date,'YYYY-MM') AS month_key,
           CASE WHEN valid_first_app=1 THEN
               (TO_TIMESTAMP(first_app_epoch) AT TIME ZONE 'America/Belize')::date-offer_date
           END AS app_day,
           CASE WHEN invalid_user=1 THEN '历史时间字段异常，无法可靠还原'
                WHEN included=0 THEN '获额时无在途订单'
                WHEN valid_first_app=1 THEN '有效首次提单'
                WHEN first_bad_epoch IS NOT NULL AND first_bad_epoch<=p.asof_epoch
                     AND first_bad_epoch<=episode_end
                     AND (first_app_epoch IS NULL OR first_bad_epoch<=first_app_epoch)
                     THEN '分期逾期记未提单'
                WHEN episode_end<=p.asof_epoch
                     AND (first_app_epoch IS NULL OR episode_end<=first_app_epoch)
                     THEN '在途全部结束记未提单'
                WHEN first_app_epoch IS NOT NULL AND has_prior_inflight=0
                     THEN '提单时无既有在途记未提单'
                ELSE '截至取数未提单' END AS reason,
           CASE WHEN included=1 AND first_bad_epoch=offer_epoch THEN 1 ELSE 0 END AS overdue_at_offer,
           CASE WHEN EXTRACT(EPOCH FROM ((offer_date+1)::timestamp AT TIME ZONE 'America/Belize'))
                          <=p.complete_before_epoch THEN 1 ELSE 0 END AS mature_d0,
           CASE WHEN EXTRACT(EPOCH FROM ((offer_date+4)::timestamp AT TIME ZONE 'America/Belize'))
                          <=p.complete_before_epoch THEN 1 ELSE 0 END AS mature_d1_3,
           CASE WHEN EXTRACT(EPOCH FROM ((offer_date+8)::timestamp AT TIME ZONE 'America/Belize'))
                          <=p.complete_before_epoch THEN 1 ELSE 0 END AS mature_d4_7
    FROM event_flags e CROSS JOIN params p
) SELECT user_id,serial_id AS offer_serial_id,offer_epoch AS offer_time,first_app_epoch AS first_app_time,first_bad_epoch AS first_overdue_time,episode_end,included,reason,valid_first_app,app_day AS day,overdue_at_offer FROM event_detail;
