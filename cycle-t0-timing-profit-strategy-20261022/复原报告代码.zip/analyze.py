"""Local cohort comparison. No database access. Output contains aggregates only."""
from pathlib import Path
from collections import defaultdict
from bisect import bisect_left,bisect_right
from datetime import date
from decimal import Decimal as D
import json,gzip
import pandas as pd
W=Path(__file__).resolve().parent
STAGES=['D0','D1','D2','D3','D4-D7','D8-D15']
MONTHS=[f'2026-{m:02d}' for m in range(1,10)]
def load(name):
 with gzip.open(W/name,'rt',encoding='utf-8') as f:return json.load(f,parse_float=D)
def ratio(a,b):return None if not b else float(a/b)
def serial(x):return None if pd.isna(x) else int(x)
def stage(day):
 return f'D{day}' if 0<=day<=3 else ('D4-D7' if 4<=day<=7 else ('D8-D15' if 8<=day<=15 else None))
def main():
 complete=json.loads((W/'extraction_complete.json').read_text());assert complete['passed']
 meta=complete['meta'];stat=date.fromisoformat(meta['business_stat_date'])
 financial={};duplicate_source=0
 def add_cash(r,key='serial_id'):
  nonlocal duplicate_source
  if r.get(key) is None:return None
  k=(int(r['user_id']),int(r[key]));principal=D(str(r['remit_amt'])) if r['remit_amt'] is not None else None
  repaid=D(str(r['repaid_amt'])) if r['repaid_amt'] is not None else None
  due=date.fromisoformat(r['due_date'][:10]) if r['due_date'] else None
  funded=int(r['is_remit']==1 and principal is not None and principal>0)
  matured=int(funded and r['is_due']==1 and due is not None and date(2000,1,1)<=due<stat)
  assert not (matured and repaid is None)
  v={'principal':principal,'repaid':repaid,'funded':funded,'matured':matured,'status8':int(r['loan_status_code']==8)}
  if k in financial:
   assert financial[k]==v,('Conflicting financial values in common snapshot',k);duplicate_source+=1
  else:financial[k]=v
  return k
 cashrows=sum((load(f'cycle_finances_{i}.json.gz') for i in range(8)),[])
 lookup={};byappuser=defaultdict(dict)
 for r in cashrows:
  key=add_cash(r);k=(int(r['user_id']),int(r['app_epoch']))
  if k not in lookup or key[1]<lookup[k][1]:lookup[k]=key
  sid=int(r['serial_id']);old=byappuser[k[0]].get((k[1],sid))
  if old is not None:assert old==r
  byappuser[k[0]][(k[1],sid)]=r
 byappuser={u:sorted(rr) for u,rr in byappuser.items()}
 t0raw=load('t0_events.json.gz');t0=[];independent=[];cut_events=0
 for r in t0raw:
  uid=int(r['user_id']);off=int(r['offer_epoch']);month=pd.Timestamp(off,unit='s',tz='UTC').tz_convert('America/Belize').strftime('%Y-%m')
  apps=byappuser.get(uid,[]);ix=bisect_left(apps,(off,-1));app=apps[ix] if ix<len(apps) and apps[ix][0]<int(r['window_end_epoch']) else None
  key=None if app is None else (uid,app[1]);app_epoch=None if app is None else app[0]
  s=None if key is None else stage((app_epoch+(-6*3600))//86400-(off+(-6*3600))//86400)
  e={'product':'T0','user':uid,'offer':int(r['offer_serial_id']),'epoch':off,'month':month,'stage':s,'order':key,'app_epoch':app_epoch}
  assert int(r['clean_settle_epoch'])<=off
  independent.append(e.copy())
  if key is not None and r['next_t0_epoch'] is not None and app_epoch>=int(r['next_t0_epoch']):
   cut_events+=1;e.update(stage=None,order=None,app_epoch=None)
  t0.append(e)
 assert len({(e['user'],e['offer']) for e in t0})==len(t0)
 cycle=[];excluded=[]
 ev=pd.read_pickle(W/'cycle_events.pkl')
 for r in ev.itertuples():
  s=stage(int(r.day)) if r.valid_first_app==1 and pd.notna(r.day) else None
  e={'product':'循环贷','user':int(r.user_id),'offer':int(r.offer_serial_id),'epoch':int(r.offer_time),'month':r.month,'stage':s,'order':lookup[(int(r.user_id),int(r.first_app_time))] if s else None,'app_epoch':int(r.first_app_time) if s else None}
  (cycle if r.included==1 else excluded).append(e)
 assert len(cycle)==263486
 assert sum(e['stage'] is not None for e in cycle)==189046
 def summarize(events,month,st,label=None):
  selected=[e for e in events if e['stage'] in st]
  keys={e['order'] for e in selected};cash=[financial[k] for k in keys];mat=[r for r in cash if r['matured']]
  p=sum((r['principal'] for r in mat),D(0));re=sum((r['repaid'] for r in mat),D(0));funded=sum(r['funded'] for r in cash)
  return {'product':events[0]['product'],'month':month,'stage':label or st[0],'offer_events':len(events),'offer_users':len({e['user'] for e in events}),
   'apply_events':len(selected),'apply_users':len({e['user'] for e in selected}),'apply_rate':ratio(len(selected),len(events)),
   'unique_orders':len(keys),'funded_orders':funded,'matured_orders':len(mat),'mature_coverage':ratio(len(mat),funded),
   'principal':str(p),'repaid':str(re),'profit':str(re-p),'profit_rate':ratio(re-p,p),'avg_mature_principal':ratio(p,len(mat)),
   'current_status8_mature_orders':sum(r['status8'] for r in mat),'funded_order_rate':ratio(funded,len(keys))}
 cohorts={'循环贷':cycle,'T0':t0};rows=[];combined=[]
 for product,events in cohorts.items():
  for month in MONTHS+['合计']:
   ee=events if month=='合计' else [e for e in events if e['month']==month]
   for s in STAGES:rows.append(summarize(ee,month,[s]))
   for ss,label in [(STAGES[1:],'D1-D15'),(STAGES,'D0-D15')]:combined.append(summarize(ee,month,ss,label))
 prevpath=W/'cycle_previous_controls.json'
 prev=json.loads((prevpath if prevpath.exists() else W.parent/'cycle_first_apply_profit_6stages_20261022/result.json').read_text())
 for r in rows:
  if r['product']=='循环贷':
   old=next(x for x in prev['rows'] if x['month_key']==r['month'] and x['stage']==r['stage'])
   for key,oldkey in [('apply_events','apply_events'),('offer_events','eligible_offer_events'),('funded_orders','funded_orders'),('matured_orders','matured_orders')]:assert r[key]==old[oldkey]
 t0prevpath=W/'t0_previous_controls.json'
 oldt0=json.loads((t0prevpath if t0prevpath.exists() else W.parent/'t0_first_apply_profit_202601_202609_20261021/result.json').read_text())
 native_control=[]
 for r in rows:
  if r['product']!='T0':continue
  old=next(x for x in oldt0['rows'] if x['month']==r['month'] and x['first_apply_bucket']==r['stage'])
  native_control.append({'month':r['month'],'stage':r['stage'],'event_count_change':r['apply_events']-old['events']})
 # Cross-cohort overlap uses event identities, nearby times, and first-order IDs separately.
 common_users={e['user'] for e in cycle}&{e['user'] for e in t0}
 exact={(e['user'],e['offer']) for e in cycle}&{(e['user'],e['offer']) for e in t0}
 cycleapps=[e for e in cycle if e['stage']];t0apps=[e for e in t0 if e['stage']]
 common_orders={e['order'] for e in cycleapps}&{e['order'] for e in t0apps}
 byuser=defaultdict(list)
 for e in t0:byuser[e['user']].append((e['epoch'],e['offer']))
 for u in byuser:byuser[u].sort()
 nearc=set();neart=set();pairs=0
 for e in cycle:
  ll=byuser.get(e['user'],[]);a=bisect_left(ll,(e['epoch']-20,-1));b=bisect_right(ll,(e['epoch']+20,10**30))
  if a<b:nearc.add((e['user'],e['offer']));pairs+=b-a
  for tm,sid in ll[a:b]:neart.add((e['user'],sid))
 overlap=[]
 for month in MONTHS+['合计']:
  ce=cycle if month=='合计' else [e for e in cycle if e['month']==month];te=t0 if month=='合计' else [e for e in t0 if e['month']==month]
  ca=[e for e in ce if e['stage']];ta=[e for e in te if e['stage']]
  for kind,cc,tt,cd,td in [
   ('同一获额订单',sum((e['user'],e['offer']) in exact for e in ce),sum((e['user'],e['offer']) in exact for e in te),len(ce),len(te)),
   ('获额时刻相差≤20秒',sum((e['user'],e['offer']) in nearc for e in ce),sum((e['user'],e['offer']) in neart for e in te),len(ce),len(te)),
   ('同一首次提单订单',sum(e['order'] in common_orders for e in ca),sum(e['order'] in common_orders for e in ta),len(ca),len(ta)),
   ('两类获额均发生的用户',sum(e['user'] in common_users for e in ce),sum(e['user'] in common_users for e in te),len(ce),len(te))]:
   overlap.append({'month':month,'kind':kind,'cycle_events':cc,'t0_events':tt,'cycle_denominator':cd,'t0_denominator':td,'cycle_share':ratio(cc,cd),'t0_share':ratio(tt,td),'cycle_all_offer_share':ratio(cc,len(ce)),'t0_all_offer_share':ratio(tt,len(te))})
 overlap_stages=[]
 for s in STAGES:
  for p,ee in [('循环贷',cycleapps),('T0',t0apps)]:
   e=[e for e in ee if e['stage']==s];hit=[e for e in e if e['order'] in common_orders]
   overlap_stages.append({'product':p,'stage':s,'apply_events':len(e),'shared_first_order_events':len(hit),'shared_share':ratio(len(hit),len(e)),'shared_orders':len({x['order'] for x in hit})})
 independent_rows=[summarize(independent,'合计',[s]) for s in STAGES]
 complete_months=[m for m in MONTHS if all(r['matured_orders']==r['funded_orders'] for r in rows if r['month']==m)]
 mature_control=[]
 for p,events in cohorts.items():
  ee=[e for e in events if e['month'] in complete_months]
  if ee:
   for s in STAGES:mature_control.append(summarize(ee,'、'.join(complete_months),[s]))
 unique_order_controls=[]
 for p,events in cohorts.items():
  ee=[dict(e,stage=None,order=None) if e['order'] in common_orders else e for e in events]
  for s in STAGES:unique_order_controls.append(summarize(ee,'合计',[s]))
 cuts_by_month={m:sum(a['stage'] is not None and b['stage'] is None for a,b in zip(independent,t0) if a['month']==m) for m in MONTHS}
 quality={'t0_previous_event_controls':native_control,'t0_cutoff_affected_events':cut_events,'cutoff_affected_by_month':cuts_by_month,'cycle_event_counts_match_previous':True,
  'cycle_excluded_offers':len(excluded),'cycle_exclusion_reasons':ev.loc[ev.included.eq(0),'reason'].value_counts().to_dict(),
  'same_snapshot_cross_cohort_financial_checks':duplicate_source,'same_offer_order_events':len(exact),'near_time_matched_pairs':pairs,'shared_first_orders':len(common_orders),
  'common_offer_users':len(common_users),'cycle_offer_users':len({e['user'] for e in cycle}),'t0_offer_users':len({e['user'] for e in t0}),
  'type_quality':json.loads((W/'type_quality.json').read_text()),'fully_mature_months':complete_months,
  'cycle_label_snapshot':'2026-10-19 audited historical event labels','t0_label_snapshot':meta['snapshot'],'cash_snapshot':meta['snapshot'],
  'passed':True,'raw_user_and_order_data_not_published':True}
 result={'meta':meta,'stages':STAGES,'months':MONTHS,'rows':rows,'combined':combined,'overlap':overlap,'overlap_stages':overlap_stages,
  'independent_t0_control':independent_rows,'fully_mature_control':mature_control,'nonshared_application_control':unique_order_controls,'quality':quality}
 (W/'analysis.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
 (W/'verification.json').write_text(json.dumps(quality,ensure_ascii=False,indent=2))
 print(json.dumps({'summary':[r for r in rows if r['month']=='合计'],'combined':[r for r in combined if r['month']=='合计'],'overlap':[r for r in overlap if r['month']=='合计'],'quality':{k:v for k,v in quality.items() if k!='t0_previous_event_controls'}},ensure_ascii=False),flush=True)
if __name__=='__main__':main()
