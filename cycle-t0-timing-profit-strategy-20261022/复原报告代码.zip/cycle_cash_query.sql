-- Read-only. users parameter comes from audited cycle event labels.
SELECT o.user_id,o.serial_id,
 CASE WHEN o.apply_time>=TIMESTAMP '2000-01-01'
 THEN EXTRACT(EPOCH FROM o.apply_time AT TIME ZONE 'America/Belize')::bigint
 WHEN o.apply_unix>0 THEN o.apply_unix::bigint END AS app_epoch,
 o.is_remit,o.remit_amt,o.repaid_amt,o.due_date,o.is_due,o.loan_status_code
 FROM wangchuanliang.order_loan_f_v2_copy o
 WHERE o.user_id IN (SELECT UNNEST(%(users)s::bigint[]))
 AND ((o.apply_time>=TIMESTAMP '2026-01-01' AND o.apply_time<TIMESTAMP '2026-10-16')
 OR ((o.apply_time IS NULL OR o.apply_time<TIMESTAMP '2000-01-01')
 AND o.apply_unix>=1767247200 AND o.apply_unix<1792130400));