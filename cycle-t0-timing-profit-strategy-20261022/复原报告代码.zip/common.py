"""Portable read-only database configuration. No credentials are stored here."""
import os,json,re
from pgpy import PGPMessage
def connection_kwargs():
 mapping={'host':'DB_HOST','port':'DB_PORT','dbname':'DB_NAME','user':'DB_USER','password':'DB_PASSWORD'}
 required=['DB_HOST','DB_NAME','DB_USER','DB_PASSWORD']
 if not all(os.environ.get(k) for k in required):raise RuntimeError('Configure DB_HOST, DB_NAME, DB_USER and DB_PASSWORD; optional DB_PORT defaults to 8000.')
 return {k:os.environ[v] for k,v in mapping.items() if os.environ.get(v)}|{'port':int(os.environ.get('DB_PORT','8000'))}
