from pathlib import Path
import json, html, csv, hashlib, zipfile, re
from bs4 import BeautifulSoup
ROOT=Path('/Users/wangchuanliang/Documents/Codex/2026-10-18/wen')
W=ROOT/'work/t0_v4_business_reliability_20261026'
O=ROOT/'outputs/T0提单意愿模型V4_业务实测与上线建议_20261026'
O.mkdir(exist_ok=True)
D=json.loads((W/'business_reliability_metrics.json').read_text())
E=json.loads((W/'business_examples.json').read_text())
P=json.loads((W/'production_readiness.json').read_text())
R=json.loads((ROOT/'work/t0_risk410_lifecycle_strategy_20261025/prediction_profiles.json').read_text())
main=next(x for x in D['rules_main'] if x['rule']=='pD3_lt_0.5')
high=next(x for x in R['rules'] if x['rule']=='LOWP_HIGH20')
report_name='T0提单意愿模型V4_实际预测效果与上线建议.html'
zip_name='T0模型V4业务实测_完整代码与统计依据.zip'
e=html.escape
def pct(v,n=2): return '—' if v is None else f'{v*100:.{n}f}%'
def num(v): return f'{v:,}'
def table(head, rows):
 return '<div class="scroll"><table><thead><tr>'+''.join('<th>'+str(x)+'</th>' for x in head)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+str(x)+'</td>' for x in r)+'</tr>' for r in rows)+'</tbody></table></div>'
def fold(title,body): return f'<details><summary>{title}</summary>{body}</details>'
def note(t): return '<p class="note">'+t+'</p>'
def call(t): return '<div class="callout">'+t+'</div>'
def section(id,title,body):return f'<section id="{id}"><h2>{title}</h2>{body}</section>'
# Independent bars avoid line/label collisions and work offline; labels reserve a fixed right column.
CHARTS=[]
def bars(id,title,rows,unit='%',maxval=100):
 # rows=(label,value,color,optional display); no shared text area with mark geometry.
 width=1060; left=310; span=510; right=width-35; top=48; step=49; height=top+step*len(rows)+28
 s=[f'<svg id="{id}" viewBox="0 0 {width} {height}" role="img" aria-label="{e(title)}"><title>{e(title)}</title>']
 for i,(label,value,color,display) in enumerate(rows):
  y=top+i*step; w=max(0,min(span,value/maxval*span))
  s+=[f'<text x="{left-18}" y="{y+5}" text-anchor="end" fill="#cbd5e1">{e(label)}</text>',f'<rect x="{left}" y="{y-13}" width="{span}" height="24" rx="4" fill="#202d43"/>',f'<rect x="{left}" y="{y-13}" width="{w:.3f}" height="24" rx="4" fill="{color}"/>',f'<text x="{right}" y="{y+5}" text-anchor="end" fill="#f8fafc" font-weight="700">{e(display or f"{value:.2f}{unit}")}</text>']
 s+=['</svg>'];CHARTS.append({'id':id,'rows':len(rows),'right_label_column':right,'bar_end_max':left+span,'height':height,'viewbox_width':width})
 return '<figure><h3>'+title+'</h3>'+''.join(s)+'</figure>'
nav=[('verdict','能不能用'),('accuracy','实际准确性'),('selection','筛选与取舍'),('dates','分批检验'),('cases','真实结果'),('production','上线与测试'),('methods','口径与复原')]
body=[]
body.append(section('verdict','一、结论：可以进入业务测试，尚不能直接全量自动投放',call('<strong>模型已经表现出识别“当天不提单事件”的实用能力。</strong>它适合先用于实时影子验证；实时数据、评分时点和用户资格验收通过后，可以做小流量优惠对照测试。现有数据还不足以证明它可以直接驱动全量自动降息或提额。')+'''<div class="cards">
<div class="card"><span>筛中后，当天确实未提单</span><strong>85.97%</strong><small>3,143 / 3,656次可判候选</small></div>
<div class="card"><span>候选覆盖全部评分事件</span><strong>41.74%</strong><small>3,701 / 8,866次事件</small></div>
<div class="card"><span>叠加410高分后的命中率</span><strong>90.69%</strong><small>1,373 / 1,514次可判候选</small></div>
<div class="card"><span>基础候选中，当天仍提单</span><strong class="red">14.03%</strong><small>513 / 3,656次可判候选</small></div></div>'''+
'<p>此前统计中，T0当天首次提单且成功放款的到期订单，当前账面盈利率为<strong>11.13%</strong>，次日及以后为<strong>19.98%</strong>。这为定向筛选提供了业务背景。本报告集中回答：模型能否把当天不提单的事件提前筛出来。</p>'+note('盈利口径为Σ(repaid_amt−remit_amt)÷Σremit_amt，使用此前2026年1月1日—10月24日事件与10月25日资金快照。时点差异是观察结果；给优惠后是否新增提单、是否维持盈利，仍须由对照测试回答。本次没有重新取数、训练或投放。')))

flow=table(['从哪里开始','事件数','处理方式'],[['10月9—21日，D3窗口已成熟且完成评分','8,866','主检验范围'],['结果可判','8,717','计算准确性；同一用户多次T0均保留'],['结果未知','149','不按未提单补零'],['pD3＜0.5筛出的完整候选','3,701','其中3,656可判、45未知']])
base=main['baseline_no_d0']
acc=bars('candidate_precision','候选名单里，实际当天未提单的比例',[
 ('全部可判T0事件',base*100,'#64748b',pct(base)),('模型：pD3＜0.5',main['ppv_no_d0']*100,'#38bdf8',pct(main['ppv_no_d0'])),('同410高分客群，未加意愿筛选',high['baseline_d0_nonapply_eligible_known']*100,'#64748b',pct(high['baseline_d0_nonapply_eligible_known'])),('意愿筛选＋410高分',high['ppv_no_d0']*100,'#34d399',pct(high['ppv_no_d0']))])
counts=table(['规则','完整候选','结果可判','实际当天未提单','实际当天提单','未知','当天未提单命中率'],[
 ['pD3＜0.5','3,701','3,656','3,143','513','45','85.97%（95%区间84.83%—86.97%）'],
 ['再要求410高分','1,532','1,514','1,373','141','18','90.69%（95%区间89.26%—92.10%）']])
body.append(section('accuracy','二、实际准确性：每筛中100次，约86次当天确实不提单',
'<p>固定使用现有V4，规则为<strong>pD3＜0.5</strong>，即模型预测从获额当日起至第3日结束前提单的概率低于50%。在3,656次可判候选中，<strong>3,143次当天未提单，513次当天仍提单</strong>。换成每100次候选，历史平均约86次判断符合当天未提单，14次存在给当天提单事件优惠的潜在误选。</p>'+acc+note('图中均为事件比例。全体基线5,276/8,717=60.53%；基础模型提高25.44个百分点。同410高分基线1,622/2,044=79.35%，模型叠加后提高11.33个百分点，表明提升并非全部来自410筛选。410高分采用此前固定阈值≥528，分档同分不拆；并不代表这批候选恰好占20%。')+
call('<strong>85.97%是“筛中名单的当天未提单命中率”，不是全体用户预测准确率。</strong>基础规则抓到全部5,276次当天未提单事件中的3,143次，占59.57%；另有2,133次当天未提单事件未被筛中。模型是在覆盖范围与误选之间做取舍。')+
'<p>若进一步要求410高分，名单缩小到全部评分事件的<strong>17.28%</strong>，每100次可判候选约91次当天不提单、9次当天仍提单。适合将它作为较保守的<strong>待测试候选规则</strong>，还不能认定它已经是最优投放规则。</p>'+
fold('查看完整人数、区间与主检验分母',counts+flow+note('未知45次全部计入候选覆盖，未计入命中率。仅按未知结果两种极端处理，完整3,701次候选的命中识别范围为84.92%—86.14%；这是缺失结果的识别范围，不是统计置信区间。95%区间按用户聚类重抽样500次，保留用户内重复事件关系。'))+
note('“当天仍提单”是历史政策环境下观察到的行为，只是潜在误选代理；本次没有给这些事件随机发优惠，不能据此断言513次优惠一定被浪费。')))

# Threshold table compares coverage measured on complete cohort, accuracy on known candidates.
threshold_rows=[]
for r in D['rules_main']:
 if r['kind']!='probability_threshold':continue
 label=('当天提单概率' if r['score']=='p_v4_d0' else 'D0—D3提单概率')+f"＜{r['threshold']:.0%}"
 threshold_rows.append([label,num(r['complete_all_candidates']),pct(r['complete_candidate_coverage']),num(r['known_d0']),pct(r['ppv_no_d0']),pct(1-r['ppv_no_d0'])])
rank=bars('d0_ranking','按当天提单概率排序，实际当天提单率明显分层',[
 (f"第{x['decile']}档"+('（预测最高）' if x['decile']==1 else '（预测最低）' if x['decile']==10 else ''),x['actual_rate']*100,'#38bdf8' if x['decile']<6 else '#34d399',pct(x['actual_rate'])) for x in E['primary_deciles']['0']['v4']])
body.append(section('selection','三、目标是当天不提单，直接用pD0是否更合适？',
'<p>V4同时输出当天提单概率pD0与D0—D3累计提单概率pD3。<strong>若业务只要求避开当天提单事件，应把pD0也纳入候选规则比较。</strong>不能因为pD0＜0.5的命中率77.26%低于pD3＜0.5的85.97%，就说当天输出较差：前者筛中的名单更大。</p>'+ 
table(['同一8,717次可判事件','筛中事件','覆盖可判事件','当天未提单命中率'],[
 ['pD0＜0.5','5,744','65.89%','77.26%'],['pD3＜0.5','3,656','41.94%','85.97%'],['pD0从低到高，也只取3,656次','3,656','41.94%','86.05%']])+
call('同样筛3,656次时，pD0与pD3规则的命中率只差<strong>0.08个百分点</strong>，配对95%差值区间为−0.47至＋0.63个百分点。现有样本没有显示两者在“避开当天提单”上有明确高下；继续沿用固定pD3规则可以测试，也可以把等容量pD0方案留作前瞻比较。')+
rank+note('分母为同一主样本8,717次事件，按pD0降序分成精确10%预算档，同分边界按权重分摊。每档871.7是事件权重，不是871.7名用户。最高档当天提单率89.71%，最低档5.28%，体现模型排序能力。')+
'<p>如果愿意缩小名单，pD0＜10%的名单在1,514次可判候选中，<strong>92.67%</strong>当天未提单；pD3＜20%对应<strong>93.63%</strong>，但只有879次可判候选。<strong>更高命中往往以减少覆盖为代价。</strong>这些是预设门槛的描述性比较，不应在同一份检验数据上挑出最高值后就当成未来保证。</p>'+
fold('查看全部预设门槛的覆盖与误选',table(['候选规则','完整候选','占8,866评分事件','可判候选','当天未提单命中','当天仍提单'],threshold_rows))+
fold('查看概率预测、AUC与版本对照',table(['指标（同8,717事件）','V4','含义'],[
 ['平均当天提单概率 / 实际','38.84% / 39.47%','群体平均接近，单人和局部分档不保证准确'],['平均D0—D3提单概率 / 实际','56.44% / 57.99%','总体略低估'],['当天AUC / D3 AUC','0.8196 / 0.8028','排序有区分度，AUC不是准确率'],['最高10%当天实际提单：V3 / V4','88.07% / 89.71%','V4提高1.64个百分点，改善幅度有限'],['把pD3＜0.5当当天不提单分类，整体准确率','69.65%','与候选名单命中率85.97%是不同指标']])+note('所有比较使用同一主样本，不混用原报告10,695次D0单独成熟样本。阈值是概率与业务成本之间的选择，参见<a href="https://scikit-learn.org/stable/modules/classification_threshold.html">scikit-learn官方阈值说明</a>。'))))

weeks=[r for r in D['consistency_weekly'] if r['rule']=='pD3_lt_0.5']
days=[r for r in D['consistency_daily'] if r['rule']=='pD3_lt_0.5']
weekchart=bars('week_accuracy','固定pD3＜0.5：三个观察时段的当天未提单命中率',[(r['observed_date_start'][5:]+'—'+r['observed_date_end'][5:],r['ppv_no_d0']*100,'#38bdf8',pct(r['ppv_no_d0'])) for r in weeks])
dailyrows=[[r['date'],num(r['all_candidates']),num(r['known_d0']),num(r['unknown_d0']),num(r['d0_apply']),pct(r['ppv_no_d0']),pct(r['ppv_no_d0_ci95_low'])+'—'+pct(r['ppv_no_d0_ci95_high']), '是' if r['D3_mature_date'] else '否'] for r in days]
body.append(section('dates','四、分批看是否可靠：周均接近，单日会波动',
'<p>同一冻结模型、同一pD3＜0.5门槛，在10月9—23日当天结果可判的数据中，三个观察时段命中率为<strong>85.23%、85.84%、85.45%</strong>。它不是只在一小组中有效，但这15天仍不足以证明跨月和未来长期稳定。</p>'+weekchart+
fold('查看三个时段的实际计数',table(['获额日期','完整候选','可判','实际未提单','实际当天提单','当天未提单命中','95%区间'],[[r['observed_date_start']+'—'+r['observed_date_end'],num(r['all_candidates']),num(r['known_d0']),num(r['no_d0']),num(r['d0_apply']),pct(r['ppv_no_d0']),pct(r['ppv_no_d0_ci95_low'])+'—'+pct(r['ppv_no_d0_ci95_high'])] for r in weeks]))+
'<p>逐日命中率为<strong>80.74%—90.23%</strong>。例如10月22日，270次可判候选的命中率80.74%，95%区间75.53%—85.43%。因此，不能把总体85.97%解释成“以后每天筛100次都只误选14次”。</p>'+
fold('查看15天逐日结果',table(['获额日','完整候选','可判','未知','实际当天提单','当天未提单命中','95%区间','D3已成熟'],dailyrows))+
note('此节为排除10月24日风险源匹配缺口后的D0成熟补充，与主样本有重叠，不是新增独立验证集，也不证明实时可用性。10月9—23日共10,298次评分事件，10,114次D0可判，184次未知。10月22—23日只有D0成熟，不能据此计算其D3准确率。10月24日此前审计有588次事件未匹配到风险模型来源，未混入此质量补充；本次未重查，不能断言源缺口已修复或仍存在。')))

G=D['d7_outcome_composition']
labels={'D0':'当天提单','D1_D3':'第1—3日提单','D4_D7':'第4—7日提单','NO_APPLY_THROUGH_D7':'到第7日仍未提单'}
d7chart=bars('d7_outcomes','低pD3候选后来怎样了？',[(labels[r['bucket']],r['share_known_d7_candidates']*100,('#fb7185' if r['bucket']=='D0' else '#38bdf8' if r['bucket']!='NO_APPLY_THROUGH_D7' else '#94a3b8'),f"{pct(r['share_known_d7_candidates'])} · {num(r['events'])}次") for r in G['rows'] if r['bucket']!='UNKNOWN'])
caserows=[]
for c in E['anonymous_cases']:
 outcome=(c['actual_first_application_time']+f"（D{c['application_natural_day_offset']}）") if c['actual_first_application_time'] else '截至10月17日00:00，完整D7窗口未见提单'
 caserows.append([c['case_no'],c['t0_time'],pct(c['p_d0']),pct(c['p_d3']),outcome])
body.append(section('cases','五、预测“不提单”不等于“3日后一定回来”',
'<p>基础候选中，真正D0—D3都未提单为<strong>2,488 / 3,656＝68.05%</strong>；另有655次在D1—D3提单。模型对“当天未提单”的筛选效果更好，不能把85.97%改写成“3日不提单准确率”。</p>'+d7chart+note('另取10月9—17日、D7已成熟的同规则候选：2,739次，其中2,708次结果可判、31次未知。图中分母统一为2,708，四类互斥合计100%；不是前文3,656次的继续延长。')+
call('D7可判候选中，<strong>12.08%</strong>在D4—D7提单，<strong>55.43%</strong>到D7仍未提单。名单里既有会较晚回来的人，也有至少一周仍未回来的人。现有模型更适合筛“短期提单意愿较低”，尚不能保证筛出“只需优惠就会回来”的人。')+
'<h3>四个匿名真实事件，直接看预测与实际</h3>'+table(['案例','T0获额时刻','预测当天提单','预测D0—D3提单','实际首次提单'],caserows)+note('均为America/Belize时间。各例均满足pD3＜0.5，按预先列明的四类实际结果分别取时间最早事件，未挑概率最极端或表现最好的个例；仅作分层说明，不代表类别比例。概率是冻结模型事后回放评分，尚非已证明当时线上生成的预测。没有在这些事件上开展随机优惠试验，不输出用户或订单标识。')))

matrix=table(['使用方式','当前结论','实际理由'],[
 ['离线辅助筛选 / 人工分析','可以','已能复现名单、概率和结果，85.97%不是随机猜测'],
 ['实时影子评分（只记录、不发优惠）','可以开始','用真实到达的数据补足当前回放缺失的上线证据'],
 ['小流量降息 / 提额对照测试','条件具备后合适','先验收时点、源健康、资格与预算，再验证新增转化和利润'],
 ['全量自动投放','证据不足','尚未验证真实实时名单质量、时延成本和优惠净收益']])
steps='''<ol class="steps"><li><strong>固定模型和候选规则。</strong>现有V4保持冻结；可先验证pD3＜0.5，另将叠加410高分规则作为较保守候选。所有门槛事先记录，使用原始概率，不用每批最高分归一化后的100分。</li>
<li><strong>先跑真实影子名单。</strong>每次T0保存实际可见特征、源到达水位、模型版本、分数、20秒去重封批时刻、评分完成时刻和拟触达时刻。当天已提单、源缺失或资格失效时不执行优惠。量化评分及时覆盖率、p50/p95/p99时延和成本。</li>
<li><strong>等结果成熟后验收。</strong>按封存名单核对D0命中、误选、覆盖、未知和每日波动。业务先定可接受的误选与成本，再用区间验收；不要事后改门槛迎合结果。</li>
<li><strong>过关后做用户级随机对照。</strong>固定同一用户的实验组；实验组按已批准方案优惠，对照组维持原策略。锚点取首次优惠前的原T0，优惠触发重获额也不重新计作新的实验起点。</li>
<li><strong>依据增量效果决定扩大。</strong>同时看D0及D0—D3提单增量、放款增量、优惠成本、后续风险与成熟账面收益。应将提单时点前移与新增提单分开核算，不能只凭D0上升认定新增召回成功；是否扩大仍看预先约定的净收益、成本和风险门槛。</li></ol>'''
body.append(section('production','六、上线判断：模型筛选这一步可测试，整个策略还需最后验证',matrix+
'<h3>为什么还不能直接写成“生产已验证可用”</h3>'+ 
'<p>本次主证据来自<strong>历史特征回放再评分</strong>。检验总材料中，16,154次10月事件为回顾重建后评分，另6,211次9月事件沿用旧保存分数；本报告业务主样本仅取10月9—21日。不具备完整的“当时已到达特征＋在线评分生成时刻＋实际触达”证据，无法保证当时和今天实时系统可见的数据相同。技术复现通过，证明代码算对了；真实影子验证才能继续证明线上能及时拿到并算对。</p>'+
'<p>原审计还发现10月24日588次事件缺少风险源匹配。模型能处理缺失值，不代表优惠系统遇到关键源缺失也应自动继续。另一方面，原410分来源未带生成时间，离线分档可以分析，生产门槛仍需确认该分在获额决策时可见。</p>'+
call('例如把“当天潜在误选不超过10%”设为<strong>假设验收线</strong>：叠加410高分的历史点估计为9.31%，但95%区间为7.90%—10.74%，上限仍超过10%。因此不能承诺以后一定达标；业务需要先批准容忍度，再用实时成熟结果验收。')+
'<h3>最短可执行闭环</h3>'+steps+note('上述为测试方案建议，没有部署、发优惠或改生产数据。实验统计保留原用户和原锚点；不因政策引发下一次T0而截掉实验收益。随机化方法可参见<a href="https://www.microsoft.com/en-us/research/?p=712624">Microsoft研究：在线受控实验</a>。')+
call('<strong>最终判断：</strong>无需为了开始验证而先重训。当前V4已足以作为定向召回的候选筛选器进入真实影子与条件受控的小流量测试；“识别当天不提单”有数据支持，“优惠提高转化且守住盈利”仍需真实对照结果闭环。')))

methodtable=table(['项目','本报告口径'],[
 ['冻结版本','t0_timing_v4_20261008；本次不训练、不重校准'],
 ['数据截止','2026年10月25日00:00:00 America/Belize之前，即截至10月24日完整自然日；本次未刷新到10月26日'],
 ['T0事件','沿用原严格T0口径、同用户20秒链式获额去重；同用户不同真实事件均统计'],
 ['D0','获额通过时刻起，到该业务自然日结束'],
 ['D3','D0、D1、D2、D3累计，即4个业务自然日期；不是滚动72小时'],
 ['提单结果','本T0之后首次实际提单，不要求与获额同订单号；提单不等于通过或成功放款'],
 ['未知结果','沿用原检验在下一次严格T0截断标签；不足以判断完整窗口的结果记未知，不补未提单'],
 ['准确性公式','当天未提单命中率＝筛中且D0未提单事件数÷筛中且D0结果可判事件数'],
 ['完整覆盖率','筛中完整候选数÷全部完成评分事件数；包含未知结果候选'],
 ['不确定性','按用户聚类bootstrap 500次；重复事件保留。置信区间不是下一批效果保证'],
 ['统计与实验单位','分析按事件；实验随机分组按用户，避免同一用户多次事件跨组'],
 ['行为时间','历史行为采用event_track_record明细回放并限制预测前。事件已发生不等于源数据已到达，这正是影子补证内容']])
source_paths=[
 ROOT/'work/t0_v4_validation_20261024_20261025/evaluation/labels_evaluated.parquet',
 ROOT/'work/t0_offer_strategy_20261025/model_targeting.json',
 ROOT/'work/t0_risk410_lifecycle_strategy_20261025/prediction_profiles.json',
 ROOT/'work/t0_risk410_lifecycle_strategy_20261025/cells.csv']
sourcetable=table(['依据','作用','SHA256（前16位）'],[[e(str(x.relative_to(ROOT))),['事件预测与可判标签','原候选计数与区间','410筛选及其基线','事件级利润背景'][i],hashlib.sha256(x.read_bytes()).hexdigest()[:16]] for i,x in enumerate(source_paths)])
codepaths=[W/'prepare_release_sql.py',W/'analyze_business_reliability.py',W/'make_business_examples.py',W/'build_production_readiness.py',W/'build_business_report.py',
 ROOT/'work/t0_v4_validation_20261024_20261025/build_features_replay.py',ROOT/'work/t0_v4_validation_20261024_20261025/score_and_assemble.py',ROOT/'work/t0_v4_validation_20261024_20261025/evaluate_validation.py',
 ROOT/'work/t0_offer_strategy_20261025/analyze_model_targeting.py',ROOT/'work/t0_risk410_lifecycle_strategy_20261025/analyze_prediction_profiles.py',ROOT/'work/t0_risk410_lifecycle_strategy_20261025/sql/strict_t0_risk410_lifecycle_global.sql']
# Original extraction SQL is included without rewriting its validated logic.
sqlpaths=sorted((ROOT/'work/t0_v4_validation_20261024_20261025/sql').glob('*.sql'))
release_root=W/'release_sql'
allcode=list(dict.fromkeys(codepaths+sqlpaths))
allcode=[release_root/x.relative_to(ROOT/'work') if x.suffix=='.sql' else x for x in allcode]
assert all(x.exists() for x in allcode), 'Missing parameterized release SQL'
allcode=[release_root/'00_release_input_tables.sql']+allcode
codebody=''.join(f'<details class="code"><summary>{e(str(x.relative_to(ROOT/"work")))}</summary><pre><code>{e(x.read_text())}</code></pre></details>' for x in allcode)
body.append(section('methods','七、口径、统计依据与完整复原代码',
'<p>主结论使用截至10月24日的既有冻结检验数据，重新整理为业务可读的计数、对比和匿名案例；原验证报告与模型文件均保留。本报告没有把后续缺失数据补为未提单，也没有用优惠效果的假设替代实际测量。</p>'+fold('查看完整口径',methodtable)+fold('查看数据来源与校验依据',sourcetable)+
f'<p><a class="button" href="{zip_name}">下载完整代码与统计依据 ZIP</a></p>'+note('ZIP包含完整统计脚本、原模型特征/评分/标签计算代码、参数化历史SQL、汇总结果与文件校验清单。SQL逻辑保留，实际用户/事件清单改为带独立批次键的授权输入表，说明中列明原集合数量与哈希；空批次不会扩大为全量。不含数据库密码、逐用户明细或模型二进制；重算原始统计需在原授权数据环境提供冻结Parquet与模型依赖，只有SQL时需重新取数。汇总数据可直接复原本报告图表。')+
fold(f'附录：复原报告代码（{len(allcode)}个完整SQL / Python文件，默认隐藏）',codebody)))
css='''*{box-sizing:border-box}html{scroll-behavior:smooth;scroll-padding-top:110px}body{margin:0;background:#0b1220;color:#dbe5f1;font-family:-apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei",sans-serif;font-size:16px;line-height:1.85}header{padding:42px 24px 24px;text-align:center;background:linear-gradient(125deg,#111f36,#0d1729)}h1{color:#f8fafc;font-size:31px;letter-spacing:.7px;margin:0 0 12px}header p{margin:3px;color:#94a3b8}.nav{position:sticky;top:0;z-index:20;display:flex;justify-content:center;gap:4px;flex-wrap:wrap;padding:12px;background:rgba(11,18,32,.97);border-bottom:1px solid #2b3c54;backdrop-filter:blur(12px)}.nav a{padding:6px 13px;border-radius:5px;text-decoration:none;font-size:14px}.nav a:hover{background:#20314b}main{max-width:1240px;margin:auto;padding:12px 28px 60px}section{scroll-margin-top:100px;margin-top:28px;padding:26px 28px;background:#111c2e;border:1px solid #29374c;border-radius:12px}h2{font-size:23px;color:#f1f5f9;margin:0 0 18px}h3{font-size:18px;color:#f1f5f9;margin:22px 0 12px}p{margin:14px 0}strong{color:#f1f5f9}a{color:#7dd3fc}.callout{border-left:4px solid #38bdf8;padding:15px 20px;background:#14283e;border-radius:4px;margin:18px 0}.cards{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px;margin:24px 0}.card{padding:18px 16px;background:#18263b;border:1px solid #31435d;border-radius:9px;display:flex;flex-direction:column}.card span{font-size:14px;color:#a7b8ce}.card strong{font-size:32px;line-height:1.3;color:#6ee7b7;margin:5px 0}.card small{font-size:12px;color:#9aadc4}.red{color:#fb7185!important}.note{font-size:13px;color:#97abc3;line-height:1.8}figure{margin:24px 0 12px;background:#0d1728;border:1px solid #29394f;border-radius:10px;padding:10px 14px}figure h3{padding:0 8px;margin:10px 0 0}svg{width:100%;height:auto;display:block}svg text{font-size:16px;font-family:inherit}details{margin:16px 0;border:1px solid #30415a;border-radius:7px;background:#0e192b}summary{cursor:pointer;padding:12px 16px;color:#a9dff7;font-weight:600}details[open]>summary{border-bottom:1px solid #2b3c53}.scroll{overflow:auto;padding:4px 14px 12px}table{width:100%;border-collapse:collapse;font-size:14px;white-space:normal}th,td{padding:12px 13px;vertical-align:top;text-align:left;border-bottom:1px solid #29394f}th{background:#17283f;color:#d1e5f9;font-weight:600}td{color:#c5d1e0}tr:last-child td{border-bottom:0}details p{padding:0 16px}.steps{padding-left:26px}.steps li{padding:0 0 15px 5px}.button{display:inline-block;padding:9px 16px;border:1px solid #3a7597;background:#14354a;border-radius:6px;text-decoration:none}pre{max-height:540px;overflow:auto;white-space:pre;font-size:12px;line-height:1.65;padding:18px;color:#b9cde2}.code{margin:10px 14px}.code summary{font-size:12px;word-break:break-word}footer{text-align:center;color:#7e93af;font-size:12px;padding:25px}@media(max-width:800px){h1{font-size:24px}.cards{grid-template-columns:repeat(2,1fr)}main{padding:0 12px 30px}section{padding:20px 16px}h2{font-size:20px}.nav{gap:0;padding:6px}.nav a{padding:4px 7px;font-size:12px}figure{overflow:auto}figure svg{min-width:690px}.scroll table{min-width:650px}html{scroll-padding-top:120px}}'''
report='<!DOCTYPE html><html lang="zh-CN"><head><meta charset="UTF-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>T0模型V4：实际预测效果与上线建议</title><style>'+css+'</style></head><body><header><h1>T0提单意愿模型V4：实际预测效果与上线建议</h1><p>能否提前筛出当天不提单的用户，并用于定向召回？</p><p class="note">报告生成：2026年10月26日 · 检验数据截至2026年10月24日</p></header><nav class="nav" aria-label="报告目录">'+''.join(f'<a href="#{id}">{title}</a>' for id,title in nav)+'</nav><main>'+''.join(body)+'</main><footer>冻结模型 · 事件口径 · 真实计数 · 原报告保留</footer></body></html>'
soup=BeautifulSoup(report,'html.parser')
for t in soup.select('table'):
 if not t.find_parent('details'):
  container=t.find_parent('div',class_='scroll')
  holder=soup.new_tag('details')
  summary=soup.new_tag('summary');summary.string='查看明细对照（默认隐藏）';holder.append(summary)
  container.wrap(holder)
report=str(soup)
(O/report_name).write_text(report)
# Deliver aggregate snapshots and code only. Never bundle raw event/user records or connection files.
readme='''T0模型V4业务实测与上线建议（2026-10-26）
报告图表使用截至2026-10-24既有冻结数据，本次无数据库查询、重训、部署或优惠发放。
1. 与本ZIP同目录交付的HTML可离线打开；报告内可直接下载相邻ZIP。
2. aggregates/保存完整统计结果与区间。计数按T0事件，重复用户保留；未知标签不补零。
3. code/为完整SQL/Python，不截取代码片段。发布SQL将原用户/订单/锚点清单参数化为不同batch_key的授权输入表，不改变其余计算逻辑；先查看inputs/00_发布SQL输入表说明.txt、输入DDL和清单哈希，必须填回原范围冻结输入，不同批次不能混用。原取数依赖授权数据库，连接配置不包含在包中；原模型和逐用户Parquet不打包。SQL与源统计代码可在原工作目录按依赖执行；复用汇总JSON可以直接运行报告构建脚本复原展示。脚本中默认工作区为本用户原路径，迁移时修改ROOT及上游路径。
4. 原始冻结标签和410映射的SHA256见manifest.json。无原明细/模型/环境时，不能只凭汇总JSON重新证明预测准确性；可以复核和复原此报告的展示。
5. 名单规则pD3<0.5；pD3为D0至D3四个自然日期累计提单概率，非72小时。85.97%是可判候选中D0未提单的比例。候选完整覆盖3,701/8,866；准确性3,143/3,656；45未知保留。
6. 新脚本依据固定规则和固定汇总复原，候选阈值表为描述性比较，未在测试集重训或自动优化阈值。
7. profit背景是当前回款账面收益，非优惠后的因果净利润，资金快照沿用原报告而非10月26日新取数。
'''
(W/'复现说明.txt').write_text(readme)
files={}
for x in allcode: files['code/'+str(x.relative_to(ROOT/'work'))]=x
for name in ['business_reliability_metrics.json','business_examples.json','production_readiness.json','business_reliability_qa.json']:
 x=W/name
 if x.exists():files['aggregates/'+x.name]=x
for x in W.glob('*.csv'): files['aggregates/'+x.name]=x
for name in ['prediction_profiles.json','prediction_profiles.csv','prediction_profiles_qa.json','cells.csv','quality.json']:
 x=ROOT/'work/t0_risk410_lifecycle_strategy_20261025'/name
 if x.exists():files['aggregates/context/'+name]=x
files['README.txt']=W/'复现说明.txt'
for name in ['release_sql_manifest.json','release_sql_qa.json']:
 x=W/name
 if x.exists():files['inputs/'+name]=x
for x in release_root.glob('*.txt'):files['inputs/'+x.name]=x
manifest={'generated_date':'2026-10-26','model':'t0_timing_v4_20261008','source_cutoff_exclusive':'2026-10-25 00:00:00 America/Belize','files':{k:{'bytes':v.stat().st_size,'sha256':hashlib.sha256(v.read_bytes()).hexdigest()} for k,v in files.items()},'private_sources_not_in_zip':{str(x.relative_to(ROOT)):hashlib.sha256(x.read_bytes()).hexdigest() for x in source_paths}}
with zipfile.ZipFile(O/zip_name,'w',zipfile.ZIP_DEFLATED,compresslevel=6) as z:
 for k,v in files.items():z.write(v,k)
 z.writestr('manifest.json',json.dumps(manifest,ensure_ascii=False,indent=2))
(W/'report_manifest.json').write_text(json.dumps({'html':str(O/report_name),'zip':str(O/zip_name),'charts':CHARTS,'code_files':len(allcode),'main_counts':{k:main[k] for k in ['known_d0','no_d0','d0_apply','ppv_no_d0','complete_all_candidates']},'original_reports_modified':False},ensure_ascii=False,indent=2))
print(json.dumps({'html':str(O/report_name),'bytes':(O/report_name).stat().st_size,'zip':str(O/zip_name),'zip_bytes':(O/zip_name).stat().st_size,'charts':len(CHARTS),'code_files':len(allcode)},ensure_ascii=False))
