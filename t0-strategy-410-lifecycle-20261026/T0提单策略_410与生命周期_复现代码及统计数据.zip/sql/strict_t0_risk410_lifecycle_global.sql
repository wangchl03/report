WITH params AS (
    SELECT DATE '2026-01-01' AS base_start_date,
           DATE '2026-01-01' AS output_start_date,
           DATE '2026-11-01' AS output_end_date,
           TIMESTAMP '2026-10-25 09:55:21.800090' AS data_cutoff_ts
), raw_pass_offer AS (
    SELECT v.user_id, v.serial_id, v.vir_date::date AS vir_date,
           v.vir_unix,
           TO_TIMESTAMP(v.vir_unix) AT TIME ZONE 'America/Belize' AS vir_time
    FROM wangchuanliang.order_vir_f_copy v CROSS JOIN params p
    WHERE v.is_pass1 = 1 AND v.loan_type_code = 2 AND v.vir_unix > 0
      AND v.vir_date >= p.base_start_date - 1
      AND v.vir_date < p.data_cutoff_ts::date + 1
      AND TO_TIMESTAMP(v.vir_unix) AT TIME ZONE 'America/Belize' < p.data_cutoff_ts
), qualified_offer AS (
    SELECT v.* FROM raw_pass_offer v
    WHERE EXISTS (
        SELECT 1 FROM wangchuanliang.side_recycle_type_copy r
        WHERE r.serial_id = v.serial_id AND r.recycle_type = 3
    )
), serial_latest AS (
    SELECT DISTINCT ON (user_id, serial_id) * FROM qualified_offer
    ORDER BY user_id, serial_id, vir_unix DESC
), lagged AS (
    SELECT v.*, LAG(vir_time) OVER (
        PARTITION BY user_id ORDER BY vir_time, serial_id
    ) AS previous_time
    FROM serial_latest v
), batched AS (
    SELECT v.*, SUM(CASE WHEN previous_time IS NULL
                              OR vir_time - previous_time > INTERVAL '20 seconds'
                        THEN 1 ELSE 0 END) OVER (
        PARTITION BY user_id ORDER BY vir_time, serial_id ROWS UNBOUNDED PRECEDING
    ) AS batch_id
    FROM lagged v
), batch_ranked AS (
    SELECT v.*, ROW_NUMBER() OVER (
        PARTITION BY user_id, batch_id ORDER BY vir_time DESC, serial_id DESC
    ) AS batch_rn
    FROM batched v
), dedup_offer AS (
    SELECT v.* FROM batch_ranked v CROSS JOIN params p
    WHERE batch_rn = 1 AND vir_date >= p.base_start_date
), candidate_users AS (
    SELECT DISTINCT user_id FROM dedup_offer
), funded_orders AS (
    SELECT DISTINCT ON (o.user_id, o.serial_id)
           o.user_id, o.serial_id, o.apply_time, o.remit_time,
           o.remit_amt, o.is_remit, o.repaid_time, o.repaid_date,
           o.is_repaid, o.loan_status_code
    FROM wangchuanliang.order_loan_f_v2_copy o
    JOIN candidate_users u ON u.user_id = o.user_id
    WHERE o.is_remit = 1 AND o.remit_amt > 0
    ORDER BY o.user_id, o.serial_id, o.apply_time ASC NULLS LAST
), clean_settlement AS (
    SELECT o.* FROM funded_orders o CROSS JOIN params p
    WHERE (o.is_repaid = 1 OR o.loan_status_code = 7)
      AND o.repaid_time > TIMESTAMP '2000-01-01'
      AND o.repaid_date >= p.base_start_date
      AND o.repaid_time < p.data_cutoff_ts
      AND NOT EXISTS (
          SELECT 1 FROM funded_orders x
          WHERE x.user_id = o.user_id AND x.serial_id <> o.serial_id
            AND x.remit_time <= o.repaid_time
            AND (x.repaid_time IS NULL
                 OR x.repaid_time <= TIMESTAMP '2000-01-01'
                 OR x.repaid_time > o.repaid_time)
      )
), settlement_matched AS (
    SELECT e.*, s.serial_id AS settled_serial_id, s.repaid_time,
           ROW_NUMBER() OVER (
               PARTITION BY e.user_id, e.serial_id
               ORDER BY s.repaid_time DESC, s.serial_id DESC
           ) AS settlement_rn
    FROM dedup_offer e JOIN clean_settlement s
      ON s.user_id = e.user_id AND s.repaid_date = e.vir_date
     AND s.repaid_time <= e.vir_time
), strict_t0_all AS (
    SELECT e.*, LEAD(vir_time) OVER (
        PARTITION BY user_id ORDER BY vir_time, serial_id
    ) AS next_t0_time
    FROM settlement_matched e WHERE settlement_rn = 1
), cohort AS (
    SELECT e.*, p.data_cutoff_ts FROM strict_t0_all e CROSS JOIN params p
    WHERE e.vir_date >= p.output_start_date AND e.vir_date < p.output_end_date
), raw_applications AS (
    SELECT o.user_id,o.serial_id,o.apply_time,o.apply_date,o.apply_amt,
           o.is_remit,o.remit_time,o.remit_amt,o.repaid_amt,o.due_date,o.is_due,
           o.loan_status_code,o.loan_day,o.total_term,
           COUNT(*) OVER(PARTITION BY o.user_id,o.serial_id) AS source_order_rows
    FROM wangchuanliang.order_loan_f_v2_copy o
    JOIN candidate_users u ON u.user_id=o.user_id CROSS JOIN params p
    WHERE o.apply_date>=p.base_start_date-1
      AND o.apply_date<p.data_cutoff_ts::date+1
      AND o.apply_time>=p.base_start_date::timestamp AND o.apply_time<p.data_cutoff_ts
), applications AS (
    SELECT DISTINCT ON (user_id,serial_id) * FROM raw_applications
    ORDER BY user_id,serial_id,apply_time
), application_ranked AS (
    SELECT e.user_id,e.serial_id AS credit_serial_id,e.vir_date,e.vir_time,
           e.settled_serial_id,e.repaid_time AS clean_settle_time,
           e.next_t0_time,e.data_cutoff_ts,
           o.serial_id AS apply_serial_id,o.apply_time,o.apply_amt,o.is_remit,
           o.remit_time,o.remit_amt,o.repaid_amt,o.due_date,o.is_due,
           o.loan_status_code,o.loan_day,o.total_term,o.source_order_rows,
           ROW_NUMBER() OVER(PARTITION BY e.user_id,e.serial_id
                              ORDER BY o.apply_time,o.serial_id) AS apply_rn
    FROM cohort e LEFT JOIN applications o
      ON o.user_id=e.user_id AND o.apply_time>=e.vir_time
     AND (e.next_t0_time IS NULL OR o.apply_time<e.next_t0_time)
),
 r410_events AS (
 SELECT * FROM application_ranked WHERE apply_rn=1 AND vir_date<data_cutoff_ts::date
 ), r410_fundseq AS (
 SELECT o.*,ROW_NUMBER() OVER(PARTITION BY user_id ORDER BY remit_time,serial_id) AS settled_loan_seq,
   SUM(CASE WHEN remit_time IS NULL OR remit_time<=TIMESTAMP '2000-01-01' THEN 1 ELSE 0 END)
      OVER(PARTITION BY user_id) AS history_bad_remit_clock_n
 FROM funded_orders o
 ), r410_model AS (
 SELECT m.user_id,m.serial_id,COUNT(*) AS score_source_rows,
   COUNT(DISTINCT CASE WHEN m.kabybmerge410fpd7cre BETWEEN 1 AND 3000 THEN m.kabybmerge410fpd7cre END) AS distinct_valid_scores,
   CASE WHEN COUNT(DISTINCT CASE WHEN m.kabybmerge410fpd7cre BETWEEN 1 AND 3000 THEN m.kabybmerge410fpd7cre END)=1
     THEN MIN(CASE WHEN m.kabybmerge410fpd7cre BETWEEN 1 AND 3000 THEN m.kabybmerge410fpd7cre END) END AS score_410,
   SUM(CASE WHEN m.kabybmerge410fpd7cre IS NULL THEN 1 ELSE 0 END) AS score_null_rows,
   SUM(CASE WHEN m.kabybmerge410fpd7cre BETWEEN 1 AND 3000 THEN 1 ELSE 0 END) AS score_valid_rows,
   SUM(CASE WHEN m.kabybmerge410fpd7cre=-9999999 THEN 1 ELSE 0 END) AS score_placeholder_rows,
   SUM(CASE WHEN m.kabybmerge410fpd7cre<=0 AND m.kabybmerge410fpd7cre<>-9999999 THEN 1 ELSE 0 END) AS score_nonpositive_rows,
   SUM(CASE WHEN m.kabybmerge410fpd7cre>3000 THEN 1 ELSE 0 END) AS score_above3000_rows,
   SUM(CASE WHEN m.kabybmerge410fpd7cre IS NOT NULL AND NOT(m.kabybmerge410fpd7cre BETWEEN 1 AND 3000)
        AND m.kabybmerge410fpd7cre<>-9999999 AND NOT(m.kabybmerge410fpd7cre<=0) AND NOT(m.kabybmerge410fpd7cre>3000)
       THEN 1 ELSE 0 END) AS score_other_invalid_rows
 FROM wangchuanliang.model_result_copy m
 WHERE EXISTS(SELECT 1 FROM r410_events e WHERE e.user_id=m.user_id AND e.credit_serial_id=m.serial_id)
 GROUP BY m.user_id,m.serial_id
 ), r410_profiles_unbinned AS (
 SELECT e.*,m.score_410,m.score_source_rows,m.distinct_valid_scores,
   COALESCE(m.score_null_rows,0) AS score_null_rows,COALESCE(m.score_valid_rows,0) AS score_valid_rows,
   COALESCE(m.score_placeholder_rows,0) AS score_placeholder_rows,
   COALESCE(m.score_nonpositive_rows,0) AS score_nonpositive_rows,
   COALESCE(m.score_above3000_rows,0) AS score_above3000_rows,
   COALESCE(m.score_other_invalid_rows,0) AS score_other_invalid_rows,
   CASE WHEN m.serial_id IS NULL THEN 'NO_RECORD'
        WHEN m.distinct_valid_scores>1 THEN 'CONFLICT'
        WHEN m.distinct_valid_scores=1 THEN 'VALID'
        WHEN m.score_null_rows=m.score_source_rows THEN 'NULL_SCORE' ELSE 'INVALID' END AS score_status,
   CASE WHEN s.history_bad_remit_clock_n=0 AND s.remit_time<=e.clean_settle_time
             AND s.remit_time<=e.vir_time THEN s.settled_loan_seq END AS settled_loan_seq,
   CASE WHEN s.serial_id IS NULL THEN 'SETTLED_ORDER_UNMATCHED'
        WHEN s.history_bad_remit_clock_n>0 THEN 'HISTORY_REMIT_CLOCK_MISSING'
        WHEN s.remit_time>e.clean_settle_time OR s.remit_time>e.vir_time THEN 'INVALID_CHRONOLOGY'
        ELSE 'VALID' END AS sequence_status,
   s.history_bad_remit_clock_n,
   e.apply_time::date-e.vir_date AS apply_day,
   CASE WHEN e.is_remit=1 AND e.remit_amt>0 THEN 1 ELSE 0 END AS funded,
   e.data_cutoff_ts::date-e.due_date AS recovery_age_days
 FROM r410_events e LEFT JOIN r410_model m
   ON m.user_id=e.user_id AND m.serial_id=e.credit_serial_id
 LEFT JOIN r410_fundseq s ON s.user_id=e.user_id AND s.serial_id=e.settled_serial_id
 ), r410_ordered_scores AS (
 SELECT score_410,ROW_NUMBER() OVER(ORDER BY score_410) AS score_rn,COUNT(*) OVER() AS valid_n
 FROM r410_profiles_unbinned WHERE score_status='VALID'
 ), r410_thresholds AS (
 SELECT MAX(valid_n) AS valid_n,
   MIN(CASE WHEN score_rn>=CEIL(valid_n*0.5) THEN score_410 END) AS q50,
   MIN(CASE WHEN score_rn>=CEIL(valid_n*0.8) THEN score_410 END) AS q80
 FROM r410_ordered_scores
 ), r410_profiles AS (
 SELECT e.*,
   CASE WHEN score_status<>'VALID' THEN score_status
        WHEN score_410>=t.q80 THEN 'HIGH20'
        WHEN score_410>=t.q50 THEN 'MID30' ELSE 'LOW50' END AS score_band,
   CASE WHEN settled_loan_seq IS NULL THEN 'UNKNOWN'
        WHEN settled_loan_seq BETWEEN 1 AND 5 THEN settled_loan_seq::text
        WHEN settled_loan_seq BETWEEN 6 AND 10 THEN '6-10'
        WHEN settled_loan_seq BETWEEN 11 AND 20 THEN '11-20' ELSE '21+' END AS lifecycle_band
 FROM r410_profiles_unbinned e CROSS JOIN r410_thresholds t
 ), r410_bucket_defs AS (
 SELECT 'D0'::text AS bucket UNION ALL SELECT 'D1' UNION ALL SELECT 'D2'
 UNION ALL SELECT 'D3' UNION ALL SELECT 'D4+' UNION ALL SELECT 'D4-D15'
 UNION ALL SELECT 'D16+' UNION ALL SELECT 'D1-D3' UNION ALL SELECT 'D1+'
 UNION ALL SELECT 'ALL' UNION ALL SELECT 'no_apply'
 ), r410_staged AS (
 SELECT e.*,b.bucket
 FROM r410_profiles e CROSS JOIN r410_bucket_defs b
 WHERE b.bucket='ALL' OR (b.bucket='no_apply' AND apply_serial_id IS NULL)
    OR (b.bucket='D0' AND apply_day=0) OR (b.bucket='D1' AND apply_day=1)
    OR (b.bucket='D2' AND apply_day=2) OR (b.bucket='D3' AND apply_day=3)
    OR (b.bucket='D4+' AND apply_day>=4) OR (b.bucket='D4-D15' AND apply_day BETWEEN 4 AND 15)
    OR (b.bucket='D16+' AND apply_day>=16) OR (b.bucket='D1-D3' AND apply_day BETWEEN 1 AND 3)
    OR (b.bucket='D1+' AND apply_day>=1)
 ), r410_grained AS (
 SELECT e.*,'event'::text AS grain FROM r410_staged e
 ), r410_scopes AS (
 SELECT 'main'::text AS scope,'mature_complete_days'::text AS scenario
 UNION ALL SELECT 'jan_sep','mature_complete_days'
 UNION ALL SELECT 'recovery30','mature_30d'
 UNION ALL SELECT 'all_funded','all_funded'
 ), r410_scoped AS (
 SELECT e.*,s.scope,s.scenario,
   CASE WHEN funded=1 AND ((s.scenario='all_funded')
     OR (s.scenario='mature_complete_days' AND due_date>=DATE '2000-01-01' AND due_date<data_cutoff_ts::date)
     OR (s.scenario='mature_30d' AND due_date>=DATE '2000-01-01' AND recovery_age_days>=30)) THEN 1 ELSE 0 END AS eligible
 FROM r410_grained e CROSS JOIN r410_scopes s
 WHERE s.scope<>'jan_sep' OR vir_date<DATE '2026-10-01'
 ), r410_periods AS (
 SELECT e.*,'ALL'::text AS period FROM r410_scoped e
 UNION ALL SELECT e.*,TO_CHAR(vir_date,'YYYY-MM') FROM r410_scoped e WHERE scope='main'
 ), r410_cells AS (
 SELECT scope,grain,period,scenario,bucket,
   CASE WHEN GROUPING(score_band)=0 AND GROUPING(lifecycle_band)=0 THEN 'joint'
        WHEN GROUPING(score_band)=0 THEN 'risk' WHEN GROUPING(lifecycle_band)=0 THEN 'lifecycle'
        ELSE 'overall' END AS level,
   CASE WHEN GROUPING(score_band)=1 THEN 'ALL' ELSE score_band END AS score_band,
   CASE WHEN GROUPING(lifecycle_band)=1 THEN 'ALL' ELSE lifecycle_band END AS lifecycle_band,
   COUNT(*) AS event_count,COUNT(DISTINCT user_id) AS users,COUNT(apply_serial_id) AS first_apply_orders,
   SUM(funded) AS funded_orders,SUM(eligible) AS mature_orders,
   SUM(CASE WHEN eligible=1 AND repaid_amt IS NOT NULL THEN remit_amt ELSE 0 END) AS principal,
   SUM(CASE WHEN eligible=1 AND repaid_amt IS NOT NULL THEN repaid_amt ELSE 0 END) AS repaid,
   SUM(CASE WHEN eligible=1 AND repaid_amt IS NULL THEN 1 ELSE 0 END) AS missing_repaid_orders,
   SUM(CASE WHEN eligible=1 AND repaid_amt IS NULL THEN remit_amt ELSE 0 END) AS missing_repaid_principal,
   SUM(CASE WHEN eligible=1 AND loan_status_code=8 THEN 1 ELSE 0 END) AS state8_orders,
   SUM(CASE WHEN score_status='VALID' THEN 1 ELSE 0 END) AS score_valid_events,
   SUM(CASE WHEN score_status='CONFLICT' THEN 1 ELSE 0 END) AS score_conflict_events,
   SUM(CASE WHEN score_status='INVALID' THEN 1 ELSE 0 END) AS score_invalid_events,
   SUM(CASE WHEN score_status='NO_RECORD' THEN 1 ELSE 0 END) AS score_no_record_events,
   SUM(CASE WHEN score_status='NULL_SCORE' THEN 1 ELSE 0 END) AS score_null_events,
   SUM(CASE WHEN sequence_status<>'VALID' THEN 1 ELSE 0 END) AS lifetime_unknown_events,
   SUM(CASE WHEN eligible=1 AND loan_day IS NOT NULL THEN loan_day ELSE 0 END) AS loan_day_sum,
   SUM(CASE WHEN eligible=1 AND loan_day IS NOT NULL THEN 1 ELSE 0 END) AS loan_day_n,
   SUM(CASE WHEN eligible=1 AND recovery_age_days IS NOT NULL THEN recovery_age_days ELSE 0 END) AS recovery_age_sum,
   SUM(CASE WHEN eligible=1 AND recovery_age_days IS NOT NULL THEN 1 ELSE 0 END) AS recovery_age_n
 FROM r410_periods
 GROUP BY GROUPING SETS (
  (scope,grain,period,scenario,bucket,score_band,lifecycle_band),
  (scope,grain,period,scenario,bucket,score_band),
  (scope,grain,period,scenario,bucket,lifecycle_band),
  (scope,grain,period,scenario,bucket))
 ), r410_exact_lifetime AS (
 SELECT grain,bucket,settled_loan_seq,COUNT(*) AS event_count,COUNT(DISTINCT user_id) AS users,
   SUM(funded) AS funded_orders,
   SUM(CASE WHEN funded=1 AND due_date>=DATE '2000-01-01' AND due_date<data_cutoff_ts::date THEN 1 ELSE 0 END) AS mature_orders
 FROM r410_grained GROUP BY grain,bucket,settled_loan_seq
 ), r410_quality AS (
 SELECT COUNT(*) AS events,COUNT(DISTINCT user_id) AS users,
   COUNT(*)-COUNT(DISTINCT user_id::text||':'||credit_serial_id::text) AS duplicate_events,
   COUNT(apply_serial_id)-COUNT(DISTINCT CASE WHEN apply_serial_id IS NOT NULL THEN user_id::text||':'||apply_serial_id::text END) AS duplicate_first_order_assignments,
   SUM(CASE WHEN source_order_rows>1 THEN 1 ELSE 0 END) AS duplicate_financial_source_orders,
   SUM(CASE WHEN clean_settle_time>vir_time OR vir_time::date<>vir_date OR apply_time<vir_time OR apply_time>=next_t0_time OR apply_time>=data_cutoff_ts THEN 1 ELSE 0 END) AS invalid_time_events,
   SUM(CASE WHEN score_status='VALID' THEN 1 ELSE 0 END) AS score_valid_events,
   SUM(CASE WHEN score_status='CONFLICT' THEN 1 ELSE 0 END) AS score_conflict_events,
   SUM(CASE WHEN score_status='INVALID' THEN 1 ELSE 0 END) AS score_invalid_events,
   SUM(CASE WHEN score_status='NO_RECORD' THEN 1 ELSE 0 END) AS score_no_record_events,
   SUM(CASE WHEN score_status='NULL_SCORE' THEN 1 ELSE 0 END) AS score_null_events,
   SUM(COALESCE(score_source_rows,0)) AS score_source_rows,
   SUM(score_null_rows) AS score_null_rows,SUM(score_valid_rows) AS score_valid_rows,
   SUM(score_placeholder_rows) AS score_placeholder_rows,SUM(score_nonpositive_rows) AS score_nonpositive_rows,
   SUM(score_above3000_rows) AS score_above3000_rows,SUM(score_other_invalid_rows) AS score_other_invalid_rows,
   SUM(CASE WHEN score_source_rows>1 THEN 1 ELSE 0 END) AS model_duplicate_row_events,
   SUM(CASE WHEN score_status='VALID' AND (score_placeholder_rows+score_nonpositive_rows+score_above3000_rows+score_other_invalid_rows)>0 THEN 1 ELSE 0 END) AS valid_with_invalid_companion_events,
   SUM(CASE WHEN sequence_status<>'VALID' THEN 1 ELSE 0 END) AS lifetime_unknown_events,
   MIN(settled_loan_seq) AS min_settled_loan_seq,MAX(settled_loan_seq) AS max_settled_loan_seq,
   MIN(vir_date) AS first_event_date,MAX(vir_date) AS last_event_date,
   MAX(data_cutoff_ts) AS observation_cutoff
 FROM r410_profiles
 ), r410_validation_mapping AS (
 SELECT credit_serial_id AS event_id,credit_serial_id,user_id,vir_time,TO_CHAR(vir_date,'YYYY-MM') AS month,
   score_410,score_status,score_band,NULL::timestamp AS score_time,
   settled_serial_id,settled_loan_seq,lifecycle_band,sequence_status,score_source_rows,distinct_valid_scores
 FROM r410_profiles WHERE credit_serial_id IN (
       /* 核验订单编号由运行方填入；公开版不携带个人订单编号。 */
       NULL::bigint
     )
 )
 SELECT 'cell'::text AS record_type,row_to_json(x)::text AS payload FROM r410_cells x
 UNION ALL SELECT 'exact_lifecycle',row_to_json(x)::text FROM r410_exact_lifetime x
 UNION ALL SELECT 'quality',row_to_json(x)::text FROM r410_quality x
 UNION ALL SELECT 'thresholds',row_to_json(x)::text FROM r410_thresholds x
 UNION ALL SELECT 'validation_mapping',row_to_json(x)::text FROM r410_validation_mapping x
;
