"""Verify global aggregate partitions and publish clean CSV / thin mapping.

Every strict T0 offer event is retained. Never add distinct-user counts across
risk/lifecycle cells: a user may have multiple events and different profiles.
"""
from pathlib import Path
from decimal import Decimal as D
import json
import numpy as np
import pandas as pd
W=Path(__file__).resolve().parent

def clean(x):
    if isinstance(x,dict):return {str(k):clean(v) for k,v in x.items()}
    if isinstance(x,(list,tuple)):return [clean(v) for v in x]
    if isinstance(x,D):return str(x)
    if isinstance(x,np.integer):return int(x)
    if isinstance(x,(np.floating,float)):return None if not np.isfinite(x) else float(x)
    if x is pd.NaT:return None
    if isinstance(x,pd.Timestamp):return x.isoformat()
    return x
def save(p,x):Path(p).write_text(json.dumps(clean(x),ensure_ascii=False,indent=2,allow_nan=False))
def dec(x):return D(0) if x is None or pd.isna(x) else D(str(x))
def rat(a,b):return float(a/b) if b else None

def main():
    ex=json.loads((W/'extraction_complete.json').read_text());assert ex['passed']
    cells_source=pd.read_pickle(W/'sources/cell.pkl.gz')
    # The frozen source file contains an older optional representative grain.
    # Current processing deliberately uses only the complete event grain,
    # matching the updated SQL without querying or refreshing any source.
    cells=cells_source.loc[cells_source.grain.eq('event')].copy()
    assert len(cells)>0
    assert cells.grain.eq('event').all()
    quality=pd.read_pickle(W/'sources/quality.pkl.gz').iloc[0].to_dict()
    th=pd.read_pickle(W/'sources/thresholds.pkl.gz').iloc[0].to_dict()
    exact_source=pd.read_pickle(W/'sources/exact_lifecycle.pkl.gz')
    exact=exact_source.loc[exact_source.grain.eq('event')].copy()
    mapping=pd.read_pickle(W/'sources/validation_mapping.pkl.gz')
    basekeys=['scope','grain','period','scenario','bucket']
    key=basekeys+['level','score_band','lifecycle_band']
    assert not cells.duplicated(key).any()
    assert quality['duplicate_events']==0
    assert quality['duplicate_first_order_assignments']==0
    assert quality['duplicate_financial_source_orders']==0
    assert quality['invalid_time_events']==0
    statuscols=['score_valid_events','score_conflict_events','score_invalid_events','score_no_record_events','score_null_events']
    assert sum(int(quality[k]) for k in statuscols)==int(quality['events'])
    rawcols=['score_null_rows','score_valid_rows','score_placeholder_rows','score_nonpositive_rows','score_above3000_rows','score_other_invalid_rows']
    assert sum(int(quality[k]) for k in rawcols)==int(quality['score_source_rows'])
    for col in ['principal','repaid','missing_repaid_principal']:
        cells[col]=cells[col].map(dec)
    additive=['event_count','first_apply_orders','funded_orders','mature_orders','principal','repaid',
              'missing_repaid_orders','missing_repaid_principal','state8_orders',*statuscols,'lifetime_unknown_events']
    ncheck=0
    for keys,g in cells.groupby(basekeys,dropna=False):
        a=g.loc[g.level.eq('overall')];assert len(a)==1
        overall=a.iloc[0]
        for level in ['joint','risk','lifecycle']:
            zz=g.loc[g.level.eq(level)]
            for c in additive:
                assert sum((dec(v) for v in zz[c]),D(0))==dec(overall[c]),(keys,level,c)
                ncheck+=1
    # Denominators are each stage's complete T0 event totals. Distinct users
    # are auxiliary and may reappear in different risk/lifecycle cells.
    over=cells.loc[cells.level.eq('overall'),basekeys+['event_count','users']].rename(columns={'event_count':'stage_event_denominator','users':'stage_user_denominator'})
    cells=cells.merge(over,on=basekeys,how='left',validate='many_to_one')
    cells['profit']=cells.repaid-cells.principal
    cells['profit_rate']=[rat(a,b) for a,b in zip(cells.profit,cells.principal)]
    cells['event_share_within_stage']=[rat(int(a),int(b)) for a,b in zip(cells.event_count,cells.stage_event_denominator)]
    cells['user_share_within_stage']=[rat(int(a),int(b)) for a,b in zip(cells.users,cells.stage_user_denominator)]
    cells['funded_conversion']=[rat(int(a),int(b)) for a,b in zip(cells.funded_orders,cells.first_apply_orders)]
    cells['included_orders']=cells.mature_orders
    cells['maturity_coverage']=[None if scope=='all_funded' else rat(int(a),int(b)) for scope,a,b in zip(cells.scope,cells.mature_orders,cells.funded_orders)]
    cells['avg_principal']=[rat(a,int(b)-int(missing)) for a,b,missing in zip(cells.principal,cells.mature_orders,cells.missing_repaid_orders)]
    cells['avg_loan_day']=[rat(dec(a),int(b)) for a,b in zip(cells.loan_day_sum,cells.loan_day_n)]
    cells['avg_recovery_age_days']=[rat(dec(a),int(b)) for a,b in zip(cells.recovery_age_sum,cells.recovery_age_n)]
    cells['score_missing_events']=cells[['score_conflict_events','score_invalid_events','score_no_record_events','score_null_events']].sum(axis=1)
    cells.to_csv(W/'cells.csv',index=False)
    for level,name in [('joint','joint_cells'),('risk','score_distribution'),('lifecycle','lifecycle_distribution'),('overall','overall')]:
        cells.loc[cells.level.eq(level)].to_csv(W/(name+'.csv'),index=False)
    exact.to_csv(W/'exact_lifecycle_counts.csv',index=False)
    for col in ['event_id','credit_serial_id','user_id','settled_serial_id','settled_loan_seq','score_source_rows','distinct_valid_scores']:
        mapping[col]=pd.array(mapping[col],dtype='Int64')
    mapping['vir_time']=pd.to_datetime(mapping.vir_time)
    mapping['score_time']=pd.to_datetime(mapping.score_time)
    assert mapping.event_id.is_unique
    requested=json.loads((W/'validation_requested_ids.json').read_text())
    wanted=set(map(int,requested['ids']));matched=set(map(int,mapping.event_id))
    missing=sorted(wanted-matched);extra=sorted(matched-wanted)
    assert not extra
    frozen=pd.read_parquet(W.parent/'t0_v4_validation_20261024_20261025/evaluation/labels_evaluated.parquet',columns=['event_id','user_id','as_of_time'])
    pair=mapping.merge(frozen,on='event_id',how='left',suffixes=('_current','_frozen'),validate='one_to_one')
    identity_bad=pair.user_id_current.ne(pair.user_id_frozen)
    assert not identity_bad.any(),'Current original-offer user differs from frozen prediction user.'
    time_bad=(pair.vir_time-pd.to_datetime(pair.as_of_time)).dt.total_seconds().abs().gt(1)
    mapping_parquet=W/'validation_mapping.parquet'
    mapping_csv=W/'validation_mapping.csv'
    if mapping_parquet.exists():
        # Parquet may restore string/null timestamp storage dtypes differently
        # across pandas versions; compare values while retaining the file.
        pd.testing.assert_frame_equal(mapping,pd.read_parquet(mapping_parquet),check_dtype=False)
    else:
        mapping.to_parquet(mapping_parquet,index=False)
    if not mapping_csv.exists():mapping.to_csv(mapping_csv,index=False)
    eventmain=cells.loc[cells.scope.eq('main')&cells.grain.eq('event')&cells.period.eq('ALL')&cells.bucket.eq('ALL')]
    bands=eventmain.loc[eventmain.level.eq('risk')]
    th.update({'cohort':'all complete-day strict T0 offer events; no application/funding/maturity filter',
      'quantile_definition':'empirical inverse CDF at ceil(0.5*N), ceil(0.8*N); original event-weighted scores, ties unsplit',
      'bands':{'HIGH20':'score >= q80','MID30':'q50 <= score < q80','LOW50':'score < q50'},
      'actual_band_events':{r.score_band:int(r.event_count) for r in bands.itertuples()},
      'actual_share_of_valid':{r.score_band:rat(int(r.event_count),int(th['valid_n'])) for r in bands.itertuples() if r.score_band in ['HIGH20','MID30','LOW50']},
      'score_validity':'historical analysis cleaning rule 1 through 3000, not verified official model card',
      'score_time_available':False})
    quality.update({'passed':True,'partition_checks':ncheck,'snapshot':ex['snapshot'],
      'validation_mapping_requested':len(wanted),'validation_mapping_matched':len(matched),
      'validation_mapping_missing_ids':missing,'validation_mapping_extra_ids':extra,
      'validation_identity_mismatch':int(identity_bad.sum()),'validation_time_diff_gt1s':int(time_bad.sum()),
      'score_field':'wangchuanliang.model_result_copy.kabybmerge410fpd7cre',
      'score_link':'original T0 credit_serial_id + user_id, unique valid score from current copy; never downstream application score',
      'score_time_caveat':'Source has no score creation/update/availability time. Earliest generation and historical availability cannot be proven.',
      'score_direction':'Higher score treated as lower observed risk, supported by historical descriptive data; formal model card unavailable',
      'lifecycle_rule':'trigger settled_serial_id rank in user funded-loan sequence ORDER BY remit_time, serial_id; not current total and not MAX prior rank',
      'analysis_grain':'event only: each strict, 20-second-deduplicated T0 offer is one event; retain all repeat events from the same user',
      'stage_denominator_rule':'Each timing stage uses its full T0 event count; score/lifecycle event shares sum to 100% including missing/invalid categories',
      'user_denominator_rule':'Distinct users are auxiliary and non-additive across score/lifecycle cells; no earliest-event representative selection is used',
      'offline_event_update':{'source_reused':True,'database_requeried':False,'model_rerun':False,
        'excluded_historical_grains':sorted(set(cells_source.grain)-{'event'}),
        'frozen_source_cell_rows':len(cells_source),'current_event_cell_rows':len(cells),
        'frozen_source_exact_rows':len(exact_source),'current_event_exact_rows':len(exact)},
      'profit_rule':'(SUM current repaid_amt - SUM remit_amt) / SUM remit_amt; only first application funded; due_date < stat date; no concessions/cost deduction; NULL not zero-filled',
      'files':{'cells':'cells.csv','mapping':'validation_mapping.parquet','thresholds':'thresholds.json'}})
    save(W/'thresholds.json',th);save(W/'quality.json',quality)
    save(W/'analysis.json',{'meta':ex['snapshot'],'quality':quality,'thresholds':th,
      'files':{name:str(W/(name+'.csv')) for name in ['cells','joint_cells','score_distribution','lifecycle_distribution','overall','exact_lifecycle_counts']}})
    print(json.dumps(clean({'phase':'risk410_lifecycle_ready','quality':quality,'thresholds':th,'cells':len(cells)}),ensure_ascii=False),flush=True)

if __name__=='__main__':main()
