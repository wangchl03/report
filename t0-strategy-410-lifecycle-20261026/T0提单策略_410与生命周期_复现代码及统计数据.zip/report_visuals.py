"""Small offline SVG charts and collapsed data tables for the strategy report."""
import html,math,json
esc=lambda v:html.escape(str(v),quote=True)
STAGES=['D0','D1','D2','D3','D4+']
STAGE_LABEL={'D0':'获额当天','D1':'次日','D2':'第2日','D3':'第3日','D4+':'第4日及以后','D1+':'次日及以后','D1-D3':'第1—3日','ALL':'全部','no_apply':'未观察到首提单','D4-D15':'第4—15日','D16+':'第16日及以后'}
RISK=['HIGH20','MID30','LOW50']
RISK_LABEL={'HIGH20':'高分前20%','MID30':'中间20%—50%','LOW50':'低分后50%','NO_RECORD':'无模型记录','NULL_SCORE':'410为空','INVALID':'超出历史有效范围','CONFLICT':'有效分冲突','UNKNOWN':'未分档','ALL':'全部'}
LIFE=['1','2','3','4','5','6-10','11-20','21+']
LIFE_LABEL={'1':'第1笔结清','2':'第2笔结清','3':'第3笔结清','4':'第4笔结清','5':'第5笔结清','6-10':'第6—10笔结清','11-20':'第11—20笔结清','21+':'第21笔及以上','UNKNOWN':'次数未知','ALL':'全部'}
def n(v):
 try:return float(v)
 except (TypeError,ValueError):return float('nan')
def fmt(v,kind='num'):
 x=n(v)
 if not math.isfinite(x):return '—'
 if kind=='pct':return f'{x*100:.2f}%'
 if kind=='int':return f'{x:,.0f}'
 if kind=='pp':return f'{x:+.2f}'
 return f'{x:,.2f}'
def section(key,title,body):return f'<section id="{key}"><h2>{esc(title)}</h2>{body}</section>'
def table(rows,cols,title='查看明细'):
 body=[]
 for r in rows:
  vals=[]
  for key,label,kind in cols:
   v=r.get(key)
   if kind=='text':
    if key=='bucket':v=STAGE_LABEL.get(v,v)
    if key=='score_band':v=RISK_LABEL.get(v,v)
    if key=='lifecycle_band':v=LIFE_LABEL.get(str(v),v)
    if key=='scope':v={'main':'1—10月完整日','jan_sep':'1—9月','recovery30':'到期至少30日','all_funded':'全部已放款含未到期'}.get(v,v)
    if key=='dimensions':v=str(v).replace('period','获额月份').replace('score_band','410分档').replace('lifecycle_band','结清序号档')
    if key=='population':v={'full8866':'完整8,866次评分','selected3701':'低pD3的3,701次候选'}.get(v,v)
    if key=='dimension':v={'risk':'410分档','life':'结清借款序号档'}.get(v,v)
    if key=='band':v=RISK_LABEL.get(str(v),LIFE_LABEL.get(str(v),v))
    s=esc('—' if v is None else v)
   else:s=fmt(v,kind)
   vals.append('<td'+(' class="negative"' if kind!='text' and n(v)<0 else '')+'>'+s+'</td>')
  body.append('<tr>'+''.join(vals)+'</tr>')
 return '<details><summary>'+esc(title)+f'（{len(rows):,}行）</summary><div class="scroll"><table><thead><tr>'+''.join('<th>'+esc(c[1])+'</th>' for c in cols)+'</tr></thead><tbody>'+''.join(body)+'</tbody></table></div></details>'
CHART_FINDINGS={}
def numbered(items):
 return '<ol class="numbered">'+''.join('<li>'+item+'</li>' for item in items)+'</ol>'
def figure(title,svg,note='',legend=''):
 conclusion=CHART_FINDINGS.get(title,'')
 finding='<p class="chart-conclusion">'+esc(conclusion)+'</p>' if conclusion else ''
 method='<details class="chart-method"><summary>查看图表口径</summary><p class="note">'+esc(note)+'</p></details>' if note else ''
 return '<div class="chart"><h3>'+esc(title)+'</h3>'+svg+legend+finding+method+'</div>'

def distribution(rows,group_key,groups,labels,title,note,stage_suffix=''):
 colors=['#61cbb3','#6aa8eb','#dfaf6b','#7d8598','#bd89d9','#de8491','#a9c66a','#7fc3d7','#b6a597']
 W,H=1120,435;left,right,top=140,50,55;bar=W-left-right
 svg=[f'<svg viewBox="0 0 {W} {H}" role="img" aria-label="{esc(title)}">']
 for j in range(6):
  x=left+bar*j/5;svg.append(f'<line x1="{x}" y1="40" x2="{x}" y2="390" stroke="#2b3c55"/><text x="{x}" y="25" text-anchor="middle" class="axis">{j*20}%</text>')
 for i,s in enumerate(STAGES):
  y=top+i*67;rr=[r for r in rows if r['bucket']==s];total=sum(n(r['event_count']) for r in rr)
  svg.append(f'<text x="{left-15}" y="{y+20}" text-anchor="end" class="axis">{STAGE_LABEL[s]}{esc(stage_suffix)}</text><text x="{left-15}" y="{y+38}" text-anchor="end" class="small">{fmt(total,"int")}次</text>')
  x=left
  for j,g in enumerate(groups):
   k=sum(n(r['event_count']) for r in rr if str(r[group_key])==g);share=k/total if total else 0;w=bar*share
   svg.append(f'<rect x="{x:.2f}" y="{y}" width="{w:.2f}" height="42" fill="{colors[j]}"/>')
   if share>=.045:svg.append(f'<text x="{x+w/2:.2f}" y="{y+26}" text-anchor="middle" font-size="14" font-weight="700" fill="#0b1729">{share:.1%}</text>')
   x+=w
 svg.append('</svg>')
 legend='<div class="legend">'+''.join(f'<span><i style="background:{colors[j]}"></i>{esc(labels[g])}</span>' for j,g in enumerate(groups))+'</div>'
 return figure(title,''.join(svg),note,legend)

def heatmap(rows,key,groups,labels,title,note):
 W=1120;rh=48;top=50;left=200;cw=170;H=top+rh*len(groups)+35
 lookup={(r['bucket'],str(r[key])):r for r in rows}
 vals=[n(r['profit_rate']) for r in rows if math.isfinite(n(r['profit_rate']))]
 lo=min(vals or [0]);hi=max(vals or [.1]);span=max(hi-lo,.01)
 svg=[f'<svg viewBox="0 0 {W} {H}" role="img" aria-label="{esc(title)}">']
 for j,s in enumerate(STAGES):svg.append(f'<text x="{left+j*cw+cw/2}" y="28" text-anchor="middle" class="axis">{STAGE_LABEL[s]}</text>')
 for i,g in enumerate(groups):
  y=top+i*rh;svg.append(f'<text x="{left-15}" y="{y+21}" text-anchor="end" class="axis">{esc(labels[g])}</text>')
  for j,s in enumerate(STAGES):
   r=lookup.get((s,g),{});v=n(r.get('profit_rate'));orders=n(r.get('mature_orders'));x=left+j*cw
   t=max(0,min(1,(v-lo)/span)) if math.isfinite(v) else 0
   color=f'rgb({int(103-65*t)},{int(53+64*t)},{int(69+57*t)})' if math.isfinite(v) else '#26344b'
   svg.append(f'<rect x="{x}" y="{y}" width="{cw-6}" height="{rh-4}" rx="5" fill="{color}"/><text x="{x+(cw-6)/2}" y="{y+19}" text-anchor="middle" class="value">{fmt(v,"pct")}</text><text x="{x+(cw-6)/2}" y="{y+36}" text-anchor="middle" class="small light">{fmt(orders,"int")}笔</text>')
 svg.append('</svg>')
 return figure(title,''.join(svg),note)

def profit_bars(rows,title,note):
 W,H=1120,390;left,right,top,bottom=90,30,45,70
 vals=[n(r['profit_rate']) for r in rows];lo=min([0]+[x for x in vals if math.isfinite(x)]);hi=max([.01]+[x for x in vals if math.isfinite(x)]);gap=max(hi-lo,.05);lo-=gap*.15 if lo<0 else 0;hi+=gap*.28
 y=lambda v:top+(hi-v)/(hi-lo)*(H-top-bottom)
 svg=[f'<svg viewBox="0 0 {W} {H}" role="img" aria-label="{esc(title)}">']
 for i in range(5):
  v=lo+(hi-lo)*i/4;yy=y(v);svg.append(f'<line x1="{left}" y1="{yy}" x2="{W-right}" y2="{yy}" stroke="#2b3c55"/><text x="{left-10}" y="{yy+4}" text-anchor="end" class="axis">{fmt(v,"pct")}</text>')
 sw=(W-left-right)/len(rows)
 for i,r in enumerate(rows):
  v=n(r['profit_rate']);x=left+sw*(i+.5);yy=y(v);z=y(0);c='#db966f' if r['bucket']=='D0' else '#65b4d8'
  svg.append(f'<rect x="{x-45}" y="{min(yy,z)}" width="90" height="{max(1,abs(yy-z))}" rx="4" fill="{c}"/><text x="{x}" y="{yy-10 if v>=0 else yy+20}" text-anchor="middle" class="value">{fmt(v,"pct")}</text><text x="{x}" y="{H-38}" text-anchor="middle" class="axis">{STAGE_LABEL[r["bucket"]]}</text><text x="{x}" y="{H-15}" text-anchor="middle" class="small">{fmt(r["mature_orders"],"int")}笔</text>')
 svg.append('</svg>');return figure(title,''.join(svg),note)

CSS='''*{box-sizing:border-box}html{scroll-behavior:smooth;scroll-padding-top:100px}body{margin:0;background:#0b1424;color:#e3ecf8;font:15px/1.8 -apple-system,BlinkMacSystemFont,"PingFang SC","Microsoft YaHei",Arial,sans-serif}header{text-align:center;padding:44px 22px 30px;background:linear-gradient(140deg,#192b47,#0b1424)}h1{font-size:30px;margin:0 0 10px}header p,.note{color:#a7b9d0;font-size:13px}nav{position:sticky;top:0;z-index:30;display:flex;justify-content:center;flex-wrap:wrap;gap:7px 20px;padding:13px;background:#102039fa;border-bottom:1px solid #334a65}a{color:#89d4f4;text-decoration:none}a:hover{text-decoration:underline}main{max-width:1400px;margin:auto;padding:0 24px 50px}section{margin-top:24px;padding:26px;background:#101e33;border:1px solid #2c415c;border-radius:12px}h2{font-size:23px;margin:0 0 20px}h3{font-size:17px;margin:0 0 13px}.cards{display:grid;grid-template-columns:repeat(4,1fr);gap:14px}.cards>div,.grid>div{background:#142640;padding:16px;border:1px solid #344e6b;border-radius:8px}.cards span,.cards small{display:block;color:#b7c8dc}.cards strong{display:block;font-size:29px;line-height:1.3;color:#82d4ed;margin:4px 0 5px}.grid{display:grid;grid-template-columns:1fr 1fr;gap:14px}.finding,.callout{padding:13px 18px;background:#162d49;border-left:4px solid #71c5e7;border-radius:6px;margin:16px 0}.finding{background:#14253c;border-left-width:3px}.chart{padding:20px;background:#0d192b;border:1px solid #2f4561;border-radius:9px;margin:20px 0}svg{display:block;width:100%;height:auto}.axis{font-size:14px;fill:#b8cbe3}.value{font-size:16px;fill:#f0f5ff;font-weight:650}.small{font-size:11px;fill:#a2b7d1}.light{fill:#d4e0f1}.legend{display:flex;justify-content:center;gap:13px 24px;flex-wrap:wrap;font-size:13px}.legend i{display:inline-block;width:12px;height:12px;margin-right:6px;border-radius:2px}details{margin:15px 0;padding:0 15px;background:#0d1b2e;border:1px solid #2b4361;border-radius:7px}summary{cursor:pointer;padding:13px 0;color:#bfd7f0}.scroll{overflow:auto;max-height:650px}table{width:100%;border-collapse:collapse;white-space:nowrap;font-size:13px}td,th{padding:10px 13px;text-align:right;border-bottom:1px solid #293e59}th{position:sticky;top:0;background:#1b3350;color:#e1edfa;z-index:1}td:first-child,th:first-child{text-align:left}.negative{color:#ff949b}.positive{color:#7bddb4}pre{overflow:auto;max-height:520px;background:#081222;padding:16px;font:12px/1.6 ui-monospace,SFMono-Regular,Consolas,monospace}li{margin:9px 0}footer{text-align:center;padding:24px;color:#93a9c5}.formula{font:14px/2 ui-monospace,Consolas,monospace;padding:15px 20px;background:#172e4a;border-radius:7px}@media(max-width:900px){.cards,.grid{grid-template-columns:1fr 1fr}main{padding:0 12px 35px}section{padding:18px}h1{font-size:25px}.chart{padding:12px}}@media(max-width:560px){.cards,.grid{grid-template-columns:1fr}}'''

CSS += """.numbered{counter-reset:point;list-style:none;padding:0;margin:16px 0}.numbered>li{counter-increment:point;position:relative;padding:10px 12px 10px 38px;margin:5px 0;background:#14253c;border-radius:6px}.numbered>li::before{content:counter(point) "、";position:absolute;left:12px;color:#82d4ed;font-weight:700}.chart-conclusion{margin:14px 0 0;padding:11px 14px;background:#153049;border-left:3px solid #71c5e7;border-radius:5px;color:#e4f2ff}.chart-method{margin:12px 0 0}.chart-method .note{margin:0 0 12px}"""
