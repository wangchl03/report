"""Global strict T0 / 410 / settled-loan-sequence aggregation, read only.

Thresholds use all complete-day T0 events with one valid original-offer score.
The model-result copy has no score timestamp: no false historical PIT claim.
Every strict T0 offer is retained as one event. No per-user representative
selection is applied; a user can contribute multiple events in a stage.
"""
from pathlib import Path
import sys,json,time
import pandas as pd
W=Path(__file__).resolve().parent
sys.path.insert(0,str(W.parent/'t0_v4_validation_20261024_20261025'))
from run_common import connect,fetch,save_json,digest,repair_json
from profit_query import make_query

def build_query(cutoff,validation_ids):
    raw=make_query(0).replace(' AND MOD(v.user_id,4)=0','')
    raw=raw.replace("CURRENT_TIMESTAMP AT TIME ZONE 'America/Belize'", "TIMESTAMP '"+cutoff+"'")
    # The full original CTEs remain available for deterministic lifecycle ranks.
    at=raw.index('\nSELECT user_id,credit_serial_id')
    q=raw[:at]+''',
 r410_events AS (
 SELECT * FROM application_ranked WHERE apply_rn=1 AND vir_date<data_cutoff_ts::date
 ), r410_fundseq AS (
 SELECT o.*,ROW_NUMBER() OVER(PARTITION BY user_id ORDER BY remit_time,serial_id) AS settled_loan_seq,
   SUM(CASE WHEN remit_time IS NULL OR remit_time<=TIMESTAMP '2000-01-01' THEN 1 ELSE 0 END)
      OVER(PARTITION BY user_id) AS history_bad_remit_clock_n
 FROM funded_orders o
 ), r410_model AS (
 SELECT m.user_id,m.serial_id,COUNT(*) AS score_source_rows,
   COUNT(DISTINCT CASE WHEN m.kabybmerge410fpd7cre BETWEEN 1 AND 3000 THEN m.kabybmerge410fpd7cre END) AS distinct_valid_scores,
   CASE WHEN COUNT(DISTINCT CASE WHEN m.kabybmerge410fpd7cre BETWEEN 1 AND 3000 THEN m.kabybmerge410fpd7cre END)=1
     THEN MIN(CASE WHEN m.kabybmerge410fpd7cre BETWEEN 1 AND 3000 THEN m.kabybmerge410fpd7cre END) END AS score_410,
   SUM(CASE WHEN m.kabybmerge410fpd7cre IS NULL THEN 1 ELSE 0 END) AS score_null_rows,
   SUM(CASE WHEN m.kabybmerge410fpd7cre BETWEEN 1 AND 3000 THEN 1 ELSE 0 END) AS score_valid_rows,
   SUM(CASE WHEN m.kabybmerge410fpd7cre=-9999999 THEN 1 ELSE 0 END) AS score_placeholder_rows,
   SUM(CASE WHEN m.kabybmerge410fpd7cre<=0 AND m.kabybmerge410fpd7cre<>-9999999 THEN 1 ELSE 0 END) AS score_nonpositive_rows,
   SUM(CASE WHEN m.kabybmerge410fpd7cre>3000 THEN 1 ELSE 0 END) AS score_above3000_rows,
   SUM(CASE WHEN m.kabybmerge410fpd7cre IS NOT NULL AND NOT(m.kabybmerge410fpd7cre BETWEEN 1 AND 3000)
        AND m.kabybmerge410fpd7cre<>-9999999 AND NOT(m.kabybmerge410fpd7cre<=0) AND NOT(m.kabybmerge410fpd7cre>3000)
       THEN 1 ELSE 0 END) AS score_other_invalid_rows
 FROM wangchuanliang.model_result_copy m
 WHERE EXISTS(SELECT 1 FROM r410_events e WHERE e.user_id=m.user_id AND e.credit_serial_id=m.serial_id)
 GROUP BY m.user_id,m.serial_id
 ), r410_profiles_unbinned AS (
 SELECT e.*,m.score_410,m.score_source_rows,m.distinct_valid_scores,
   COALESCE(m.score_null_rows,0) AS score_null_rows,COALESCE(m.score_valid_rows,0) AS score_valid_rows,
   COALESCE(m.score_placeholder_rows,0) AS score_placeholder_rows,
   COALESCE(m.score_nonpositive_rows,0) AS score_nonpositive_rows,
   COALESCE(m.score_above3000_rows,0) AS score_above3000_rows,
   COALESCE(m.score_other_invalid_rows,0) AS score_other_invalid_rows,
   CASE WHEN m.serial_id IS NULL THEN 'NO_RECORD'
        WHEN m.distinct_valid_scores>1 THEN 'CONFLICT'
        WHEN m.distinct_valid_scores=1 THEN 'VALID'
        WHEN m.score_null_rows=m.score_source_rows THEN 'NULL_SCORE' ELSE 'INVALID' END AS score_status,
   CASE WHEN s.history_bad_remit_clock_n=0 AND s.remit_time<=e.clean_settle_time
             AND s.remit_time<=e.vir_time THEN s.settled_loan_seq END AS settled_loan_seq,
   CASE WHEN s.serial_id IS NULL THEN 'SETTLED_ORDER_UNMATCHED'
        WHEN s.history_bad_remit_clock_n>0 THEN 'HISTORY_REMIT_CLOCK_MISSING'
        WHEN s.remit_time>e.clean_settle_time OR s.remit_time>e.vir_time THEN 'INVALID_CHRONOLOGY'
        ELSE 'VALID' END AS sequence_status,
   s.history_bad_remit_clock_n,
   e.apply_time::date-e.vir_date AS apply_day,
   CASE WHEN e.is_remit=1 AND e.remit_amt>0 THEN 1 ELSE 0 END AS funded,
   e.data_cutoff_ts::date-e.due_date AS recovery_age_days
 FROM r410_events e LEFT JOIN r410_model m
   ON m.user_id=e.user_id AND m.serial_id=e.credit_serial_id
 LEFT JOIN r410_fundseq s ON s.user_id=e.user_id AND s.serial_id=e.settled_serial_id
 ), r410_ordered_scores AS (
 SELECT score_410,ROW_NUMBER() OVER(ORDER BY score_410) AS score_rn,COUNT(*) OVER() AS valid_n
 FROM r410_profiles_unbinned WHERE score_status='VALID'
 ), r410_thresholds AS (
 SELECT MAX(valid_n) AS valid_n,
   MIN(CASE WHEN score_rn>=CEIL(valid_n*0.5) THEN score_410 END) AS q50,
   MIN(CASE WHEN score_rn>=CEIL(valid_n*0.8) THEN score_410 END) AS q80
 FROM r410_ordered_scores
 ), r410_profiles AS (
 SELECT e.*,
   CASE WHEN score_status<>'VALID' THEN score_status
        WHEN score_410>=t.q80 THEN 'HIGH20'
        WHEN score_410>=t.q50 THEN 'MID30' ELSE 'LOW50' END AS score_band,
   CASE WHEN settled_loan_seq IS NULL THEN 'UNKNOWN'
        WHEN settled_loan_seq BETWEEN 1 AND 5 THEN settled_loan_seq::text
        WHEN settled_loan_seq BETWEEN 6 AND 10 THEN '6-10'
        WHEN settled_loan_seq BETWEEN 11 AND 20 THEN '11-20' ELSE '21+' END AS lifecycle_band
 FROM r410_profiles_unbinned e CROSS JOIN r410_thresholds t
 ), r410_bucket_defs AS (
 SELECT 'D0'::text AS bucket UNION ALL SELECT 'D1' UNION ALL SELECT 'D2'
 UNION ALL SELECT 'D3' UNION ALL SELECT 'D4+' UNION ALL SELECT 'D4-D15'
 UNION ALL SELECT 'D16+' UNION ALL SELECT 'D1-D3' UNION ALL SELECT 'D1+'
 UNION ALL SELECT 'ALL' UNION ALL SELECT 'no_apply'
 ), r410_staged AS (
 SELECT e.*,b.bucket
 FROM r410_profiles e CROSS JOIN r410_bucket_defs b
 WHERE b.bucket='ALL' OR (b.bucket='no_apply' AND apply_serial_id IS NULL)
    OR (b.bucket='D0' AND apply_day=0) OR (b.bucket='D1' AND apply_day=1)
    OR (b.bucket='D2' AND apply_day=2) OR (b.bucket='D3' AND apply_day=3)
    OR (b.bucket='D4+' AND apply_day>=4) OR (b.bucket='D4-D15' AND apply_day BETWEEN 4 AND 15)
    OR (b.bucket='D16+' AND apply_day>=16) OR (b.bucket='D1-D3' AND apply_day BETWEEN 1 AND 3)
    OR (b.bucket='D1+' AND apply_day>=1)
 ), r410_grained AS (
 SELECT e.*,'event'::text AS grain FROM r410_staged e
 ), r410_scopes AS (
 SELECT 'main'::text AS scope,'mature_complete_days'::text AS scenario
 UNION ALL SELECT 'jan_sep','mature_complete_days'
 UNION ALL SELECT 'recovery30','mature_30d'
 UNION ALL SELECT 'all_funded','all_funded'
 ), r410_scoped AS (
 SELECT e.*,s.scope,s.scenario,
   CASE WHEN funded=1 AND ((s.scenario='all_funded')
     OR (s.scenario='mature_complete_days' AND due_date>=DATE '2000-01-01' AND due_date<data_cutoff_ts::date)
     OR (s.scenario='mature_30d' AND due_date>=DATE '2000-01-01' AND recovery_age_days>=30)) THEN 1 ELSE 0 END AS eligible
 FROM r410_grained e CROSS JOIN r410_scopes s
 WHERE s.scope<>'jan_sep' OR vir_date<DATE '2026-10-01'
 ), r410_periods AS (
 SELECT e.*,'ALL'::text AS period FROM r410_scoped e
 UNION ALL SELECT e.*,TO_CHAR(vir_date,'YYYY-MM') FROM r410_scoped e WHERE scope='main'
 ), r410_cells AS (
 SELECT scope,grain,period,scenario,bucket,
   CASE WHEN GROUPING(score_band)=0 AND GROUPING(lifecycle_band)=0 THEN 'joint'
        WHEN GROUPING(score_band)=0 THEN 'risk' WHEN GROUPING(lifecycle_band)=0 THEN 'lifecycle'
        ELSE 'overall' END AS level,
   CASE WHEN GROUPING(score_band)=1 THEN 'ALL' ELSE score_band END AS score_band,
   CASE WHEN GROUPING(lifecycle_band)=1 THEN 'ALL' ELSE lifecycle_band END AS lifecycle_band,
   COUNT(*) AS event_count,COUNT(DISTINCT user_id) AS users,COUNT(apply_serial_id) AS first_apply_orders,
   SUM(funded) AS funded_orders,SUM(eligible) AS mature_orders,
   SUM(CASE WHEN eligible=1 AND repaid_amt IS NOT NULL THEN remit_amt ELSE 0 END) AS principal,
   SUM(CASE WHEN eligible=1 AND repaid_amt IS NOT NULL THEN repaid_amt ELSE 0 END) AS repaid,
   SUM(CASE WHEN eligible=1 AND repaid_amt IS NULL THEN 1 ELSE 0 END) AS missing_repaid_orders,
   SUM(CASE WHEN eligible=1 AND repaid_amt IS NULL THEN remit_amt ELSE 0 END) AS missing_repaid_principal,
   SUM(CASE WHEN eligible=1 AND loan_status_code=8 THEN 1 ELSE 0 END) AS state8_orders,
   SUM(CASE WHEN score_status='VALID' THEN 1 ELSE 0 END) AS score_valid_events,
   SUM(CASE WHEN score_status='CONFLICT' THEN 1 ELSE 0 END) AS score_conflict_events,
   SUM(CASE WHEN score_status='INVALID' THEN 1 ELSE 0 END) AS score_invalid_events,
   SUM(CASE WHEN score_status='NO_RECORD' THEN 1 ELSE 0 END) AS score_no_record_events,
   SUM(CASE WHEN score_status='NULL_SCORE' THEN 1 ELSE 0 END) AS score_null_events,
   SUM(CASE WHEN sequence_status<>'VALID' THEN 1 ELSE 0 END) AS lifetime_unknown_events,
   SUM(CASE WHEN eligible=1 AND loan_day IS NOT NULL THEN loan_day ELSE 0 END) AS loan_day_sum,
   SUM(CASE WHEN eligible=1 AND loan_day IS NOT NULL THEN 1 ELSE 0 END) AS loan_day_n,
   SUM(CASE WHEN eligible=1 AND recovery_age_days IS NOT NULL THEN recovery_age_days ELSE 0 END) AS recovery_age_sum,
   SUM(CASE WHEN eligible=1 AND recovery_age_days IS NOT NULL THEN 1 ELSE 0 END) AS recovery_age_n
 FROM r410_periods
 GROUP BY GROUPING SETS (
  (scope,grain,period,scenario,bucket,score_band,lifecycle_band),
  (scope,grain,period,scenario,bucket,score_band),
  (scope,grain,period,scenario,bucket,lifecycle_band),
  (scope,grain,period,scenario,bucket))
 ), r410_exact_lifetime AS (
 SELECT grain,bucket,settled_loan_seq,COUNT(*) AS event_count,COUNT(DISTINCT user_id) AS users,
   SUM(funded) AS funded_orders,
   SUM(CASE WHEN funded=1 AND due_date>=DATE '2000-01-01' AND due_date<data_cutoff_ts::date THEN 1 ELSE 0 END) AS mature_orders
 FROM r410_grained GROUP BY grain,bucket,settled_loan_seq
 ), r410_quality AS (
 SELECT COUNT(*) AS events,COUNT(DISTINCT user_id) AS users,
   COUNT(*)-COUNT(DISTINCT user_id::text||':'||credit_serial_id::text) AS duplicate_events,
   COUNT(apply_serial_id)-COUNT(DISTINCT CASE WHEN apply_serial_id IS NOT NULL THEN user_id::text||':'||apply_serial_id::text END) AS duplicate_first_order_assignments,
   SUM(CASE WHEN source_order_rows>1 THEN 1 ELSE 0 END) AS duplicate_financial_source_orders,
   SUM(CASE WHEN clean_settle_time>vir_time OR vir_time::date<>vir_date OR apply_time<vir_time OR apply_time>=next_t0_time OR apply_time>=data_cutoff_ts THEN 1 ELSE 0 END) AS invalid_time_events,
   SUM(CASE WHEN score_status='VALID' THEN 1 ELSE 0 END) AS score_valid_events,
   SUM(CASE WHEN score_status='CONFLICT' THEN 1 ELSE 0 END) AS score_conflict_events,
   SUM(CASE WHEN score_status='INVALID' THEN 1 ELSE 0 END) AS score_invalid_events,
   SUM(CASE WHEN score_status='NO_RECORD' THEN 1 ELSE 0 END) AS score_no_record_events,
   SUM(CASE WHEN score_status='NULL_SCORE' THEN 1 ELSE 0 END) AS score_null_events,
   SUM(COALESCE(score_source_rows,0)) AS score_source_rows,
   SUM(score_null_rows) AS score_null_rows,SUM(score_valid_rows) AS score_valid_rows,
   SUM(score_placeholder_rows) AS score_placeholder_rows,SUM(score_nonpositive_rows) AS score_nonpositive_rows,
   SUM(score_above3000_rows) AS score_above3000_rows,SUM(score_other_invalid_rows) AS score_other_invalid_rows,
   SUM(CASE WHEN score_source_rows>1 THEN 1 ELSE 0 END) AS model_duplicate_row_events,
   SUM(CASE WHEN score_status='VALID' AND (score_placeholder_rows+score_nonpositive_rows+score_above3000_rows+score_other_invalid_rows)>0 THEN 1 ELSE 0 END) AS valid_with_invalid_companion_events,
   SUM(CASE WHEN sequence_status<>'VALID' THEN 1 ELSE 0 END) AS lifetime_unknown_events,
   MIN(settled_loan_seq) AS min_settled_loan_seq,MAX(settled_loan_seq) AS max_settled_loan_seq,
   MIN(vir_date) AS first_event_date,MAX(vir_date) AS last_event_date,
   MAX(data_cutoff_ts) AS observation_cutoff
 FROM r410_profiles
 ), r410_validation_mapping AS (
 SELECT credit_serial_id AS event_id,credit_serial_id,user_id,vir_time,TO_CHAR(vir_date,'YYYY-MM') AS month,
   score_410,score_status,score_band,NULL::timestamp AS score_time,
   settled_serial_id,settled_loan_seq,lifecycle_band,sequence_status,score_source_rows,distinct_valid_scores
 FROM r410_profiles WHERE credit_serial_id IN (''' + ','.join(map(str,validation_ids))+''')
 )
 SELECT 'cell'::text AS record_type,row_to_json(x)::text AS payload FROM r410_cells x
 UNION ALL SELECT 'exact_lifecycle',row_to_json(x)::text FROM r410_exact_lifetime x
 UNION ALL SELECT 'quality',row_to_json(x)::text FROM r410_quality x
 UNION ALL SELECT 'thresholds',row_to_json(x)::text FROM r410_thresholds x
 UNION ALL SELECT 'validation_mapping',row_to_json(x)::text FROM r410_validation_mapping x
'''
    return q

def main():
    conn=connect();at=time.monotonic()
    try:
        with conn.cursor() as q:
            q.execute('SET statement_timeout=1800000')
            q.execute("SET work_mem='128MB'")
            q.execute("SELECT CURRENT_TIMESTAMP AT TIME ZONE 'America/Belize',CURRENT_DATE,CURRENT_TIMESTAMP AT TIME ZONE 'Asia/Shanghai',current_setting('transaction_read_only')")
            meta=dict(zip(['snapshot_belize','business_stat_date','snapshot_beijing','transaction_read_only'],q.fetchone()))
        assert meta['transaction_read_only']=='on'
        save_json(W/'snapshot.json',meta)
        labels=pd.read_parquet(W.parent/'t0_v4_validation_20261024_20261025/evaluation/labels_evaluated.parquet')
        use=labels.as_of_time.ge(pd.Timestamp('2026-10-09')) & labels.as_of_time.lt(pd.Timestamp('2026-10-22')) & labels.p_v4_d3.notna()
        ids=labels.loc[use,'event_id'].astype(int).tolist()
        assert len(ids)==len(set(ids));assert len(ids)==8866
        save_json(W/'validation_requested_ids.json',{'event_count':len(ids),'ids':ids})
        coverage_sql=(W.parent/'t0_offer_strategy_20261025/profit_sql/source_coverage.sql').read_text().strip().rstrip(';')
        coverage=fetch(conn,coverage_sql,label='risk410_source_coverage')
        coverage.to_csv(W/'sources/source_coverage.csv',index=False)
        sql=build_query(str(meta['snapshot_belize']),ids)
        (W/'sql/strict_t0_risk410_lifecycle_global.sql').write_text(sql+';\n')
        print(json.dumps({'phase':'global_query_started','validation_mapping_requested':len(ids),'meta':meta},default=str),flush=True)
        frame=fetch(conn,sql,label='global_t0_410_lifecycle_cells_and_mapping')
        frame.to_pickle(W/'sources/global_records.pkl.gz',compression='gzip')
        for kind,g in frame.groupby('record_type'):
            df=pd.DataFrame([repair_json(x) for x in g.payload],dtype=object)
            df.to_pickle(W/f'sources/{kind}.pkl.gz',compression='gzip')
            print(json.dumps({'phase':'section_ready','section':kind,'rows':len(df)}),flush=True)
        save_json(W/'extraction_complete.json',{'passed':True,'snapshot':meta,'rows':len(frame),
          'sections':frame.record_type.value_counts().to_dict(),'seconds':round(time.monotonic()-at,2),
          'sha256':digest(W/'sources/global_records.pkl.gz'),'cutoff_explicitly_frozen':True,
          'readonly':True,'single_global_query':True,'score_time_available':False})
        conn.rollback()
    finally:conn.close()

if __name__=='__main__':main()
