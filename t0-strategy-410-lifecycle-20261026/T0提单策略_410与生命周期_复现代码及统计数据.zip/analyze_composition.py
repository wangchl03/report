"""Descriptive fixed-weight comparisons of T0 timing cohorts.

This is standardization of observed book profit, not a treatment-effect model.
All cell weights use the same pooled D0+delayed principal distribution.
"""
from pathlib import Path
from decimal import Decimal
import json, math
import pandas as pd

ROOT=Path(__file__).resolve().parent
VALID_BANDS=['HIGH20','MID30','LOW50']
LIFE=['1','2','3','4','5','6-10','11-20','21+']
def js(v):
    if isinstance(v,dict):return {str(k):js(x) for k,x in v.items()}
    if isinstance(v,(tuple,list)):return [js(x) for x in v]
    if isinstance(v,Decimal):return str(v)
    if pd.isna(v):return None
    if hasattr(v,'item'):return js(v.item())
    return v
def total(s):return sum((Decimal(str(v)) for v in s if pd.notna(v)),Decimal(0))

def standardized(df,scope,delayed,keys,min_orders=30):
    selected_scope='main' if scope=='jan_sep' and 'period' in keys else scope
    grain=df[df.scope.eq(selected_scope)&df.grain.eq('event')&df.bucket.isin(['D0',delayed])]
    if scope=='jan_sep' and 'period' in keys:
        grain=grain[grain.period.between('2026-01','2026-09')]
    if 'period' in keys and not (~grain.period.eq('ALL')).any():
        return {'scope':scope,'delayed':delayed,'dimensions':keys,'min_orders_each_cell':min_orders,
                'cells':None,'estimable':False,'unavailable_reason':'Monthly cells were not extracted for this maturity scope; no zero-support inference.'}
    if keys==['score_band']:
        grain=grain[grain.level.eq('risk')&grain.period.eq('ALL')&grain.score_band.isin(VALID_BANDS)]
    elif keys==['lifecycle_band']:
        grain=grain[grain.level.eq('lifecycle')&grain.period.eq('ALL')&grain.lifecycle_band.isin(LIFE)]
    else:
        grain=grain[grain.level.eq('joint')&grain.score_band.isin(VALID_BANDS)&grain.lifecycle_band.isin(LIFE)]
        grain=grain[~grain.period.eq('ALL') if 'period' in keys else grain.period.eq('ALL')]
    a=grain[grain.bucket.eq('D0')].set_index(keys)
    b=grain[grain.bucket.eq(delayed)].set_index(keys)
    assert not a.index.duplicated().any() and not b.index.duplicated().any()
    shared=a.index.intersection(b.index)
    valid=[k for k in shared if float(a.loc[k,'principal'])>0 and float(b.loc[k,'principal'])>0
           and int(a.loc[k,'mature_orders'])>=min_orders and int(b.loc[k,'mature_orders'])>=min_orders]
    full={x:{'principal':total(grain[grain.bucket.eq(x)].principal),'profit':total(grain[grain.bucket.eq(x)].profit),'orders':int(grain[grain.bucket.eq(x)].mature_orders.sum())} for x in ['D0',delayed]}
    if not valid:return {'scope':scope,'delayed':delayed,'dimensions':keys,'min_orders_each_cell':min_orders,'cells':0,'estimable':False}
    aa=a.loc[valid];bb=b.loc[valid]
    pa=aa.principal.astype(float).to_numpy();pb=bb.principal.astype(float).to_numpy()
    ra=aa.profit.astype(float).to_numpy()/pa;rb=bb.profit.astype(float).to_numpy()/pb
    weights=(pa+pb)/(pa+pb).sum()
    pointa=float((weights*ra).sum());pointb=float((weights*rb).sum())
    out={'scope':scope,'delayed':delayed,'dimensions':keys,'min_orders_each_cell':min_orders,'cells':len(valid),'estimable':True,
         'D0_standardized_profit_rate':pointa,'delayed_standardized_profit_rate':pointb,'delayed_minus_D0_pp':100*(pointb-pointa),
         'weight_method':'same pooled principal weights on common cells; no causal effect or remaining-unmeasured-confounder adjustment',
         'D0_common_principal':float(pa.sum()),'delayed_common_principal':float(pb.sum()),
         'D0_common_raw_profit_rate':float(aa.profit.astype(float).sum()/pa.sum()),
         'delayed_common_raw_profit_rate':float(bb.profit.astype(float).sum()/pb.sum()),
         'D0_principal_coverage':float(pa.sum()/float(full['D0']['principal'])) if full['D0']['principal'] else None,
         'delayed_principal_coverage':float(pb.sum()/float(full[delayed]['principal'])) if full[delayed]['principal'] else None,
         'D0_common_orders':int(aa.mature_orders.sum()),'delayed_common_orders':int(bb.mature_orders.sum()),
         'coverage_denominator':'same dimensions valid-score/known-lifecycle sample before minimum-cell restriction; not all T0',
         'cell_weights':[{**dict(zip(keys,(k if isinstance(k,tuple) else (k,)))),'weight':float(w),'D0_orders':int(a.loc[k,'mature_orders']),'delayed_orders':int(b.loc[k,'mature_orders'])} for k,w in zip(valid,weights)]}
    return out

def main():
    df=pd.read_csv(ROOT/'cells.csv',dtype={'period':'string','lifecycle_band':'string','score_band':'string','principal':'string','repaid':'string','profit':'string'})
    results=[]
    for scope in ['main','jan_sep','recovery30']:
      for delayed in ['D1+','D4+']:
        for dims in [['score_band'],['lifecycle_band'],['score_band','lifecycle_band'],['period','score_band','lifecycle_band']]:
            results.append(standardized(df,scope,delayed,dims))
    summary={
      'method':'common-support descriptive standardization, no treatment effect; same D0 and delayed weights',
      'predeclared_min_orders_per_arm_cell':30,
      'results':results,
      'warnings':['Financing and maturity are post-offer selections; results conditional on funded/overdue-date-complete first applications.',
                  'User lifecycle is the settled order successful funding sequence at this T0, never current lifetime total.',
                  'Percentile cuts fixed on all complete-day valid-score T0 offer events; ties are not split.',
                  'Coverage is conditional on observed valid dimensions. Missing-score users are separately reported, not reallocated.']}
    (ROOT/'composition_analysis.json').write_text(json.dumps(js(summary),ensure_ascii=False,indent=2,allow_nan=False))
    flat=[{k:v for k,v in x.items() if k!='cell_weights'} for x in results]
    for x in flat:x['dimensions']=' + '.join(x['dimensions'])
    pd.DataFrame(flat).to_csv(ROOT/'composition_standardized.csv',index=False)
    print(json.dumps({'comparisons':len(results),'estimable':sum(x['estimable'] for x in results)},ensure_ascii=False))

if __name__=='__main__':main()
