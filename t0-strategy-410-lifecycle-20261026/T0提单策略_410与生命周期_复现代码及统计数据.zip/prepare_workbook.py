"""Create typed spreadsheet input from the verified report aggregates."""
from pathlib import Path
import json,math
import pandas as pd
from report_visuals import STAGES,RISK_LABEL,LIFE_LABEL,STAGE_LABEL
W=Path(__file__).resolve().parent
df=pd.read_csv(W/'cells.csv',dtype={'period':'str','lifecycle_band':'str'})
p=json.loads((W/'prediction_profiles.json').read_text())
s=json.loads((W/'composition_analysis.json').read_text())
th=json.loads((W/'thresholds.json').read_text());q=json.loads((W/'quality.json').read_text())
def rec(mask):return df.loc[mask].to_dict('records')
def label(r):
 r=dict(r)
 for k,mp in [('bucket',STAGE_LABEL),('score_band',RISK_LABEL),('lifecycle_band',LIFE_LABEL),('scope',{'main':'1—10月完整日','jan_sep':'1—9月','recovery30':'到期至少30日','all_funded':'全部已放款含未到期'}),('grain',{'event':'T0事件'}),('level',{'risk':'410分档','lifecycle':'生命周期','overall':'总体','joint':'410与生命周期联合'})]:
  if k in r:r[k]=mp.get(str(r[k]),r[k])
 return r
base=(df.scope=='main')&(df.period=='ALL')&(df.grain=='event')&df.bucket.isin(STAGES+['D1+'])
eventcols=[('bucket','首次提单阶段','text'),('event_count','T0首次提单事件数','int'),('stage_event_denominator','该阶段全部T0首次提单事件','int'),('event_share_within_stage','占该阶段全部首次提单事件','pct'),('funded_orders','对应首单放款数','int'),('mature_orders','对应首单到期数','int'),('principal','对应到期首单本金','amount'),('repaid','对应首单当前回款','amount'),('profit','对应首单账面盈利','amount'),('profit_rate','对应到期首单盈利率','pct')]
profitcols=[('scope','时期或观察口径','text'),('period','获额月份','text'),('level','分析维度','text'),('bucket','首次提单阶段','text'),('score_band','410分档','text'),('lifecycle_band','上笔结清放款序号档','text'),('event_count','获额事件数','int'),('users','单格去重用户数不可加总','int'),('first_apply_orders','首次提单订单','int'),('funded_orders','首提单放款数','int'),('mature_orders','本口径纳入订单','int'),('maturity_coverage','纳入订单占放款','pct'),('principal','纳入订单本金','amount'),('repaid','当前repaid_amt合计','amount'),('profit','账面盈利金额','amount'),('profit_rate','金额加权盈利率','pct'),('state8_orders','当前状态8订单数','int'),('missing_repaid_orders','回款字段缺失订单','int'),('avg_principal','平均放款本金','amount'),('avg_loan_day','平均合同天数','num'),('avg_recovery_age_days','平均到期后天数','num')]
std=[]
for r in s['results']:
 x=dict(r);x['dimensions']='＋'.join(x['dimensions']);x['status_label']='可估计' if x['estimable'] else ('未提取月度格，未计算' if x.get('unavailable_reason') else '共同样本不足');std.append(label(x))
rules=[]
for key,title in [('rules','完整8,866评分母集'),('rules_main_evaluable','主8,717可评母集')]:
 for r in p[key]:rules.append({**r,'population_label':title})
modelcols=[('population_label','检验母集','text'),('name','低pD3候选规则','text'),('all_candidates','筛中全部候选事件','int'),('all_candidate_users','筛中候选用户','int'),('known_d0','D0已知候选','int'),('unknown_d0','D0未知候选','int'),('no_d0','D0未提单候选','int'),('d0_apply','D0提单候选','int'),('ppv_no_d0','D0未提单命中率','pct'),('ci95_low','命中率95%下界','pct'),('ci95_high','命中率95%上界','pct'),('d3_known','D3已知候选','int'),('d3_unknown','D3未知候选','int'),('d1_d3_apply','已知子集D1至D3提单','int'),('npv_d3','D3已知子集未提单率','pct'),('all_candidate_coverage','占母集评分事件','pct')]
notes=[
 ('统计范围','2026年1月1日至10月24日完整Belize业务日T0；当前回款在北京时间2026-10-25 23:55:21开始的本次只读取数可见值。主220253事件112131用户。'),
 ('410来源','原T0 credit_serial_id+user_id关联model_result_copy.kabybmerge410fpd7cre，未取随后提单订单分数，未混cyc字段。'),
 ('统一分界',f'有效分全部T0事件统一q50={th["q50"]}、q80={th["q80"]}。HIGH20≥q80，MID30为q50≤分<q80，LOW50<q50。同分不拆，实际20.17%/30.26%/49.57%。'),
 ('410质量','有效219665/220253=99.73%，无模型记录588；其余NULL/无效/冲突均0。1—3000是历史清洗规则，非已核实模型card。'),
 ('评分时间限制','源表无生成/更新时间，本次原获额单副本分回填不能证明最初版本及当时可用。'),
 ('事件构成口径','该阶段该档T0首次提单事件数÷该阶段全部T0首次提单事件数。同一用户第1笔与第3笔结清后各发生一次T0当天提单，两次分别计入，不取最早代表。保留原20秒获额去重。'),
 ('盈利表人数','到期订单盈利表为全事件。格内去重用户数仅辅助，不作为分布分母，不能跨410/生命周期档相加。前两表的分母均为T0首次提单事件数。'),
 ('生命周期定义','触发T0、使在贷归零的settled_serial_id在用户成功放款序列中的序号，按remit_time、serial_id排序。不用用户现在总次数或T0前MAX。'),
 ('首次提单','取T0获额后至下一严格T0/观察截止前第一笔apply_time，不要求同一获额订单；首单失败不替换后续成功单。'),
 ('盈利公式','(SUM当前repaid_amt−SUM remit_amt)/SUM remit_amt，金额加权；回款NULL与真实0区分。保留状态8/未结清到期订单，不另扣减免。'),
 ('成熟度','主due_date<统计日；recovery30要求到期至少30日；all_funded含未到期，低回款不代表最终亏损。'),
 ('时段桶','D0/D1/D2/D3/D4+互斥；D1+、D1-D3、D4-D15、D16+、ALL为辅助合并/拆分，不能重复相加。D4+不限15天。'),
 ('模型目标','冻结V4 D3为D0至D3结束共四个自然日期，不是72小时；本次不重训，pD3<0.5只作检验起点。'),
 ('预测分母','完整8866评分，低p候选3701；可评主母集8717，候选3656，D0未提单3143。45未知不填0。'),
 ('结构对齐','双方每格至少30笔到期首单，共同格采用D0+延迟本金同一权重。保留率分母为有效410/已知生命周期对应样本；非因果效应。'),
 ('运营验收','低意愿×410/借款历史为试验候选，不保证优惠后收益。用户级随机四组，转化增量+盈利率不劣+人均增量收益与风险共同验收。')]
tabs=[
 {'name':'410事件分布','columns':[eventcols[0],('score_band','410模型分档','text')]+eventcols[1:],'rows':[label(r) for r in rec(base&(df.level=='risk'))]},
 {'name':'生命周期事件分布','columns':[eventcols[0],('lifecycle_band','刚结清借款放款序号','text')]+eventcols[1:],'rows':[label(r) for r in rec(base&(df.level=='lifecycle'))]},
 {'name':'到期订单盈利','columns':profitcols,'rows':[label(r) for r in rec((df.grain=='event')&(df.level!='joint'))]},
 {'name':'同结构盈利复核','columns':[('scope','时期或观察口径','text'),('delayed','延迟对照组','text'),('dimensions','对齐维度','text'),('status_label','估计状态','text'),('cells','共同支持格数','int'),('D0_standardized_profit_rate','D0同权重盈利率','pct'),('delayed_standardized_profit_rate','延迟组同权重盈利率','pct'),('delayed_minus_D0_pp','延迟减D0百分点','num'),('D0_common_orders','D0共同订单','int'),('delayed_common_orders','延迟共同订单','int'),('D0_principal_coverage','D0有效维度本金保留','pct'),('delayed_principal_coverage','延迟有效维度本金保留','pct')],'rows':std},
 {'name':'预测候选分层','columns':modelcols,'rows':rules},
 {'name':'精确借款序号','columns':[('grain','统计粒度','text'),('bucket','提单阶段','text'),('settled_loan_seq','刚结清单放款序号','int'),('event_count','T0事件数','int'),('users','格内去重人数仅辅助','int'),('funded_orders','对应首单放款','int'),('mature_orders','对应首单到期','int')],'rows':[label(r) for r in pd.read_csv(W/'exact_lifecycle_counts.csv').to_dict('records')]},
 {'name':'统计口径','columns':[('item','项目','text'),('definition','口径说明','text')],'rows':[{'item':a,'definition':b} for a,b in notes]}]
def cell(v,kind):
 if v is None or (isinstance(v,float) and math.isnan(v)):return None
 if kind=='text':return str(v)
 return float(v) if math.isfinite(float(v)) else None
for tab in tabs:
 cols=tab['columns'];tab['matrix']=[[c[1] for c in cols]]+[[cell(r.get(c[0]),c[2]) for c in cols] for r in tab.pop('rows')]
(W/'workbook_payload.json').write_text(json.dumps({'tabs':tabs},ensure_ascii=False,separators=(',',':')))
print(json.dumps({'sheets':[(t['name'],len(t['matrix'])-1) for t in tabs]},ensure_ascii=False))
