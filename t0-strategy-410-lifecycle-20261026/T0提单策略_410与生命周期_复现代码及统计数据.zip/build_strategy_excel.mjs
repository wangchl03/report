import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import {fileURLToPath} from 'node:url';
import {Workbook, SpreadsheetFile} from '@oai/artifact-tool';

const dir=path.dirname(fileURLToPath(import.meta.url));
const payload=JSON.parse(await fs.readFile(path.join(dir,'workbook_payload.json'),'utf8'));
const wb=Workbook.create();
const count='#,##0;[Red]-#,##0;0';
const amount='#,##0.00;[Red]-#,##0.00;0.00';
const percent='0.00%;[Red]-0.00%;0.00%';
const sheets=[];
function colName(i){let s='';while(i>0){i--;s=String.fromCharCode(65+i%26)+s;i=Math.floor(i/26);}return s;}
for(const [ti,t] of payload.tabs.entries()){
  const sh=wb.worksheets.add(t.name);sh.showGridLines=false;
  const rows=t.matrix.length,cols=t.columns.length,last=colName(cols);
  assert(t.matrix.every(row=>row.length===cols));
  const all=sh.getRange(`A1:${last}${rows}`);all.values=t.matrix;
  all.format={font:{name:'Arial',size:10,color:'#1F2937'},rowHeight:23,columnWidth:20,verticalAlignment:'center'};
  sh.tables.add(`A1:${last}${rows}`,true,`StrategyTable${ti+1}`);
  const header=sh.getRange(`A1:${last}1`);
  header.format={fill:'#19324F',font:{name:'Arial',size:10,bold:true,color:'#FFFFFF'},wrapText:true,rowHeight:45,horizontalAlignment:'center',verticalAlignment:'center'};
  for(const [ci,c] of t.columns.entries()){
    if(rows<2)continue;
    const r=sh.getRange(`${colName(ci+1)}2:${colName(ci+1)}${rows}`);
    if(c[2]==='pct')r.setNumberFormat(percent);
    else if(c[2]==='int')r.setNumberFormat(count);
    else if(c[2]!=='text')r.setNumberFormat(amount);
    if(c[2]!=='text')r.format.horizontalAlignment='right';
    if(c[2]==='amount')sh.getRange(`${colName(ci+1)}1:${colName(ci+1)}${rows}`).format.columnWidth=24;
  }
  if(t.name==='统计口径'){
    sh.getRange(`A1:A${rows}`).format.columnWidth=25;
    sh.getRange(`B1:B${rows}`).format.columnWidth=110;
    sh.getRange(`B2:B${rows}`).format.wrapText=true;
    sh.getRange(`A2:B${rows}`).format.rowHeight=64;
    sh.getRange('A2:B2').format.rowHeight=94;
  }else{
    sh.getRange(`A1:A${rows}`).format.columnWidth=t.name==='模型阈值与覆盖'?32:25;
    const bucket=t.columns.findIndex(c=>c[0]==='bucket');
    if(bucket>=0)for(let i=1;i<rows;i++)if(t.matrix[i][bucket]==='ALL'){
      const tr=sh.getRange(`A${i+1}:${last}${i+1}`);tr.format.fill='#DFEAF2';tr.format.font={name:'Arial',size:10,bold:true,color:'#19324F'};
    }
  }
  sh.freezePanes.freezeRows(1);sh.freezePanes.freezeColumns(t.name==='统计口径'?1:3);
  assert.deepEqual(all.values,t.matrix);
  sheets.push({name:t.name,dataRows:rows-1,columns:cols});
}
wb.recalculate();
const peek=await wb.inspect({kind:'table',range:'410事件分布!A1:K7',include:'values',tableMaxRows:7,tableMaxCols:13,maxChars:2500});
await fs.writeFile(path.join(dir,'excel_inspection.ndjson'),peek.ndjson);
const out=path.resolve(dir,'../../outputs/T0提单策略_410分与生命周期验证_20261026');
await fs.mkdir(out,{recursive:true});
const file=path.join(out,'T0提单策略_410分与生命周期统计.xlsx');
await (await SpreadsheetFile.exportXlsx(wb)).save(file);
const audit={passed:true,sheets,file,bytes:(await fs.stat(file)).size,staticData:true,renderSkipped:'用户要求默认不做Excel截图或渲染；仅核对字段、数量、金额与数据类型'};
await fs.writeFile(path.join(dir,'excel_verification.json'),JSON.stringify(audit,null,2));
console.log(JSON.stringify(audit));
