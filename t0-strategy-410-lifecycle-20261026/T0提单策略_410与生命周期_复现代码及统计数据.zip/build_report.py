"""Build the T0 credit-score/lifecycle strategy report from verified aggregates."""
from pathlib import Path
import json,math,hashlib
import pandas as pd
from report_visuals import *
ROOT=Path(__file__).resolve().parent
OUT=ROOT.parents[1]/'outputs/T0提单策略_410分与生命周期验证_20261026'
OUT.mkdir(parents=True,exist_ok=True)
PAPER='T0提单策略_410模型分与生命周期分析报告.html'
BOOK='T0提单策略_410分与生命周期统计.xlsx'

def main():
 df=pd.read_csv(ROOT/'cells.csv',dtype={'period':'string','lifecycle_band':'string'})
 quality=json.loads((ROOT/'quality.json').read_text());assert quality['passed']
 th=json.loads((ROOT/'thresholds.json').read_text())
 prediction=json.loads((ROOT/'prediction_profiles.json').read_text())
 standard=json.loads((ROOT/'composition_analysis.json').read_text())
 def data(**kw):
  mask=pd.Series(True,index=df.index)
  for k,v in kw.items():mask &= df[k].isin(v) if isinstance(v,list) else df[k].eq(v)
  return df.loc[mask].to_dict('records')
 def base(grain='event',level='overall',**extra):
  return data(scope='main',grain=grain,period='ALL',level=level,**extra)
 def one(rows,**kw):return next(r for r in rows if all(r[k]==v for k,v in kw.items()))
 over=base();r_risk=base('event','risk');r_life=base('event','lifecycle')
 d0=one(over,bucket='D0');delayed=one(over,bucket='D1+')
 def share(rows,bucket,bands,key):
  rr=[r for r in rows if r['bucket']==bucket]
  return sum(n(r['event_count']) for r in rr if str(r[key]) in bands)/sum(n(r['event_count']) for r in rr)
 high0=share(r_risk,'D0',['HIGH20'],'score_band');highd=share(r_risk,'D1+',['HIGH20'],'score_band')
 low0=share(r_risk,'D0',['LOW50'],'score_band');lowd=share(r_risk,'D1+',['LOW50'],'score_band')
 life0=share(r_life,'D0',['6-10','11-20','21+'],'lifecycle_band');lifed=share(r_life,'D1+',['6-10','11-20','21+'],'lifecycle_band')
 score_direction=('当天首次提单事件中的高410分占比较低，支持您提出的分布假设。' if high0<highd else '当天首次提单事件中的高410分占比没有低于延迟组，不能直接支持您预期的分布方向。')
 stage_rows=[one(over,bucket=s) for s in STAGES]
 gap=100*(n(delayed['profit_rate'])-n(d0['profit_rate']))
 rules=prediction['rules'];main_rules=prediction['rules_main_evaluable']
 selected_high=one(rules,rule='LOWP_HIGH20');selected_high6=one(rules,rule='LOWP_HIGH20_LIFE6PLUS')
 cards=[('D0当前账面盈利率',fmt(d0['profit_rate'],'pct'),fmt(d0['mature_orders'],'int')+'笔到期首单'),('D1及以后盈利率',fmt(delayed['profit_rate'],'pct'),f'比D0高{gap:.2f}个百分点'),('D0高410分事件占比',fmt(high0,'pct'),fmt(d0['event_count'],'int')+'次当天首次提单事件作分母'),('D1及以后高分占比',fmt(highd,'pct'),fmt(delayed['event_count'],'int')+'次延迟首次提单事件作分母')]
 CHART_FINDINGS.update({
  '各首次提单阶段的410分事件分布':'结论：高分档在当天组占'+fmt(high0,'pct')+'，在次日及以后组占'+fmt(highd,'pct')+'；当天组的410分构成相对偏低。',
  '全部T0首单的当前账面盈利率':'结论：当天盈利率为'+fmt(d0['profit_rate'],'pct')+'，其余四阶段为'+fmt(min(n(r['profit_rate']) for r in stage_rows[1:]),'pct')+'—'+fmt(max(n(r['profit_rate']) for r in stage_rows[1:]),'pct')+'，均高于当天。',
  '410分档 × 首次提单时间：当前盈利率':'结论：各阶段高分档盈利率均高于中低分档；当天低分档为'+fmt(one(r_risk,bucket='D0',score_band='LOW50')['profit_rate'],'pct')+'。',
  '各提单阶段的借款生命周期事件分布':'结论：上笔结清序号≥6的事件，当天组占'+fmt(life0,'pct')+'、延迟组占'+fmt(lifed,'pct')+'；延迟组并没有更多长借款历史事件。',
  '生命周期 × 首次提单时间：全事件首单盈利率':'结论：同一结清序号档内，多数延迟阶段盈利率高于当天，但并非提单越晚、盈利越高。'
 })
 content=section('conclusion','一、核心结论',
 '<div class="cards">'+''.join('<div><span>'+esc(a)+'</span><strong>'+esc(b)+'</strong><small>'+esc(c)+'</small></div>' for a,b,c in cards)+'</div>'
 +numbered([
  '<strong>当天组盈利较低。</strong>当天为'+fmt(d0['profit_rate'],'pct')+'，次日及以后为'+fmt(delayed['profit_rate'],'pct')+'，相差'+f'{gap:.2f}'+'个百分点。',
  '<strong>延迟组高分事件更多。</strong>410高分档占比为'+fmt(highd,'pct')+'，高于当天组的'+fmt(high0,'pct')+'；长借款历史事件占比反而略低。',
  '<strong>优先检验“低意愿＋410高分”候选层。</strong>1,514次结果已知候选中，1,373次当天未提单，命中率'+fmt(selected_high['ppv_no_d0'],'pct')+'；仅筛低意愿为85.97%。',
  '<strong>可以进入对照试验，不能保证优惠后的盈利。</strong>转化提升、盈利率和每随机用户增量盈利需同时验收。'
 ]))
 snapshot=quality.get('snapshot',{})
 defs=[('时间与事件','2026年1月1日至10月24日完整获额业务日。America/Belize。严格干净结清后当日重新获额通过的T0，同用户20秒链式获额去重；当前回款采用本次只读取数可见值。'),
 ('410分来源','本次T0原获额订单的user_id＋credit_serial_id关联model_result_copy.kabybmerge410fpd7cre，不使用随后提单订单的分，不混用cyc410。源副本没有生成/更新时间，不能证明历史最早评分版本及当时线上可用性。'),
 ('统一分档',f'全期全部T0获额事件中唯一有效410分的事件一次计算切点：q50={fmt(th["q50"],"int")}，q80={fmt(th["q80"],"int")}。高分≥q80；中档q50≤分＜q80；低分＜q50。各阶段不重新分位，同分不拆。实际比例会略偏离20%/30%/50%。'),
 ('有效分及方向','沿用旧分析1—3000清洗范围，−9999999及其他范围外值独立标记；它不是已核实的正式模型定义。全220,253次T0中有效410为219,665次（99.73%），其余588次无模型记录，集中在10月24日；没有无效或冲突分。高/中/低表示数值顺序，不解释为校准坏账概率。'),
 ('事件构成口径','某档事件占比＝该阶段该档T0首次提单事件数÷该阶段全部T0首次提单事件数。同一用户在第1笔、第3笔结清后各发生一次T0当天提单，两次分别计入相应借款序号。不同T0不按用户合并；原20秒获额去重保留。'),
 ('盈利订单口径','保留全部T0事件的首笔提单：允许提单与获额不同订单，观察截至下一严格T0或查询截止；首笔提单失败不替换成后续成功单。仅对首单已放款、due_date早于统计日者计算主盈利。构成占比不要求提单已放款或已到期。'),
 ('生命周期次数','找到触发该T0、使全部成功放款订单在贷数归零的settled_serial_id；按用户全历史成功放款时间、订单号排序，取这笔结清单的序号。它不是当前总借款次数，也不等于T0前所有借款的最大序号。'),
 ('盈利公式','[SUM(当前repaid_amt)−SUM(remit_amt)] / SUM(remit_amt)，金额加权。保留逾期、未结清及真实0回款；回款NULL不补0并单列。不是扣除资金、触达等全部成本后的净利。'),
 ('模型与提单时间','D0为获额后当天；D1/D2/D3按自然日期差；D4+为第4日及以后，不限15日。冻结T0 V4的D3是D0至D3结束，共四个自然日期；原始概率门槛pD3＜0.5只作检验起点。')]
 content+=section('contract','二、统计口径',
 numbered([
  '<strong>事件：</strong>2026年1月1日—10月24日的合格T0；同用户20秒链式获额去重，不同T0分别计入。',
  '<strong>构成占比：</strong>某阶段某档首次提单事件数÷该阶段全部首次提单事件数，不是该档用户的提单率。',
  '<strong>盈利率：</strong>到期放款首单的[Σ当前repaid_amt−Σremit_amt]÷Σremit_amt，按金额加权。',
  '<strong>分档：</strong>410取原获额单；生命周期取触发本次T0的刚结清订单放款序号。D4+不限15天。'
 ])
 +'<details><summary>查看完整统计口径（9项）</summary><div class="grid">'+''.join('<div><h3>'+esc(a)+'</h3><p>'+esc(b)+'</p></div>' for a,b in defs)+'</div></details>'
 +'<details><summary>取数时点、字段和全量质量审计</summary><pre>'+esc(json.dumps({'snapshot':snapshot,'thresholds':th,'quality':quality},ensure_ascii=False,indent=2))+'</pre></details>')
 # The chart combines all missing-score reasons into one explicit bucket.
 missing={'NO_RECORD','NULL_SCORE','INVALID','CONFLICT'};dist=[]
 for r in r_risk:
  if r['bucket'] in STAGES:dist.append({**r,'score_band':'UNKNOWN' if r['score_band'] in missing else r['score_band']})
 ucols=[('bucket','首次提单阶段','text'),('score_band','410分档','text'),('event_count','T0首次提单事件数','int'),('stage_event_denominator','该阶段全部T0首次提单事件','int'),('event_share_within_stage','占该阶段全部首次提单事件','pct'),('funded_orders','对应首单放款数','int'),('mature_orders','对应首单到期数','int'),('profit_rate','对应到期首单盈利率','pct')]
 content+=section('score_distribution','三、410模型分分布',
 distribution(dist,'score_band',RISK+['UNKNOWN'],RISK_LABEL,'各首次提单阶段的410分事件分布','分母为该阶段全部T0首次提单事件，包含缺分/冲突；每阶段加总100%。同一用户多次T0分别计入。小于4.5%的段不在图内挤入标签，精确值见折叠表。')
 +table([r for r in r_risk if r['bucket'] in STAGES+['D1+']],ucols,'410分档事件数、阶段分母、构成占比与对应盈利')
 +'<details><summary>查看补充说明</summary><p>当日与延迟组使用相同分界。高分事件占比差反映客群结构关联，不能直接证明某一位用户因延迟提单而变得资质更好。缺分独立列，不将缺分当作低分。这里描述的是已发生首次提单事件的构成，不是各410档T0获额后的提单率。</p></details>')
 pcols=[('bucket','提单阶段','text'),('score_band','410分档','text'),('event_count','首提单事件数','int'),('users','单格去重用户数','int'),('funded_orders','首单放款数','int'),('mature_orders','已到期放款首单数','int'),('principal','到期本金','num'),('repaid','当前回款','num'),('profit','账面盈利金额','num'),('profit_rate','账面盈利率','pct'),('state8_orders','当前状态8订单数','int'),('maturity_coverage','到期覆盖','pct')]
 rr=[r for r in r_risk if r['score_band'] in RISK and r['bucket'] in STAGES]
 comparisons=[]
 for band in RISK:
  a=one(r_risk,bucket='D0',score_band=band);b=one(r_risk,bucket='D1+',score_band=band)
  comparisons.append(RISK_LABEL[band]+'：D0 '+fmt(a['profit_rate'],'pct')+'，次日及以后 '+fmt(b['profit_rate'],'pct'))
 content+=section('score_profit','四、410分档与盈利',
 profit_bars(stage_rows,'全部T0首单的当前账面盈利率','事件/首单盈利沿用原报告2026年10月25日23:55起的回款取数快照。仅纳入到期业务日已结束订单；本次修订构成分布的计数口径。')
 +heatmap(rr,'score_band',RISK,RISK_LABEL,'410分档 × 首次提单时间：当前盈利率','图内同时显示盈利率及到期首单数。所有分档均用同一切点；金额加权，不是逐笔盈利率的均值。')
 +numbered(comparisons)
 +table([r for r in r_risk if r['bucket'] in STAGES+['D1+']],pcols,'全事件口径：410分档金额、盈利及缺分组')
 +table([r for r in data(scope='main',grain='event',level='risk') if r['period']!='ALL' and r['bucket'] in STAGES],[('period','获额月','text')]+pcols,'月度410分档盈利明细')
 +'<details><summary>查看补充说明</summary><p>分布与盈利均以完整T0事件为锚点，盈利另外要求对应首单成功放款并到期。表中“单格去重用户数”仅为辅助人数，同一用户可能贡献多个事件或跨档出现，不作为构成占比分母，也不能跨格相加。</p></details>')
 lcols=[('bucket','首次提单阶段','text'),('lifecycle_band','上笔结清单放款序号','text'),('event_count','T0首次提单事件数','int'),('stage_event_denominator','该阶段全部T0首次提单事件','int'),('event_share_within_stage','占该阶段全部首次提单事件','pct'),('funded_orders','对应首单放款数','int'),('mature_orders','对应首单到期数','int'),('profit_rate','对应到期首单盈利率','pct')]
 content+=section('lifecycle','五、借款生命周期与盈利',
 distribution([r for r in r_life if r['bucket'] in STAGES],'lifecycle_band',LIFE+['UNKNOWN'],LIFE_LABEL,'各提单阶段的借款生命周期事件分布','每根横条的分母为该阶段全部T0首次提单事件。同一用户不同T0分别计入，不取最早代表。各档事件数加总等于该阶段分母，构成占比合计100%。',stage_suffix='提单')
 +heatmap([r for r in r_life if r['bucket'] in STAGES and str(r['lifecycle_band']) in LIFE],'lifecycle_band',LIFE,LIFE_LABEL,'生命周期 × 首次提单时间：全事件首单盈利率','不按最终借款次数回填历史事件，避免把未来留存信息带入当前策略。')
 +table([r for r in r_life if r['bucket'] in STAGES+['D1+']],lcols,'生命周期事件数、阶段分母、构成占比与对应盈利')
 +table([r for r in r_life if r['bucket'] in STAGES+['D1+']],[('bucket','提单阶段','text'),('lifecycle_band','上笔结清序号档','text')]+pcols[2:],'生命周期全事件盈利明细')
 +'<details><summary>查看补充说明</summary><p>例如当天组第1笔结清事件占比为37,387÷96,986＝38.55%；次日组为8,049÷22,047＝36.51%。分子、分母均按T0事件计数。这里的“首次提单”是每次T0获额后的第一笔提单，不是用户生命周期内第一次提单；也不是该结清序号的获额后提单率。</p></details>'
 +'<details><summary>精确到每一笔成功放款序号的事件数</summary><pre>'+esc((ROOT/'exact_lifecycle_counts.csv').read_text())+'</pre></details>')
 standrows=[{**r,'dimensions':'＋'.join(r['dimensions']),'status_label':'可估计' if r['estimable'] else ('未提取此口径月度格，未计算' if r.get('unavailable_reason') else '共同样本不足')} for r in standard['results'] if r['delayed']=='D1+']
 scols=[('scope','样本观察口径','text'),('dimensions','结构对齐维度','text'),('status_label','估计状态','text'),('cells','共同支持格数','int'),('D0_standardized_profit_rate','D0同权重盈利率','pct'),('delayed_standardized_profit_rate','延迟同权重盈利率','pct'),('delayed_minus_D0_pp','延迟减D0百分点','pp'),('D0_principal_coverage','D0有效维度本金保留','pct'),('delayed_principal_coverage','延迟有效维度本金保留','pct')]
 mainstand=[r for r in standrows if r['scope']=='main' and r.get('estimable')]
 joint=next((r for r in mainstand if r['dimensions']=='period＋score_band＋lifecycle_band'),None)
 stdtext=('<p class="callout">同时对齐获额月份、410和生命周期后，D0 / 次日及以后盈利率为'+fmt(joint['D0_standardized_profit_rate'],'pct')+' / '+fmt(joint['delayed_standardized_profit_rate'],'pct')+'，延迟组差值'+fmt(joint['delayed_minus_D0_pp'],'pp')+'个百分点。该比较只覆盖双方均有至少30笔到期首单的共同格，保留范围见下表。</p>' if joint else '<p>月份、410和生命周期的联合共同支持不足，不能报告完整联合结构对齐结果；保留可估计维度及其覆盖率。</p>')
 riskstd=next(r for r in mainstand if r['dimensions']=='score_band');lifestd=next(r for r in mainstand if r['dimensions']=='lifecycle_band')
 content+=section('standard','六、结构对齐后的盈利差异',
 numbered([
  '原始延迟组盈利率比当天组高'+f'{gap:.2f}'+'个百分点；仅对齐410结构后差'+fmt(riskstd['delayed_minus_D0_pp'],'pp')+'个百分点，仅对齐生命周期后差'+fmt(lifestd['delayed_minus_D0_pp'],'pp')+'个百分点。',
  ('同时对齐月份、410和生命周期后，当天 / 延迟组为'+fmt(joint['D0_standardized_profit_rate'],'pct')+' / '+fmt(joint['delayed_standardized_profit_rate'],'pct')+'，仍差'+fmt(joint['delayed_minus_D0_pp'],'pp')+'个百分点。' if joint else '三维共同样本不足，不展示联合结果。'),
  '联合结果仅覆盖双方每格均有至少30笔到期首单的共同样本；各项本金保留率见下表。'
 ])
 +table(standrows,scols,'同本金权重的结构对齐结果与保留率')
 +'<details><summary>查看结构对齐方法与解释范围</summary><p>每个共同格分别计算两组盈利率，两组使用该格合并本金的同一权重；未知档、稀疏格不填0。本金保留率以对应维度已知样本为分母。结果未对齐所有日息、额度、期限和资质，也不代表优惠的因果效果。</p></details>')
 predcols=[('name','候选描述规则','text'),('all_candidates','完整候选事件','int'),('all_candidate_users','完整候选用户','int'),('all_candidate_coverage','占对应评分母集覆盖','pct'),('known_d0','D0已知候选','int'),('unknown_d0','D0未知候选','int'),('no_d0','实际D0未提单','int'),('ppv_no_d0','D0未提单命中率','pct'),('ci95_low','95%下界','pct'),('ci95_high','95%上界','pct'),('d3_known','D3可判候选','int'),('d3_unknown','D3未知候选','int'),('npv_d3','D3可判子集：未提单比例','pct')]
 compcols=[('population','名单母集','text'),('dimension','画像维度','text'),('band','分档','text'),('events','事件数','int'),('users','格内去重人数','int'),('share','事件占比','pct')]
 content+=section('prediction','七、预测筛选结果',
 numbered([
  '<strong>原名单：</strong>冻结V4在10月9—21日评分8,866次，pD3（D0—D3累计提单预测概率）＜50%筛中3,701次；3,656次当天结果已知，未提单命中率85.97%，另45次未知不补0。',
  '<strong>叠加410高分：</strong>候选1,532次，可评1,514次，实际当天未提单1,373次，命中率'+fmt(selected_high['ppv_no_d0'],'pct')+'；完整候选占原评分事件17.28%。',
  '<strong>再加结清序号≥6：</strong>候选276次，可评269次，命中率'+fmt(selected_high6['ppv_no_d0'],'pct')+'；覆盖更小，不能凭本批结果认定最优。'
 ])
 +'<details><summary>查看候选画像与使用限制</summary><p>低pD3候选中，410高分占41.39%，低分占31.37%；结清序号1—2笔占67.77%，≥6占10.59%。意愿分不能替代资质与价值筛选。这里只给冻结预测事件补画像，没有重训或按实际提单时间反向选人。21+档仅11次可评，不能据此宣称未来命中率100%。</p></details>'
 +table(rules,predcols,'低pD3与410、生命周期组合候选：完整候选及命中率')
 +table(main_rules,predcols,'同一D3成熟可评母集内的组合复核')
 +table(prediction['group_composition'],compcols,'原评分母集与低pD3名单的画像构成')
 +'<details><summary>画像回接质量和完整统计分母</summary><pre>'+esc(json.dumps({'meta':prediction['meta'],'match_quality':prediction['match_quality']},ensure_ascii=False,indent=2))+'</pre></details>')
 strategy=[('T0锚点','全订单干净结清后获额通过，完成20秒链去重。记录原T0订单、410来源、结清序号与评分时刻。'),('意愿筛选','沿用冻结V4原始pD3概率；0.5为本次检验起点，生产门槛依据预算、误优惠容忍度和前瞻试验固定，不使用批内最高概率归一化分。'),('价值分层','把低意愿且410高分前20%列为优先候选试验层。生命周期用于分层和风险约束，不一刀切只留6次以上：借款1—2次的高分潜力用户也可单列试验。410低分或未知者单独处理，不能因“不想借”就普遍提额。'),('发放前复核','实际优惠曝光前，确认仍可提单、无当前状态8、无已发生提单及其他失效情况。评分所需和风险所需字段必须当时已到达，记录available_at。'),('分别试验','同客群用户固定随机进入正常条件、仅降息、仅提额、组合四组；风险档和生命周期档内分层随机，优惠幅度及风险额度沿用已批准范围。'),('固定随访','提额可能生成新的获额记录。固定优惠前T0和用户随机组，不因新获额重分组或截断用户级收益，未曝光、未提单、未放款者留在原组。'),('双目标验收','提单率/放款率提升与同观察期盈利率不劣于预设经营容忍线同时验收，主经济指标仍看每随机用户增量盈利金额；同步看同账龄逾期和本金敞口。'),('扩大或停止','先影子评分验证真实时点，再按预注册样本量和窗口完成随机试验。转化提升但人均收益下降、盈利率/风险超经营边界时，调整或停止对应策略。')]
 content+=section('strategy','八、策略执行流程',
 numbered([
  '<strong>筛选：</strong>固定T0锚点，以低pD3＋410高分筛候选，生命周期分层；优惠曝光前复核仍可提单、无状态8、尚未提单，且评分数据当时已可用。',
  '<strong>试验：</strong>同客群用户固定随机进入正常条件、仅降息、仅提额、组合四组，沿用已批准的优惠和风险额度范围。',
  '<strong>随访：</strong>固定用户级30/60/90日窗口，未曝光、未提单、未放款者仍保留原组；提额产生新获额也不重分组。',
  '<strong>验收：</strong>同时看提单增量、同账龄盈利率、每随机用户增量盈利及逾期；不达经营边界则调整或停止对应策略。'
 ])
 +'<details><summary>查看完整运营步骤与验收公式</summary><div class="grid">'+''.join('<div><h3>'+str(i+1)+'. '+esc(a)+'</h3><p>'+esc(b)+'</p></div>' for i,(a,b) in enumerate(strategy))+'</div>'
 +'<div class="formula">提单增量＝处理组提单率−对照组提单率<br>盈利率不劣＝处理组同观察期盈利率−对照组盈利率≥−预设容忍界值<br>主经济指标＝每随机用户增量Σ(repaid_amt−remit_amt)−未在回款中体现的新增费用</div><p>验收保留全部随机用户，不只看已放款者。让利若已反映为repaid_amt减少，不重复扣除；其他费用另列。先影子评分，再按预注册样本量和窗口完成试验。</p></details>'
 +'<p><a href="../T0低意愿用户当日优惠_可行性与召回SOP_20261025/T0低意愿用户当日优惠_策略可行性分析报告.html">前一份可行性报告</a>　<a href="../T0低意愿用户当日优惠_可行性与召回SOP_20261025/T0低意愿用户当日优惠_运营SOP.html">完整运营SOP</a></p>')
 caveats=[('历史410可用性','当前副本按原获额单回接正确，但没有评分生成/更新时间；历史最初版本和实际available_at未证明，上线前须留存。'),('分位切点前瞻冻结','全期切点用于本次描述；未来运营应固定切点和模型版本，不在当期结果出来后重定高分。'),('已放款与已到期选择','盈利主样本是已提单、已放款、已到期的子集；缺乏完整到期的10月尤其应看覆盖。未到期回款少不能直接当最终亏损。'),('观测不等于优惠效果','高分、借款历史、晚提单与盈利的关联不能代替用户对优惠的因果响应；实际是否既增转化又保利以随机试验决定。')]
 codefiles=[p for p in sorted(ROOT.glob('*.py')) if p.name not in ['audit_risk410_source.py']]
 sqlfiles=sorted((ROOT/'sql').glob('*.sql'))
 code='<details><summary>完整Python代码（默认隐藏）</summary>'+''.join('<details><summary>'+esc(p.name)+'</summary><pre><code>'+esc(p.read_text())+'</code></pre></details>' for p in codefiles)+'</details>'
 code+='<details><summary>完整SQL代码（默认隐藏）</summary>'+''.join('<details><summary>'+esc(p.name)+'</summary><pre><code>'+esc(p.read_text())+'</code></pre></details>' for p in sqlfiles)+'</details>'
 content+=section('appendix','九、附录：复原报告代码',
 '<details><summary>查看适用边界（4项）</summary><div class="grid">'+''.join('<div><h3>'+esc(a)+'</h3><p>'+esc(b)+'</p></div>' for a,b in caveats)+'</div></details>'
 +'<p><a href="'+BOOK+'">下载完整计算附表</a>　<a href="T0提单策略_410与生命周期_复现代码及统计数据.zip">下载SQL、Python及统计数据</a></p>'+code)
 nav=[('conclusion','结论'),('contract','统计口径'),('score_distribution','410事件分布'),('score_profit','410与盈利'),('lifecycle','生命周期'),('standard','结构复核'),('prediction','预测名单'),('strategy','策略与SOP'),('appendix','代码与附表')]
 doc='<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>T0提单策略：410分与生命周期验证</title><style>'+CSS+'</style></head><body><header><h1>T0提单策略：410模型分与用户生命周期验证</h1><p>精简版　·　数据、图表和事件统计口径保持原样</p><p>获额事件：2026年1月1日—10月24日完整业务日　·　回款快照沿用：北京时间2026年10月25日23:55起</p></header><nav>'+''.join('<a href="#'+k+'">'+v+'</a>' for k,v in nav)+'</nav><main>'+content+'</main><footer>T0事件构成与当前账面盈利分析　·　表格与代码默认折叠</footer></body></html>'
 file=OUT/PAPER;file.write_text(doc)
 findings={'distribution_grain':'strict_T0_first_application_event','D0_profit_rate':d0['profit_rate'],'D1plus_profit_rate':delayed['profit_rate'],'D0_high_score_event_share':high0,'D1plus_high_score_event_share':highd,'D0_low_score_event_share':low0,'D1plus_low_score_event_share':lowd,'D0_life6plus_event_share':life0,'D1plus_life6plus_event_share':lifed,'score_hypothesis_supported_descriptively':bool(high0<highd),'joint_month_standardization':joint,'report':str(file),'financial_snapshot_refreshed_this_edit':False}
 (ROOT/'report_findings.json').write_text(json.dumps(findings,ensure_ascii=False,indent=2,default=str))
 print(json.dumps({'report':str(file),'bytes':file.stat().st_size,'sha256':hashlib.sha256(file.read_bytes()).hexdigest()},ensure_ascii=False))

if __name__=='__main__':main()
