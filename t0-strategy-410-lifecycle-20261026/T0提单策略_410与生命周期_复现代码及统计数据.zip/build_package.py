"""Package the current event-grain report code and aggregate inputs."""
from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
import hashlib,json
W=Path(__file__).resolve().parent
OUT=W.parents[1]/'outputs/T0提单策略_410分与生命周期验证_20261026'
README='''T0提单策略：410模型分与用户生命周期验证（事件口径修订版）

本版于2026年10月26日修订。构成分布统一采用T0事件数，不按用户取最早代表；同一用户在不同借款阶段发生的每次合格T0事件分别计入，原同用户20秒链式获额去重保留。

一、统计口径
某档构成占比＝该首次提单阶段该档T0事件数÷该阶段全部T0首次提单事件数。例：D0第1笔结清37387/96986=38.55%；D1第1笔结清8049/22047=36.51%。这里的首次是每次T0获额后的第一笔后续提单，不是用户一生第一次。构成分母只含该阶段实际发生首次提单的事件，不能解释为某借款序号全部T0获额后的提单率。
410和生命周期主图、主表统一grain=event；去重用户数仅为辅助，不能跨档相加或作为构成分母。各阶段事件档互斥加总100%，不同T0即使同用户也不合并。精确借款序号表只保留事件粒度。用户级随机试验和用户聚类Bootstrap是独立方法，不因统计分布改为事件而更改。
主事件2026-01-01至2026-10-24完整Belize业务日；回款沿用2026-10-25北京时间23:55起原只读取数可见的repaid_amt。此次修订未查询数据库、重新训练模型或刷新财务；事件金额、410切点、冻结预测与匹配画像均与原事件子集一致。

二、离线复现
1. prepare_risk_lifecycle.py从原查询冻结缓存筛grain=event，生成cells.csv、score_distribution.csv、lifecycle_distribution.csv、overall.csv、joint_cells.csv、exact_lifecycle_counts.csv及质量审计。旧缓存可含历史代表视图，当前生成器明确不输出它；新SQL只计算事件粒度。
2. analyze_composition.py从cells.csv重算共同结构盈利。主规则双方每格至少30笔已到期首单；没有该到期口径月度输入时明确未计算，不补0。
3. prepare_workbook.py生成Excel输入；build_strategy_excel.mjs通过@oai/artifact-tool导出Excel。前两页为410事件分布、生命周期事件分布。
4. build_report.py与report_visuals.py读取当前汇总重建完整HTML及图表。输出默认指向原工作区outputs同名文件，可按部署环境修改OUT。表与代码默认折叠，报告无外部JS资源依赖。

三、原SQL与数据库复跑
extract_risk_lifecycle.py及sql/strict_t0_risk410_lifecycle_global.sql包含严格T0、410、触发结清单放款序号、事件聚合完整逻辑；已移除按用户挑最早代表的排序和stage_user分支。Python连接适配器沿用原工作区run_common，本包不含连接凭据，也可在已有数据库客户端运行完整SQL。
SQL观察截止固定为原Belize时间2026-10-25 09:55:21，但当前源repaid_amt和模型副本会更新，未来重跑不保证冻结金额相同。本包统计CSV均为汇总，不含运营名单或用户级画像映射；完整SQL保留原获额订单ID常量，用于复现验证母集。

四、预测复核
analyze_prediction_profiles.py保留冻结V4预测、冻结标签、原获额单画像关联及500次用户聚类Bootstrap。其运行依赖原工作区前次预测/标签文件及validation_mapping.parquet；本包提供聚合后的prediction_profiles.json/CSV与分母审计，不包含模型二进制或原用户映射明细。本任务没有重训。D3包含D0—D3四个自然日期；未知标签不填未提单。

五、其他关键定义
410取原T0获额订单cre410，不混cyc410；q50=499、q80=528，全部有效T0一次定档，同分不拆。1—3000为历史清洗规则，不是正式模型卡。源无评分时间，不能证明最初版本或当时可用性。
生命周期是使全部在贷归零的刚结清订单在用户成功放款序列中的序号，按remit_time、serial_id排序，不取当前总次数或T0前MAX。
盈利只用每次T0后首笔提单中已放款且到期业务日已结束的订单，首单失败不跳后续成功单；保留逾期/未结清和真实0回款。盈利率=(SUM当前repaid_amt-SUM remit_amt)/SUM remit_amt。D4+不限15天，历史事件在下一严格T0处截断。
结构对齐是描述性关系，不是优惠增量效果；保持盈利与提高转化需要同客群用户级随机试验同时验收。策略产生新获额时，用户级ITT随机分组和收益随访不因此重置。
'''

def main():
    (W/'复现说明.txt').write_text(README)
    exclude={'validation_mapping.csv','validation_requested_ids.json','risk410_sample_keys.json',
             'workbook_payload.json','package_manifest.json','risk410_sample_check.sql','audit_risk410_source.py'}
    files=[]
    for pat in ['*.py','*.mjs','*.json','*.csv','*.sql','复现说明.txt']:
        files += [p for p in W.glob(pat) if p.name not in exclude]
    files += list((W/'sql').glob('*.sql'))+[W/'sources/source_coverage.csv']
    manifest=[];dest=OUT/'T0提单策略_410与生命周期_复现代码及统计数据.zip'
    with ZipFile(dest,'w',ZIP_DEFLATED) as z:
        for p in sorted(set(files)):
            name=str(p.relative_to(W));b=p.read_bytes();z.writestr(name,b)
            manifest.append({'file':name,'bytes':len(b),'sha256':hashlib.sha256(b).hexdigest()})
        z.writestr('PACKAGE_MANIFEST.json',json.dumps({'files':manifest,'distribution_grain':'event',
            'individual_user_profile_or_recall_list_included':False,'validation_order_id_constants_retained_in_sql':True},ensure_ascii=False,indent=2))
    (W/'package_manifest.json').write_text(json.dumps({'zip':str(dest),'bytes':dest.stat().st_size,'files':len(files),
        'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'distribution_grain':'event'},ensure_ascii=False,indent=2))
    print(json.dumps({'zip':str(dest),'bytes':dest.stat().st_size,'files':len(files)},ensure_ascii=False))

if __name__=='__main__':main()
