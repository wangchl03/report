"""Generate the exact strict T0 / first-application query from the frozen template."""
from pathlib import Path
W=Path(__file__).resolve().parent

def make_query(shard):
    original = (W / 'profit_T0_template.sql').read_text()
    source = original[original.index('WITH params AS ('):original.index('), raw_applications AS (')]
    source = source.replace("DATE '2026-10-01' AS output_end_date", "DATE '2026-11-01' AS output_end_date")
    source = source.replace("WHERE v.is_pass1 = 1 AND v.loan_type_code = 2 AND v.vir_unix > 0",
        f"WHERE v.is_pass1 = 1 AND v.loan_type_code = 2 AND v.vir_unix > 0 AND MOD(v.user_id,4)={shard}")
    return source + '''), raw_applications AS (
    SELECT o.user_id,o.serial_id,o.apply_time,o.apply_date,o.apply_amt,
           o.is_remit,o.remit_time,o.remit_amt,o.repaid_amt,o.due_date,o.is_due,
           o.loan_status_code,o.loan_day,o.total_term,
           COUNT(*) OVER(PARTITION BY o.user_id,o.serial_id) AS source_order_rows
    FROM wangchuanliang.order_loan_f_v2_copy o
    JOIN candidate_users u ON u.user_id=o.user_id CROSS JOIN params p
    WHERE o.apply_date>=p.base_start_date-1
      AND o.apply_date<p.data_cutoff_ts::date+1
      AND o.apply_time>=p.base_start_date::timestamp AND o.apply_time<p.data_cutoff_ts
), applications AS (
    SELECT DISTINCT ON (user_id,serial_id) * FROM raw_applications
    ORDER BY user_id,serial_id,apply_time
), application_ranked AS (
    SELECT e.user_id,e.serial_id AS credit_serial_id,e.vir_date,e.vir_time,
           e.settled_serial_id,e.repaid_time AS clean_settle_time,
           e.next_t0_time,e.data_cutoff_ts,
           o.serial_id AS apply_serial_id,o.apply_time,o.apply_amt,o.is_remit,
           o.remit_time,o.remit_amt,o.repaid_amt,o.due_date,o.is_due,
           o.loan_status_code,o.loan_day,o.total_term,o.source_order_rows,
           ROW_NUMBER() OVER(PARTITION BY e.user_id,e.serial_id
                              ORDER BY o.apply_time,o.serial_id) AS apply_rn
    FROM cohort e LEFT JOIN applications o
      ON o.user_id=e.user_id AND o.apply_time>=e.vir_time
     AND (e.next_t0_time IS NULL OR o.apply_time<e.next_t0_time)
)
SELECT user_id,credit_serial_id,vir_date,vir_time,settled_serial_id,
       clean_settle_time,next_t0_time,data_cutoff_ts,
       apply_serial_id,apply_time,apply_amt,is_remit,remit_time,
       remit_amt,repaid_amt,due_date,is_due,loan_status_code,loan_day,total_term,
       source_order_rows
FROM application_ranked WHERE apply_rn=1
'''
