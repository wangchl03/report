WITH offer_source AS (
 SELECT v.user_id,v.serial_id,v.vir_unix,v.vir_date,v.vir_rnb,v.loan_type_code,
 v.is_pass1,v.is_pass,v.vir_status_code,v.max_credit_apply_amt::text credit_amt,
 v.max_risk_credit_amount::text risk_credit_amt,v.is_can_apply,v.is_eff,
 ROW_NUMBER() OVER(PARTITION BY v.user_id ORDER BY v.vir_unix DESC,v.serial_id DESC,v.vir_rnb DESC) AS user_rn
 FROM wangchuanliang.order_vir_f_copy v
 WHERE v.user_id IN (SELECT unnest(%(users)s::bigint[])) AND v.vir_unix>946706400 AND v.vir_unix<=%(epoch)s
), matched AS (
 SELECT v.*,ROW_NUMBER() OVER(PARTITION BY v.user_id,v.serial_id ORDER BY v.vir_unix DESC,v.vir_rnb DESC) AS order_rn
 FROM offer_source v JOIN wangchuanliang.order_loan_f_v2_copy o ON o.user_id=v.user_id AND o.serial_id=v.serial_id
 WHERE o.apply_amt>0 AND o.apply_date>=DATE '2025-01-01' AND o.apply_date<DATE '2026-10-01'
 AND TIMESTAMP 'epoch'+v.vir_unix*INTERVAL '1 second'-INTERVAL '6 hours'<=
 CASE WHEN o.apply_time>=TIMESTAMP '2000-01-01' THEN o.apply_time ELSE o.apply_date::timestamp END
)
SELECT user_id,serial_id,vir_unix,vir_date,vir_rnb,loan_type_code,is_pass1,is_pass,vir_status_code,credit_amt,risk_credit_amt,is_can_apply,is_eff
 FROM offer_source WHERE user_rn=1
UNION
SELECT user_id,serial_id,vir_unix,vir_date,vir_rnb,loan_type_code,is_pass1,is_pass,vir_status_code,credit_amt,risk_credit_amt,is_can_apply,is_eff
 FROM matched WHERE order_rn=1