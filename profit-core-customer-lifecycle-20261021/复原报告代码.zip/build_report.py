"""Build the dark, self-contained aggregate report from the frozen analysis JSON."""
from pathlib import Path
import os,json,html,re,hashlib,shutil,zipfile
from datetime import datetime
from zoneinfo import ZoneInfo
W=Path(__file__).resolve().parent
OUT=Path(os.environ.get('CORE_CUSTOMER_REPORT_OUT',str(W.parents[1]/'outputs/核心利润客群_用户生命周期特征分析_20261021')))
esc=lambda x:html.escape(str(x))
def num(v,d=0):return '—' if v is None else f'{float(v):,.{d}f}'
def pct(v):return '—' if v is None else f'{float(v)*100:.2f}%'
def table(headers,rows):
    return '<div class="scroll"><table><thead><tr>'+''.join('<th>'+esc(x)+'</th>' for x in headers)+'</tr></thead><tbody>'+''.join('<tr>'+''.join('<td>'+esc(x)+'</td>' for x in r)+'</tr>' for r in rows)+'</tbody></table></div>'
def details(label,content):return '<details class="data-details"><summary>'+esc(label)+'</summary>'+content+'</details>'
def chart(title,labels,series,percent=True,unit='',ceiling=None):
    # Plain SVG: every bar has a visible label, and remains available offline.
    width=1120;left=270;right=140;top=62;bar=18;gap=8;groupgap=26
    stride=len(series)*(bar+gap)+groupgap;height=top+len(labels)*stride+25
    maximum=max([v for s in series for v in s['values'] if v is not None]+[0])
    scale=ceiling or max(maximum*1.12,0.01);plot=width-left-right
    svg=f'<svg role="img" aria-label="{esc(title)}" viewBox="0 0 {width} {height}" xmlns="http://www.w3.org/2000/svg"><title>{esc(title)}</title>'
    for i,s in enumerate(series):
        svg+=f'<rect x="{left+i*245}" y="13" width="13" height="13" rx="3" fill="{s["color"]}"/><text x="{left+20+i*245}" y="25" fill="#d9e7ef" font-size="14">{esc(s["name"])}</text>'
    for i,label in enumerate(labels):
        y=top+i*stride
        svg+=f'<text x="{left-18}" y="{y+bar}" fill="#d9e7ef" text-anchor="end" font-size="15">{esc(label)}</text>'
        for j,s in enumerate(series):
            v=s['values'][i];yy=y+j*(bar+gap);w=0 if v is None else max(0,v/scale*plot)
            label_v=pct(v) if percent else num(v,2)+unit
            svg+=f'<rect x="{left}" y="{yy}" width="{w:.2f}" height="{bar}" rx="3" fill="{s["color"]}"/><text x="{left+w+9:.2f}" y="{yy+14}" fill="{s["color"]}" font-size="14">{esc(label_v)}</text>'
    return '<div class="figure">'+svg+'</svg></div>'

def main():
    OUT.mkdir(parents=True,exist_ok=True);d=json.loads((W/'analysis.json').read_text());allg=d['groups'][0];groups=d['groups'][1:];g80=d['coverage_profiles'][3]
    colors=['#43c7e7','#64dcae','#ffc26b'];labels=['借款11次及以上','借款6—10次','借款5次及以下']
    css='''*{box-sizing:border-box}:root{color-scheme:dark;--bg:#061b2a;--panel:#0b2a40;--paper:#082235;--line:#21465a;--ink:#d9e7ef;--muted:#9bb5c7;--cyan:#43c7e7;--green:#64dcae;--amber:#ffc26b}body{margin:0;background:var(--bg);color:var(--ink);font:16px/1.8 -apple-system,BlinkMacSystemFont,"PingFang SC",sans-serif}main{max-width:1320px;margin:auto;padding:34px 24px 60px}h1{font-size:33px;line-height:1.4;margin:10px 0 14px;text-align:center;color:#f3faff}h2{font-size:23px;line-height:1.5;margin:0 0 14px;color:var(--cyan)}h3{font-size:18px;margin:18px 0 8px;color:var(--amber)}p{margin:10px 0}section{padding:26px;margin:22px 0;border:1px solid var(--line);border-radius:12px;background:var(--paper);scroll-margin-top:20px}nav{display:flex;justify-content:center;text-align:center;gap:20px;flex-wrap:wrap;margin:20px 0;font-size:14px}a,summary{color:var(--cyan);text-decoration:none}a:hover{text-decoration:underline}.note,.chart-note,.muted{font-size:14px;color:var(--muted)}.conclusion{padding:12px 16px;border-left:3px solid var(--cyan);background:#123146;margin:14px 0}.cards{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:14px;margin:20px 0}.card{padding:16px;background:var(--panel);border:1px solid var(--line);border-top:3px solid var(--cyan);border-radius:8px}.card h3{font-size:14px;line-height:1.4;margin:0 0 3px;color:var(--ink)}.card strong{display:block;font-size:29px;line-height:1.5;color:var(--green);font-variant-numeric:tabular-nums}.card small{display:block;font-size:12px;color:var(--muted);margin-top:3px}.profiles{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:15px}.profile{padding:18px;border:1px solid var(--line);border-radius:9px;background:var(--panel)}.profile h3{margin-top:0}.tag{display:inline-block;border:1px solid var(--line);border-radius:5px;font-size:13px;padding:3px 8px;margin:3px;color:var(--green)}.figure svg{display:block;width:100%;height:auto}.scroll{overflow:auto}table{width:100%;border-collapse:collapse;font-size:13px;margin:14px 0;font-variant-numeric:tabular-nums}th,td{padding:10px 12px;border-bottom:1px solid var(--line);text-align:right;vertical-align:top}th{white-space:nowrap;background:#123b51;color:var(--cyan)}th:first-child,td:first-child{text-align:left}tbody tr:nth-child(even){background:var(--panel)}.data-details{border-top:1px solid var(--line);padding:13px 0;margin-top:10px}summary{cursor:pointer;font-size:14px}.definition{border-left:2px solid #3e6a82;padding-left:14px}.definition b{color:var(--ink)}pre{overflow:auto;background:#041725;border:1px solid var(--line);border-radius:8px;padding:18px;max-height:600px}code{font:12px/1.65 ui-monospace,Menlo,monospace;white-space:pre}select{background:var(--panel);color:var(--ink);font:inherit;padding:7px 12px;border:1px solid var(--line);border-radius:6px}.interactive{margin:14px 0}.good{color:var(--green)}.bad{color:#ff7a83}#appendix{padding:18px 24px}#appendix h2{font-size:20px}.center{text-align:center}a:focus-visible,summary:focus-visible,select:focus-visible{outline:2px solid var(--cyan);outline-offset:4px}@media(max-width:1000px){.cards{grid-template-columns:repeat(2,minmax(0,1fr))}.profiles{grid-template-columns:1fr}}@media(max-width:650px){main{padding:20px 12px}section{padding:20px 15px}h1{font-size:26px}.cards{grid-template-columns:1fr}.figure{overflow:auto}.figure svg{min-width:720px}table{font-size:12px}}@media print{nav,.interactive,#appendix{display:none}section{break-inside:auto}.figure{break-inside:avoid}}'''
    parts=[f'<!doctype html><html lang="zh-CN"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>核心利润客群：用户生命周期特征分析</title><style>{css}</style></head><body><main><header><h1>核心利润客群：用户生命周期特征分析</h1><p class="muted center">生成时间 · {datetime.now(ZoneInfo("Asia/Shanghai")).strftime("%Y年%m月%d日")}</p></header>']
    nav=[('core','核心判断'),('profiles','客群特征'),('history','逾期与结清'),('retention','结清后提单'),('usage','额度使用率'),('latest','当前与获额'),('definitions','指标口径'),('appendix','复原报告代码')]
    parts.append('<nav>'+''.join(f'<a href="#{k}">{v}</a>' for k,v in nav)+'</nav>')
    parts.append('<section id="core"><h2>核心判断</h2>')
    parts.append(f'<p class="conclusion">历史利润集中于多次借款用户：{num(g80["users"])}人、占全部用户{pct(g80["user_share_all"])}，贡献公司约80%的净利润。覆盖90%的{num(allg["users"])}人中，借款11次及以上用户贡献公司{pct(groups[0]["profit_share"])}的净利润；多次借款、高历史贡献与逾期记录可以同时存在。</p>')
    cards=[('覆盖80%净利润的最少用户',num(g80['users'])+'人','占全部统计用户'+pct(g80['user_share_all'])),
           ('覆盖90%净利润的最少用户',num(allg['users'])+'人','占全部统计用户'+pct(allg['user_share_all'])),
           ('核心90%中当前状态8用户',pct(allg['current_status8_share']),num(allg['current_status8_users'])+' / '+num(allg['users'])+'人；全部保留'),
           ('核心90%中曾分期逾期后结清',pct(allg['history_late_then_settled_share']),num(allg['history_late_then_settled_users'])+' / '+num(allg['users'])+'人')]
    parts.append('<div class="cards">'+''.join(f'<div class="card"><h3>{esc(a)}</h3><strong>{esc(b)}</strong><small>{esc(c)}</small></div>' for a,b,c in cards)+'</div>')
    parts.append(f'<p>核心用户中，{pct(allg["ever_gap7_share"])}曾在完全结清后的7天内未再提单；按结清事件统计，该比例为{pct(allg["gap7_event_share"])}。历史发生过提单中断，不代表用户之后一直没有回来。</p>')
    parts.append('<p class="note">利润窗口：2025-01-01—2026-09-30成功放款订单，按当前还款金额减放款本金。公司净利润包含负贡献抵消；覆盖90%净利润不等于覆盖90%盈利用户的正利润。所有状态8用户保留，本报告只描述客群，不筛选运营可触达资格。</p>')
    parts.append(details('展开50%—90%利润覆盖人数及金额',table(['目标净利润覆盖','最少用户数','占全部用户','名单实际利润','实际覆盖','其中当前状态8占比'],[[f'{r["target_pct"]}%',num(r['minimum_users']),pct(r['user_share']),num(r['profit'],2),pct(r['profit_share']),pct(p['current_status8_share'])] for r,p in zip(d['coverage'],d['coverage_profiles'])])))
    parts.append('</section><section id="profiles"><h2>三类核心用户，借款习惯有什么不同</h2><p class="note">以下三类互斥，合计为历史贡献前90%名单；不代表全部用户中该借款次数的所有人。按生命周期成功借款次数划分，状态8不参与分组。</p><div class="profiles">')
    for label,g in zip(labels,groups):
        parts.append(f'<article class="profile"><h3>{esc(label)}</h3><p><b>{num(g["users"])}人</b> · 贡献公司净利润<b>{pct(g["profit_share"])}</b></p><div class="tag">借款次数中位数 {num(g["life_loan_median"],1)}次</div><div class="tag">单笔放款 {num(g["principal_per_scoped_order"],2)}</div><p>用户典型借款间隔：<b>{num(g["borrow_gap_user_median"],2)}天</b>；曾有循环贷放款的用户占<b>{pct(g["cycle_user_share"])}</b>。</p><p>完全结清后曾7天未再提单：<b>{pct(g["ever_gap7_share"])}</b>（{num(g["ever_gap7_users"])} / {num(g["mature7_users"])}人）；当前状态8占<b>{pct(g["current_status8_share"])}</b>。</p></article>')
    parts.append('</div>')
    parts.append(f'<p class="conclusion">借款11次及以上组的典型借款间隔为{num(groups[0]["borrow_gap_user_median"],2)}天，完全结清后再提单的典型间隔为{num(groups[0]["return_gap_user_median"],2)}天。该组7天未再提单事件率为{pct(groups[0]["gap7_event_share"])}，低于6—10次组的{pct(groups[1]["gap7_event_share"])}和5次及以下组的{pct(groups[2]["gap7_event_share"])}，复借更快。</p>')
    old80=d['coverage'][3];base=d['baseline']
    parts.append(f'<p class="conclusion">覆盖80%净利润的用户，平均生命周期借款{num(old80["mean_lifetime_loans"],2)}次，全体用户为{num(base["mean_lifetime_loans"],2)}次；统计期单笔平均放款{num(old80["avg_remit_per_order"],2)}，全体为{num(base["avg_remit_per_order"],2)}。这批用户同时具有借款次数多、单笔金额较高的特征。</p>')
    parts.append(details('展开核心80%与全部用户的基础特征对比',table(['指标','全部统计用户','覆盖80%最小名单'],[
       ['用户数',num(d['company']['total_users']),num(old80['users'])],
       ['平均生命周期成功借款次数',num(base['mean_lifetime_loans'],2),num(old80['mean_lifetime_loans'],2)],
       ['借款至少6次用户占比',pct(base['share_loans_ge6']),pct(old80['share_loans_ge6'])],
       ['统计期单笔平均放款金额',num(base['avg_remit_per_order'],2),num(old80['avg_remit_per_order'],2)],
       ['统计期订单当前已结清占比',pct(base['settled_order_share']),pct(old80['settled_order_share'])],
       ['统计期续贷订单占比（非循环贷口径）',pct(base['reloan_order_share']),pct(old80['reloan_order_share'])]
    ])))
    parts.append(chart('各类用户典型借款与结清后再提单间隔',labels,[{'name':'相邻成功借款间隔','color':colors[0],'values':[g['borrow_gap_user_median'] for g in groups]}, {'name':'完全结清后再提单间隔','color':colors[1],'values':[g['return_gap_user_median'] for g in groups]}],False,'天'))
    parts.append('<p class="chart-note">先计算每位用户的历史间隔中位数，再取客群用户中位数。结清后间隔仅使用已观察到下次提单的事件，未再提单不填0；两个指标衡量不同阶段，不能直接相减。</p>')
    parts.append(details('展开客群完整特征对比表',table(['指标']+labels,[
      ['用户数']+[num(g['users']) for g in groups],['公司净利润贡献占比']+[pct(g['profit_share']) for g in groups],
      ['生命周期借款次数中位数']+[num(g['life_loan_median'],1) for g in groups],['单笔平均放款金额（统计期）']+[num(g['principal_per_scoped_order'],2) for g in groups],
      ['相邻借款间隔：用户中位数的中位数/天']+[num(g['borrow_gap_user_median'],2) for g in groups],
      ['完全结清至下次提单：用户中位数的中位数/天']+[num(g['return_gap_user_median'],2) for g in groups],
      ['曾整笔提前结清用户占比']+[pct(g['early_settled_user_share']) for g in groups],['统计期订单当前已结清占比']+[pct(g['scoped_settled_order_share']) for g in groups],
      ['曾循环贷成功放款用户占比']+[pct(g['cycle_user_share']) for g in groups],['全部历史放款订单中循环贷占比']+[pct(g['cycle_order_share']) for g in groups],
      ['最近一次放款是循环贷的用户占比']+[pct(g['latest_funded_cycle_share']) for g in groups],['最近一次获额是循环贷的用户占比']+[pct(g['latest_offer_cycle_share']) for g in groups]
    ])))
    parts.append('</section><section id="history"><h2>历史分期逾期后结清，与当前逾期分开看</h2>')
    parts.append(chart('历史分期逾期后结清与当前状态8用户占比',labels,[{'name':'曾分期逾期后整笔结清','color':colors[1],'values':[g['history_late_then_settled_share'] for g in groups]},{'name':'当前有状态8订单','color':'#ff7a83','values':[g['current_status8_share'] for g in groups]}],ceiling=1.05))
    parts.append(f'<p class="conclusion">历史核心90%名单中，{num(allg["history_late_then_settled_users"])}人曾有分期逾期后整笔结清，{num(allg["current_status8_users"])}人当前仍持有状态8订单。两个标记可以重叠：曾经结清过逾期贷款的用户，也可能在后续订单再次逾期。</p>')
    parts.append('<p class="chart-note">历史标记取全生命周期分期记录：任一期overdue_days_period&gt;0，或实际分期还款日期晚于分期应还日期，且该整笔贷款后来已结清。两组柱图分母均为该客群全部用户；当前状态8来自特征快照。</p>')
    parts.append(details('展开互斥逾期特征分类及明细统计',table(['特征分类','用户数','占核心90%名单','历史利润','占公司净利润'],[[r['label'],num(r['users']),pct(r['share']),num(r['profit'],2),pct(r['profit_share'])] for r in d['history_types']])+table(['客群','曾逾期后结清用户/全组用户','曾逾期后结清订单/历史已结清订单'],[[labels[i],f'{num(g["history_late_then_settled_users"])} / {num(g["users"])}',f'{num(g["history_late_then_settled_orders"])} / {num(g["settled_history_orders"])}（{pct(g["history_late_then_settled_order_share"])}）'] for i,g in enumerate(groups)])))
    parts.append('</section><section id="retention"><h2>完全结清后，是否曾5天或7天未再提单</h2>')
    parts.append(chart('曾发生完全结清后5天及7天未提单的用户占比',labels,[{'name':'曾5天未再提单的用户','color':colors[0],'values':[g['ever_gap5_share'] for g in groups]},{'name':'曾7天未再提单的用户','color':colors[2],'values':[g['ever_gap7_share'] for g in groups]}],ceiling=1.05))
    parts.append('<p class="chart-note">上图为用户口径：分母分别为该客群至少有1次已观察满5天、7天的完全结清事件的用户。完全结清指用户名下全部已放款订单均已结清。5天、7天为精确120/168小时，未成熟事件不进入分母。</p>')
    parts.append(f'<p class="conclusion">整体共有{num(allg["full_clear_mature7"])}次观察成熟的完全结清事件，其中{num(allg["gap7_events"])}次在7天内未再提单，占{pct(allg["gap7_event_share"])}；其中{num(allg["returned_after7_events"])}次后来仍再次提单。该指标描述“阶段性中断”，不能直接认定永久流失。</p>')
    parts.append(chart('观察满7天的完全结清事件：后续提单间隔',[r['label'] for r in d['return_gap_distribution']],[{'name':'成熟完全结清事件占比','color':colors[0],'values':[r['share'] for r in d['return_gap_distribution']]}],ceiling=max(.3,max(r['share'] for r in d['return_gap_distribution'])*1.15)))
    parts.append(details('展开用户口径与事件口径的分子分母',table(['客群','5天中断用户/成熟用户','5天中断事件/成熟事件','7天中断用户/成熟用户','7天中断事件/成熟事件','当前结清后仍未再提单超过7天人数'],[[labels[i],f'{num(g["ever_gap5_users"])} / {num(g["mature5_users"])}（{pct(g["ever_gap5_share"])}）',f'{num(g["gap5_events"])} / {num(g["full_clear_mature5"])}（{pct(g["gap5_event_share"])}）',f'{num(g["ever_gap7_users"])} / {num(g["mature7_users"])}（{pct(g["ever_gap7_share"])}）',f'{num(g["gap7_events"])} / {num(g["full_clear_mature7"])}（{pct(g["gap7_event_share"])}）',num(g['currently_waiting_after_clear7_users'])] for i,g in enumerate(groups)])+table(['下次提单间隔','事件数','占观察成熟事件'],[[r['label'],num(r['events']),pct(r['share'])] for r in d['return_gap_distribution']])))
    parts.append('</section><section id="usage"><h2>额度使用率与循环贷习惯</h2>')
    parts.append(chart('提单额度使用率：订单均值与总额加权比率',labels,[{'name':'有效提单订单使用率均值','color':colors[0],'values':[g['usage_mean_order'] for g in groups]},{'name':'总提单金额 / 总获额额度','color':colors[1],'values':[g['usage_weighted'] for g in groups]}]))
    parts.append(f'<p class="conclusion">核心90%名单的提单额度使用率均值为{pct(allg["usage_mean_order"])}，总额加权比率为{pct(allg["usage_weighted"])}；{pct(allg["cycle_user_share"])}的用户曾有循环贷成功放款。额度使用率与循环贷使用反映资金使用习惯，不直接代表信用资质好坏。</p>')
    parts.append(f'<p class="chart-note">额度使用率使用2025-01-01—2026-09-30提单订单。分母来自同用户、同订单、提单前最近一次通过获额的max_credit_apply_amt；分子为apply_amt。有效匹配{num(allg["usage_orders"])} / {num(allg["usage_attempts"])}笔，覆盖{pct(allg["usage_coverage"])}；超过100%的{num(allg["usage_gt100_orders"])}笔原样保留，未截断。循环贷用户指全历史至少有一笔recycle_type=2成功放款订单。</p>')
    parts.append(f'<p class="note">超过100%的记录占有效匹配订单{pct(allg["usage_gt100_orders"]/allg["usage_orders"])}。本指标严格表示apply_amt与获额额度之比；两金额字段是否包含相同费用尚未核实，不据此认定用户超额借款。5次及以下组单笔平均放款{num(groups[2]["principal_per_scoped_order"],2)}、使用率均值{pct(groups[2]["usage_mean_order"])}，均高于11次及以上组。</p>')
    parts.append(details('展开额度匹配覆盖与循环贷数据',table(['客群','有效额度匹配/提单订单','使用率均值','总额加权比率','超过100%订单数','循环贷用户/全组','循环贷放款订单/全部历史放款订单'],[[labels[i],f'{num(g["usage_orders"])} / {num(g["usage_attempts"])}（{pct(g["usage_coverage"])}）',pct(g['usage_mean_order']),pct(g['usage_weighted']),num(g['usage_gt100_orders']),f'{num(g["cycle_users"])} / {num(g["users"])}（{pct(g["cycle_user_share"])}）',f'{num(g["cycle_funded_orders"])} / {num(g["funded_orders"])}（{pct(g["cycle_order_share"])}）'] for i,g in enumerate(groups)])))
    parts.append('</section><section id="latest"><h2>当前无状态8用户，最新一笔获额是否通过</h2>')
    parts.append(chart('无当前状态8用户内的最新获额结果',labels,[{'name':'最新获额通过','color':colors[1],'values':[g['no8_latest_pass_share'] for g in groups]},{'name':'最新获额未通过','color':'#ff7a83','values':[g['no8_latest_notpass_share'] for g in groups]}],ceiling=1.05))
    parts.append(f'<p class="conclusion">历史核心90%名单中，无当前状态8用户{num(allg["no_current8_users"])}人：最新获额通过{num(allg["no8_latest_pass_users"])}人（{pct(allg["no8_latest_pass_share"])}），未通过{num(allg["no8_latest_notpass_users"])}人（{pct(allg["no8_latest_notpass_share"])}），结果缺失或未知{num(allg["no8_latest_unknown_users"])}人（{pct(allg["no8_latest_unknown_share"])}）。这些是客群现状描述，本轮不据此排除任何人。</p>')
    parts.append('<p class="chart-note">最新获额从全部获额订单中按获额时间取最后一笔；同一时刻取serial_id最大，再以vir_rnb打破剩余并列。沿用is_pass1：1为通过、0为未通过。未通过不等同已经确认风控拒绝；通过也不直接等同当前具备所有提单条件。</p>')
    parts.append(details('展开最新获额结果及分母',table(['客群','全组用户','当前状态8用户','无当前状态8用户（分母）','最新获额通过','最新获额未通过','结果缺失或未知'],[[labels[i],num(g['users']),f'{num(g["current_status8_users"])}（{pct(g["current_status8_share"])}）',num(g['no_current8_users']),f'{num(g["no8_latest_pass_users"])}（{pct(g["no8_latest_pass_share"])}）',f'{num(g["no8_latest_notpass_users"])}（{pct(g["no8_latest_notpass_share"])}）',f'{num(g["no8_latest_unknown_users"])}（{pct(g["no8_latest_unknown_share"])}）'] for i,g in enumerate(groups)])))
    parts.append('<div class="interactive"><label for="coverage-selector">切换累计核心名单：</label><select id="coverage-selector">'+''.join(f'<option value="{i}" {"selected" if i==4 else ""}>覆盖{50+i*10}%净利润</option>' for i in range(5))+'</select><div id="coverage-detail" aria-live="polite"></div></div>')
    parts.append('</section><section id="definitions"><h2>指标口径与数据边界</h2>')
    definitions_names={'profit':'利润与统计订单','lifetime_count':'生命周期借款次数','historical_overdue_resolved':'先分期逾期、后整笔结清','full_clear':'用户名下完全结清事件','gap5_7':'5天/7天未再提单','gap_user_vs_event':'用户率和事件率分母','return_gap':'结清后再提单间隔','usage':'提单额度使用率','current_overdue':'当前逾期用户','latest_offer':'无当前逾期内的最新获额结果','cycle_user':'循环贷用户','borrow_gap':'借款间隔','early_settlement':'提前结清','limitations':'解释边界'}
    parts.append(f'<p>利润名单冻结时点（北京时间）：{esc(d["meta"]["cohort_snapshot_shanghai"])}；生命周期特征快照（北京时间）：{esc(d["meta"]["feature_snapshot_shanghai"])}。所有业务日期和事件时间均按America/Belize处理。</p>')
    parts.append(details('展开完整指标定义', ''.join(f'<p class="definition"><b>{definitions_names[k]}：</b>{esc(v)}</p>' for k,v in d['feature_definitions'].items())))
    qa=d['qa'];parts.append(f'<p class="note">核对：核心用户{num(allg["users"])}人均保留；特征快照相对利润快照，状态8标记变化{num(qa["current_status8_changed_vs_frozen"])}人、生命周期成功借款次数变化{num(qa["lifetime_count_changed_vs_frozen"])}人、统计期利润变化{num(qa["source_profit_changed_vs_frozen_users"])}人。利润分组和贡献不随本轮特征提取重排。</p>')
    parts.append(details('展开数据完整性检查',table(['检查项','结果'],[[k,str(v)] for k,v in qa.items() if k not in ['offer_pass_flags']])))
    parts.append('</section><section id="appendix"><h2>附录：复原报告代码</h2>')
    # Everything, including the count of files, remains collapsed by default.
    files=['extract.py','extract_supplement.py','extract_offers_compact.py','finalize_extraction.py','analyze.py','build_report.py','cohort_query.sql','loans_query.sql','periods_query.sql','offers_query.sql','recycle_query.sql']
    code='<p class="note">完整代码共'+str(len(files))+'个文件。汇总结果可直接复原网页；重新提取用户级历史需数据库只读权限和利润名单输入。公开网页包仅含汇总数据与代码。</p><p><a href="复原报告代码.zip">下载代码与汇总结果</a> · <a href="analysis.json">下载报告汇总数据</a></p>'
    for name in files:code+=details(name,'<pre><code>'+esc((W/name).read_text())+'</code></pre>')
    parts.append(details('展开完整SQL / Python代码与下载',code));parts.append('</section>')
    payload=json.dumps(d['coverage_profiles'],ensure_ascii=False).replace('</','<\\/')
    parts.append('<script id="coverage-data" type="application/json">'+payload+'</script><script>const profiles=JSON.parse(document.getElementById("coverage-data").textContent);const fmt=x=>x==null?"—":(x*100).toFixed(2)+"%";const n=x=>new Intl.NumberFormat("zh-CN").format(x);function refresh(){const g=profiles[document.getElementById("coverage-selector").value];document.getElementById("coverage-detail").innerHTML=`<p class="conclusion">${g.label}：${n(g.users)}人；当前状态8占${fmt(g.current_status8_share)}；曾逾期后结清占${fmt(g.history_late_then_settled_share)}；曾7天未再提单占${fmt(g.ever_gap7_share)}（分母${n(g.mature7_users)}人）；循环贷用户占${fmt(g.cycle_user_share)}；无状态8的${n(g.no_current8_users)}人中，最新获额通过${fmt(g.no8_latest_pass_share)}、未通过${fmt(g.no8_latest_notpass_share)}。</p>`}document.getElementById("coverage-selector").addEventListener("change",refresh);refresh();</script>')
    parts.append('</main></body></html>');report=''.join(parts)
    assert not re.search(r'<details[^>]*\bopen(?:\s|>)',report)
    assert 'user_id' not in report.split('<section id="appendix">')[0]
    target=OUT/'核心利润客群_用户生命周期特征分析报告.html';target.write_text(report)
    (OUT/'analysis.json').write_text(json.dumps(d,ensure_ascii=False,indent=2))
    code_dir=OUT/'复原代码';code_dir.mkdir(exist_ok=True)
    for name in files:shutil.copy2(W/name,code_dir/name)
    shutil.copy2(W/'analysis.json',code_dir/'analysis.json')
    (code_dir/'README.txt').write_text('核心利润客群生命周期特征分析\n\n离线复原网页：python3 build_report.py（与analysis.json置于同目录）。可设置CORE_CUSTOMER_REPORT_OUT指定输出目录。\n重新提取：设置CORE_CUSTOMER_COHORT_JSON为前次利润集中度结果JSON文件；配置DB_HOST、DB_PORT、DB_NAME、DB_USER、DB_PASSWORD，以只读用户依次运行extract.py、analyze.py、build_report.py。extract.py中的本机连接回退为当前工作区兼容入口；其他环境请提供环境变量。需要pandas、numpy、psycopg2、pgpy、pyarrow。使用缓存提取必须具备完整extraction_manifest.json和匹配SHA256。\n利润名单冻结于前次快照，公开包不包含用户ID、订单ID或明细缓存。重新取数会随源副本后补发生变化。\n')
    with zipfile.ZipFile(OUT/'复原报告代码.zip','w',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(code_dir.iterdir()):z.write(p,p.name)
    print(json.dumps({'file':str(target),'bytes':target.stat().st_size,'figures':report.count('<svg '),'all_tables_collapsed':True,'source_files':len(files)},ensure_ascii=False))

if __name__=='__main__':main()
