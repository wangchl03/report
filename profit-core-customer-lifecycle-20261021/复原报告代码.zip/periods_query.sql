SELECT p.user_id,p.serial_id,COUNT(*)::bigint period_rows,
         MAX(CASE WHEN p.overdue_days_period>0 OR (p.is_repaid_period=1
          AND p.repaid_date_period>p.due_date_period AND p.repaid_date_period>=DATE '2000-01-01')
          THEN 1 ELSE 0 END) AS has_late_period
         FROM wangchuanliang.repayment_plan_v2_copy p
         WHERE p.user_id IN (SELECT unnest(%(users)s::bigint[])) GROUP BY p.user_id,p.serial_id