"""Describe frozen historical-profit cohorts, retaining every current status 8 user."""
from pathlib import Path
import os,json,statistics,math
from decimal import Decimal
import numpy as np
import pandas as pd
W=Path(__file__).resolve().parent
COHORT=Path(os.environ.get('CORE_CUSTOMER_COHORT_JSON',str(W.parent/'profit_concentration_20250101_20260930_20261021/result.json')))
DAY=pd.Timedelta(days=1)

def safe(v):
    if isinstance(v,dict):return {k:safe(x) for k,x in v.items()}
    if isinstance(v,list):return [safe(x) for x in v]
    if v is None:return None
    if isinstance(v,(pd.Timestamp,)):return v.isoformat()
    if isinstance(v,(np.integer,)):return int(v)
    if isinstance(v,(np.bool_,)):return bool(v)
    if isinstance(v,(Decimal,)):return str(v)
    if isinstance(v,(float,np.floating)) and not math.isfinite(v):return None
    return v
def ratio(n,d):return float(n/d) if d else None
def median(x):
    a=[float(v) for v in x if v is not None and pd.notna(v)];return float(np.median(a)) if a else None
def dates(df,t,d,cutoff):
    ts=pd.to_datetime(df[t],errors='coerce');ds=pd.to_datetime(df[d],errors='coerce')
    valid=ts.ge('2000-01-01')&ts.le(cutoff)
    fallback=(~valid)&ds.ge('2000-01-01')&ds.le(cutoff.normalize())
    return ts.where(valid,ds.where(fallback)),int(fallback.sum())

def main():
    d=json.loads(COHORT.read_text());manifest=json.loads((W/'extraction_manifest.json').read_text());assert manifest['complete']
    cutoff=pd.Timestamp(manifest['business_cutoff']);start=pd.Timestamp('2025-01-01');end=pd.Timestamp('2026-10-01')
    L=pd.read_pickle(W/'loans.pkl.gz');P=pd.read_pickle(W/'periods.pkl.gz');O=pd.read_pickle(W/'offers.pkl.gz');R=pd.read_pickle(W/'recycle.pkl.gz')
    assert not L.serial_id.duplicated().any()
    duplicate_types=int(R.serial_id.duplicated().sum());assert not (R.groupby('serial_id').recycle_type.nunique()>1).any()
    R=R.drop_duplicates('serial_id');L=L.merge(R,on='serial_id',how='left',validate='many_to_one');O=O.merge(R,on='serial_id',how='left',validate='many_to_one')
    qa={'loans':len(L),'periods':len(P),'offers':len(O),'recycle_duplicate_same_type_rows':duplicate_types}
    qa['offer_extract_equivalence']=('Only latest user offers and exact pre-application offers transferred; selected from all history with no loss of requested metrics.' if manifest['tables']['offers'].get('compact_equivalent_latest_and_utilization_offers') else 'Complete source offers transferred.')
    for t,dt in [('apply_time','apply_date'),('remit_time','remit_date'),('repaid_time','repaid_date')]:
        L[t+'_valid'],qa[t+'_date_fallback']=dates(L,t,dt,cutoff)
    for c in ['apply_amt','remit_amt','repaid_amt']:L[c]=pd.to_numeric(L[c],errors='coerce')
    L['apply_t']=L.apply_time_valid;L['remit_t']=L.remit_time_valid;L['settle_t']=L.repaid_time_valid.where(L.is_repaid.eq(1))
    status_flags=L.groupby('user_id').loan_status_code.agg(has8=lambda s:bool(s.eq(8).any()),has5=lambda s:bool(s.eq(5).any()))
    qa['future_or_missing_apply_rows']=int(L.apply_t.isna().sum())
    L=L.loc[L.apply_t.notna()].copy()
    F=L.loc[L.is_remit.eq(1)&L.remit_t.notna()].copy()
    F['invalid_settle_t']=F.is_repaid.eq(1)&(F.settle_t.isna()|F.settle_t.lt(F.remit_t))
    qa['settled_missing_or_pre_remit_timestamp_orders']=int(F.invalid_settle_t.sum())
    F.loc[F.invalid_settle_t,'settle_t']=pd.NaT
    F['early_settled']=F.settle_t.notna()&F.settle_t.dt.normalize().lt(pd.to_datetime(F.due_date,errors='coerce'))
    if 'has_late_period' in P:
        assert not P.serial_id.duplicated().any()
        PG=P.set_index('serial_id')[['period_rows','has_late_period']].copy()
        PG['has_late_period']=PG.has_late_period.eq(1)
        qa['period_source_rows_aggregated']=int(P.period_rows.sum())
        qa['period_history_transfer']='per-order MAX historical-lateness marker, computed from complete source installment rows'
    else:
        P['repaid_period_t'],qa['period_repaid_date_fallback']=dates(P,'repaid_time_period','repaid_date_period',cutoff)
        P['due_d']=pd.to_datetime(P.due_date_period,errors='coerce')
        P['ever_late_period']=P.overdue_days_period.gt(0)|(P.is_repaid_period.eq(1)&P.repaid_period_t.dt.normalize().gt(P.due_d))
        qa['duplicate_period_rows']=int(P.duplicated(['serial_id','current_term']).sum())
        PG=P.groupby('serial_id').agg(period_rows=('current_term','size'),has_late_period=('ever_late_period','max'))
    F=F.join(PG,on='serial_id');F['late_then_settled']=F.has_late_period.fillna(False)&F.is_repaid.eq(1)&F.settle_t.notna()
    qa['funded_orders_missing_periods']=int(F.period_rows.isna().sum())
    O['offer_t']=pd.to_datetime(O.vir_unix,unit='s',errors='coerce')-pd.Timedelta(hours=6)
    O['credit_amt']=pd.to_numeric(O.credit_amt,errors='coerce')
    qa['offer_rows_with_invalid_or_future_event_time']=int((~(O.offer_t.ge('2000-01-01')&O.offer_t.le(cutoff))).sum())
    O=O.loc[O.offer_t.ge('2000-01-01')&O.offer_t.le(cutoff)].copy()
    O=O.sort_values(['offer_t','serial_id','vir_rnb']).drop_duplicates(['user_id','serial_id','vir_unix','vir_rnb'],keep='last')
    qa['offer_pass_flags']=O.groupby(['is_pass1','vir_status_code'],dropna=False).size().reset_index(name='rows').to_dict('records')
    A=L.loc[L.apply_amt.gt(0)].copy()
    right=O[['user_id','serial_id','offer_t','credit_amt','is_pass1']].sort_values('offer_t')
    match=pd.merge_asof(A[['user_id','serial_id','apply_t','apply_amt']].sort_values('apply_t'),right,
                       by=['user_id','serial_id'],left_on='apply_t',right_on='offer_t',direction='backward',allow_exact_matches=True)
    match['valid_usage']=match.is_pass1.eq(1)&match.credit_amt.gt(0)
    match['usage']=np.where(match.valid_usage,match.apply_amt/match.credit_amt,np.nan)
    M=match.loc[match.apply_t.ge(start)&match.apply_t.lt(end)].copy()
    qa['usage_period_submitted_orders']=len(M);qa['usage_period_matched_orders']=int(M.valid_usage.sum())
    qa['usage_over100_orders']=int(M.usage.gt(1).sum())
    qa['funded_history_extent']=[str(F.remit_t.min()),str(F.remit_t.max())]
    qa['apply_history_extent']=[str(L.apply_t.min()),str(L.apply_t.max())]
    groups_L={int(k):v.sort_values(['apply_t','serial_id']) for k,v in L.groupby('user_id')}
    groups_F={int(k):v.sort_values(['remit_t','serial_id']) for k,v in F.groupby('user_id')}
    groups_O={int(k):v.sort_values(['offer_t','serial_id','vir_rnb']) for k,v in O.groupby('user_id')}
    groups_M={int(k):v for k,v in M.groupby('user_id')}
    rows=[];all_clear=[]
    for orig in d['members']:
        uid=orig['user_id'];a=groups_L.get(uid,L.iloc[:0]);f=groups_F.get(uid,F.iloc[:0]);o=groups_O.get(uid,O.iloc[:0]);m=groups_M.get(uid,M.iloc[:0]);valid=m.loc[m.valid_usage]
        row={**orig,'current_lifetime_loans':len(f),'lifetime_apply_orders':len(a),
             'current_has8':bool(status_flags.loc[uid,'has8']),'current_has5':bool(status_flags.loc[uid,'has5']),
             'median_borrow_gap_days':median(f.remit_t.diff().dt.total_seconds()/86400),
             'mean_borrow_gap_days':float((f.remit_t.max()-f.remit_t.min())/DAY/(len(f)-1)) if len(f)>1 else None,
             'same_day_repeat_borrow_gaps':int(f.remit_t.dt.normalize().diff().eq(pd.Timedelta(0)).sum()),
             'has_late_then_settled':bool(f.late_then_settled.any()),'late_then_settled_orders':int(f.late_then_settled.sum()),
             'settled_history_orders':int(f.is_repaid.eq(1).sum()),'period_known_orders':int(f.period_rows.notna().sum()),
             'has_early_settled':bool(f.early_settled.any()),'early_settled_orders':int(f.early_settled.sum()),
             'cycle_funded_orders':int(f.recycle_type.eq(2).sum()),'has_cycle_funded':bool(f.recycle_type.eq(2).any()),
             'cycle_type_known_orders':int(f.recycle_type.notna().sum()),'latest_funded_is_cycle':bool(len(f) and f.iloc[-1].recycle_type==2),
             'usage_orders':len(valid),'usage_attempts':len(m),'usage_sum':float(valid.usage.sum()),
             'usage_apply_amt':float(valid.apply_amt.sum()),'usage_credit_amt':float(valid.credit_amt.sum()),
             'usage_gt100_orders':int(valid.usage.gt(1).sum()),
             'user_mean_usage':float(valid.usage.mean()) if len(valid) else None,
             'latest_offer_pass':int(o.iloc[-1].is_pass1) if len(o) and pd.notna(o.iloc[-1].is_pass1) else None,
             'latest_offer_date':o.iloc[-1].offer_t.isoformat() if len(o) else None,
             'latest_offer_is_cycle':bool(len(o) and o.iloc[-1].recycle_type==2),
             'latest_offer_credit':float(o.iloc[-1].credit_amt) if len(o) and pd.notna(o.iloc[-1].credit_amt) else None,
             'funded_orders':len(f),'has_incomplete_timeline':bool(f.invalid_settle_t.any())}
        # A complete-settlement anchor must leave ZERO of this user's prior disbursements outstanding.
        # Group simultaneous openings and closings before assessing the balance; one settled loan alone is insufficient.
        opens=pd.DataFrame({'t':f.remit_t,'delta':1,'is_close':0})
        close_f=f.loc[f.settle_t.notna()]
        closes=pd.DataFrame({'t':close_f.settle_t,'delta':-1,'is_close':1})
        timeline=pd.concat([opens,closes]).groupby('t').agg(delta=('delta','sum'),is_close=('is_close','sum')).sort_index()
        timeline['active_after']=timeline.delta.cumsum()
        assert (timeline.active_after>=0).all(),uid
        anchors=timeline.loc[timeline.is_close.gt(0)&timeline.active_after.eq(0)].index
        applies=a.apply_t.to_numpy(dtype='datetime64[ns]')
        events=[]
        for t in anchors:
            idx=np.searchsorted(applies,t.to_datetime64(),side='left')
            next_t=pd.Timestamp(applies[idx]) if idx<len(applies) else None
            elapsed=float((cutoff-t)/DAY);gap=float((next_t-t)/DAY) if next_t is not None else None
            event={'user_id':uid,'t':t,'next_t':next_t,'observed_days':elapsed,'gap_days':gap,
                   'mature5':elapsed>=5,'mature7':elapsed>=7,
                   'gap5':elapsed>=5 and (gap is None or gap>5),'gap7':elapsed>=7 and (gap is None or gap>7),
                   'returned_after7':gap is not None and gap>7,'in_profit_period':start<=t<end}
            events.append(event);all_clear.append(event)
        row.update({'full_clear_events':len(events),
                    'full_clear_mature5':sum(e['mature5'] for e in events),'full_clear_gap5':sum(e['gap5'] for e in events),
                    'full_clear_mature7':sum(e['mature7'] for e in events),'full_clear_gap7':sum(e['gap7'] for e in events),
                    'full_clear_returned_after7':sum(e['returned_after7'] for e in events),
                    'has_gap5':any(e['gap5'] for e in events),'has_gap7':any(e['gap7'] for e in events),
                    'return_gaps_observed':len([e for e in events if e['gap_days'] is not None]),
                    'return_gap_median_days':median(e['gap_days'] for e in events if e['gap_days'] is not None),
                    'latest_clear_waiting_days':float((cutoff-events[-1]['t'])/DAY) if events and events[-1]['next_t'] is None else None,
                    'current_all_loans_settled':bool(len(f) and (f.is_repaid.eq(1)&f.settle_t.notna()).all())})
        rows.append(row)
    U=pd.DataFrame(rows);E=pd.DataFrame(all_clear)
    assert len(U)==6144 and U.user_id.nunique()==6144
    qa['current_status8_changed_vs_frozen']=int((U.current_has8.astype(int)!=U.has_current_status8).sum())
    qa['lifetime_count_changed_vs_frozen']=int(U.current_lifetime_loans.ne(U.lifetime_loans).sum())
    scoped_now=F.loc[pd.to_datetime(F.remit_date).ge(start)&pd.to_datetime(F.remit_date).lt(end)].copy()
    scoped_now['profit_now']=scoped_now.repaid_amt-scoped_now.remit_amt
    profit_now=scoped_now.groupby('user_id').profit_now.sum()
    qa['source_profit_changed_vs_frozen_users']=int(sum(not math.isclose(float(profit_now.get(r.user_id,0)),float(r.profit),abs_tol=.005) for r in U.itertuples()))
    # No current-status or application-eligibility filters are applied to any cohort.
    def summary(u,label):
        uid=set(u.user_id);e=E.loc[E.user_id.isin(uid)];mv=u.usage_orders.sum();fund=u.funded_orders.sum()
        clear5=u.full_clear_mature5.gt(0);clear7=u.full_clear_mature7.gt(0);no8=~u.current_has8
        profit=sum((Decimal(v) for v in u.profit),Decimal(0))
        return {'label':label,'users':len(u),'profit':str(profit),'profit_share':float(profit/Decimal(d['totals']['total_profit'])),
         'user_share_all':ratio(len(u),d['totals']['total_users']),'life_loan_median':median(u.lifetime_loans),'life_loan_mean':float(u.lifetime_loans.mean()),
         'borrow_gap_user_median':median(u.median_borrow_gap_days),'borrow_gap_user_mean_median':median(u.mean_borrow_gap_days),
         'return_gap_user_median':median(u.return_gap_median_days),'observed_return_users':int(u.return_gaps_observed.gt(0).sum()),
         'history_late_then_settled_users':int(u.has_late_then_settled.sum()),'history_late_then_settled_share':float(u.has_late_then_settled.mean()),
         'history_late_then_settled_orders':int(u.late_then_settled_orders.sum()),'settled_history_orders':int(u.settled_history_orders.sum()),
         'history_late_then_settled_order_share':ratio(u.late_then_settled_orders.sum(),u.settled_history_orders.sum()),
         'current_status8_users':int(u.current_has8.sum()),'current_status8_share':float(u.current_has8.mean()),
         'no_current8_users':int(no8.sum()),'no8_latest_pass_users':int((no8&u.latest_offer_pass.eq(1)).sum()),
         'no8_latest_notpass_users':int((no8&u.latest_offer_pass.eq(0)).sum()),
         'no8_latest_unknown_users':int((no8&~u.latest_offer_pass.isin([0,1])).sum()),
         'no8_latest_pass_share':ratio((no8&u.latest_offer_pass.eq(1)).sum(),no8.sum()),
         'no8_latest_notpass_share':ratio((no8&u.latest_offer_pass.eq(0)).sum(),no8.sum()),
         'no8_latest_unknown_share':ratio((no8&~u.latest_offer_pass.isin([0,1])).sum(),no8.sum()),
         'cycle_users':int(u.has_cycle_funded.sum()),'cycle_user_share':float(u.has_cycle_funded.mean()),
         'cycle_funded_orders':int(u.cycle_funded_orders.sum()),'funded_orders':int(fund),
         'cycle_order_share':ratio(u.cycle_funded_orders.sum(),fund),'latest_funded_cycle_share':float(u.latest_funded_is_cycle.mean()),
         'latest_offer_cycle_share':float(u.latest_offer_is_cycle.mean()),
         'usage_orders':int(mv),'usage_attempts':int(u.usage_attempts.sum()),'usage_coverage':ratio(mv,u.usage_attempts.sum()),
         'usage_mean_order':ratio(u.usage_sum.sum(),mv),'usage_weighted':ratio(u.usage_apply_amt.sum(),u.usage_credit_amt.sum()),
         'usage_user_median':median(u.user_mean_usage),'usage_gt100_orders':int(u.usage_gt100_orders.sum()),
         'full_clear_events':len(e),'full_clear_mature5':int(e.mature5.sum()),'full_clear_mature7':int(e.mature7.sum()),
         'gap5_events':int(e.gap5.sum()),'gap7_events':int(e.gap7.sum()),
         'gap5_event_share':ratio(e.gap5.sum(),e.mature5.sum()),'gap7_event_share':ratio(e.gap7.sum(),e.mature7.sum()),
         'mature5_users':int(clear5.sum()),'mature7_users':int(clear7.sum()),
         'ever_gap5_users':int(u.has_gap5.sum()),'ever_gap7_users':int(u.has_gap7.sum()),
         'ever_gap5_share':ratio(u.has_gap5.sum(),clear5.sum()),'ever_gap7_share':ratio(u.has_gap7.sum(),clear7.sum()),
         'returned_after7_events':int(e.returned_after7.sum()),
         'early_settled_users':int(u.has_early_settled.sum()),'early_settled_user_share':float(u.has_early_settled.mean()),
         'current_all_settled_users':int(u.current_all_loans_settled.sum()),'current_all_settled_share':float(u.current_all_loans_settled.mean()),
         'currently_waiting_after_clear7_users':int(u.latest_clear_waiting_days.gt(7).sum()),
         'principal_per_scoped_order':float(sum(Decimal(v) for v in u.remit_amt)/sum(u.scoped_orders)),
         'scoped_settled_order_share':ratio(sum(u.settled_orders),sum(u.scoped_orders))}
    results=[summary(U,'历史核心90%整体')]
    for label in d['core90_classes']:results.append(summary(U.loc[U.customer_class.eq(label['customer_class'])],label['customer_class']))
    cover=[summary(U.loc[U.profit_rank.le(r['minimum_users'])],f'覆盖{r["target_pct"]}%最小名单') for r in d['coverage']]
    mature=E.loc[E.mature7];gap_dist=[]
    for label,lo,hi in [('0—1天',0,1),('1—3天',1,3),('3—5天',3,5),('5—7天',5,7),('超过7天后再提单',7,float('inf'))]:
        mask=(mature.gap_days.ge(lo) if lo==0 else mature.gap_days.gt(lo))&mature.gap_days.le(hi)
        gap_dist.append({'label':label,'events':int(mask.sum()),'share':ratio(mask.sum(),len(mature))})
    gap_dist.append({'label':'截至观察时点仍未再提单','events':int(mature.next_t.isna().sum()),'share':ratio(mature.next_t.isna().sum(),len(mature))})
    assert sum(x['events'] for x in gap_dist)==len(mature)
    # Mutually exclusive descriptive risk-history types, keeping all records.
    history_types=[]
    for label,mask in [('当前有状态8订单',U.current_has8),('当前无状态8，曾分期逾期后结清',~U.current_has8&U.has_late_then_settled),('当前无状态8，未识别到分期逾期后结清',~U.current_has8&~U.has_late_then_settled)]:
        sub=U.loc[mask];p=sum((Decimal(v) for v in sub.profit),Decimal(0))
        history_types.append({'label':label,'users':len(sub),'share':ratio(len(sub),len(U)),'profit':str(p),'profit_share':float(p/Decimal(d['totals']['total_profit']))})
    assert sum(x['users'] for x in history_types)==len(U)
    public={'meta':{'cohort_snapshot_shanghai':d['meta']['shanghai_cutoff'],'feature_snapshot_shanghai':manifest['shanghai_cutoff'],
                    'feature_snapshot_business':manifest['business_cutoff'],'timezone':'America/Belize','profit_period':['2025-01-01','2026-09-30']},
            'company':{k:d['totals'][k] for k in ['total_users','total_profit','total_orders','positive_user_profit','negative_user_profit']},
            'coverage':d['coverage'],'simple_count_rules':d['loan_count_rules'],'baseline':d['baseline'],
            'groups':results,'coverage_profiles':cover,'return_gap_distribution':gap_dist,'history_types':history_types,'qa':qa,
            'feature_definitions':{
             'profit':'2025-01-01至2026-09-30成功放款订单，当前repaid_amt减remit_amt；未结清及状态8保留，回款不截断至9月30日；利润排序和名单冻结于前次统计快照。',
             'lifetime_count':'截至原利润快照，全历史成功放款订单数；不是当前单的第几次借款。特征取数时点另列。',
             'historical_overdue_resolved':'全历史成功放款订单中，任一期overdue_days_period>0，或实际分期还款日期晚于分期应还日期，且整笔is_repaid=1并有有效结清时间。用户占比分母为该客群全部用户；不是当前仍逾期。',
             'full_clear':'以整笔实际结清时间为事件时点；按用户全部已放款订单的[放款时间,实际结清时间)重建余额，要求该时点结清后所有在借订单数为0。同一时刻多笔结清合为1次事件；不是结清任一单即计。',
             'gap5_7':'全生命周期完全结清事件，观察已满5×24小时/7×24小时才入相应分母；从结清时刻至其后120/168小时内无任何真实订单提单，记5/7天未再提单。包含失败提单；页面进页不算提单。窗口含终点，结清同刻提单记已提单。',
             'gap_user_vs_event':'事件率=未在5/7天内再提单的完全结清事件数/观察成熟事件数；曾发生用户占比=至少发生1次该中断的用户数/至少有1次成熟完全结清事件的用户数。不是所有用户为分母。',
             'return_gap':'仅已观察到下次提单的完全结清事件计算间隔；先取用户内间隔中位数，再取客群用户中位数，仍未再提单不填0。',
             'usage':'统计期内提单订单：同用户同serial_id、提单时点前最近获额记录，要求is_pass1=1且max_credit_apply_amt>0；使用率=apply_amt/max_credit_apply_amt。主指标是有效订单使用率算术平均，并列总提单金额/总额度的加权比率。不用放款金额、不把缺失填0、不截断超过100%的值。',
             'current_overdue':'特征快照下，用户名下任一订单loan_status_code=8；分母为客群全部用户；仅描述不排除。',
             'latest_offer':'用户全部获额记录按vir_unix、serial_id、vir_rnb降序取最新一笔；同一时刻取serial_id最大。仅在无当前状态8用户内计算通过/未通过占比，is_pass1=1为通过、0为未通过；未通过不直接等同风控拒绝，缺失单列。',
             'cycle_user':'全历史至少有1笔成功放款订单，side_recycle_type_copy.recycle_type=2。循环贷用户与续贷用户不是同义词；另列最近放款是否循环贷和循环贷订单占比。',
             'borrow_gap':'按实际成功放款时间排序，相邻成功借款间隔；图表主值先取用户内间隔中位数，再取客群用户中位数。同日借多笔可产生小于1天间隔。',
             'early_settlement':'整笔实际结清日期严格早于整笔最终应还日期，is_repaid=1；用户占比按全组用户计算。',
             'limitations':'历史中断可在之后再次提单，不等同永久流失；本次不做运营可触达筛选。贷款、分期、获额、循环贷类型分表在相邻只读快照提取，事件统一截止贷款特征快照，未取得不可变历史入库快照，源副本后补会影响复跑结果。'} }
    public['meta']['table_snapshots']={k:v.get('snapshot_business',manifest['business_cutoff']) for k,v in manifest['tables'].items()}
    (W/'analysis.json').write_text(json.dumps(safe(public),ensure_ascii=False,indent=2,allow_nan=False))
    U.to_pickle(W/'user_features.pkl.gz');E.to_pickle(W/'full_clear_events.pkl.gz')
    (W/'qa.json').write_text(json.dumps(safe({'passed':True,**qa,'core_users':len(U),'status8_users_retained':int(U.current_has8.sum()),'mature7_events':len(mature),'group_users_sum':sum(g['users'] for g in results[1:])}),ensure_ascii=False,indent=2,allow_nan=False))
    print(json.dumps(safe({'groups':results,'qa':qa,'history_types':history_types,'return_gap_distribution':gap_dist}),ensure_ascii=False,allow_nan=False))

if __name__=='__main__':main()
