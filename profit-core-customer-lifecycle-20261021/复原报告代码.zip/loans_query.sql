SELECT o.user_id,o.serial_id,o.apply_time,o.apply_date,o.apply_amt::text apply_amt,
 o.remit_time,o.remit_date,o.remit_amt::text remit_amt,o.repaid_time,o.repaid_date,o.due_date,
 o.is_remit,o.is_repaid,o.repaid_amt::text repaid_amt,o.loan_status_code,o.overdue_days,o.loan_type,
 o.total_term,o.product_no FROM wangchuanliang.order_loan_f_v2_copy o WHERE o.user_id IN (SELECT unnest(%(users)s::bigint[]))