"""Bounded parallel, read-only supplements; preserve the completed main loan snapshot."""
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import json,base64,secrets,time,hashlib,os,signal
import pandas as pd
import psycopg2
from extract import W,COHORT,queries,connection_kwargs,PGPMessage

def run(name,users):
    t=time.monotonic();frames=[]
    query=queries[name]
    if name=='periods':
        # Only the per-order historical-lateness marker is needed; aggregate before transfer.
        query='''SELECT p.user_id,p.serial_id,COUNT(*)::bigint period_rows,
         MAX(CASE WHEN p.overdue_days_period>0 OR (p.is_repaid_period=1
          AND p.repaid_date_period>p.due_date_period AND p.repaid_date_period>=DATE '2000-01-01')
          THEN 1 ELSE 0 END) AS has_late_period
         FROM wangchuanliang.repayment_plan_v2_copy p
         WHERE p.user_id IN (SELECT unnest(%(users)s::bigint[])) GROUP BY p.user_id,p.serial_id'''
    (W/(name+'_query.sql')).write_text(query)
    with psycopg2.connect(**dict(connection_kwargs(),connect_timeout=20,keepalives=1,keepalives_idle=30,keepalives_interval=10,keepalives_count=3,application_name='core_portrait_supplement_'+name)) as conn:
        conn.set_session(readonly=True,isolation_level='REPEATABLE READ')
        with conn.cursor() as c:
            for setting in ["SET TIME ZONE 'America/Belize'",'SET query_dop=1','SET statement_timeout=300000']:c.execute(setting)
            c.execute("SELECT current_timestamp AT TIME ZONE 'America/Belize',current_setting('transaction_read_only')")
            snap,ro=c.fetchone();assert ro=='on'
            for i in range(8):
                key=secrets.token_urlsafe(32);chunk=users[i::8]
                sql="SELECT COUNT(*),encode(pgp_sym_encrypt(string_agg(row_to_json(q)::text,E'\\n'),%(key)s,'compress-algo=1,compress-level=6,cipher-algo=aes256'),'base64') FROM ("+query+") q"
                c.execute(sql,{'users':'{'+','.join(map(str,chunk))+'}','key':key});count,blob=c.fetchone()
                if count:
                    msg=PGPMessage.from_blob(base64.b64decode(blob)).decrypt(key).message
                    if isinstance(msg,(bytes,bytearray)):msg=bytes(msg).decode()
                    frame=pd.DataFrame([json.loads(line) for line in str(msg).splitlines()])
                else:frame=pd.DataFrame()
                assert len(frame)==count;frames.append(frame)
                print(json.dumps({'table':name,'shard':i,'rows':count,'bytes':len(blob or ''),'seconds':round(time.monotonic()-t,1)}),flush=True)
        conn.rollback()
    df=pd.concat(frames,ignore_index=True);target=W/(name+'.pkl.gz');df.to_pickle(str(target)+'.partial',compression='gzip');Path(str(target)+'.partial').replace(target)
    info={'rows':len(df),'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'snapshot_business':snap.isoformat(),'seconds':round(time.monotonic()-t,1),'read_only':True}
    (W/(name+'_manifest.json')).write_text(json.dumps(info,indent=2))
    return info

def main():
    users=sorted(r['user_id'] for r in json.loads(COHORT.read_text())['members'])
    with ThreadPoolExecutor(max_workers=3) as pool:
        fut={name:pool.submit(run,name,users) for name in ['periods','offers','recycle']}
        results={name:f.result() for name,f in fut.items()}
    (W/'supplement_manifest.json').write_text(json.dumps({'complete':True,'tables':results},indent=2))
    print(json.dumps({'complete':True,'tables':results}),flush=True)

if __name__=='__main__':main()
