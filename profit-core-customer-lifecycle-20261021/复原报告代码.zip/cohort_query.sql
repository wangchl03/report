SET TIME ZONE 'America/Belize';
WITH funded AS (
 SELECT user_id,serial_id,remit_time,remit_date,remit_amt,repaid_amt,is_repaid,loan_status_code,loan_type,total_term,overdue_days
 FROM wangchuanliang.order_loan_f_v2_copy
 WHERE is_remit=1 AND remit_time<=CURRENT_TIMESTAMP AT TIME ZONE 'America/Belize'
), lifetime AS (
 SELECT user_id,COUNT(*) AS lifetime_loans,
 MIN(CASE WHEN remit_date>=DATE '2000-01-01' THEN remit_date END) AS first_remit_date,
 MAX(CASE WHEN remit_date>=DATE '2000-01-01' THEN remit_date END) AS last_remit_date,
 MAX(CASE WHEN loan_status_code=8 THEN 1 ELSE 0 END) AS has_current_status8,
 MAX(CASE WHEN loan_status_code=5 THEN 1 ELSE 0 END) AS has_current_status5,
 MAX(overdue_days) AS max_recorded_overdue_days
 FROM funded GROUP BY user_id
), scoped AS (
 SELECT * FROM funded WHERE remit_date>=DATE '2025-01-01' AND remit_date<DATE '2026-10-01'
), user_profit AS (
 SELECT user_id,COUNT(*) AS scoped_orders,SUM(remit_amt) AS remit_amt,SUM(repaid_amt) AS repaid_amt,
 SUM(repaid_amt-remit_amt) AS profit,
 SUM(CASE WHEN is_repaid=1 THEN 1 ELSE 0 END) AS settled_orders,
 SUM(CASE WHEN loan_status_code=8 THEN 1 ELSE 0 END) AS scoped_status8_orders,
 SUM(CASE WHEN loan_type='reloan' THEN 1 ELSE 0 END) AS reloan_orders,
 SUM(total_term) AS total_terms,SUM(CASE WHEN total_term IS NOT NULL THEN 1 ELSE 0 END) AS known_term_orders
 FROM scoped GROUP BY user_id
), features AS (
 SELECT p.*,l.lifetime_loans,l.first_remit_date,l.last_remit_date,
 l.has_current_status8,l.has_current_status5,l.max_recorded_overdue_days,
 ((CURRENT_TIMESTAMP AT TIME ZONE 'America/Belize')::date-l.last_remit_date) AS days_since_last_remit,
 CASE WHEN l.lifetime_loans>1 THEN (l.last_remit_date-l.first_remit_date)::numeric/(l.lifetime_loans-1) ELSE NULL END AS mean_lifetime_borrow_gap_days
 FROM user_profit p JOIN lifetime l ON l.user_id=p.user_id
), totals AS (
 SELECT COUNT(*) AS total_users,SUM(scoped_orders) AS total_orders,
 SUM(remit_amt) AS total_remit_amt,SUM(repaid_amt) AS total_repaid_amt,SUM(profit) AS total_profit,
 SUM(CASE WHEN profit>0 THEN profit ELSE 0 END) AS positive_user_profit,
 SUM(CASE WHEN profit<0 THEN profit ELSE 0 END) AS negative_user_profit,
 SUM(CASE WHEN profit>0 THEN 1 ELSE 0 END) AS profitable_users,
 SUM(lifetime_loans) AS total_lifetime_loans,SUM(settled_orders) AS total_settled_orders,
 SUM(has_current_status8) AS current_status8_users,SUM(has_current_status5) AS current_status5_users,
 SUM(CASE WHEN lifetime_loans>=6 THEN 1 ELSE 0 END) AS loans_ge6_users,
 SUM(CASE WHEN lifetime_loans>=11 THEN 1 ELSE 0 END) AS loans_ge11_users,
 SUM(days_since_last_remit) AS total_days_since_last_remit,
 SUM(total_terms) AS total_terms,SUM(known_term_orders) AS known_term_orders,
 SUM(reloan_orders) AS reloan_orders
 FROM features
), ranked AS (
 SELECT f.*,ROW_NUMBER() OVER(ORDER BY profit DESC,user_id ASC) AS profit_rank,
 SUM(profit) OVER(ORDER BY profit DESC,user_id ASC ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW) AS cumulative_profit
 FROM features f WHERE profit>0
), cutoffs AS (
 SELECT MIN(CASE WHEN r.cumulative_profit>=t.total_profit*0.5 THEN r.profit_rank END) AS k50,
 MIN(CASE WHEN r.cumulative_profit>=t.total_profit*0.6 THEN r.profit_rank END) AS k60,
 MIN(CASE WHEN r.cumulative_profit>=t.total_profit*0.7 THEN r.profit_rank END) AS k70,
 MIN(CASE WHEN r.cumulative_profit>=t.total_profit*0.8 THEN r.profit_rank END) AS k80,
 MIN(CASE WHEN r.cumulative_profit>=t.total_profit*0.9 THEN r.profit_rank END) AS k90
 FROM ranked r CROSS JOIN totals t
)
SELECT r.*,c.k50,c.k60,c.k70,c.k80,c.k90
 FROM ranked r CROSS JOIN cutoffs c WHERE r.profit_rank<=c.k90 ORDER BY r.profit_rank