"""Finalize separately verified read-only table extractions; never claim one shared snapshot."""
import json,hashlib
from pathlib import Path
from extract import W,COHORT

def main():
    d=json.loads((W/'loan_snapshot.json').read_text())
    compact=W/'offers_compact_manifest.json'
    if compact.exists():
        tables={n:json.loads((W/(n+'_manifest.json')).read_text()) for n in ['periods','recycle']}
        import shutil
        shutil.copy2(W/'offers_compact.pkl.gz',W/'offers.pkl.gz')
        tables['offers']=json.loads(compact.read_text())
        (W/'offers_query.sql').write_text((W/'offers_compact_query.sql').read_text())
    else:
        supp=json.loads((W/'supplement_manifest.json').read_text());assert supp['complete'];tables=supp['tables']
    p=W/'loans.pkl.gz'
    import pandas as pd
    f=pd.read_pickle(p);assert f.user_id.nunique()==6144 and not f.serial_id.duplicated().any()
    tables['loans']={'rows':len(f),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'snapshot_business':d['business_cutoff'],'read_only':True}
    for name,info in tables.items():assert hashlib.sha256((W/(name+'.pkl.gz')).read_bytes()).hexdigest()==info['sha256']
    assert hashlib.sha256(COHORT.read_bytes()).hexdigest()==d['cohort_sha256']
    result={**d,'complete':True,'read_only':True,'single_repeatable_read_snapshot':False,'repeatable_read_per_shard':True,
            'business_timezone':'America/Belize','requested_users':6144,'tables':tables,
            'availability_limit':'Source tables extracted at adjacent read-only snapshots; loan snapshot fixes event cutoff. No immutable historical ingestion snapshot.'}
    (W/'extraction_manifest.json').write_text(json.dumps(result,indent=2));(W/'extraction_inprogress.json').unlink(missing_ok=True)
    p=W/'periods_aggregate_query.sql'
    if p.exists():(W/'periods_query.sql').write_text(p.read_text())
    print(json.dumps({'complete':True,'tables':{k:v['rows'] for k,v in tables.items()},'read_only':True}))

if __name__=='__main__':main()
