SELECT r.serial_id,r.recycle_type FROM wangchuanliang.side_recycle_type_copy r
 WHERE EXISTS (SELECT 1 FROM wangchuanliang.order_loan_f_v2_copy o WHERE o.serial_id=r.serial_id AND o.user_id IN (SELECT unnest(%(users)s::bigint[])))
 OR EXISTS (SELECT 1 FROM wangchuanliang.order_vir_f_copy v WHERE v.serial_id=r.serial_id AND v.user_id IN (SELECT unnest(%(users)s::bigint[])))