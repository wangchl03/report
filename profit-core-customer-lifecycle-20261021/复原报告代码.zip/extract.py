"""Read-only complete histories for the frozen profit-core cohort. No database writes."""
from pathlib import Path
import os, sys, json, time, base64, secrets, hashlib, warnings
warnings.filterwarnings('ignore', category=UserWarning)
import pandas as pd
import psycopg2
W=Path(__file__).resolve().parent
sys.path.insert(0,str(W.parent/'intent_v2_behavior_windows_20261019/vendor'))
from pgpy import PGPMessage

def connection_kwargs():
    keys={'host':'DB_HOST','port':'DB_PORT','dbname':'DB_NAME','user':'DB_USER','password':'DB_PASSWORD'}
    if all(os.environ.get(keys[k]) for k in ['host','dbname','user','password']):
        return {k:os.environ[v] for k,v in keys.items() if os.environ.get(v)}
    sys.path.insert(0,'/Users/wangchuanliang/Documents/Codex/2026-09-21/ji-x/work')
    from analyze_t0_down_d1_d5_maturity_profit import connection_kwargs as local_connection
    return local_connection()

COHORT=Path(os.environ.get('CORE_CUSTOMER_COHORT_JSON',str(W.parent/'profit_concentration_20250101_20260930_20261021/result.json')))
filt=' IN (SELECT unnest(%(users)s::bigint[]))'
queries={
 'loans':'''SELECT o.user_id,o.serial_id,o.apply_time,o.apply_date,o.apply_amt::text apply_amt,
 o.remit_time,o.remit_date,o.remit_amt::text remit_amt,o.repaid_time,o.repaid_date,o.due_date,
 o.is_remit,o.is_repaid,o.repaid_amt::text repaid_amt,o.loan_status_code,o.overdue_days,o.loan_type,
 o.total_term,o.product_no FROM wangchuanliang.order_loan_f_v2_copy o WHERE o.user_id'''+filt,
 'periods':'''SELECT p.user_id,p.serial_id,p.current_term,p.due_date_period,p.repaid_time_period,
 p.repaid_date_period,p.is_repaid_period,p.overdue_days_period,p.loan_status_code_period,
 p.expect_repay_amt_period::text expect_repay_amt_period,p.repaid_amt_period::text repaid_amt_period
 FROM wangchuanliang.repayment_plan_v2_copy p WHERE p.user_id'''+filt,
 'offers':'''SELECT v.user_id,v.serial_id,v.vir_unix,v.vir_date,v.vir_rnb,v.loan_type_code,
 v.is_pass1,v.is_pass,v.vir_status_code,v.max_credit_apply_amt::text credit_amt,
 v.max_risk_credit_amount::text risk_credit_amt,v.is_can_apply,v.is_eff
 FROM wangchuanliang.order_vir_f_copy v WHERE v.user_id'''+filt,
 'recycle':'''SELECT r.serial_id,r.recycle_type FROM wangchuanliang.side_recycle_type_copy r
 WHERE EXISTS (SELECT 1 FROM wangchuanliang.order_loan_f_v2_copy o WHERE o.serial_id=r.serial_id AND o.user_id'''+filt+''')
 OR EXISTS (SELECT 1 FROM wangchuanliang.order_vir_f_copy v WHERE v.serial_id=r.serial_id AND v.user_id'''+filt+''')'''
}

def main():
    started=time.monotonic();cohort=json.loads(COHORT.read_text());users=sorted(r['user_id'] for r in cohort['members'])
    cohort_hash=hashlib.sha256(COHORT.read_bytes()).hexdigest()
    manifest=W/'extraction_manifest.json'
    if manifest.exists():
        old=json.loads(manifest.read_text())
        if old.get('complete') and old['cohort_sha256']==cohort_hash and all(hashlib.sha256((W/(k+'.pkl.gz')).read_bytes()).hexdigest()==v['sha256'] for k,v in old['tables'].items()):
            print('Complete verified extraction reused.',flush=True);return
    (W/'extraction_inprogress.json').write_text(json.dumps({'complete':False,'requested_users':len(users),'tables':list(queries)}))
    tables={}
    with psycopg2.connect(**dict(connection_kwargs(),connect_timeout=20,keepalives=1,keepalives_idle=30,keepalives_interval=10,keepalives_count=3,application_name='core_customer_lifetime_portrait_readonly')) as conn:
        conn.set_session(readonly=True,isolation_level='REPEATABLE READ')
        with conn.cursor() as c:
            for setting in ["SET TIME ZONE 'America/Belize'",'SET query_dop=1','SET statement_timeout=300000']:c.execute(setting)
            c.execute("SELECT current_timestamp,current_timestamp AT TIME ZONE 'America/Belize',current_timestamp AT TIME ZONE 'Asia/Shanghai',current_setting('transaction_read_only')")
            snapshot,business_cutoff,shanghai_cutoff,ro=c.fetchone();assert ro=='on'
            (W/'loan_snapshot.json').write_text(json.dumps({'snapshot':snapshot.isoformat(),'business_cutoff':business_cutoff.isoformat(),'shanghai_cutoff':shanghai_cutoff.isoformat(),'cohort_sha256':cohort_hash},indent=2))
            print(json.dumps({'snapshot':str(snapshot),'readonly':ro,'users':len(users)}),flush=True)
            for name,q in queries.items():
                (W/(name+'_query.sql')).write_text(q)
                t=time.monotonic();frames=[];n=0
                for shard in range(8):
                    chunk=users[shard::8];key=secrets.token_urlsafe(32)
                    sql="SELECT COUNT(*),encode(pgp_sym_encrypt(string_agg(row_to_json(q)::text,E'\\n'),%(key)s,'compress-algo=1,compress-level=6,cipher-algo=aes256'),'base64') FROM ("+q+") q"
                    c.execute(sql,{'users':'{'+','.join(map(str,chunk))+'}','key':key});count,blob=c.fetchone()
                    print(json.dumps({'table':name,'shard':shard,'rows':count,'transfer_bytes':len(blob or '')}),flush=True)
                    if count:
                        msg=PGPMessage.from_blob(base64.b64decode(blob)).decrypt(key).message
                        if isinstance(msg,(bytes,bytearray)):msg=bytes(msg).decode()
                        frame=pd.DataFrame([json.loads(line) for line in str(msg).splitlines()])
                    else:frame=pd.DataFrame()
                    assert len(frame)==count
                    frames.append(frame);n+=count
                df=pd.concat(frames,ignore_index=True)
                assert len(df)==n
                if 'user_id' in df:assert set(df.user_id).issubset(set(users))
                target=W/(name+'.pkl.gz');df.to_pickle(str(target)+'.partial',compression='gzip');Path(str(target)+'.partial').replace(target)
                tables[name]={'rows':n,'sha256':hashlib.sha256(target.read_bytes()).hexdigest(),'seconds':round(time.monotonic()-t,1)}
                print(json.dumps({'table':name,**tables[name]}),flush=True)
        conn.rollback()
    result={'complete':True,'read_only':True,'single_repeatable_read_snapshot':True,'snapshot':snapshot.isoformat(),
            'business_cutoff':business_cutoff.isoformat(),'shanghai_cutoff':shanghai_cutoff.isoformat(),'business_timezone':'America/Belize',
            'cohort_sha256':cohort_hash,'requested_users':len(users),'tables':tables,'seconds':round(time.monotonic()-started,1)}
    manifest.write_text(json.dumps(result,ensure_ascii=False,indent=2));(W/'extraction_inprogress.json').unlink(missing_ok=True)
    print(json.dumps({'complete':True,'seconds':result['seconds']}),flush=True)

if __name__=='__main__':main()
