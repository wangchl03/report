"""Transfer only latest user offers and the exact pre-application offers used for utilization."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from datetime import datetime,timezone,timedelta
import json,base64,secrets,hashlib,time
import pandas as pd
import psycopg2
from extract import W,COHORT,connection_kwargs,PGPMessage

QUERY='''WITH offer_source AS (
 SELECT v.user_id,v.serial_id,v.vir_unix,v.vir_date,v.vir_rnb,v.loan_type_code,
 v.is_pass1,v.is_pass,v.vir_status_code,v.max_credit_apply_amt::text credit_amt,
 v.max_risk_credit_amount::text risk_credit_amt,v.is_can_apply,v.is_eff,
 ROW_NUMBER() OVER(PARTITION BY v.user_id ORDER BY v.vir_unix DESC,v.serial_id DESC,v.vir_rnb DESC) AS user_rn
 FROM wangchuanliang.order_vir_f_copy v
 WHERE v.user_id IN (SELECT unnest(%(users)s::bigint[])) AND v.vir_unix>946706400 AND v.vir_unix<=%(epoch)s
), matched AS (
 SELECT v.*,ROW_NUMBER() OVER(PARTITION BY v.user_id,v.serial_id ORDER BY v.vir_unix DESC,v.vir_rnb DESC) AS order_rn
 FROM offer_source v JOIN wangchuanliang.order_loan_f_v2_copy o ON o.user_id=v.user_id AND o.serial_id=v.serial_id
 WHERE o.apply_amt>0 AND o.apply_date>=DATE '2025-01-01' AND o.apply_date<DATE '2026-10-01'
 AND TIMESTAMP 'epoch'+v.vir_unix*INTERVAL '1 second'-INTERVAL '6 hours'<=
 CASE WHEN o.apply_time>=TIMESTAMP '2000-01-01' THEN o.apply_time ELSE o.apply_date::timestamp END
)
SELECT user_id,serial_id,vir_unix,vir_date,vir_rnb,loan_type_code,is_pass1,is_pass,vir_status_code,credit_amt,risk_credit_amt,is_can_apply,is_eff
 FROM offer_source WHERE user_rn=1
UNION
SELECT user_id,serial_id,vir_unix,vir_date,vir_rnb,loan_type_code,is_pass1,is_pass,vir_status_code,credit_amt,risk_credit_amt,is_can_apply,is_eff
 FROM matched WHERE order_rn=1'''

def run(i,users,epoch):
    started=time.monotonic();key=secrets.token_urlsafe(32)
    with psycopg2.connect(**dict(connection_kwargs(),connect_timeout=20,keepalives=1,keepalives_idle=30,application_name='core_portrait_compact_offers')) as conn:
        conn.set_session(readonly=True,isolation_level='REPEATABLE READ')
        with conn.cursor() as c:
            for s in ["SET TIME ZONE 'America/Belize'",'SET query_dop=1','SET statement_timeout=180000']:c.execute(s)
            c.execute("SELECT current_timestamp AT TIME ZONE 'America/Belize'");snap=c.fetchone()[0]
            sql="SELECT COUNT(*),encode(pgp_sym_encrypt(string_agg(row_to_json(q)::text,E'\\n'),%(key)s,'compress-algo=1,compress-level=6,cipher-algo=aes256'),'base64') FROM ("+QUERY+") q"
            c.execute(sql,{'users':'{'+','.join(map(str,users[i::8]))+'}','epoch':epoch,'key':key});n,blob=c.fetchone()
            msg=PGPMessage.from_blob(base64.b64decode(blob)).decrypt(key).message
            if isinstance(msg,(bytes,bytearray)):msg=bytes(msg).decode()
            df=pd.DataFrame([json.loads(line) for line in str(msg).splitlines()]);assert len(df)==n
        conn.rollback()
    info={'shard':i,'rows':n,'snapshot_business':snap.isoformat(),'seconds':round(time.monotonic()-started,1)}
    print(json.dumps(info),flush=True);return df,info

def main():
    users=sorted(r['user_id'] for r in json.loads(COHORT.read_text())['members'])
    epoch=datetime.fromisoformat(json.loads((W/'loan_snapshot.json').read_text())['business_cutoff']).replace(tzinfo=timezone(timedelta(hours=-6))).timestamp()
    (W/'offers_compact_query.sql').write_text(QUERY)
    with ThreadPoolExecutor(max_workers=4) as pool:results=list(pool.map(lambda i:run(i,users,epoch),range(8)))
    df=pd.concat([r[0] for r in results],ignore_index=True);assert not df.duplicated(['user_id','serial_id','vir_unix','vir_rnb']).any()
    p=W/'offers_compact.pkl.gz';df.to_pickle(p)
    info={'rows':len(df),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'snapshot_business':min(r[1]['snapshot_business'] for r in results),
          'shards':[r[1] for r in results],'read_only':True,'same_event_cutoff':True,'compact_equivalent_latest_and_utilization_offers':True}
    (W/'offers_compact_manifest.json').write_text(json.dumps(info,indent=2));print(json.dumps({'complete':True,'rows':len(df)}),flush=True)

if __name__=='__main__':main()
